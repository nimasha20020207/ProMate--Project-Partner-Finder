import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Projects/InsertProject.jsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=383bea9f"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"];
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=383bea9f";
import { useAuth } from "/src/context/AuthContext.jsx";
import "/src/pages/Projects/InsertProject.css";
const CheckboxGroup = ({
  options,
  selectedValues,
  onChange
}) => /* @__PURE__ */ jsxDEV("div", { className: "checkbox-group-ip", children: options.map((option) => /* @__PURE__ */ jsxDEV("label", { className: "checkbox-label-ip", children: [
  /* @__PURE__ */ jsxDEV("input", { type: "checkbox", value: option, checked: selectedValues.includes(option), onChange: (e) => {
    const isChecked = e.target.checked;
    const newValues = isChecked ? [...selectedValues, option] : selectedValues.filter((v) => v !== option);
    onChange(newValues);
  } }, void 0, false, {
    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
    lineNumber: 12,
    columnNumber: 9
  }, this),
  option
] }, option, true, {
  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
  lineNumber: 11,
  columnNumber: 28
}, this)) }, void 0, false, {
  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
  lineNumber: 10,
  columnNumber: 7
}, this);
_c = CheckboxGroup;
const InsertProject = ({
  onSuccess
}) => {
  _s();
  const {
    token
  } = useAuth();
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    teamSize: "",
    projectType: "",
    minimumCGPA: "",
    essentialSkills: {
      languages: [],
      frameworks: [],
      libraries: [],
      databases: [],
      tools: []
    },
    optionalSkills: {
      languages: [],
      frameworks: [],
      libraries: [],
      databases: [],
      tools: []
    },
    requiredRoles: [],
    availabilityRequirement: {
      weeklyHours: "",
      meetingDays: [],
      durationWeeks: ""
    },
    domain: [],
    dueDate: ""
  });
  const [errors, setErrors] = useState({});
  const [touched, setTouched] = useState({});
  const validateField = (name, value) => {
    let errorMsg = "";
    const strVal = value !== null && value !== void 0 ? String(value).trim() : "";
    switch (name) {
      case "itNumber":
        if (!strVal)
          errorMsg = "IT Number is required.";
        else if (!/^IT\d{8}$/i.test(strVal))
          errorMsg = 'IT Number must be exactly 10 characters starting with "IT".';
        break;
      case "title":
        if (!strVal) {
          errorMsg = "Project title cannot be empty.";
        } else if (/^\d+$/.test(strVal)) {
          errorMsg = "Project title cannot be only numbers.";
        } else if (/^\d/.test(strVal)) {
          errorMsg = "Project title cannot start with a number.";
        }
        break;
      case "description":
        if (!strVal) {
          errorMsg = "Description cannot be empty.";
        } else if (/^\d+$/.test(strVal)) {
          errorMsg = "Description cannot be only numbers.";
        }
        break;
      case "teamSize":
        if (!strVal || parseInt(strVal) < 1)
          errorMsg = "Team size must be at least 1.";
        break;
      case "projectType":
        if (!strVal)
          errorMsg = "Project type is required.";
        break;
      case "dueDate":
        if (!strVal) {
          errorMsg = "Due date is required.";
        } else {
          const selectedDate = new Date(strVal);
          const today = /* @__PURE__ */ new Date();
          today.setHours(0, 0, 0, 0);
          if (selectedDate <= today) {
            errorMsg = "Due date must be a future date.";
          }
        }
        break;
      case "specialization":
        if (!strVal)
          errorMsg = "Specialization is required.";
        break;
      case "year":
        if (!strVal || parseInt(strVal) < 1 || parseInt(strVal) > 4)
          errorMsg = "Year must be between 1 and 4.";
        break;
      case "semester":
        if (!strVal || parseInt(strVal) < 1 || parseInt(strVal) > 2)
          errorMsg = "Semester must be 1 or 2.";
        break;
      case "minimumCGPA":
        if (strVal !== "" && (parseFloat(strVal) < 0 || parseFloat(strVal) > 4))
          errorMsg = "CGPA must be between 0.0 and 4.0.";
        break;
      case "weeklyHours":
        if (!strVal || parseInt(strVal) < 1)
          errorMsg = "Weekly hours must be at least 1.";
        break;
      case "durationWeeks":
        if (!strVal || parseInt(strVal) < 1)
          errorMsg = "Duration must be at least 1 week.";
        break;
      default:
        break;
    }
    return errorMsg;
  };
  const handleBlur = (e) => {
    const {
      name,
      value
    } = e.target;
    setTouched((prev) => ({
      ...prev,
      [name]: true
    }));
    const errorMsg = validateField(name, value);
    setErrors((prev) => ({
      ...prev,
      [name]: errorMsg
    }));
  };
  const handleChange = (e) => {
    const {
      name,
      value
    } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));
    if (touched[name]) {
      setErrors((prev) => ({
        ...prev,
        [name]: validateField(name, value)
      }));
    }
  };
  const handleNestedChange = (section, field, value) => {
    setFormData((prev) => ({
      ...prev,
      [section]: {
        ...prev[section],
        [field]: value
      }
    }));
    if (touched[field]) {
      setErrors((prev) => ({
        ...prev,
        [field]: validateField(field, value)
      }));
    }
  };
  const handleNestedBlur = (section, field) => {
    setTouched((prev) => ({
      ...prev,
      [field]: true
    }));
    const errorMsg = validateField(field, formData[section][field]);
    setErrors((prev) => ({
      ...prev,
      [field]: errorMsg
    }));
  };
  const handleSkillChange = (type, category, newValues) => {
    setFormData((prev) => {
      const updatedData = {
        ...prev,
        [type]: {
          ...prev[type],
          [category]: newValues
        }
      };
      if (type === "essentialSkills" && touched.essentialSkills) {
        const hasEssentialSkills = Object.values(updatedData.essentialSkills).some((arr) => arr && arr.length > 0);
        setErrors((e) => ({
          ...e,
          essentialSkills: hasEssentialSkills ? "" : "Essential Skills can't be empty."
        }));
      }
      return updatedData;
    });
  };
  const validateAll = () => {
    const newErrors = {};
    const textFields = ["title", "description", "teamSize", "projectType", "minimumCGPA", "dueDate"];
    textFields.forEach((field) => {
      const err = validateField(field, formData[field]);
      if (err)
        newErrors[field] = err;
    });
    const nestedFields = ["weeklyHours", "durationWeeks"];
    nestedFields.forEach((field) => {
      const err = validateField(field, formData.availabilityRequirement[field]);
      if (err)
        newErrors[field] = err;
    });
    const hasEssentialSkills = Object.values(formData.essentialSkills).some((arr) => arr && arr.length > 0);
    if (!hasEssentialSkills) {
      newErrors.essentialSkills = "Essential Skills can't be empty.";
    }
    setErrors(newErrors);
    const allTouched = {};
    [...textFields, ...nestedFields, "essentialSkills"].forEach((f) => allTouched[f] = true);
    setTouched(allTouched);
    if (formData.domain.length === 0) {
      alert("Please select at least one domain.");
      return false;
    }
    if (formData.requiredRoles.length === 0) {
      alert("Please select at least one required role.");
      return false;
    }
    if (formData.availabilityRequirement.meetingDays.length === 0) {
      alert("Please select at least one meeting day.");
      return false;
    }
    return Object.keys(newErrors).length === 0;
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateAll()) {
      return;
    }
    try {
      const response = await fetch("http://localhost:3000/api/posts", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-auth-token": token
        },
        body: JSON.stringify(formData)
      });
      if (response.ok) {
        if (onSuccess) {
          onSuccess();
        } else {
          alert("Project created successfully!");
          navigate("/your-projects");
        }
      } else {
        const errorData = await response.json();
        alert(`Failed to create project: ${errorData.msg || "Unknown error"}`);
      }
    } catch (error) {
      console.error("Error creating project:", error);
      alert("An error occurred while creating the project. Please check the console.");
    }
  };
  const todayStr = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
  return /* @__PURE__ */ jsxDEV("div", { className: "insert-project-container-ip", children: /* @__PURE__ */ jsxDEV("div", { className: "insert-project-card-ip", children: [
    /* @__PURE__ */ jsxDEV("h1", { className: "insert-project-title-ip", children: "Create New Project" }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
      lineNumber: 267,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "insert-project-subtitle-ip", children: "Post a new project outline to find the perfect team members." }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
      lineNumber: 268,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, className: "insert-project-form-ip", noValidate: true, children: [
      /* @__PURE__ */ jsxDEV("div", { className: "form-section-ip", children: [
        /* @__PURE__ */ jsxDEV("h2", { children: "Basic Information" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
          lineNumber: 273,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "form-group-ip", children: [
          /* @__PURE__ */ jsxDEV("label", { children: "Project Title *" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
            lineNumber: 276,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("input", { type: "text", name: "title", value: formData.title, onChange: handleChange, onBlur: handleBlur, className: touched.title && errors.title ? "input-error-ip" : "", placeholder: "Enter project title" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
            lineNumber: 277,
            columnNumber: 15
          }, this),
          touched.title && errors.title && /* @__PURE__ */ jsxDEV("span", { className: "error-message-ip", children: errors.title }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
            lineNumber: 278,
            columnNumber: 49
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
          lineNumber: 275,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "form-group-ip", children: [
          /* @__PURE__ */ jsxDEV("label", { children: "Description *" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
            lineNumber: 282,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("textarea", { name: "description", value: formData.description, onChange: handleChange, onBlur: handleBlur, className: touched.description && errors.description ? "input-error-ip" : "", placeholder: "What is this project about? Provide some context and goals." }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
            lineNumber: 283,
            columnNumber: 15
          }, this),
          touched.description && errors.description && /* @__PURE__ */ jsxDEV("span", { className: "error-message-ip", children: errors.description }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
            lineNumber: 284,
            columnNumber: 61
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
          lineNumber: 281,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "form-row-ip", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "form-group-ip", children: [
            /* @__PURE__ */ jsxDEV("label", { children: "Team Size *" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
              lineNumber: 289,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("input", { type: "number", name: "teamSize", value: formData.teamSize, onChange: handleChange, onBlur: handleBlur, className: touched.teamSize && errors.teamSize ? "input-error-ip" : "", min: "1", placeholder: "e.g. 4" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
              lineNumber: 290,
              columnNumber: 17
            }, this),
            touched.teamSize && errors.teamSize && /* @__PURE__ */ jsxDEV("span", { className: "error-message-ip", children: errors.teamSize }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
              lineNumber: 291,
              columnNumber: 57
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
            lineNumber: 288,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "form-group-ip", children: [
            /* @__PURE__ */ jsxDEV("label", { children: "Project Type *" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
              lineNumber: 294,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("select", { name: "projectType", value: formData.projectType, onChange: handleChange, onBlur: handleBlur, className: touched.projectType && errors.projectType ? "input-error-ip" : "", children: [
              /* @__PURE__ */ jsxDEV("option", { value: "", children: "Select Type" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
                lineNumber: 296,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("option", { value: "Research", children: "Research" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
                lineNumber: 297,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("option", { value: "Development", children: "Development" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
                lineNumber: 298,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("option", { value: "Final Year Project", children: "Final Year Project" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
                lineNumber: 299,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("option", { value: "Hackathon", children: "Hackathon" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
                lineNumber: 300,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("option", { value: "Open Source", children: "Open Source" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
                lineNumber: 301,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
              lineNumber: 295,
              columnNumber: 17
            }, this),
            touched.projectType && errors.projectType && /* @__PURE__ */ jsxDEV("span", { className: "error-message-ip", children: errors.projectType }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
              lineNumber: 303,
              columnNumber: 63
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
            lineNumber: 293,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
          lineNumber: 287,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "form-group-ip", children: [
          /* @__PURE__ */ jsxDEV("label", { children: "Due Date *" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
            lineNumber: 308,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("input", { type: "date", name: "dueDate", value: formData.dueDate, onChange: handleChange, onBlur: handleBlur, min: todayStr, className: touched.dueDate && errors.dueDate ? "input-error-ip" : "" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
            lineNumber: 309,
            columnNumber: 15
          }, this),
          touched.dueDate && errors.dueDate && /* @__PURE__ */ jsxDEV("span", { className: "error-message-ip", children: errors.dueDate }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
            lineNumber: 310,
            columnNumber: 53
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
          lineNumber: 307,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "form-group-ip", children: [
          /* @__PURE__ */ jsxDEV("label", { children: "Domain *" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
            lineNumber: 314,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(CheckboxGroup, { options: ["Web Development", "Mobile Development", "AI / ML", "Data Science", "Cybersecurity", "Cloud Computing", "Game Development", "IoT", "Blockchain", "DevOps"], selectedValues: formData.domain, onChange: (values) => setFormData((prev) => ({
            ...prev,
            domain: values
          })) }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
            lineNumber: 315,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
          lineNumber: 313,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
        lineNumber: 272,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "form-section-ip", children: [
        /* @__PURE__ */ jsxDEV("h2", { children: "Academic Details (Auto-filled from Profile)" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
          lineNumber: 324,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { style: {
          fontSize: "13px",
          color: "#64748b",
          marginBottom: "16px"
        }, children: "Your IT Number, Specialization, Year, and Semester are automatically linked to this project." }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
          lineNumber: 325,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "form-row-ip", children: /* @__PURE__ */ jsxDEV("div", { className: "form-group-ip", children: [
          /* @__PURE__ */ jsxDEV("label", { children: "Minimum CGPA Requirement (Optional)" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
            lineNumber: 332,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("input", { type: "number", step: "0.01", name: "minimumCGPA", value: formData.minimumCGPA, onChange: handleChange, onBlur: handleBlur, className: touched.minimumCGPA && errors.minimumCGPA ? "input-error-ip" : "", placeholder: "e.g. 3.0" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
            lineNumber: 333,
            columnNumber: 17
          }, this),
          touched.minimumCGPA && errors.minimumCGPA && /* @__PURE__ */ jsxDEV("span", { className: "error-message-ip", children: errors.minimumCGPA }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
            lineNumber: 334,
            columnNumber: 63
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
          lineNumber: 331,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
          lineNumber: 330,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
        lineNumber: 323,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "form-section-ip", children: [
        /* @__PURE__ */ jsxDEV("h2", { children: "Essential Skills (Must Have)" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
          lineNumber: 341,
          columnNumber: 13
        }, this),
        touched.essentialSkills && errors.essentialSkills && /* @__PURE__ */ jsxDEV("span", { className: "error-message-ip", style: {
          display: "block",
          marginBottom: "15px"
        }, children: errors.essentialSkills }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
          lineNumber: 342,
          columnNumber: 67
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "form-group-ip", children: [
          /* @__PURE__ */ jsxDEV("label", { children: "Languages *" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
            lineNumber: 349,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(CheckboxGroup, { options: ["JavaScript", "TypeScript", "Python", "Java", "C", "C++", "C#", "Go", "Rust", "Kotlin", "Swift", "PHP", "Ruby", "Dart", "R", "MATLAB"], selectedValues: formData.essentialSkills.languages, onChange: (values) => handleSkillChange("essentialSkills", "languages", values) }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
            lineNumber: 350,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
          lineNumber: 348,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "form-group-ip", children: [
          /* @__PURE__ */ jsxDEV("label", { children: "Frameworks *" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
            lineNumber: 353,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(CheckboxGroup, { options: ["React", "Angular", "Vue.js", "Next.js", "Nuxt.js", "Node.js", "Express.js", "Django", "Flask", "Spring Boot", "ASP.NET", "Laravel", "Ruby on Rails", "Flutter", "React Native"], selectedValues: formData.essentialSkills.frameworks, onChange: (values) => handleSkillChange("essentialSkills", "frameworks", values) }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
            lineNumber: 354,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
          lineNumber: 352,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "form-group-ip", children: [
          /* @__PURE__ */ jsxDEV("label", { children: "Databases *" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
            lineNumber: 357,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(CheckboxGroup, { options: ["MongoDB", "MySQL", "PostgreSQL", "SQLite", "Oracle", "Microsoft SQL Server", "Firebase", "Redis", "Cassandra", "DynamoDB", "Neo4j"], selectedValues: formData.essentialSkills.databases, onChange: (values) => handleSkillChange("essentialSkills", "databases", values) }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
            lineNumber: 358,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
          lineNumber: 356,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "form-group-ip", children: [
          /* @__PURE__ */ jsxDEV("label", { children: "Libraries *" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
            lineNumber: 362,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(CheckboxGroup, { options: ["Redux", "Axios", "jQuery", "Lodash", "TensorFlow", "Keras", "PyTorch", "Scikit-learn", "Pandas", "NumPy", "Chart.js", "D3.js", "Three.js", "Socket.io", "Bootstrap"], selectedValues: formData.essentialSkills.libraries, onChange: (values) => handleSkillChange("essentialSkills", "libraries", values) }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
            lineNumber: 363,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
          lineNumber: 361,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "form-group-ip", children: [
          /* @__PURE__ */ jsxDEV("label", { children: "Tools *" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
            lineNumber: 367,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(CheckboxGroup, { options: ["Git", "GitHub", "GitLab", "Docker", "Kubernetes", "Postman", "Jira", "Trello", "Figma", "Adobe XD", "VS Code", "IntelliJ IDEA", "Eclipse", "Webpack", "Babel"], selectedValues: formData.essentialSkills.tools, onChange: (values) => handleSkillChange("essentialSkills", "tools", values) }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
            lineNumber: 368,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
          lineNumber: 366,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
        lineNumber: 340,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "form-section-ip", children: [
        /* @__PURE__ */ jsxDEV("h2", { children: "Optional Skills (Nice to Have)" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
          lineNumber: 374,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "form-group-ip", children: [
          /* @__PURE__ */ jsxDEV("label", { children: "Languages" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
            lineNumber: 376,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(CheckboxGroup, { options: ["JavaScript", "TypeScript", "Python", "Java", "C", "C++", "C#", "Go", "Rust", "Kotlin", "Swift", "PHP", "Ruby", "Dart", "R", "MATLAB"], selectedValues: formData.optionalSkills.languages, onChange: (values) => handleSkillChange("optionalSkills", "languages", values) }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
            lineNumber: 377,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
          lineNumber: 375,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "form-group-ip", children: [
          /* @__PURE__ */ jsxDEV("label", { children: "Frameworks" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
            lineNumber: 380,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(CheckboxGroup, { options: ["React", "Angular", "Vue.js", "Next.js", "Nuxt.js", "Node.js", "Express.js", "Django", "Flask", "Spring Boot", "ASP.NET", "Laravel", "Ruby on Rails", "Flutter", "React Native"], selectedValues: formData.optionalSkills.frameworks, onChange: (values) => handleSkillChange("optionalSkills", "frameworks", values) }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
            lineNumber: 381,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
          lineNumber: 379,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "form-group-ip", children: [
          /* @__PURE__ */ jsxDEV("label", { children: "Databases" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
            lineNumber: 384,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(CheckboxGroup, { options: ["MongoDB", "MySQL", "PostgreSQL", "SQLite", "Oracle", "Microsoft SQL Server", "Firebase", "Redis", "Cassandra", "DynamoDB", "Neo4j"], selectedValues: formData.optionalSkills.databases, onChange: (values) => handleSkillChange("optionalSkills", "databases", values) }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
            lineNumber: 385,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
          lineNumber: 383,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "form-group-ip", children: [
          /* @__PURE__ */ jsxDEV("label", { children: "Libraries " }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
            lineNumber: 389,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(CheckboxGroup, { options: ["Redux", "Axios", "jQuery", "Lodash", "TensorFlow", "Keras", "PyTorch", "Scikit-learn", "Pandas", "NumPy", "Chart.js", "D3.js", "Three.js", "Socket.io", "Bootstrap"], selectedValues: formData.optionalSkills.libraries, onChange: (values) => handleSkillChange("optionalSkills", "libraries", values) }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
            lineNumber: 390,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
          lineNumber: 388,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "form-group-ip", children: [
          /* @__PURE__ */ jsxDEV("label", { children: "Tools " }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
            lineNumber: 394,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(CheckboxGroup, { options: ["Git", "GitHub", "GitLab", "Docker", "Kubernetes", "Postman", "Jira", "Trello", "Figma", "Adobe XD", "VS Code", "IntelliJ IDEA", "Eclipse", "Webpack", "Babel"], selectedValues: formData.optionalSkills.tools, onChange: (values) => handleSkillChange("optionalSkills", "tools", values) }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
            lineNumber: 395,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
          lineNumber: 393,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
        lineNumber: 373,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "form-section-ip", children: [
        /* @__PURE__ */ jsxDEV("h2", { children: "Roles & Availability" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
          lineNumber: 401,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "form-group-ip", children: [
          /* @__PURE__ */ jsxDEV("label", { children: "Required Roles *" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
            lineNumber: 403,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(CheckboxGroup, { options: ["Frontend Developer", "Backend Developer", "Fullstack Developer", "Mobile App Developer", "ML Engineer", "Data Scientist", "UI/UX Designer", "DevOps Engineer", "QA Engineer", "Project Manager"], selectedValues: formData.requiredRoles, onChange: (values) => setFormData((prev) => ({
            ...prev,
            requiredRoles: values
          })) }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
            lineNumber: 404,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
          lineNumber: 402,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "form-row-ip", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "form-group-ip", children: [
            /* @__PURE__ */ jsxDEV("label", { children: "Weekly Hours Required *" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
              lineNumber: 412,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("input", { type: "number", name: "weeklyHours", value: formData.availabilityRequirement.weeklyHours, onChange: (e) => handleNestedChange("availabilityRequirement", "weeklyHours", e.target.value), onBlur: () => handleNestedBlur("availabilityRequirement", "weeklyHours"), className: touched.weeklyHours && errors.weeklyHours ? "input-error-ip" : "", min: "1", placeholder: "e.g. 10" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
              lineNumber: 413,
              columnNumber: 17
            }, this),
            touched.weeklyHours && errors.weeklyHours && /* @__PURE__ */ jsxDEV("span", { className: "error-message-ip", children: errors.weeklyHours }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
              lineNumber: 414,
              columnNumber: 63
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
            lineNumber: 411,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "form-group-ip", children: [
            /* @__PURE__ */ jsxDEV("label", { children: "Duration (Weeks) *" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
              lineNumber: 417,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("input", { type: "number", name: "durationWeeks", value: formData.availabilityRequirement.durationWeeks, onChange: (e) => handleNestedChange("availabilityRequirement", "durationWeeks", e.target.value), onBlur: () => handleNestedBlur("availabilityRequirement", "durationWeeks"), className: touched.durationWeeks && errors.durationWeeks ? "input-error-ip" : "", min: "1", placeholder: "e.g. 12" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
              lineNumber: 418,
              columnNumber: 17
            }, this),
            touched.durationWeeks && errors.durationWeeks && /* @__PURE__ */ jsxDEV("span", { className: "error-message-ip", children: errors.durationWeeks }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
              lineNumber: 419,
              columnNumber: 67
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
            lineNumber: 416,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
          lineNumber: 410,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "form-group-ip", children: [
          /* @__PURE__ */ jsxDEV("label", { children: "Preferred Meeting Days *" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
            lineNumber: 424,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(CheckboxGroup, { options: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"], selectedValues: formData.availabilityRequirement.meetingDays, onChange: (values) => handleNestedChange("availabilityRequirement", "meetingDays", values) }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
            lineNumber: 425,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
          lineNumber: 423,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
        lineNumber: 400,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "form-actions-ip", children: /* @__PURE__ */ jsxDEV("button", { type: "submit", className: "submit-btn-ip", children: "Create Project" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
        lineNumber: 430,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
        lineNumber: 429,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
      lineNumber: 270,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
    lineNumber: 266,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx",
    lineNumber: 265,
    columnNumber: 10
  }, this);
};
_s(InsertProject, "dJj4jnWXapqObu+vyIPTa+1GewM=", false, function() {
  return [useAuth, useNavigate];
});
_c2 = InsertProject;
export default InsertProject;
var _c, _c2;
$RefreshReg$(_c, "CheckboxGroup");
$RefreshReg$(_c2, "InsertProject");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/InsertProject.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBU1E7Ozs7Ozs7Ozs7Ozs7Ozs7QUFUUixPQUFPQSxTQUFTQyxnQkFBZ0I7QUFDaEMsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLGVBQWU7QUFDeEIsT0FBTztBQUVQLE1BQU1DLGdCQUFnQkEsQ0FBQztBQUFBLEVBQUVDO0FBQUFBLEVBQVNDO0FBQUFBLEVBQWdCQztBQUFTLE1BQ3pELHVCQUFDLFNBQUksV0FBVSxxQkFDWkYsa0JBQVFHLElBQUtDLFlBQ1osdUJBQUMsV0FBbUIsV0FBVSxxQkFDNUI7QUFBQSx5QkFBQyxXQUNDLE1BQUssWUFDTCxPQUFPQSxRQUNQLFNBQVNILGVBQWVJLFNBQVNELE1BQU0sR0FDdkMsVUFBV0UsT0FBTTtBQUNmLFVBQU1DLFlBQVlELEVBQUVFLE9BQU9DO0FBQzNCLFVBQU1DLFlBQVlILFlBQ2QsQ0FBQyxHQUFHTixnQkFBZ0JHLE1BQU0sSUFDMUJILGVBQWVVLE9BQVFDLE9BQU1BLE1BQU1SLE1BQU07QUFDN0NGLGFBQVNRLFNBQVM7QUFBQSxFQUNwQixLQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FVSTtBQUFBLEVBRUhOO0FBQUFBLEtBYlNBLFFBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQWNBLENBQ0QsS0FqQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQWtCQTtBQUNBUyxLQXBCSWQ7QUFzQk4sTUFBTWUsZ0JBQWdCQSxDQUFDO0FBQUEsRUFBRUM7QUFBVSxNQUFNO0FBQUFDLEtBQUE7QUFDdkMsUUFBTTtBQUFBLElBQUVDO0FBQUFBLEVBQU0sSUFBSW5CLFFBQVE7QUFDMUIsUUFBTW9CLFdBQVdyQixZQUFZO0FBQzdCLFFBQU0sQ0FBQ3NCLFVBQVVDLFdBQVcsSUFBSXhCLFNBQVM7QUFBQSxJQUN2Q3lCLE9BQU87QUFBQSxJQUNQQyxhQUFhO0FBQUEsSUFDYkMsVUFBVTtBQUFBLElBQ1ZDLGFBQWE7QUFBQSxJQUNiQyxhQUFhO0FBQUEsSUFDYkMsaUJBQWlCO0FBQUEsTUFBRUMsV0FBVztBQUFBLE1BQUlDLFlBQVk7QUFBQSxNQUFJQyxXQUFXO0FBQUEsTUFBSUMsV0FBVztBQUFBLE1BQUlDLE9BQU87QUFBQSxJQUFHO0FBQUEsSUFDMUZDLGdCQUFnQjtBQUFBLE1BQUVMLFdBQVc7QUFBQSxNQUFJQyxZQUFZO0FBQUEsTUFBSUMsV0FBVztBQUFBLE1BQUlDLFdBQVc7QUFBQSxNQUFJQyxPQUFPO0FBQUEsSUFBRztBQUFBLElBQ3pGRSxlQUFlO0FBQUEsSUFDZkMseUJBQXlCO0FBQUEsTUFBRUMsYUFBYTtBQUFBLE1BQUlDLGFBQWE7QUFBQSxNQUFJQyxlQUFlO0FBQUEsSUFBRztBQUFBLElBQy9FQyxRQUFRO0FBQUEsSUFDUkMsU0FBUztBQUFBLEVBQ1gsQ0FBQztBQUVELFFBQU0sQ0FBQ0MsUUFBUUMsU0FBUyxJQUFJN0MsU0FBUyxDQUFDLENBQUM7QUFDdkMsUUFBTSxDQUFDOEMsU0FBU0MsVUFBVSxJQUFJL0MsU0FBUyxDQUFDLENBQUM7QUFFekMsUUFBTWdELGdCQUFnQkEsQ0FBQ0MsTUFBTUMsVUFBVTtBQUNyQyxRQUFJQyxXQUFXO0FBQ2YsVUFBTUMsU0FBU0YsVUFBVSxRQUFRQSxVQUFVRyxTQUFZQyxPQUFPSixLQUFLLEVBQUVLLEtBQUssSUFBSTtBQUU5RSxZQUFRTixNQUFJO0FBQUEsTUFDVixLQUFLO0FBQ0gsWUFBSSxDQUFDRztBQUFRRCxxQkFBVztBQUFBLGlCQUNmLENBQUMsYUFBYUssS0FBS0osTUFBTTtBQUFHRCxxQkFBVztBQUNoRDtBQUFBLE1BQ0YsS0FBSztBQUNILFlBQUksQ0FBQ0MsUUFBUTtBQUNYRCxxQkFBVztBQUFBLFFBQ2IsV0FBVyxRQUFRSyxLQUFLSixNQUFNLEdBQUc7QUFDL0JELHFCQUFXO0FBQUEsUUFDYixXQUFXLE1BQU1LLEtBQUtKLE1BQU0sR0FBRztBQUM3QkQscUJBQVc7QUFBQSxRQUNiO0FBQ0E7QUFBQSxNQUNGLEtBQUs7QUFDSCxZQUFJLENBQUNDLFFBQVE7QUFDWEQscUJBQVc7QUFBQSxRQUNiLFdBQVcsUUFBUUssS0FBS0osTUFBTSxHQUFHO0FBQy9CRCxxQkFBVztBQUFBLFFBQ2I7QUFDQTtBQUFBLE1BQ0YsS0FBSztBQUNILFlBQUksQ0FBQ0MsVUFBVUssU0FBU0wsTUFBTSxJQUFJO0FBQUdELHFCQUFXO0FBQ2hEO0FBQUEsTUFDRixLQUFLO0FBQ0gsWUFBSSxDQUFDQztBQUFRRCxxQkFBVztBQUN4QjtBQUFBLE1BQ0YsS0FBSztBQUNILFlBQUksQ0FBQ0MsUUFBUTtBQUNYRCxxQkFBVztBQUFBLFFBQ2IsT0FBTztBQUNMLGdCQUFNTyxlQUFlLElBQUlDLEtBQUtQLE1BQU07QUFDcEMsZ0JBQU1RLFFBQVEsb0JBQUlELEtBQUs7QUFDdkJDLGdCQUFNQyxTQUFTLEdBQUcsR0FBRyxHQUFHLENBQUM7QUFDekIsY0FBSUgsZ0JBQWdCRSxPQUFPO0FBQ3pCVCx1QkFBVztBQUFBLFVBQ2I7QUFBQSxRQUNGO0FBQ0E7QUFBQSxNQUNGLEtBQUs7QUFDSCxZQUFJLENBQUNDO0FBQVFELHFCQUFXO0FBQ3hCO0FBQUEsTUFDRixLQUFLO0FBQ0gsWUFBSSxDQUFDQyxVQUFVSyxTQUFTTCxNQUFNLElBQUksS0FBS0ssU0FBU0wsTUFBTSxJQUFJO0FBQUdELHFCQUFXO0FBQ3hFO0FBQUEsTUFDRixLQUFLO0FBQ0gsWUFBSSxDQUFDQyxVQUFVSyxTQUFTTCxNQUFNLElBQUksS0FBS0ssU0FBU0wsTUFBTSxJQUFJO0FBQUdELHFCQUFXO0FBQ3hFO0FBQUEsTUFDRixLQUFLO0FBQ0gsWUFBSUMsV0FBVyxPQUFPVSxXQUFXVixNQUFNLElBQUksS0FBS1UsV0FBV1YsTUFBTSxJQUFJO0FBQU1ELHFCQUFXO0FBQ3RGO0FBQUEsTUFDRixLQUFLO0FBQ0gsWUFBSSxDQUFDQyxVQUFVSyxTQUFTTCxNQUFNLElBQUk7QUFBR0QscUJBQVc7QUFDaEQ7QUFBQSxNQUNGLEtBQUs7QUFDSCxZQUFJLENBQUNDLFVBQVVLLFNBQVNMLE1BQU0sSUFBSTtBQUFHRCxxQkFBVztBQUNoRDtBQUFBLE1BQ0Y7QUFDRTtBQUFBLElBQ0o7QUFDQSxXQUFPQTtBQUFBQSxFQUNUO0FBRUEsUUFBTVksYUFBY3JELE9BQU07QUFDeEIsVUFBTTtBQUFBLE1BQUV1QztBQUFBQSxNQUFNQztBQUFBQSxJQUFNLElBQUl4QyxFQUFFRTtBQUMxQm1DLGVBQVlpQixXQUFVO0FBQUEsTUFBRSxHQUFHQTtBQUFBQSxNQUFNLENBQUNmLElBQUksR0FBRztBQUFBLElBQUssRUFBRTtBQUNoRCxVQUFNRSxXQUFXSCxjQUFjQyxNQUFNQyxLQUFLO0FBQzFDTCxjQUFXbUIsV0FBVTtBQUFBLE1BQUUsR0FBR0E7QUFBQUEsTUFBTSxDQUFDZixJQUFJLEdBQUdFO0FBQUFBLElBQVMsRUFBRTtBQUFBLEVBQ3JEO0FBRUEsUUFBTWMsZUFBZ0J2RCxPQUFNO0FBQzFCLFVBQU07QUFBQSxNQUFFdUM7QUFBQUEsTUFBTUM7QUFBQUEsSUFBTSxJQUFJeEMsRUFBRUU7QUFDMUJZLGdCQUFhd0MsV0FBVTtBQUFBLE1BQUUsR0FBR0E7QUFBQUEsTUFBTSxDQUFDZixJQUFJLEdBQUdDO0FBQUFBLElBQU0sRUFBRTtBQUNsRCxRQUFJSixRQUFRRyxJQUFJLEdBQUc7QUFDakJKLGdCQUFXbUIsV0FBVTtBQUFBLFFBQUUsR0FBR0E7QUFBQUEsUUFBTSxDQUFDZixJQUFJLEdBQUdELGNBQWNDLE1BQU1DLEtBQUs7QUFBQSxNQUFFLEVBQUU7QUFBQSxJQUN2RTtBQUFBLEVBQ0Y7QUFFQSxRQUFNZ0IscUJBQXFCQSxDQUFDQyxTQUFTQyxPQUFPbEIsVUFBVTtBQUNwRDFCLGdCQUFhd0MsV0FBVTtBQUFBLE1BQ3JCLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQ0csT0FBTyxHQUFHO0FBQUEsUUFBRSxHQUFHSCxLQUFLRyxPQUFPO0FBQUEsUUFBRyxDQUFDQyxLQUFLLEdBQUdsQjtBQUFBQSxNQUFNO0FBQUEsSUFDaEQsRUFBRTtBQUNGLFFBQUlKLFFBQVFzQixLQUFLLEdBQUc7QUFDbEJ2QixnQkFBV21CLFdBQVU7QUFBQSxRQUFFLEdBQUdBO0FBQUFBLFFBQU0sQ0FBQ0ksS0FBSyxHQUFHcEIsY0FBY29CLE9BQU9sQixLQUFLO0FBQUEsTUFBRSxFQUFFO0FBQUEsSUFDekU7QUFBQSxFQUNGO0FBRUEsUUFBTW1CLG1CQUFtQkEsQ0FBQ0YsU0FBU0MsVUFBVTtBQUMzQ3JCLGVBQVlpQixXQUFVO0FBQUEsTUFBRSxHQUFHQTtBQUFBQSxNQUFNLENBQUNJLEtBQUssR0FBRztBQUFBLElBQUssRUFBRTtBQUNqRCxVQUFNakIsV0FBV0gsY0FBY29CLE9BQU83QyxTQUFTNEMsT0FBTyxFQUFFQyxLQUFLLENBQUM7QUFDOUR2QixjQUFXbUIsV0FBVTtBQUFBLE1BQUUsR0FBR0E7QUFBQUEsTUFBTSxDQUFDSSxLQUFLLEdBQUdqQjtBQUFBQSxJQUFTLEVBQUU7QUFBQSxFQUN0RDtBQUVBLFFBQU1tQixvQkFBb0JBLENBQUNDLE1BQU1DLFVBQVUxRCxjQUFjO0FBQ3ZEVSxnQkFBYXdDLFVBQVM7QUFDcEIsWUFBTVMsY0FBYztBQUFBLFFBQ2xCLEdBQUdUO0FBQUFBLFFBQ0gsQ0FBQ08sSUFBSSxHQUFHO0FBQUEsVUFBRSxHQUFHUCxLQUFLTyxJQUFJO0FBQUEsVUFBRyxDQUFDQyxRQUFRLEdBQUcxRDtBQUFBQSxRQUFVO0FBQUEsTUFDakQ7QUFFQSxVQUFJeUQsU0FBUyxxQkFBcUJ6QixRQUFRaEIsaUJBQWlCO0FBQ3pELGNBQU00QyxxQkFBcUJDLE9BQU9DLE9BQU9ILFlBQVkzQyxlQUFlLEVBQUUrQyxLQUFLQyxTQUFPQSxPQUFPQSxJQUFJQyxTQUFTLENBQUM7QUFDdkdsQyxrQkFBVW5DLFFBQU07QUFBQSxVQUNkLEdBQUdBO0FBQUFBLFVBQ0hvQixpQkFBaUI0QyxxQkFBcUIsS0FBSztBQUFBLFFBQzdDLEVBQUU7QUFBQSxNQUNKO0FBRUEsYUFBT0Q7QUFBQUEsSUFDVCxDQUFDO0FBQUEsRUFDSDtBQUVBLFFBQU1PLGNBQWNBLE1BQU07QUFDeEIsVUFBTUMsWUFBWSxDQUFDO0FBQ25CLFVBQU1DLGFBQWEsQ0FBQyxTQUFTLGVBQWUsWUFBWSxlQUFlLGVBQWUsU0FBUztBQUUvRkEsZUFBV0MsUUFBUWYsV0FBUztBQUMxQixZQUFNZ0IsTUFBTXBDLGNBQWNvQixPQUFPN0MsU0FBUzZDLEtBQUssQ0FBQztBQUNoRCxVQUFJZ0I7QUFBS0gsa0JBQVViLEtBQUssSUFBSWdCO0FBQUFBLElBQzlCLENBQUM7QUFFRCxVQUFNQyxlQUFlLENBQUMsZUFBZSxlQUFlO0FBQ3BEQSxpQkFBYUYsUUFBUWYsV0FBUztBQUM1QixZQUFNZ0IsTUFBTXBDLGNBQWNvQixPQUFPN0MsU0FBU2Usd0JBQXdCOEIsS0FBSyxDQUFDO0FBQ3hFLFVBQUlnQjtBQUFLSCxrQkFBVWIsS0FBSyxJQUFJZ0I7QUFBQUEsSUFDOUIsQ0FBQztBQUVELFVBQU1WLHFCQUFxQkMsT0FBT0MsT0FBT3JELFNBQVNPLGVBQWUsRUFBRStDLEtBQUtDLFNBQU9BLE9BQU9BLElBQUlDLFNBQVMsQ0FBQztBQUNwRyxRQUFJLENBQUNMLG9CQUFvQjtBQUN2Qk8sZ0JBQVVuRCxrQkFBa0I7QUFBQSxJQUM5QjtBQUVBZSxjQUFVb0MsU0FBUztBQUVuQixVQUFNSyxhQUFhLENBQUM7QUFDcEIsS0FBQyxHQUFHSixZQUFZLEdBQUdHLGNBQWMsaUJBQWlCLEVBQUVGLFFBQVFJLE9BQUtELFdBQVdDLENBQUMsSUFBSSxJQUFJO0FBQ3JGeEMsZUFBV3VDLFVBQVU7QUFFckIsUUFBSS9ELFNBQVNtQixPQUFPcUMsV0FBVyxHQUFHO0FBQ2hDUyxZQUFNLG9DQUFvQztBQUMxQyxhQUFPO0FBQUEsSUFDVDtBQUNBLFFBQUlqRSxTQUFTYyxjQUFjMEMsV0FBVyxHQUFHO0FBQ3ZDUyxZQUFNLDJDQUEyQztBQUNqRCxhQUFPO0FBQUEsSUFDVDtBQUNBLFFBQUlqRSxTQUFTZSx3QkFBd0JFLFlBQVl1QyxXQUFXLEdBQUc7QUFDN0RTLFlBQU0seUNBQXlDO0FBQy9DLGFBQU87QUFBQSxJQUNUO0FBRUEsV0FBT2IsT0FBT2MsS0FBS1IsU0FBUyxFQUFFRixXQUFXO0FBQUEsRUFDM0M7QUFFQSxRQUFNVyxlQUFlLE9BQU9oRixNQUFNO0FBQ2hDQSxNQUFFaUYsZUFBZTtBQUNqQixRQUFJLENBQUNYLFlBQVksR0FBRztBQUNsQjtBQUFBLElBQ0Y7QUFFQSxRQUFJO0FBQ0YsWUFBTVksV0FBVyxNQUFNQyxNQUFNLG1DQUFtQztBQUFBLFFBQzlEQyxRQUFRO0FBQUEsUUFDUkMsU0FBUztBQUFBLFVBQ1AsZ0JBQWdCO0FBQUEsVUFDaEIsZ0JBQWdCMUU7QUFBQUEsUUFDbEI7QUFBQSxRQUNBMkUsTUFBTUMsS0FBS0MsVUFBVTNFLFFBQVE7QUFBQSxNQUMvQixDQUFDO0FBRUQsVUFBSXFFLFNBQVNPLElBQUk7QUFDZixZQUFJaEYsV0FBVztBQUNiQSxvQkFBVTtBQUFBLFFBQ1osT0FBTztBQUNMcUUsZ0JBQU0sK0JBQStCO0FBQ3JDbEUsbUJBQVMsZ0JBQWdCO0FBQUEsUUFDM0I7QUFBQSxNQUNGLE9BQU87QUFDTCxjQUFNOEUsWUFBWSxNQUFNUixTQUFTUyxLQUFLO0FBQ3RDYixjQUFNLDZCQUE2QlksVUFBVUUsT0FBTyxlQUFlLEVBQUU7QUFBQSxNQUN2RTtBQUFBLElBQ0YsU0FBU0MsT0FBTztBQUNkQyxjQUFRRCxNQUFNLDJCQUEyQkEsS0FBSztBQUM5Q2YsWUFBTSx5RUFBeUU7QUFBQSxJQUNqRjtBQUFBLEVBQ0Y7QUFFQSxRQUFNaUIsWUFBVyxvQkFBSTlDLEtBQUssR0FBRStDLFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUV0RCxTQUNFLHVCQUFDLFNBQUksV0FBVSwrQkFDYixpQ0FBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQSwyQkFBQyxRQUFHLFdBQVUsMkJBQTBCLGtDQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBEO0FBQUEsSUFDMUQsdUJBQUMsT0FBRSxXQUFVLDhCQUE2Qiw0RUFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzRztBQUFBLElBRXRHLHVCQUFDLFVBQUssVUFBVWpCLGNBQWMsV0FBVSwwQkFBeUIsWUFBVSxNQUV6RTtBQUFBLDZCQUFDLFNBQUksV0FBVSxtQkFDYjtBQUFBLCtCQUFDLFFBQUcsaUNBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxQjtBQUFBLFFBRXJCLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLGlDQUFDLFdBQU0sK0JBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0I7QUFBQSxVQUN0Qix1QkFBQyxXQUFNLE1BQUssUUFBTyxNQUFLLFNBQVEsT0FBT25FLFNBQVNFLE9BQU8sVUFBVXdDLGNBQWMsUUFBUUYsWUFBWSxXQUFXakIsUUFBUXJCLFNBQVNtQixPQUFPbkIsUUFBUSxtQkFBbUIsSUFBSSxhQUFZLHlCQUFqTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzTTtBQUFBLFVBQ3JNcUIsUUFBUXJCLFNBQVNtQixPQUFPbkIsU0FBUyx1QkFBQyxVQUFLLFdBQVUsb0JBQW9CbUIsaUJBQU9uQixTQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpRDtBQUFBLGFBSHJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsaUNBQUMsV0FBTSw2QkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvQjtBQUFBLFVBQ3BCLHVCQUFDLGNBQVMsTUFBSyxlQUFjLE9BQU9GLFNBQVNHLGFBQWEsVUFBVXVDLGNBQWMsUUFBUUYsWUFBWSxXQUFXakIsUUFBUXBCLGVBQWVrQixPQUFPbEIsY0FBYyxtQkFBbUIsSUFBSSxhQUFZLGlFQUFoTTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4UDtBQUFBLFVBQzdQb0IsUUFBUXBCLGVBQWVrQixPQUFPbEIsZUFBZSx1QkFBQyxVQUFLLFdBQVUsb0JBQW9Ca0IsaUJBQU9sQixlQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1RDtBQUFBLGFBSHZHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSxtQ0FBQyxXQUFNLDJCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtCO0FBQUEsWUFDbEIsdUJBQUMsV0FBTSxNQUFLLFVBQVMsTUFBSyxZQUFXLE9BQU9ILFNBQVNJLFVBQVUsVUFBVXNDLGNBQWMsUUFBUUYsWUFBWSxXQUFXakIsUUFBUW5CLFlBQVlpQixPQUFPakIsV0FBVyxtQkFBbUIsSUFBSSxLQUFJLEtBQUksYUFBWSxZQUF2TTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErTTtBQUFBLFlBQzlNbUIsUUFBUW5CLFlBQVlpQixPQUFPakIsWUFBWSx1QkFBQyxVQUFLLFdBQVUsb0JBQW9CaUIsaUJBQU9qQixZQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvRDtBQUFBLGVBSDlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSUE7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLG1DQUFDLFdBQU0sOEJBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUI7QUFBQSxZQUNyQix1QkFBQyxZQUFPLE1BQUssZUFBYyxPQUFPSixTQUFTSyxhQUFhLFVBQVVxQyxjQUFjLFFBQVFGLFlBQVksV0FBV2pCLFFBQVFsQixlQUFlZ0IsT0FBT2hCLGNBQWMsbUJBQW1CLElBQzVLO0FBQUEscUNBQUMsWUFBTyxPQUFNLElBQUcsMkJBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTRCO0FBQUEsY0FDNUIsdUJBQUMsWUFBTyxPQUFNLFlBQVcsd0JBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWlDO0FBQUEsY0FDakMsdUJBQUMsWUFBTyxPQUFNLGVBQWMsMkJBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXVDO0FBQUEsY0FDdkMsdUJBQUMsWUFBTyxPQUFNLHNCQUFxQixrQ0FBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUQ7QUFBQSxjQUNyRCx1QkFBQyxZQUFPLE9BQU0sYUFBWSx5QkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbUM7QUFBQSxjQUNuQyx1QkFBQyxZQUFPLE9BQU0sZUFBYywyQkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBdUM7QUFBQSxpQkFOekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFPQTtBQUFBLFlBQ0NrQixRQUFRbEIsZUFBZWdCLE9BQU9oQixlQUFlLHVCQUFDLFVBQUssV0FBVSxvQkFBb0JnQixpQkFBT2hCLGVBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVEO0FBQUEsZUFWdkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFXQTtBQUFBLGFBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFrQkE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLGlDQUFDLFdBQU0sMEJBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUI7QUFBQSxVQUNqQix1QkFBQyxXQUFNLE1BQUssUUFBTyxNQUFLLFdBQVUsT0FBT0wsU0FBU29CLFNBQVMsVUFBVXNCLGNBQWMsUUFBUUYsWUFBWSxLQUFLMEMsVUFBVSxXQUFXM0QsUUFBUUgsV0FBV0MsT0FBT0QsVUFBVSxtQkFBbUIsTUFBeEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkw7QUFBQSxVQUMxTEcsUUFBUUgsV0FBV0MsT0FBT0QsV0FBVyx1QkFBQyxVQUFLLFdBQVUsb0JBQW9CQyxpQkFBT0QsV0FBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUQ7QUFBQSxhQUgzRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSUE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLGlDQUFDLFdBQU0sd0JBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZTtBQUFBLFVBQ2YsdUJBQUMsaUJBQ0MsU0FBUyxDQUFDLG1CQUFtQixzQkFBc0IsV0FBVyxnQkFBZ0IsaUJBQWlCLG1CQUFtQixvQkFBb0IsT0FBTyxjQUFjLFFBQVEsR0FDbkssZ0JBQWdCcEIsU0FBU21CLFFBQ3pCLFVBQVdrQyxZQUFXcEQsWUFBWXdDLFdBQVM7QUFBQSxZQUFFLEdBQUdBO0FBQUFBLFlBQU10QixRQUFRa0M7QUFBQUEsVUFBTyxFQUFFLEtBSHpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRzJFO0FBQUEsYUFMN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsV0FoREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWlEQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxXQUFVLG1CQUNiO0FBQUEsK0JBQUMsUUFBRywyREFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStDO0FBQUEsUUFDL0MsdUJBQUMsT0FBRSxPQUFPO0FBQUEsVUFBRWdDLFVBQVU7QUFBQSxVQUFRQyxPQUFPO0FBQUEsVUFBV0MsY0FBYztBQUFBLFFBQU8sR0FBRyw0R0FBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvSztBQUFBLFFBQ3BLLHVCQUFDLFNBQUksV0FBVSxlQUNiLGlDQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLGlDQUFDLFdBQU0sbURBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEM7QUFBQSxVQUMxQyx1QkFBQyxXQUFNLE1BQUssVUFBUyxNQUFLLFFBQU8sTUFBSyxlQUFjLE9BQU92RixTQUFTTSxhQUFhLFVBQVVvQyxjQUFjLFFBQVFGLFlBQVksV0FBV2pCLFFBQVFqQixlQUFlZSxPQUFPZixjQUFjLG1CQUFtQixJQUFJLGFBQVksY0FBdk47QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaU87QUFBQSxVQUNoT2lCLFFBQVFqQixlQUFlZSxPQUFPZixlQUFlLHVCQUFDLFVBQUssV0FBVSxvQkFBb0JlLGlCQUFPZixlQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1RDtBQUFBLGFBSHZHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQSxLQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNQTtBQUFBLFdBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQSwrQkFBQyxRQUFHLDRDQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0M7QUFBQSxRQUMvQmlCLFFBQVFoQixtQkFBbUJjLE9BQU9kLG1CQUNqQyx1QkFBQyxVQUFLLFdBQVUsb0JBQW1CLE9BQU87QUFBQSxVQUFFaUYsU0FBUztBQUFBLFVBQVNELGNBQWM7QUFBQSxRQUFPLEdBQ2hGbEUsaUJBQU9kLG1CQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBRUYsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsaUNBQUMsV0FBTSwyQkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrQjtBQUFBLFVBQ2xCLHVCQUFDLGlCQUNDLFNBQVMsQ0FBQyxjQUFjLGNBQWMsVUFBVSxRQUFRLEtBQUssT0FBTyxNQUFNLE1BQU0sUUFBUSxVQUFVLFNBQVMsT0FBTyxRQUFRLFFBQVEsS0FBSyxRQUFRLEdBQy9JLGdCQUFnQlAsU0FBU08sZ0JBQWdCQyxXQUN6QyxVQUFXNkMsWUFBV04sa0JBQWtCLG1CQUFtQixhQUFhTSxNQUFNLEtBSGhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR2tGO0FBQUEsYUFMcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSxpQ0FBQyxXQUFNLDRCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1CO0FBQUEsVUFDbkIsdUJBQUMsaUJBQ0MsU0FBUyxDQUFDLFNBQVMsV0FBVyxVQUFVLFdBQVcsV0FBVyxXQUFXLGNBQWMsVUFBVSxTQUFTLGVBQWUsV0FBVyxXQUFXLGlCQUFpQixXQUFXLGNBQWMsR0FDekwsZ0JBQWdCckQsU0FBU08sZ0JBQWdCRSxZQUN6QyxVQUFXNEMsWUFBV04sa0JBQWtCLG1CQUFtQixjQUFjTSxNQUFNLEtBSGpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR21GO0FBQUEsYUFMckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSxpQ0FBQyxXQUFNLDJCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtCO0FBQUEsVUFDbEIsdUJBQUMsaUJBQ0MsU0FBUyxDQUFDLFdBQVcsU0FBUyxjQUFjLFVBQVUsVUFBVSx3QkFBd0IsWUFBWSxTQUFTLGFBQWEsWUFBWSxPQUFPLEdBQzdJLGdCQUFnQnJELFNBQVNPLGdCQUFnQkksV0FDekMsVUFBVzBDLFlBQVdOLGtCQUFrQixtQkFBbUIsYUFBYU0sTUFBTSxLQUhoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdrRjtBQUFBLGFBTHBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsaUNBQUMsV0FBTSwyQkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrQjtBQUFBLFVBQ2xCLHVCQUFDLGlCQUNDLFNBQVMsQ0FBQyxTQUFTLFNBQVMsVUFBVSxVQUFVLGNBQWMsU0FBUyxXQUFXLGdCQUFnQixVQUFVLFNBQVMsWUFBWSxTQUFTLFlBQVksYUFBYSxXQUFXLEdBQzlLLGdCQUFnQnJELFNBQVNPLGdCQUFnQkcsV0FDekMsVUFBVzJDLFlBQVdOLGtCQUFrQixtQkFBbUIsYUFBYU0sTUFBTSxLQUhoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdrRjtBQUFBLGFBTHBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsaUNBQUMsV0FBTSx1QkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFjO0FBQUEsVUFDZCx1QkFBQyxpQkFDQyxTQUFTLENBQUMsT0FBTyxVQUFVLFVBQVUsVUFBVSxjQUFjLFdBQVcsUUFBUSxVQUFVLFNBQVMsWUFBWSxXQUFXLGlCQUFpQixXQUFXLFdBQVcsT0FBTyxHQUN4SyxnQkFBZ0JyRCxTQUFTTyxnQkFBZ0JLLE9BQ3pDLFVBQVd5QyxZQUFXTixrQkFBa0IsbUJBQW1CLFNBQVNNLE1BQU0sS0FINUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHOEU7QUFBQSxhQUxoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxXQWhERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBaURBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQSwrQkFBQyxRQUFHLDhDQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0M7QUFBQSxRQUNsQyx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSxpQ0FBQyxXQUFNLHlCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdCO0FBQUEsVUFDaEIsdUJBQUMsaUJBQ0MsU0FBUyxDQUFDLGNBQWMsY0FBYyxVQUFVLFFBQVEsS0FBSyxPQUFPLE1BQU0sTUFBTSxRQUFRLFVBQVUsU0FBUyxPQUFPLFFBQVEsUUFBUSxLQUFLLFFBQVEsR0FDL0ksZ0JBQWdCckQsU0FBU2EsZUFBZUwsV0FDeEMsVUFBVzZDLFlBQVdOLGtCQUFrQixrQkFBa0IsYUFBYU0sTUFBTSxLQUgvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdpRjtBQUFBLGFBTG5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsaUNBQUMsV0FBTSwwQkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpQjtBQUFBLFVBQ2pCLHVCQUFDLGlCQUNDLFNBQVMsQ0FBQyxTQUFTLFdBQVcsVUFBVSxXQUFXLFdBQVcsV0FBVyxjQUFjLFVBQVUsU0FBUyxlQUFlLFdBQVcsV0FBVyxpQkFBaUIsV0FBVyxjQUFjLEdBQ3pMLGdCQUFnQnJELFNBQVNhLGVBQWVKLFlBQ3hDLFVBQVc0QyxZQUFXTixrQkFBa0Isa0JBQWtCLGNBQWNNLE1BQU0sS0FIaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHa0Y7QUFBQSxhQUxwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLGlDQUFDLFdBQU0seUJBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0I7QUFBQSxVQUNoQix1QkFBQyxpQkFDQyxTQUFTLENBQUMsV0FBVyxTQUFTLGNBQWMsVUFBVSxVQUFVLHdCQUF3QixZQUFZLFNBQVMsYUFBYSxZQUFZLE9BQU8sR0FDN0ksZ0JBQWdCckQsU0FBU2EsZUFBZUYsV0FDeEMsVUFBVzBDLFlBQVdOLGtCQUFrQixrQkFBa0IsYUFBYU0sTUFBTSxLQUgvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdpRjtBQUFBLGFBTG5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsaUNBQUMsV0FBTSwwQkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpQjtBQUFBLFVBQ2pCLHVCQUFDLGlCQUNDLFNBQVMsQ0FBQyxTQUFTLFNBQVMsVUFBVSxVQUFVLGNBQWMsU0FBUyxXQUFXLGdCQUFnQixVQUFVLFNBQVMsWUFBWSxTQUFTLFlBQVksYUFBYSxXQUFXLEdBQzlLLGdCQUFnQnJELFNBQVNhLGVBQWVILFdBQ3hDLFVBQVcyQyxZQUFXTixrQkFBa0Isa0JBQWtCLGFBQWFNLE1BQU0sS0FIL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHaUY7QUFBQSxhQUxuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLGlDQUFDLFdBQU0sc0JBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBYTtBQUFBLFVBQ2IsdUJBQUMsaUJBQ0MsU0FBUyxDQUFDLE9BQU8sVUFBVSxVQUFVLFVBQVUsY0FBYyxXQUFXLFFBQVEsVUFBVSxTQUFTLFlBQVksV0FBVyxpQkFBaUIsV0FBVyxXQUFXLE9BQU8sR0FDeEssZ0JBQWdCckQsU0FBU2EsZUFBZUQsT0FDeEMsVUFBV3lDLFlBQVdOLGtCQUFrQixrQkFBa0IsU0FBU00sTUFBTSxLQUgzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUc2RTtBQUFBLGFBTC9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFdBM0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE0Q0E7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSxtQkFDYjtBQUFBLCtCQUFDLFFBQUcsb0NBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3QjtBQUFBLFFBQ3hCLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLGlDQUFDLFdBQU0sZ0NBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUI7QUFBQSxVQUN2Qix1QkFBQyxpQkFDQyxTQUFTLENBQUMsc0JBQXNCLHFCQUFxQix1QkFBdUIsd0JBQXdCLGVBQWUsa0JBQWtCLGtCQUFrQixtQkFBbUIsZUFBZSxpQkFBaUIsR0FDMU0sZ0JBQWdCckQsU0FBU2MsZUFDekIsVUFBV3VDLFlBQVdwRCxZQUFZd0MsV0FBUztBQUFBLFlBQUUsR0FBR0E7QUFBQUEsWUFBTTNCLGVBQWV1QztBQUFBQSxVQUFPLEVBQUUsS0FIaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHa0Y7QUFBQSxhQUxwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsbUNBQUMsV0FBTSx1Q0FBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4QjtBQUFBLFlBQzlCLHVCQUFDLFdBQU0sTUFBSyxVQUFTLE1BQUssZUFBYyxPQUFPckQsU0FBU2Usd0JBQXdCQyxhQUFhLFVBQVc3QixPQUFNd0QsbUJBQW1CLDJCQUEyQixlQUFleEQsRUFBRUUsT0FBT3NDLEtBQUssR0FBRyxRQUFRLE1BQU1tQixpQkFBaUIsMkJBQTJCLGFBQWEsR0FBRyxXQUFXdkIsUUFBUVAsZUFBZUssT0FBT0wsY0FBYyxtQkFBbUIsSUFBSSxLQUFJLEtBQUksYUFBWSxhQUF4VztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpWDtBQUFBLFlBQ2hYTyxRQUFRUCxlQUFlSyxPQUFPTCxlQUFlLHVCQUFDLFVBQUssV0FBVSxvQkFBb0JLLGlCQUFPTCxlQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1RDtBQUFBLGVBSHZHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSUE7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLG1DQUFDLFdBQU0sa0NBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUI7QUFBQSxZQUN6Qix1QkFBQyxXQUFNLE1BQUssVUFBUyxNQUFLLGlCQUFnQixPQUFPaEIsU0FBU2Usd0JBQXdCRyxlQUFlLFVBQVcvQixPQUFNd0QsbUJBQW1CLDJCQUEyQixpQkFBaUJ4RCxFQUFFRSxPQUFPc0MsS0FBSyxHQUFHLFFBQVEsTUFBTW1CLGlCQUFpQiwyQkFBMkIsZUFBZSxHQUFHLFdBQVd2QixRQUFRTCxpQkFBaUJHLE9BQU9ILGdCQUFnQixtQkFBbUIsSUFBSSxLQUFJLEtBQUksYUFBWSxhQUFwWDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2WDtBQUFBLFlBQzVYSyxRQUFRTCxpQkFBaUJHLE9BQU9ILGlCQUFpQix1QkFBQyxVQUFLLFdBQVUsb0JBQW9CRyxpQkFBT0gsaUJBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlEO0FBQUEsZUFIN0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJQTtBQUFBLGFBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVdBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSxpQ0FBQyxXQUFNLHdDQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStCO0FBQUEsVUFDL0IsdUJBQUMsaUJBQ0MsU0FBUyxDQUFDLFVBQVUsV0FBVyxhQUFhLFlBQVksVUFBVSxZQUFZLFFBQVEsR0FDdEYsZ0JBQWdCbEIsU0FBU2Usd0JBQXdCRSxhQUNqRCxVQUFXb0MsWUFBV1YsbUJBQW1CLDJCQUEyQixlQUFlVSxNQUFNLEtBSDNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRzZGO0FBQUEsYUFML0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsV0EvQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWdDQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLG1CQUNiLGlDQUFDLFlBQU8sTUFBSyxVQUFTLFdBQVUsaUJBQWdCLDhCQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThELEtBRGhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBMU1GO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EyTUE7QUFBQSxPQS9NRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBZ05BLEtBak5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FrTkE7QUFFSjtBQUFFeEQsR0EzYUlGLGVBQWE7QUFBQSxVQUNDaEIsU0FDREQsV0FBVztBQUFBO0FBQUErRyxNQUZ4QjlGO0FBNmFOLGVBQWVBO0FBQWMsSUFBQUQsSUFBQStGO0FBQUFDLGFBQUFoRyxJQUFBO0FBQUFnRyxhQUFBRCxLQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJ1c2VTdGF0ZSIsInVzZU5hdmlnYXRlIiwidXNlQXV0aCIsIkNoZWNrYm94R3JvdXAiLCJvcHRpb25zIiwic2VsZWN0ZWRWYWx1ZXMiLCJvbkNoYW5nZSIsIm1hcCIsIm9wdGlvbiIsImluY2x1ZGVzIiwiZSIsImlzQ2hlY2tlZCIsInRhcmdldCIsImNoZWNrZWQiLCJuZXdWYWx1ZXMiLCJmaWx0ZXIiLCJ2IiwiX2MiLCJJbnNlcnRQcm9qZWN0Iiwib25TdWNjZXNzIiwiX3MiLCJ0b2tlbiIsIm5hdmlnYXRlIiwiZm9ybURhdGEiLCJzZXRGb3JtRGF0YSIsInRpdGxlIiwiZGVzY3JpcHRpb24iLCJ0ZWFtU2l6ZSIsInByb2plY3RUeXBlIiwibWluaW11bUNHUEEiLCJlc3NlbnRpYWxTa2lsbHMiLCJsYW5ndWFnZXMiLCJmcmFtZXdvcmtzIiwibGlicmFyaWVzIiwiZGF0YWJhc2VzIiwidG9vbHMiLCJvcHRpb25hbFNraWxscyIsInJlcXVpcmVkUm9sZXMiLCJhdmFpbGFiaWxpdHlSZXF1aXJlbWVudCIsIndlZWtseUhvdXJzIiwibWVldGluZ0RheXMiLCJkdXJhdGlvbldlZWtzIiwiZG9tYWluIiwiZHVlRGF0ZSIsImVycm9ycyIsInNldEVycm9ycyIsInRvdWNoZWQiLCJzZXRUb3VjaGVkIiwidmFsaWRhdGVGaWVsZCIsIm5hbWUiLCJ2YWx1ZSIsImVycm9yTXNnIiwic3RyVmFsIiwidW5kZWZpbmVkIiwiU3RyaW5nIiwidHJpbSIsInRlc3QiLCJwYXJzZUludCIsInNlbGVjdGVkRGF0ZSIsIkRhdGUiLCJ0b2RheSIsInNldEhvdXJzIiwicGFyc2VGbG9hdCIsImhhbmRsZUJsdXIiLCJwcmV2IiwiaGFuZGxlQ2hhbmdlIiwiaGFuZGxlTmVzdGVkQ2hhbmdlIiwic2VjdGlvbiIsImZpZWxkIiwiaGFuZGxlTmVzdGVkQmx1ciIsImhhbmRsZVNraWxsQ2hhbmdlIiwidHlwZSIsImNhdGVnb3J5IiwidXBkYXRlZERhdGEiLCJoYXNFc3NlbnRpYWxTa2lsbHMiLCJPYmplY3QiLCJ2YWx1ZXMiLCJzb21lIiwiYXJyIiwibGVuZ3RoIiwidmFsaWRhdGVBbGwiLCJuZXdFcnJvcnMiLCJ0ZXh0RmllbGRzIiwiZm9yRWFjaCIsImVyciIsIm5lc3RlZEZpZWxkcyIsImFsbFRvdWNoZWQiLCJmIiwiYWxlcnQiLCJrZXlzIiwiaGFuZGxlU3VibWl0IiwicHJldmVudERlZmF1bHQiLCJyZXNwb25zZSIsImZldGNoIiwibWV0aG9kIiwiaGVhZGVycyIsImJvZHkiLCJKU09OIiwic3RyaW5naWZ5Iiwib2siLCJlcnJvckRhdGEiLCJqc29uIiwibXNnIiwiZXJyb3IiLCJjb25zb2xlIiwidG9kYXlTdHIiLCJ0b0lTT1N0cmluZyIsInNwbGl0IiwiZm9udFNpemUiLCJjb2xvciIsIm1hcmdpbkJvdHRvbSIsImRpc3BsYXkiLCJfYzIiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJJbnNlcnRQcm9qZWN0LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XHJcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tICcuLi8uLi9jb250ZXh0L0F1dGhDb250ZXh0JztcclxuaW1wb3J0ICcuL0luc2VydFByb2plY3QuY3NzJztcclxuXHJcbmNvbnN0IENoZWNrYm94R3JvdXAgPSAoeyBvcHRpb25zLCBzZWxlY3RlZFZhbHVlcywgb25DaGFuZ2UgfSkgPT4gKFxyXG4gIDxkaXYgY2xhc3NOYW1lPVwiY2hlY2tib3gtZ3JvdXAtaXBcIj5cclxuICAgIHtvcHRpb25zLm1hcCgob3B0aW9uKSA9PiAoXHJcbiAgICAgIDxsYWJlbCBrZXk9e29wdGlvbn0gY2xhc3NOYW1lPVwiY2hlY2tib3gtbGFiZWwtaXBcIj5cclxuICAgICAgICA8aW5wdXRcclxuICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICB2YWx1ZT17b3B0aW9ufVxyXG4gICAgICAgICAgY2hlY2tlZD17c2VsZWN0ZWRWYWx1ZXMuaW5jbHVkZXMob3B0aW9uKX1cclxuICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICBjb25zdCBpc0NoZWNrZWQgPSBlLnRhcmdldC5jaGVja2VkO1xyXG4gICAgICAgICAgICBjb25zdCBuZXdWYWx1ZXMgPSBpc0NoZWNrZWRcclxuICAgICAgICAgICAgICA/IFsuLi5zZWxlY3RlZFZhbHVlcywgb3B0aW9uXVxyXG4gICAgICAgICAgICAgIDogc2VsZWN0ZWRWYWx1ZXMuZmlsdGVyKCh2KSA9PiB2ICE9PSBvcHRpb24pO1xyXG4gICAgICAgICAgICBvbkNoYW5nZShuZXdWYWx1ZXMpO1xyXG4gICAgICAgICAgfX1cclxuICAgICAgICAvPlxyXG4gICAgICAgIHtvcHRpb259XHJcbiAgICAgIDwvbGFiZWw+XHJcbiAgICApKX1cclxuICA8L2Rpdj5cclxuKTtcclxuXHJcbmNvbnN0IEluc2VydFByb2plY3QgPSAoeyBvblN1Y2Nlc3MgfSkgPT4ge1xyXG4gIGNvbnN0IHsgdG9rZW4gfSA9IHVzZUF1dGgoKTtcclxuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XHJcbiAgY29uc3QgW2Zvcm1EYXRhLCBzZXRGb3JtRGF0YV0gPSB1c2VTdGF0ZSh7XHJcbiAgICB0aXRsZTogJycsXHJcbiAgICBkZXNjcmlwdGlvbjogJycsXHJcbiAgICB0ZWFtU2l6ZTogJycsXHJcbiAgICBwcm9qZWN0VHlwZTogJycsXHJcbiAgICBtaW5pbXVtQ0dQQTogJycsXHJcbiAgICBlc3NlbnRpYWxTa2lsbHM6IHsgbGFuZ3VhZ2VzOiBbXSwgZnJhbWV3b3JrczogW10sIGxpYnJhcmllczogW10sIGRhdGFiYXNlczogW10sIHRvb2xzOiBbXSB9LFxyXG4gICAgb3B0aW9uYWxTa2lsbHM6IHsgbGFuZ3VhZ2VzOiBbXSwgZnJhbWV3b3JrczogW10sIGxpYnJhcmllczogW10sIGRhdGFiYXNlczogW10sIHRvb2xzOiBbXSB9LFxyXG4gICAgcmVxdWlyZWRSb2xlczogW10sXHJcbiAgICBhdmFpbGFiaWxpdHlSZXF1aXJlbWVudDogeyB3ZWVrbHlIb3VyczogJycsIG1lZXRpbmdEYXlzOiBbXSwgZHVyYXRpb25XZWVrczogJycgfSxcclxuICAgIGRvbWFpbjogW10sXHJcbiAgICBkdWVEYXRlOiAnJ1xyXG4gIH0pO1xyXG5cclxuICBjb25zdCBbZXJyb3JzLCBzZXRFcnJvcnNdID0gdXNlU3RhdGUoe30pO1xyXG4gIGNvbnN0IFt0b3VjaGVkLCBzZXRUb3VjaGVkXSA9IHVzZVN0YXRlKHt9KTtcclxuXHJcbiAgY29uc3QgdmFsaWRhdGVGaWVsZCA9IChuYW1lLCB2YWx1ZSkgPT4ge1xyXG4gICAgbGV0IGVycm9yTXNnID0gJyc7XHJcbiAgICBjb25zdCBzdHJWYWwgPSB2YWx1ZSAhPT0gbnVsbCAmJiB2YWx1ZSAhPT0gdW5kZWZpbmVkID8gU3RyaW5nKHZhbHVlKS50cmltKCkgOiAnJztcclxuXHJcbiAgICBzd2l0Y2ggKG5hbWUpIHtcclxuICAgICAgY2FzZSAnaXROdW1iZXInOlxyXG4gICAgICAgIGlmICghc3RyVmFsKSBlcnJvck1zZyA9ICdJVCBOdW1iZXIgaXMgcmVxdWlyZWQuJztcclxuICAgICAgICBlbHNlIGlmICghL15JVFxcZHs4fSQvaS50ZXN0KHN0clZhbCkpIGVycm9yTXNnID0gJ0lUIE51bWJlciBtdXN0IGJlIGV4YWN0bHkgMTAgY2hhcmFjdGVycyBzdGFydGluZyB3aXRoIFwiSVRcIi4nO1xyXG4gICAgICAgIGJyZWFrO1xyXG4gICAgICBjYXNlICd0aXRsZSc6XHJcbiAgICAgICAgaWYgKCFzdHJWYWwpIHtcclxuICAgICAgICAgIGVycm9yTXNnID0gJ1Byb2plY3QgdGl0bGUgY2Fubm90IGJlIGVtcHR5Lic7XHJcbiAgICAgICAgfSBlbHNlIGlmICgvXlxcZCskLy50ZXN0KHN0clZhbCkpIHtcclxuICAgICAgICAgIGVycm9yTXNnID0gJ1Byb2plY3QgdGl0bGUgY2Fubm90IGJlIG9ubHkgbnVtYmVycy4nO1xyXG4gICAgICAgIH0gZWxzZSBpZiAoL15cXGQvLnRlc3Qoc3RyVmFsKSkge1xyXG4gICAgICAgICAgZXJyb3JNc2cgPSAnUHJvamVjdCB0aXRsZSBjYW5ub3Qgc3RhcnQgd2l0aCBhIG51bWJlci4nO1xyXG4gICAgICAgIH1cclxuICAgICAgICBicmVhaztcclxuICAgICAgY2FzZSAnZGVzY3JpcHRpb24nOlxyXG4gICAgICAgIGlmICghc3RyVmFsKSB7XHJcbiAgICAgICAgICBlcnJvck1zZyA9ICdEZXNjcmlwdGlvbiBjYW5ub3QgYmUgZW1wdHkuJztcclxuICAgICAgICB9IGVsc2UgaWYgKC9eXFxkKyQvLnRlc3Qoc3RyVmFsKSkge1xyXG4gICAgICAgICAgZXJyb3JNc2cgPSAnRGVzY3JpcHRpb24gY2Fubm90IGJlIG9ubHkgbnVtYmVycy4nO1xyXG4gICAgICAgIH1cclxuICAgICAgICBicmVhaztcclxuICAgICAgY2FzZSAndGVhbVNpemUnOlxyXG4gICAgICAgIGlmICghc3RyVmFsIHx8IHBhcnNlSW50KHN0clZhbCkgPCAxKSBlcnJvck1zZyA9ICdUZWFtIHNpemUgbXVzdCBiZSBhdCBsZWFzdCAxLic7XHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICAgIGNhc2UgJ3Byb2plY3RUeXBlJzpcclxuICAgICAgICBpZiAoIXN0clZhbCkgZXJyb3JNc2cgPSAnUHJvamVjdCB0eXBlIGlzIHJlcXVpcmVkLic7XHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICAgIGNhc2UgJ2R1ZURhdGUnOlxyXG4gICAgICAgIGlmICghc3RyVmFsKSB7XHJcbiAgICAgICAgICBlcnJvck1zZyA9ICdEdWUgZGF0ZSBpcyByZXF1aXJlZC4nO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBjb25zdCBzZWxlY3RlZERhdGUgPSBuZXcgRGF0ZShzdHJWYWwpO1xyXG4gICAgICAgICAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpO1xyXG4gICAgICAgICAgdG9kYXkuc2V0SG91cnMoMCwgMCwgMCwgMCk7XHJcbiAgICAgICAgICBpZiAoc2VsZWN0ZWREYXRlIDw9IHRvZGF5KSB7XHJcbiAgICAgICAgICAgIGVycm9yTXNnID0gJ0R1ZSBkYXRlIG11c3QgYmUgYSBmdXR1cmUgZGF0ZS4nO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBicmVhaztcclxuICAgICAgY2FzZSAnc3BlY2lhbGl6YXRpb24nOlxyXG4gICAgICAgIGlmICghc3RyVmFsKSBlcnJvck1zZyA9ICdTcGVjaWFsaXphdGlvbiBpcyByZXF1aXJlZC4nO1xyXG4gICAgICAgIGJyZWFrO1xyXG4gICAgICBjYXNlICd5ZWFyJzpcclxuICAgICAgICBpZiAoIXN0clZhbCB8fCBwYXJzZUludChzdHJWYWwpIDwgMSB8fCBwYXJzZUludChzdHJWYWwpID4gNCkgZXJyb3JNc2cgPSAnWWVhciBtdXN0IGJlIGJldHdlZW4gMSBhbmQgNC4nO1xyXG4gICAgICAgIGJyZWFrO1xyXG4gICAgICBjYXNlICdzZW1lc3Rlcic6XHJcbiAgICAgICAgaWYgKCFzdHJWYWwgfHwgcGFyc2VJbnQoc3RyVmFsKSA8IDEgfHwgcGFyc2VJbnQoc3RyVmFsKSA+IDIpIGVycm9yTXNnID0gJ1NlbWVzdGVyIG11c3QgYmUgMSBvciAyLic7XHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICAgIGNhc2UgJ21pbmltdW1DR1BBJzpcclxuICAgICAgICBpZiAoc3RyVmFsICE9PSAnJyAmJiAocGFyc2VGbG9hdChzdHJWYWwpIDwgMCB8fCBwYXJzZUZsb2F0KHN0clZhbCkgPiA0LjApKSBlcnJvck1zZyA9ICdDR1BBIG11c3QgYmUgYmV0d2VlbiAwLjAgYW5kIDQuMC4nO1xyXG4gICAgICAgIGJyZWFrO1xyXG4gICAgICBjYXNlICd3ZWVrbHlIb3Vycyc6XHJcbiAgICAgICAgaWYgKCFzdHJWYWwgfHwgcGFyc2VJbnQoc3RyVmFsKSA8IDEpIGVycm9yTXNnID0gJ1dlZWtseSBob3VycyBtdXN0IGJlIGF0IGxlYXN0IDEuJztcclxuICAgICAgICBicmVhaztcclxuICAgICAgY2FzZSAnZHVyYXRpb25XZWVrcyc6XHJcbiAgICAgICAgaWYgKCFzdHJWYWwgfHwgcGFyc2VJbnQoc3RyVmFsKSA8IDEpIGVycm9yTXNnID0gJ0R1cmF0aW9uIG11c3QgYmUgYXQgbGVhc3QgMSB3ZWVrLic7XHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gZXJyb3JNc2c7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQmx1ciA9IChlKSA9PiB7XHJcbiAgICBjb25zdCB7IG5hbWUsIHZhbHVlIH0gPSBlLnRhcmdldDtcclxuICAgIHNldFRvdWNoZWQoKHByZXYpID0+ICh7IC4uLnByZXYsIFtuYW1lXTogdHJ1ZSB9KSk7XHJcbiAgICBjb25zdCBlcnJvck1zZyA9IHZhbGlkYXRlRmllbGQobmFtZSwgdmFsdWUpO1xyXG4gICAgc2V0RXJyb3JzKChwcmV2KSA9PiAoeyAuLi5wcmV2LCBbbmFtZV06IGVycm9yTXNnIH0pKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVDaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyBuYW1lLCB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbiAgICBzZXRGb3JtRGF0YSgocHJldikgPT4gKHsgLi4ucHJldiwgW25hbWVdOiB2YWx1ZSB9KSk7XHJcbiAgICBpZiAodG91Y2hlZFtuYW1lXSkge1xyXG4gICAgICBzZXRFcnJvcnMoKHByZXYpID0+ICh7IC4uLnByZXYsIFtuYW1lXTogdmFsaWRhdGVGaWVsZChuYW1lLCB2YWx1ZSkgfSkpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZU5lc3RlZENoYW5nZSA9IChzZWN0aW9uLCBmaWVsZCwgdmFsdWUpID0+IHtcclxuICAgIHNldEZvcm1EYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAuLi5wcmV2LFxyXG4gICAgICBbc2VjdGlvbl06IHsgLi4ucHJldltzZWN0aW9uXSwgW2ZpZWxkXTogdmFsdWUgfVxyXG4gICAgfSkpO1xyXG4gICAgaWYgKHRvdWNoZWRbZmllbGRdKSB7XHJcbiAgICAgIHNldEVycm9ycygocHJldikgPT4gKHsgLi4ucHJldiwgW2ZpZWxkXTogdmFsaWRhdGVGaWVsZChmaWVsZCwgdmFsdWUpIH0pKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVOZXN0ZWRCbHVyID0gKHNlY3Rpb24sIGZpZWxkKSA9PiB7XHJcbiAgICBzZXRUb3VjaGVkKChwcmV2KSA9PiAoeyAuLi5wcmV2LCBbZmllbGRdOiB0cnVlIH0pKTtcclxuICAgIGNvbnN0IGVycm9yTXNnID0gdmFsaWRhdGVGaWVsZChmaWVsZCwgZm9ybURhdGFbc2VjdGlvbl1bZmllbGRdKTtcclxuICAgIHNldEVycm9ycygocHJldikgPT4gKHsgLi4ucHJldiwgW2ZpZWxkXTogZXJyb3JNc2cgfSkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVNraWxsQ2hhbmdlID0gKHR5cGUsIGNhdGVnb3J5LCBuZXdWYWx1ZXMpID0+IHtcclxuICAgIHNldEZvcm1EYXRhKChwcmV2KSA9PiB7XHJcbiAgICAgIGNvbnN0IHVwZGF0ZWREYXRhID0ge1xyXG4gICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgW3R5cGVdOiB7IC4uLnByZXZbdHlwZV0sIFtjYXRlZ29yeV06IG5ld1ZhbHVlcyB9XHJcbiAgICAgIH07XHJcbiAgICAgIFxyXG4gICAgICBpZiAodHlwZSA9PT0gJ2Vzc2VudGlhbFNraWxscycgJiYgdG91Y2hlZC5lc3NlbnRpYWxTa2lsbHMpIHtcclxuICAgICAgICBjb25zdCBoYXNFc3NlbnRpYWxTa2lsbHMgPSBPYmplY3QudmFsdWVzKHVwZGF0ZWREYXRhLmVzc2VudGlhbFNraWxscykuc29tZShhcnIgPT4gYXJyICYmIGFyci5sZW5ndGggPiAwKTtcclxuICAgICAgICBzZXRFcnJvcnMoZSA9PiAoe1xyXG4gICAgICAgICAgLi4uZSxcclxuICAgICAgICAgIGVzc2VudGlhbFNraWxsczogaGFzRXNzZW50aWFsU2tpbGxzID8gJycgOiBcIkVzc2VudGlhbCBTa2lsbHMgY2FuJ3QgYmUgZW1wdHkuXCJcclxuICAgICAgICB9KSk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIHJldHVybiB1cGRhdGVkRGF0YTtcclxuICAgIH0pO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IHZhbGlkYXRlQWxsID0gKCkgPT4ge1xyXG4gICAgY29uc3QgbmV3RXJyb3JzID0ge307XHJcbiAgICBjb25zdCB0ZXh0RmllbGRzID0gWyd0aXRsZScsICdkZXNjcmlwdGlvbicsICd0ZWFtU2l6ZScsICdwcm9qZWN0VHlwZScsICdtaW5pbXVtQ0dQQScsICdkdWVEYXRlJ107XHJcblxyXG4gICAgdGV4dEZpZWxkcy5mb3JFYWNoKGZpZWxkID0+IHtcclxuICAgICAgY29uc3QgZXJyID0gdmFsaWRhdGVGaWVsZChmaWVsZCwgZm9ybURhdGFbZmllbGRdKTtcclxuICAgICAgaWYgKGVycikgbmV3RXJyb3JzW2ZpZWxkXSA9IGVycjtcclxuICAgIH0pO1xyXG5cclxuICAgIGNvbnN0IG5lc3RlZEZpZWxkcyA9IFsnd2Vla2x5SG91cnMnLCAnZHVyYXRpb25XZWVrcyddO1xyXG4gICAgbmVzdGVkRmllbGRzLmZvckVhY2goZmllbGQgPT4ge1xyXG4gICAgICBjb25zdCBlcnIgPSB2YWxpZGF0ZUZpZWxkKGZpZWxkLCBmb3JtRGF0YS5hdmFpbGFiaWxpdHlSZXF1aXJlbWVudFtmaWVsZF0pO1xyXG4gICAgICBpZiAoZXJyKSBuZXdFcnJvcnNbZmllbGRdID0gZXJyO1xyXG4gICAgfSk7XHJcblxyXG4gICAgY29uc3QgaGFzRXNzZW50aWFsU2tpbGxzID0gT2JqZWN0LnZhbHVlcyhmb3JtRGF0YS5lc3NlbnRpYWxTa2lsbHMpLnNvbWUoYXJyID0+IGFyciAmJiBhcnIubGVuZ3RoID4gMCk7XHJcbiAgICBpZiAoIWhhc0Vzc2VudGlhbFNraWxscykge1xyXG4gICAgICBuZXdFcnJvcnMuZXNzZW50aWFsU2tpbGxzID0gXCJFc3NlbnRpYWwgU2tpbGxzIGNhbid0IGJlIGVtcHR5LlwiO1xyXG4gICAgfVxyXG5cclxuICAgIHNldEVycm9ycyhuZXdFcnJvcnMpO1xyXG5cclxuICAgIGNvbnN0IGFsbFRvdWNoZWQgPSB7fTtcclxuICAgIFsuLi50ZXh0RmllbGRzLCAuLi5uZXN0ZWRGaWVsZHMsICdlc3NlbnRpYWxTa2lsbHMnXS5mb3JFYWNoKGYgPT4gYWxsVG91Y2hlZFtmXSA9IHRydWUpO1xyXG4gICAgc2V0VG91Y2hlZChhbGxUb3VjaGVkKTtcclxuXHJcbiAgICBpZiAoZm9ybURhdGEuZG9tYWluLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgICBhbGVydCgnUGxlYXNlIHNlbGVjdCBhdCBsZWFzdCBvbmUgZG9tYWluLicpO1xyXG4gICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICB9XHJcbiAgICBpZiAoZm9ybURhdGEucmVxdWlyZWRSb2xlcy5sZW5ndGggPT09IDApIHtcclxuICAgICAgYWxlcnQoJ1BsZWFzZSBzZWxlY3QgYXQgbGVhc3Qgb25lIHJlcXVpcmVkIHJvbGUuJyk7XHJcbiAgICAgIHJldHVybiBmYWxzZTtcclxuICAgIH1cclxuICAgIGlmIChmb3JtRGF0YS5hdmFpbGFiaWxpdHlSZXF1aXJlbWVudC5tZWV0aW5nRGF5cy5sZW5ndGggPT09IDApIHtcclxuICAgICAgYWxlcnQoJ1BsZWFzZSBzZWxlY3QgYXQgbGVhc3Qgb25lIG1lZXRpbmcgZGF5LicpO1xyXG4gICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIE9iamVjdC5rZXlzKG5ld0Vycm9ycykubGVuZ3RoID09PSAwO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICBpZiAoIXZhbGlkYXRlQWxsKCkpIHtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goJ2h0dHA6Ly9sb2NhbGhvc3Q6MzAwMC9hcGkvcG9zdHMnLCB7XHJcbiAgICAgICAgbWV0aG9kOiAnUE9TVCcsXHJcbiAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyxcclxuICAgICAgICAgICd4LWF1dGgtdG9rZW4nOiB0b2tlblxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoZm9ybURhdGEpXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgaWYgKHJlc3BvbnNlLm9rKSB7XHJcbiAgICAgICAgaWYgKG9uU3VjY2Vzcykge1xyXG4gICAgICAgICAgb25TdWNjZXNzKCk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIGFsZXJ0KCdQcm9qZWN0IGNyZWF0ZWQgc3VjY2Vzc2Z1bGx5IScpO1xyXG4gICAgICAgICAgbmF2aWdhdGUoJy95b3VyLXByb2plY3RzJyk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGNvbnN0IGVycm9yRGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcclxuICAgICAgICBhbGVydChgRmFpbGVkIHRvIGNyZWF0ZSBwcm9qZWN0OiAke2Vycm9yRGF0YS5tc2cgfHwgJ1Vua25vd24gZXJyb3InfWApO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBjcmVhdGluZyBwcm9qZWN0OicsIGVycm9yKTtcclxuICAgICAgYWxlcnQoJ0FuIGVycm9yIG9jY3VycmVkIHdoaWxlIGNyZWF0aW5nIHRoZSBwcm9qZWN0LiBQbGVhc2UgY2hlY2sgdGhlIGNvbnNvbGUuJyk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgdG9kYXlTdHIgPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc3BsaXQoJ1QnKVswXTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5zZXJ0LXByb2plY3QtY29udGFpbmVyLWlwXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5zZXJ0LXByb2plY3QtY2FyZC1pcFwiPlxyXG4gICAgICAgIDxoMSBjbGFzc05hbWU9XCJpbnNlcnQtcHJvamVjdC10aXRsZS1pcFwiPkNyZWF0ZSBOZXcgUHJvamVjdDwvaDE+XHJcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwiaW5zZXJ0LXByb2plY3Qtc3VidGl0bGUtaXBcIj5Qb3N0IGEgbmV3IHByb2plY3Qgb3V0bGluZSB0byBmaW5kIHRoZSBwZXJmZWN0IHRlYW0gbWVtYmVycy48L3A+XHJcblxyXG4gICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9IGNsYXNzTmFtZT1cImluc2VydC1wcm9qZWN0LWZvcm0taXBcIiBub1ZhbGlkYXRlPlxyXG4gICAgICAgICAgey8qIFNlY3Rpb246IEJhc2ljIEluZm8gKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tc2VjdGlvbi1pcFwiPlxyXG4gICAgICAgICAgICA8aDI+QmFzaWMgSW5mb3JtYXRpb248L2gyPlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwLWlwXCI+XHJcbiAgICAgICAgICAgICAgPGxhYmVsPlByb2plY3QgVGl0bGUgKjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgbmFtZT1cInRpdGxlXCIgdmFsdWU9e2Zvcm1EYXRhLnRpdGxlfSBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfSBvbkJsdXI9e2hhbmRsZUJsdXJ9IGNsYXNzTmFtZT17dG91Y2hlZC50aXRsZSAmJiBlcnJvcnMudGl0bGUgPyAnaW5wdXQtZXJyb3ItaXAnIDogJyd9IHBsYWNlaG9sZGVyPVwiRW50ZXIgcHJvamVjdCB0aXRsZVwiIC8+XHJcbiAgICAgICAgICAgICAge3RvdWNoZWQudGl0bGUgJiYgZXJyb3JzLnRpdGxlICYmIDxzcGFuIGNsYXNzTmFtZT1cImVycm9yLW1lc3NhZ2UtaXBcIj57ZXJyb3JzLnRpdGxlfTwvc3Bhbj59XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwLWlwXCI+XHJcbiAgICAgICAgICAgICAgPGxhYmVsPkRlc2NyaXB0aW9uICo8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDx0ZXh0YXJlYSBuYW1lPVwiZGVzY3JpcHRpb25cIiB2YWx1ZT17Zm9ybURhdGEuZGVzY3JpcHRpb259IG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9IG9uQmx1cj17aGFuZGxlQmx1cn0gY2xhc3NOYW1lPXt0b3VjaGVkLmRlc2NyaXB0aW9uICYmIGVycm9ycy5kZXNjcmlwdGlvbiA/ICdpbnB1dC1lcnJvci1pcCcgOiAnJ30gcGxhY2Vob2xkZXI9XCJXaGF0IGlzIHRoaXMgcHJvamVjdCBhYm91dD8gUHJvdmlkZSBzb21lIGNvbnRleHQgYW5kIGdvYWxzLlwiPjwvdGV4dGFyZWE+XHJcbiAgICAgICAgICAgICAge3RvdWNoZWQuZGVzY3JpcHRpb24gJiYgZXJyb3JzLmRlc2NyaXB0aW9uICYmIDxzcGFuIGNsYXNzTmFtZT1cImVycm9yLW1lc3NhZ2UtaXBcIj57ZXJyb3JzLmRlc2NyaXB0aW9ufTwvc3Bhbj59XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLXJvdy1pcFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncm91cC1pcFwiPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsPlRlYW0gU2l6ZSAqPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwibnVtYmVyXCIgbmFtZT1cInRlYW1TaXplXCIgdmFsdWU9e2Zvcm1EYXRhLnRlYW1TaXplfSBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfSBvbkJsdXI9e2hhbmRsZUJsdXJ9IGNsYXNzTmFtZT17dG91Y2hlZC50ZWFtU2l6ZSAmJiBlcnJvcnMudGVhbVNpemUgPyAnaW5wdXQtZXJyb3ItaXAnIDogJyd9IG1pbj1cIjFcIiBwbGFjZWhvbGRlcj1cImUuZy4gNFwiIC8+XHJcbiAgICAgICAgICAgICAgICB7dG91Y2hlZC50ZWFtU2l6ZSAmJiBlcnJvcnMudGVhbVNpemUgJiYgPHNwYW4gY2xhc3NOYW1lPVwiZXJyb3ItbWVzc2FnZS1pcFwiPntlcnJvcnMudGVhbVNpemV9PC9zcGFuPn1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXAtaXBcIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbD5Qcm9qZWN0IFR5cGUgKjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8c2VsZWN0IG5hbWU9XCJwcm9qZWN0VHlwZVwiIHZhbHVlPXtmb3JtRGF0YS5wcm9qZWN0VHlwZX0gb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX0gb25CbHVyPXtoYW5kbGVCbHVyfSBjbGFzc05hbWU9e3RvdWNoZWQucHJvamVjdFR5cGUgJiYgZXJyb3JzLnByb2plY3RUeXBlID8gJ2lucHV0LWVycm9yLWlwJyA6ICcnfT5cclxuICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPlNlbGVjdCBUeXBlPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJSZXNlYXJjaFwiPlJlc2VhcmNoPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJEZXZlbG9wbWVudFwiPkRldmVsb3BtZW50PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJGaW5hbCBZZWFyIFByb2plY3RcIj5GaW5hbCBZZWFyIFByb2plY3Q8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkhhY2thdGhvblwiPkhhY2thdGhvbjwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiT3BlbiBTb3VyY2VcIj5PcGVuIFNvdXJjZTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICB7dG91Y2hlZC5wcm9qZWN0VHlwZSAmJiBlcnJvcnMucHJvamVjdFR5cGUgJiYgPHNwYW4gY2xhc3NOYW1lPVwiZXJyb3ItbWVzc2FnZS1pcFwiPntlcnJvcnMucHJvamVjdFR5cGV9PC9zcGFuPn1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXAtaXBcIj5cclxuICAgICAgICAgICAgICA8bGFiZWw+RHVlIERhdGUgKjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJkYXRlXCIgbmFtZT1cImR1ZURhdGVcIiB2YWx1ZT17Zm9ybURhdGEuZHVlRGF0ZX0gb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX0gb25CbHVyPXtoYW5kbGVCbHVyfSBtaW49e3RvZGF5U3RyfSBjbGFzc05hbWU9e3RvdWNoZWQuZHVlRGF0ZSAmJiBlcnJvcnMuZHVlRGF0ZSA/ICdpbnB1dC1lcnJvci1pcCcgOiAnJ30gLz5cclxuICAgICAgICAgICAgICB7dG91Y2hlZC5kdWVEYXRlICYmIGVycm9ycy5kdWVEYXRlICYmIDxzcGFuIGNsYXNzTmFtZT1cImVycm9yLW1lc3NhZ2UtaXBcIj57ZXJyb3JzLmR1ZURhdGV9PC9zcGFuPn1cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXAtaXBcIj5cclxuICAgICAgICAgICAgICA8bGFiZWw+RG9tYWluICo8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxDaGVja2JveEdyb3VwXHJcbiAgICAgICAgICAgICAgICBvcHRpb25zPXtbXCJXZWIgRGV2ZWxvcG1lbnRcIiwgXCJNb2JpbGUgRGV2ZWxvcG1lbnRcIiwgXCJBSSAvIE1MXCIsIFwiRGF0YSBTY2llbmNlXCIsIFwiQ3liZXJzZWN1cml0eVwiLCBcIkNsb3VkIENvbXB1dGluZ1wiLCBcIkdhbWUgRGV2ZWxvcG1lbnRcIiwgXCJJb1RcIiwgXCJCbG9ja2NoYWluXCIsIFwiRGV2T3BzXCJdfVxyXG4gICAgICAgICAgICAgICAgc2VsZWN0ZWRWYWx1ZXM9e2Zvcm1EYXRhLmRvbWFpbn1cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWVzKSA9PiBzZXRGb3JtRGF0YShwcmV2ID0+ICh7IC4uLnByZXYsIGRvbWFpbjogdmFsdWVzIH0pKX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIHsvKiBTZWN0aW9uOiBBY2FkZW1pYyBDb25zdHJhaW50cyAqL31cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1zZWN0aW9uLWlwXCI+XHJcbiAgICAgICAgICAgIDxoMj5BY2FkZW1pYyBEZXRhaWxzIChBdXRvLWZpbGxlZCBmcm9tIFByb2ZpbGUpPC9oMj5cclxuICAgICAgICAgICAgPHAgc3R5bGU9e3sgZm9udFNpemU6ICcxM3B4JywgY29sb3I6ICcjNjQ3NDhiJywgbWFyZ2luQm90dG9tOiAnMTZweCcgfX0+WW91ciBJVCBOdW1iZXIsIFNwZWNpYWxpemF0aW9uLCBZZWFyLCBhbmQgU2VtZXN0ZXIgYXJlIGF1dG9tYXRpY2FsbHkgbGlua2VkIHRvIHRoaXMgcHJvamVjdC48L3A+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1yb3ctaXBcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXAtaXBcIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbD5NaW5pbXVtIENHUEEgUmVxdWlyZW1lbnQgKE9wdGlvbmFsKTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cIm51bWJlclwiIHN0ZXA9XCIwLjAxXCIgbmFtZT1cIm1pbmltdW1DR1BBXCIgdmFsdWU9e2Zvcm1EYXRhLm1pbmltdW1DR1BBfSBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfSBvbkJsdXI9e2hhbmRsZUJsdXJ9IGNsYXNzTmFtZT17dG91Y2hlZC5taW5pbXVtQ0dQQSAmJiBlcnJvcnMubWluaW11bUNHUEEgPyAnaW5wdXQtZXJyb3ItaXAnIDogJyd9IHBsYWNlaG9sZGVyPVwiZS5nLiAzLjBcIiAvPlxyXG4gICAgICAgICAgICAgICAge3RvdWNoZWQubWluaW11bUNHUEEgJiYgZXJyb3JzLm1pbmltdW1DR1BBICYmIDxzcGFuIGNsYXNzTmFtZT1cImVycm9yLW1lc3NhZ2UtaXBcIj57ZXJyb3JzLm1pbmltdW1DR1BBfTwvc3Bhbj59XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgey8qIFNlY3Rpb246IEVzc2VudGlhbCBTa2lsbHMgKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tc2VjdGlvbi1pcFwiPlxyXG4gICAgICAgICAgICA8aDI+RXNzZW50aWFsIFNraWxscyAoTXVzdCBIYXZlKTwvaDI+XHJcbiAgICAgICAgICAgIHt0b3VjaGVkLmVzc2VudGlhbFNraWxscyAmJiBlcnJvcnMuZXNzZW50aWFsU2tpbGxzICYmIChcclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJlcnJvci1tZXNzYWdlLWlwXCIgc3R5bGU9e3sgZGlzcGxheTogJ2Jsb2NrJywgbWFyZ2luQm90dG9tOiAnMTVweCcgfX0+XHJcbiAgICAgICAgICAgICAgICB7ZXJyb3JzLmVzc2VudGlhbFNraWxsc31cclxuICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncm91cC1pcFwiPlxyXG4gICAgICAgICAgICAgIDxsYWJlbD5MYW5ndWFnZXMgKjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPENoZWNrYm94R3JvdXBcclxuICAgICAgICAgICAgICAgIG9wdGlvbnM9e1tcIkphdmFTY3JpcHRcIiwgXCJUeXBlU2NyaXB0XCIsIFwiUHl0aG9uXCIsIFwiSmF2YVwiLCBcIkNcIiwgXCJDKytcIiwgXCJDI1wiLCBcIkdvXCIsIFwiUnVzdFwiLCBcIktvdGxpblwiLCBcIlN3aWZ0XCIsIFwiUEhQXCIsIFwiUnVieVwiLCBcIkRhcnRcIiwgXCJSXCIsIFwiTUFUTEFCXCJdfVxyXG4gICAgICAgICAgICAgICAgc2VsZWN0ZWRWYWx1ZXM9e2Zvcm1EYXRhLmVzc2VudGlhbFNraWxscy5sYW5ndWFnZXN9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlcykgPT4gaGFuZGxlU2tpbGxDaGFuZ2UoJ2Vzc2VudGlhbFNraWxscycsICdsYW5ndWFnZXMnLCB2YWx1ZXMpfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXAtaXBcIj5cclxuICAgICAgICAgICAgICA8bGFiZWw+RnJhbWV3b3JrcyAqPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8Q2hlY2tib3hHcm91cFxyXG4gICAgICAgICAgICAgICAgb3B0aW9ucz17W1wiUmVhY3RcIiwgXCJBbmd1bGFyXCIsIFwiVnVlLmpzXCIsIFwiTmV4dC5qc1wiLCBcIk51eHQuanNcIiwgXCJOb2RlLmpzXCIsIFwiRXhwcmVzcy5qc1wiLCBcIkRqYW5nb1wiLCBcIkZsYXNrXCIsIFwiU3ByaW5nIEJvb3RcIiwgXCJBU1AuTkVUXCIsIFwiTGFyYXZlbFwiLCBcIlJ1Ynkgb24gUmFpbHNcIiwgXCJGbHV0dGVyXCIsIFwiUmVhY3QgTmF0aXZlXCJdfVxyXG4gICAgICAgICAgICAgICAgc2VsZWN0ZWRWYWx1ZXM9e2Zvcm1EYXRhLmVzc2VudGlhbFNraWxscy5mcmFtZXdvcmtzfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZXMpID0+IGhhbmRsZVNraWxsQ2hhbmdlKCdlc3NlbnRpYWxTa2lsbHMnLCAnZnJhbWV3b3JrcycsIHZhbHVlcyl9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncm91cC1pcFwiPlxyXG4gICAgICAgICAgICAgIDxsYWJlbD5EYXRhYmFzZXMgKjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPENoZWNrYm94R3JvdXBcclxuICAgICAgICAgICAgICAgIG9wdGlvbnM9e1tcIk1vbmdvREJcIiwgXCJNeVNRTFwiLCBcIlBvc3RncmVTUUxcIiwgXCJTUUxpdGVcIiwgXCJPcmFjbGVcIiwgXCJNaWNyb3NvZnQgU1FMIFNlcnZlclwiLCBcIkZpcmViYXNlXCIsIFwiUmVkaXNcIiwgXCJDYXNzYW5kcmFcIiwgXCJEeW5hbW9EQlwiLCBcIk5lbzRqXCJdfVxyXG4gICAgICAgICAgICAgICAgc2VsZWN0ZWRWYWx1ZXM9e2Zvcm1EYXRhLmVzc2VudGlhbFNraWxscy5kYXRhYmFzZXN9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlcykgPT4gaGFuZGxlU2tpbGxDaGFuZ2UoJ2Vzc2VudGlhbFNraWxscycsICdkYXRhYmFzZXMnLCB2YWx1ZXMpfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwLWlwXCI+XHJcbiAgICAgICAgICAgICAgPGxhYmVsPkxpYnJhcmllcyAqPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8Q2hlY2tib3hHcm91cFxyXG4gICAgICAgICAgICAgICAgb3B0aW9ucz17W1wiUmVkdXhcIiwgXCJBeGlvc1wiLCBcImpRdWVyeVwiLCBcIkxvZGFzaFwiLCBcIlRlbnNvckZsb3dcIiwgXCJLZXJhc1wiLCBcIlB5VG9yY2hcIiwgXCJTY2lraXQtbGVhcm5cIiwgXCJQYW5kYXNcIiwgXCJOdW1QeVwiLCBcIkNoYXJ0LmpzXCIsIFwiRDMuanNcIiwgXCJUaHJlZS5qc1wiLCBcIlNvY2tldC5pb1wiLCBcIkJvb3RzdHJhcFwiXX1cclxuICAgICAgICAgICAgICAgIHNlbGVjdGVkVmFsdWVzPXtmb3JtRGF0YS5lc3NlbnRpYWxTa2lsbHMubGlicmFyaWVzfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZXMpID0+IGhhbmRsZVNraWxsQ2hhbmdlKCdlc3NlbnRpYWxTa2lsbHMnLCAnbGlicmFyaWVzJywgdmFsdWVzKX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncm91cC1pcFwiPlxyXG4gICAgICAgICAgICAgIDxsYWJlbD5Ub29scyAqPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8Q2hlY2tib3hHcm91cFxyXG4gICAgICAgICAgICAgICAgb3B0aW9ucz17W1wiR2l0XCIsIFwiR2l0SHViXCIsIFwiR2l0TGFiXCIsIFwiRG9ja2VyXCIsIFwiS3ViZXJuZXRlc1wiLCBcIlBvc3RtYW5cIiwgXCJKaXJhXCIsIFwiVHJlbGxvXCIsIFwiRmlnbWFcIiwgXCJBZG9iZSBYRFwiLCBcIlZTIENvZGVcIiwgXCJJbnRlbGxpSiBJREVBXCIsIFwiRWNsaXBzZVwiLCBcIldlYnBhY2tcIiwgXCJCYWJlbFwiXX1cclxuICAgICAgICAgICAgICAgIHNlbGVjdGVkVmFsdWVzPXtmb3JtRGF0YS5lc3NlbnRpYWxTa2lsbHMudG9vbHN9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlcykgPT4gaGFuZGxlU2tpbGxDaGFuZ2UoJ2Vzc2VudGlhbFNraWxscycsICd0b29scycsIHZhbHVlcyl9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7LyogU2VjdGlvbjogT3B0aW9uYWwgU2tpbGxzICovfVxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLXNlY3Rpb24taXBcIj5cclxuICAgICAgICAgICAgPGgyPk9wdGlvbmFsIFNraWxscyAoTmljZSB0byBIYXZlKTwvaDI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncm91cC1pcFwiPlxyXG4gICAgICAgICAgICAgIDxsYWJlbD5MYW5ndWFnZXM8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxDaGVja2JveEdyb3VwXHJcbiAgICAgICAgICAgICAgICBvcHRpb25zPXtbXCJKYXZhU2NyaXB0XCIsIFwiVHlwZVNjcmlwdFwiLCBcIlB5dGhvblwiLCBcIkphdmFcIiwgXCJDXCIsIFwiQysrXCIsIFwiQyNcIiwgXCJHb1wiLCBcIlJ1c3RcIiwgXCJLb3RsaW5cIiwgXCJTd2lmdFwiLCBcIlBIUFwiLCBcIlJ1YnlcIiwgXCJEYXJ0XCIsIFwiUlwiLCBcIk1BVExBQlwiXX1cclxuICAgICAgICAgICAgICAgIHNlbGVjdGVkVmFsdWVzPXtmb3JtRGF0YS5vcHRpb25hbFNraWxscy5sYW5ndWFnZXN9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlcykgPT4gaGFuZGxlU2tpbGxDaGFuZ2UoJ29wdGlvbmFsU2tpbGxzJywgJ2xhbmd1YWdlcycsIHZhbHVlcyl9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncm91cC1pcFwiPlxyXG4gICAgICAgICAgICAgIDxsYWJlbD5GcmFtZXdvcmtzPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8Q2hlY2tib3hHcm91cFxyXG4gICAgICAgICAgICAgICAgb3B0aW9ucz17W1wiUmVhY3RcIiwgXCJBbmd1bGFyXCIsIFwiVnVlLmpzXCIsIFwiTmV4dC5qc1wiLCBcIk51eHQuanNcIiwgXCJOb2RlLmpzXCIsIFwiRXhwcmVzcy5qc1wiLCBcIkRqYW5nb1wiLCBcIkZsYXNrXCIsIFwiU3ByaW5nIEJvb3RcIiwgXCJBU1AuTkVUXCIsIFwiTGFyYXZlbFwiLCBcIlJ1Ynkgb24gUmFpbHNcIiwgXCJGbHV0dGVyXCIsIFwiUmVhY3QgTmF0aXZlXCJdfVxyXG4gICAgICAgICAgICAgICAgc2VsZWN0ZWRWYWx1ZXM9e2Zvcm1EYXRhLm9wdGlvbmFsU2tpbGxzLmZyYW1ld29ya3N9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlcykgPT4gaGFuZGxlU2tpbGxDaGFuZ2UoJ29wdGlvbmFsU2tpbGxzJywgJ2ZyYW1ld29ya3MnLCB2YWx1ZXMpfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXAtaXBcIj5cclxuICAgICAgICAgICAgICA8bGFiZWw+RGF0YWJhc2VzPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8Q2hlY2tib3hHcm91cFxyXG4gICAgICAgICAgICAgICAgb3B0aW9ucz17W1wiTW9uZ29EQlwiLCBcIk15U1FMXCIsIFwiUG9zdGdyZVNRTFwiLCBcIlNRTGl0ZVwiLCBcIk9yYWNsZVwiLCBcIk1pY3Jvc29mdCBTUUwgU2VydmVyXCIsIFwiRmlyZWJhc2VcIiwgXCJSZWRpc1wiLCBcIkNhc3NhbmRyYVwiLCBcIkR5bmFtb0RCXCIsIFwiTmVvNGpcIl19XHJcbiAgICAgICAgICAgICAgICBzZWxlY3RlZFZhbHVlcz17Zm9ybURhdGEub3B0aW9uYWxTa2lsbHMuZGF0YWJhc2VzfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZXMpID0+IGhhbmRsZVNraWxsQ2hhbmdlKCdvcHRpb25hbFNraWxscycsICdkYXRhYmFzZXMnLCB2YWx1ZXMpfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwLWlwXCI+XHJcbiAgICAgICAgICAgICAgPGxhYmVsPkxpYnJhcmllcyA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxDaGVja2JveEdyb3VwXHJcbiAgICAgICAgICAgICAgICBvcHRpb25zPXtbXCJSZWR1eFwiLCBcIkF4aW9zXCIsIFwialF1ZXJ5XCIsIFwiTG9kYXNoXCIsIFwiVGVuc29yRmxvd1wiLCBcIktlcmFzXCIsIFwiUHlUb3JjaFwiLCBcIlNjaWtpdC1sZWFyblwiLCBcIlBhbmRhc1wiLCBcIk51bVB5XCIsIFwiQ2hhcnQuanNcIiwgXCJEMy5qc1wiLCBcIlRocmVlLmpzXCIsIFwiU29ja2V0LmlvXCIsIFwiQm9vdHN0cmFwXCJdfVxyXG4gICAgICAgICAgICAgICAgc2VsZWN0ZWRWYWx1ZXM9e2Zvcm1EYXRhLm9wdGlvbmFsU2tpbGxzLmxpYnJhcmllc31cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWVzKSA9PiBoYW5kbGVTa2lsbENoYW5nZSgnb3B0aW9uYWxTa2lsbHMnLCAnbGlicmFyaWVzJywgdmFsdWVzKX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncm91cC1pcFwiPlxyXG4gICAgICAgICAgICAgIDxsYWJlbD5Ub29scyA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxDaGVja2JveEdyb3VwXHJcbiAgICAgICAgICAgICAgICBvcHRpb25zPXtbXCJHaXRcIiwgXCJHaXRIdWJcIiwgXCJHaXRMYWJcIiwgXCJEb2NrZXJcIiwgXCJLdWJlcm5ldGVzXCIsIFwiUG9zdG1hblwiLCBcIkppcmFcIiwgXCJUcmVsbG9cIiwgXCJGaWdtYVwiLCBcIkFkb2JlIFhEXCIsIFwiVlMgQ29kZVwiLCBcIkludGVsbGlKIElERUFcIiwgXCJFY2xpcHNlXCIsIFwiV2VicGFja1wiLCBcIkJhYmVsXCJdfVxyXG4gICAgICAgICAgICAgICAgc2VsZWN0ZWRWYWx1ZXM9e2Zvcm1EYXRhLm9wdGlvbmFsU2tpbGxzLnRvb2xzfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZXMpID0+IGhhbmRsZVNraWxsQ2hhbmdlKCdvcHRpb25hbFNraWxscycsICd0b29scycsIHZhbHVlcyl9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7LyogU2VjdGlvbjogUm9sZXMgJiBBdmFpbGFiaWxpdHkgKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tc2VjdGlvbi1pcFwiPlxyXG4gICAgICAgICAgICA8aDI+Um9sZXMgJiBBdmFpbGFiaWxpdHk8L2gyPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXAtaXBcIj5cclxuICAgICAgICAgICAgICA8bGFiZWw+UmVxdWlyZWQgUm9sZXMgKjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPENoZWNrYm94R3JvdXBcclxuICAgICAgICAgICAgICAgIG9wdGlvbnM9e1tcIkZyb250ZW5kIERldmVsb3BlclwiLCBcIkJhY2tlbmQgRGV2ZWxvcGVyXCIsIFwiRnVsbHN0YWNrIERldmVsb3BlclwiLCBcIk1vYmlsZSBBcHAgRGV2ZWxvcGVyXCIsIFwiTUwgRW5naW5lZXJcIiwgXCJEYXRhIFNjaWVudGlzdFwiLCBcIlVJL1VYIERlc2lnbmVyXCIsIFwiRGV2T3BzIEVuZ2luZWVyXCIsIFwiUUEgRW5naW5lZXJcIiwgXCJQcm9qZWN0IE1hbmFnZXJcIl19XHJcbiAgICAgICAgICAgICAgICBzZWxlY3RlZFZhbHVlcz17Zm9ybURhdGEucmVxdWlyZWRSb2xlc31cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWVzKSA9PiBzZXRGb3JtRGF0YShwcmV2ID0+ICh7IC4uLnByZXYsIHJlcXVpcmVkUm9sZXM6IHZhbHVlcyB9KSl9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tcm93LWlwXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwLWlwXCI+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWw+V2Vla2x5IEhvdXJzIFJlcXVpcmVkICo8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJudW1iZXJcIiBuYW1lPVwid2Vla2x5SG91cnNcIiB2YWx1ZT17Zm9ybURhdGEuYXZhaWxhYmlsaXR5UmVxdWlyZW1lbnQud2Vla2x5SG91cnN9IG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlTmVzdGVkQ2hhbmdlKCdhdmFpbGFiaWxpdHlSZXF1aXJlbWVudCcsICd3ZWVrbHlIb3VycycsIGUudGFyZ2V0LnZhbHVlKX0gb25CbHVyPXsoKSA9PiBoYW5kbGVOZXN0ZWRCbHVyKCdhdmFpbGFiaWxpdHlSZXF1aXJlbWVudCcsICd3ZWVrbHlIb3VycycpfSBjbGFzc05hbWU9e3RvdWNoZWQud2Vla2x5SG91cnMgJiYgZXJyb3JzLndlZWtseUhvdXJzID8gJ2lucHV0LWVycm9yLWlwJyA6ICcnfSBtaW49XCIxXCIgcGxhY2Vob2xkZXI9XCJlLmcuIDEwXCIgLz5cclxuICAgICAgICAgICAgICAgIHt0b3VjaGVkLndlZWtseUhvdXJzICYmIGVycm9ycy53ZWVrbHlIb3VycyAmJiA8c3BhbiBjbGFzc05hbWU9XCJlcnJvci1tZXNzYWdlLWlwXCI+e2Vycm9ycy53ZWVrbHlIb3Vyc308L3NwYW4+fVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncm91cC1pcFwiPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsPkR1cmF0aW9uIChXZWVrcykgKjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cIm51bWJlclwiIG5hbWU9XCJkdXJhdGlvbldlZWtzXCIgdmFsdWU9e2Zvcm1EYXRhLmF2YWlsYWJpbGl0eVJlcXVpcmVtZW50LmR1cmF0aW9uV2Vla3N9IG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlTmVzdGVkQ2hhbmdlKCdhdmFpbGFiaWxpdHlSZXF1aXJlbWVudCcsICdkdXJhdGlvbldlZWtzJywgZS50YXJnZXQudmFsdWUpfSBvbkJsdXI9eygpID0+IGhhbmRsZU5lc3RlZEJsdXIoJ2F2YWlsYWJpbGl0eVJlcXVpcmVtZW50JywgJ2R1cmF0aW9uV2Vla3MnKX0gY2xhc3NOYW1lPXt0b3VjaGVkLmR1cmF0aW9uV2Vla3MgJiYgZXJyb3JzLmR1cmF0aW9uV2Vla3MgPyAnaW5wdXQtZXJyb3ItaXAnIDogJyd9IG1pbj1cIjFcIiBwbGFjZWhvbGRlcj1cImUuZy4gMTJcIiAvPlxyXG4gICAgICAgICAgICAgICAge3RvdWNoZWQuZHVyYXRpb25XZWVrcyAmJiBlcnJvcnMuZHVyYXRpb25XZWVrcyAmJiA8c3BhbiBjbGFzc05hbWU9XCJlcnJvci1tZXNzYWdlLWlwXCI+e2Vycm9ycy5kdXJhdGlvbldlZWtzfTwvc3Bhbj59XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwLWlwXCI+XHJcbiAgICAgICAgICAgICAgPGxhYmVsPlByZWZlcnJlZCBNZWV0aW5nIERheXMgKjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPENoZWNrYm94R3JvdXBcclxuICAgICAgICAgICAgICAgIG9wdGlvbnM9e1snTW9uZGF5JywgJ1R1ZXNkYXknLCAnV2VkbmVzZGF5JywgJ1RodXJzZGF5JywgJ0ZyaWRheScsICdTYXR1cmRheScsICdTdW5kYXknXX1cclxuICAgICAgICAgICAgICAgIHNlbGVjdGVkVmFsdWVzPXtmb3JtRGF0YS5hdmFpbGFiaWxpdHlSZXF1aXJlbWVudC5tZWV0aW5nRGF5c31cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWVzKSA9PiBoYW5kbGVOZXN0ZWRDaGFuZ2UoJ2F2YWlsYWJpbGl0eVJlcXVpcmVtZW50JywgJ21lZXRpbmdEYXlzJywgdmFsdWVzKX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1hY3Rpb25zLWlwXCI+XHJcbiAgICAgICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiIGNsYXNzTmFtZT1cInN1Ym1pdC1idG4taXBcIj5DcmVhdGUgUHJvamVjdDwvYnV0dG9uPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9mb3JtPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBJbnNlcnRQcm9qZWN0OyJdLCJmaWxlIjoiRjovWTNTMi9JVFBNIHByb2plY3QvUHJvTWF0ZS0tUHJvamVjdC1QYXJ0bmVyLUZpbmRlci9mcm9udGVuZC9zcmMvcGFnZXMvUHJvamVjdHMvSW5zZXJ0UHJvamVjdC5qc3gifQ==