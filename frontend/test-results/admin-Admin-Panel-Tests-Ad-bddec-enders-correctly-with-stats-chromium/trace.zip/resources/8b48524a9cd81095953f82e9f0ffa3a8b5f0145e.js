import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Navbar.jsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=383bea9f"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import { Link, useLocation, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=383bea9f";
import { Home, PlusSquare, Bell, Folder, Users, LogOut, Star, Settings as SettingsIcon, ChevronRight, LayoutDashboard, Briefcase, MessageSquare, UserCircle } from "/node_modules/.vite/deps/lucide-react.js?v=383bea9f";
import { useAuth } from "/src/context/AuthContext.jsx";
import ProMateLogo from "/src/assets/images/logo.jpeg?import";
import DummyProfile from "/src/assets/images/pic1.jpeg?import";
import { calculateProfileCompleteness } from "/src/utils/profileUtils.js";
const Navbar = () => {
  _s();
  const location = useLocation();
  const navigate = useNavigate();
  const {
    user,
    logout
  } = useAuth();
  const handleLogout = () => {
    logout();
    navigate("/");
  };
  const getInitials = (name) => name ? name.split(" ").map((n) => n[0]).join("").substring(0, 2).toUpperCase() : "U";
  const {
    percentage: completion
  } = calculateProfileCompleteness(user);
  const navItems = [{
    text: "Dashboard",
    icon: /* @__PURE__ */ jsxDEV(LayoutDashboard, { size: 20 }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
      lineNumber: 31,
      columnNumber: 11
    }, this),
    path: "/dashboard",
    section: "Main"
  }, {
    text: "Discover Projects",
    icon: /* @__PURE__ */ jsxDEV(Briefcase, { size: 20 }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
      lineNumber: 36,
      columnNumber: 11
    }, this),
    path: "/all-projects",
    section: "Main"
  }, {
    text: "Notifications",
    icon: /* @__PURE__ */ jsxDEV(Bell, { size: 20 }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
      lineNumber: 41,
      columnNumber: 11
    }, this),
    badge: "3",
    path: "/notifications",
    section: "Main"
  }, {
    text: "Your projects",
    icon: /* @__PURE__ */ jsxDEV(Folder, { size: 20 }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
      lineNumber: 47,
      columnNumber: 11
    }, this),
    path: "/your-projects",
    section: "Work"
  }, {
    text: "Rate & Review",
    icon: /* @__PURE__ */ jsxDEV(Star, { size: 20 }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
      lineNumber: 52,
      columnNumber: 11
    }, this),
    path: "/feedbacks",
    section: "Work"
  }, {
    text: "Settings",
    icon: /* @__PURE__ */ jsxDEV(SettingsIcon, { size: 20 }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
      lineNumber: 57,
      columnNumber: 11
    }, this),
    path: "/settings",
    section: "Account"
  }];
  const teams = [{
    name: "ITPM project 0013",
    path: "/teams/itpm-0013",
    color: "bg-blue-500"
  }, {
    name: "PAF project 0018",
    path: "/teams/paf-0018",
    color: "bg-pink-500"
  }];
  return /* @__PURE__ */ jsxDEV("div", { className: "h-screen w-72 bg-white border-r border-gray-100 flex flex-col justify-between p-6 shadow-xl shadow-gray-200/50 z-50", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col h-full scrollbar-none overflow-y-auto", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center mb-10 gap-4 px-2", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "p-2 bg-gradient-to-br from-primary/10 to-secondary/10 rounded-2xl shadow-inner", children: /* @__PURE__ */ jsxDEV("img", { src: ProMateLogo, alt: "ProMate Logo", className: "w-10 h-10 rounded-xl object-cover" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
          lineNumber: 75,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
          lineNumber: 74,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-black tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-primary to-secondary", children: "ProMate" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
            lineNumber: 78,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[10px] font-bold text-gray-400 uppercase tracking-widest leading-none mt-1", children: "Project Partner Finder" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
            lineNumber: 79,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
          lineNumber: 77,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
        lineNumber: 73,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-8 flex-1", children: [
        /* @__PURE__ */ jsxDEV("section", { children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] font-bold text-gray-400 uppercase tracking-[0.2em] mb-4 ml-4", children: "Explore" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
            lineNumber: 87,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("nav", { className: "space-y-1.5", children: navItems.filter((i) => i.section === "Main").map((item) => /* @__PURE__ */ jsxDEV(Link, { to: item.path, children: /* @__PURE__ */ jsxDEV(NavItem, { icon: item.icon, text: item.text, badge: item.badge, active: location.pathname === item.path }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
            lineNumber: 90,
            columnNumber: 19
          }, this) }, item.text, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
            lineNumber: 89,
            columnNumber: 71
          }, this)) }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
            lineNumber: 88,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
          lineNumber: 86,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("section", { children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] font-bold text-gray-400 uppercase tracking-[0.2em] mb-4 ml-4", children: "My workspace" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
            lineNumber: 97,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("nav", { className: "space-y-1.5", children: navItems.filter((i) => i.section === "Work").map((item) => /* @__PURE__ */ jsxDEV(Link, { to: item.path, children: /* @__PURE__ */ jsxDEV(NavItem, { icon: item.icon, text: item.text, badge: item.badge, active: location.pathname === item.path }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
            lineNumber: 100,
            columnNumber: 19
          }, this) }, item.text, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
            lineNumber: 99,
            columnNumber: 71
          }, this)) }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
            lineNumber: 98,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
          lineNumber: 96,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("section", { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-4 ml-4 pr-2", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] font-bold text-gray-400 uppercase tracking-[0.2em]", children: "Active Teams" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
              lineNumber: 108,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(PlusSquare, { size: 14, className: "text-gray-400 cursor-pointer hover:text-primary transition-colors" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
              lineNumber: 109,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
            lineNumber: 107,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-1", children: teams.map((team) => /* @__PURE__ */ jsxDEV(Link, { to: team.path, className: "group block", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 px-4 py-2 rounded-xl hover:bg-gray-50 transition-all duration-200", children: [
            /* @__PURE__ */ jsxDEV("div", { className: `w-2 h-2 rounded-full ${team.color} group-hover:scale-125 transition-transform` }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
              lineNumber: 114,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-gray-600 group-hover:text-primary transition-colors truncate", children: team.name }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
              lineNumber: 115,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
            lineNumber: 113,
            columnNumber: 19
          }, this) }, team.name, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
            lineNumber: 112,
            columnNumber: 34
          }, this)) }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
            lineNumber: 111,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
          lineNumber: 106,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
        lineNumber: 84,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-auto pt-6 border-t border-gray-100 space-y-1", children: [
        /* @__PURE__ */ jsxDEV(Link, { to: "/settings", children: /* @__PURE__ */ jsxDEV(NavItem, { icon: /* @__PURE__ */ jsxDEV(SettingsIcon, { size: 18 }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
          lineNumber: 125,
          columnNumber: 28
        }, this), text: "Settings", active: location.pathname === "/settings" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
          lineNumber: 125,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
          lineNumber: 124,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { onClick: handleLogout, className: "group", children: /* @__PURE__ */ jsxDEV(NavItem, { icon: /* @__PURE__ */ jsxDEV(LogOut, { size: 18 }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
          lineNumber: 128,
          columnNumber: 28
        }, this), text: "Sign Out", className: "text-red-500 hover:bg-red-50 hover:text-red-600" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
          lineNumber: 128,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
          lineNumber: 127,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
        lineNumber: 123,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
      lineNumber: 71,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Link, { to: "/profile", className: "block", children: /* @__PURE__ */ jsxDEV("div", { className: "mt-8 p-4 bg-slate-50 rounded-3xl border border-slate-100 relative group overflow-hidden hover:bg-slate-100 transition-colors cursor-pointer", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "absolute top-0 right-0 p-3 opacity-0 group-hover:opacity-100 transition-opacity", children: /* @__PURE__ */ jsxDEV(ChevronRight, { size: 16, className: "text-gray-400" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
        lineNumber: 137,
        columnNumber: 12
      }, this) }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
        lineNumber: 136,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 mb-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
          /* @__PURE__ */ jsxDEV("img", { src: user?.profilePicture || DummyProfile, alt: "Profile", className: "w-12 h-12 rounded-2xl object-cover ring-2 ring-white shadow-md transition-transform group-hover:rotate-3" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
            lineNumber: 142,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 border-2 border-white rounded-full shadow-sm" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
            lineNumber: 143,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
          lineNumber: 141,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col min-w-0", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-bold text-gray-900 truncate tracking-tight", children: user?.fullName || "Student" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
            lineNumber: 146,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] font-medium text-gray-500 truncate", children: user?.email || "student@promate.com" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
            lineNumber: 147,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
          lineNumber: 145,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
        lineNumber: 140,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center text-[10px] font-bold uppercase tracking-wider", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-gray-400", children: "Profile Level" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
            lineNumber: 154,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "text-primary", children: [
            completion,
            "%"
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
            lineNumber: 155,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
          lineNumber: 153,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "w-full bg-gray-200/50 rounded-full h-1.5 p-[1px]", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-primary to-secondary h-full rounded-full transition-all duration-1000 ease-in-out shadow-sm shadow-primary/20", style: {
          width: `${completion}%`
        } }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
          lineNumber: 158,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
          lineNumber: 157,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
        lineNumber: 152,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
      lineNumber: 135,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
      lineNumber: 134,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
    lineNumber: 70,
    columnNumber: 10
  }, this);
};
_s(Navbar, "vx4Vs1TGsREAwP04TvjwNLgQSPQ=", false, function() {
  return [useLocation, useNavigate, useAuth];
});
_c = Navbar;
function NavItem({
  icon,
  text,
  active,
  badge,
  className = ""
}) {
  return /* @__PURE__ */ jsxDEV("div", { className: `flex items-center gap-3 px-4 py-3 rounded-2xl cursor-pointer transition-all duration-300 group relative ${active ? "bg-gradient-to-br from-primary/10 to-secondary/10 text-primary font-bold shadow-[0_4px_12px_rgba(59,130,246,0.08)]" : `text-gray-500 hover:bg-gray-50 hover:text-gray-900 ${className}`}`, children: [
    active && /* @__PURE__ */ jsxDEV("div", { className: "absolute left-0 top-1/4 bottom-1/4 w-1 bg-primary rounded-r-full" }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
      lineNumber: 182,
      columnNumber: 18
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: `transition-transform duration-300 group-hover:scale-110 ${active ? "text-primary" : "text-gray-400 group-hover:text-primary"}`, children: icon }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
      lineNumber: 184,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("span", { className: "text-[14px] flex-1 leading-none", children: text }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
      lineNumber: 188,
      columnNumber: 7
    }, this),
    badge && /* @__PURE__ */ jsxDEV("span", { className: "bg-primary text-white text-[10px] tabular-nums font-black min-w-[18px] h-[18px] flex items-center justify-center rounded-full shadow-lg shadow-primary/20", children: badge }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
      lineNumber: 190,
      columnNumber: 17
    }, this),
    !active && /* @__PURE__ */ jsxDEV(ChevronRight, { size: 14, className: "opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all text-gray-300" }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
      lineNumber: 194,
      columnNumber: 19
    }, this)
  ] }, void 0, true, {
    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx",
    lineNumber: 180,
    columnNumber: 10
  }, this);
}
_c2 = NavItem;
export default Navbar;
var _c, _c2;
$RefreshReg$(_c, "Navbar");
$RefreshReg$(_c2, "NavItem");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/Navbar.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUMrQjs7Ozs7Ozs7Ozs7Ozs7OztBQXZDL0IsT0FBT0EsV0FBVztBQUNsQixTQUFTQyxNQUFNQyxhQUFhQyxtQkFBbUI7QUFDL0MsU0FDRUMsTUFDQUMsWUFDQUMsTUFDQUMsUUFDQUMsT0FDQUMsUUFDQUMsTUFDQUMsWUFBWUMsY0FDWkMsY0FDQUMsaUJBQ0FDLFdBQ0FDLGVBQ0FDLGtCQUNLO0FBQ1AsU0FBU0MsZUFBZTtBQUN4QixPQUFPQyxpQkFBaUI7QUFDeEIsT0FBT0Msa0JBQWtCO0FBQ3pCLFNBQVNDLG9DQUFvQztBQUU3QyxNQUFNQyxTQUFTQSxNQUFNO0FBQUFDLEtBQUE7QUFDbkIsUUFBTUMsV0FBV3RCLFlBQVk7QUFDN0IsUUFBTXVCLFdBQVd0QixZQUFZO0FBQzdCLFFBQU07QUFBQSxJQUFFdUI7QUFBQUEsSUFBTUM7QUFBQUEsRUFBTyxJQUFJVCxRQUFRO0FBRWpDLFFBQU1VLGVBQWVBLE1BQU07QUFDekJELFdBQU87QUFDUEYsYUFBUyxHQUFHO0FBQUEsRUFDZDtBQUdBLFFBQU1JLGNBQWVDLFVBQVNBLE9BQU9BLEtBQUtDLE1BQU0sR0FBRyxFQUFFQyxJQUFJQyxPQUFLQSxFQUFFLENBQUMsQ0FBQyxFQUFFQyxLQUFLLEVBQUUsRUFBRUMsVUFBVSxHQUFHLENBQUMsRUFBRUMsWUFBWSxJQUFJO0FBRzdHLFFBQU07QUFBQSxJQUFFQyxZQUFZQztBQUFBQSxFQUFXLElBQUlqQiw2QkFBNkJLLElBQUk7QUFFcEUsUUFBTWEsV0FBVyxDQUNmO0FBQUEsSUFBRUMsTUFBTTtBQUFBLElBQWFDLE1BQU0sdUJBQUMsbUJBQWdCLE1BQU0sTUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwQjtBQUFBLElBQUtDLE1BQU07QUFBQSxJQUFjQyxTQUFTO0FBQUEsRUFBTyxHQUM5RjtBQUFBLElBQUVILE1BQU07QUFBQSxJQUFxQkMsTUFBTSx1QkFBQyxhQUFVLE1BQU0sTUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFvQjtBQUFBLElBQUtDLE1BQU07QUFBQSxJQUFpQkMsU0FBUztBQUFBLEVBQU8sR0FDbkc7QUFBQSxJQUFFSCxNQUFNO0FBQUEsSUFBaUJDLE1BQU0sdUJBQUMsUUFBSyxNQUFNLE1BQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFlO0FBQUEsSUFBS0csT0FBTztBQUFBLElBQUtGLE1BQU07QUFBQSxJQUFrQkMsU0FBUztBQUFBLEVBQU8sR0FDdkc7QUFBQSxJQUFFSCxNQUFNO0FBQUEsSUFBaUJDLE1BQU0sdUJBQUMsVUFBTyxNQUFNLE1BQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFpQjtBQUFBLElBQUtDLE1BQU07QUFBQSxJQUFrQkMsU0FBUztBQUFBLEVBQU8sR0FDN0Y7QUFBQSxJQUFFSCxNQUFNO0FBQUEsSUFBaUJDLE1BQU0sdUJBQUMsUUFBSyxNQUFNLE1BQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFlO0FBQUEsSUFBS0MsTUFBTTtBQUFBLElBQWNDLFNBQVM7QUFBQSxFQUFPLEdBQ3ZGO0FBQUEsSUFBRUgsTUFBTTtBQUFBLElBQVlDLE1BQU0sdUJBQUMsZ0JBQWEsTUFBTSxNQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXVCO0FBQUEsSUFBS0MsTUFBTTtBQUFBLElBQWFDLFNBQVM7QUFBQSxFQUFVLENBQUM7QUFHL0YsUUFBTUUsUUFBUSxDQUNaO0FBQUEsSUFBRWYsTUFBTTtBQUFBLElBQXFCWSxNQUFNO0FBQUEsSUFBb0JJLE9BQU87QUFBQSxFQUFjLEdBQzVFO0FBQUEsSUFBRWhCLE1BQU07QUFBQSxJQUFvQlksTUFBTTtBQUFBLElBQW1CSSxPQUFPO0FBQUEsRUFBYyxDQUFDO0FBRzdFLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLHVIQUNiO0FBQUEsMkJBQUMsU0FBSSxXQUFVLHVEQUViO0FBQUEsNkJBQUMsU0FBSSxXQUFVLHNDQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGtGQUNiLGlDQUFDLFNBQUksS0FBSzNCLGFBQWEsS0FBSSxnQkFBZSxXQUFVLHVDQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVGLEtBRHpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFFBQUcsV0FBVSwrR0FBOEcsdUJBQTVIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1JO0FBQUEsVUFDbkksdUJBQUMsT0FBRSxXQUFVLG1GQUFrRixzQ0FBL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUg7QUFBQSxhQUZ2SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxXQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxXQUFVLG9CQUViO0FBQUEsK0JBQUMsYUFDQztBQUFBLGlDQUFDLE9BQUUsV0FBVSw0RUFBMkUsdUJBQXhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStGO0FBQUEsVUFDL0YsdUJBQUMsU0FBSSxXQUFVLGVBQ1pvQixtQkFBU1EsT0FBT0MsT0FBS0EsRUFBRUwsWUFBWSxNQUFNLEVBQUVYLElBQUtpQixVQUMvQyx1QkFBQyxRQUFxQixJQUFJQSxLQUFLUCxNQUM3QixpQ0FBQyxXQUNDLE1BQU1PLEtBQUtSLE1BQ1gsTUFBTVEsS0FBS1QsTUFDWCxPQUFPUyxLQUFLTCxPQUNaLFFBQVFwQixTQUFTMEIsYUFBYUQsS0FBS1AsUUFKckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJMEMsS0FMakNPLEtBQUtULE1BQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0EsQ0FDRCxLQVZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBV0E7QUFBQSxhQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFjQTtBQUFBLFFBR0EsdUJBQUMsYUFDQztBQUFBLGlDQUFDLE9BQUUsV0FBVSw0RUFBMkUsNEJBQXhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9HO0FBQUEsVUFDcEcsdUJBQUMsU0FBSSxXQUFVLGVBQ1pELG1CQUFTUSxPQUFPQyxPQUFLQSxFQUFFTCxZQUFZLE1BQU0sRUFBRVgsSUFBS2lCLFVBQy9DLHVCQUFDLFFBQXFCLElBQUlBLEtBQUtQLE1BQzdCLGlDQUFDLFdBQ0MsTUFBTU8sS0FBS1IsTUFDWCxNQUFNUSxLQUFLVCxNQUNYLE9BQU9TLEtBQUtMLE9BQ1osUUFBUXBCLFNBQVMwQixhQUFhRCxLQUFLUCxRQUpyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUkwQyxLQUxqQ08sS0FBS1QsTUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQSxDQUNELEtBVkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFXQTtBQUFBLGFBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWNBO0FBQUEsUUFHQSx1QkFBQyxhQUNDO0FBQUEsaUNBQUMsU0FBSSxXQUFVLG9EQUNiO0FBQUEsbUNBQUMsT0FBRSxXQUFVLGtFQUFpRSw0QkFBOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEY7QUFBQSxZQUMxRix1QkFBQyxjQUFXLE1BQU0sSUFBSSxXQUFVLHVFQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtRztBQUFBLGVBRnJHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxhQUNaSyxnQkFBTWIsSUFBS21CLFVBQ1YsdUJBQUMsUUFBcUIsSUFBSUEsS0FBS1QsTUFBTSxXQUFVLGVBQzdDLGlDQUFDLFNBQUksV0FBVSw2RkFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVyx3QkFBd0JTLEtBQUtMLEtBQUssaURBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlHO0FBQUEsWUFDakcsdUJBQUMsVUFBSyxXQUFVLHlGQUF5RkssZUFBS3JCLFFBQTlHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1IO0FBQUEsZUFGckg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQSxLQUpTcUIsS0FBS3JCLE1BQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0EsQ0FDRCxLQVJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBU0E7QUFBQSxhQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFlQTtBQUFBLFdBbkRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFvREE7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSxtREFDYjtBQUFBLCtCQUFDLFFBQUssSUFBRyxhQUNQLGlDQUFDLFdBQVEsTUFBTSx1QkFBQyxnQkFBYSxNQUFNLE1BQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUIsR0FBSyxNQUFLLFlBQVcsUUFBUU4sU0FBUzBCLGFBQWEsZUFBekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxRyxLQUR2RztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFNBQUksU0FBU3RCLGNBQWMsV0FBVSxTQUNwQyxpQ0FBQyxXQUNDLE1BQU0sdUJBQUMsVUFBTyxNQUFNLE1BQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpQixHQUN2QixNQUFLLFlBQ0wsV0FBVSxxREFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRzZELEtBSi9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNQTtBQUFBLFdBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVdBO0FBQUEsU0EvRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWdGQTtBQUFBLElBR0EsdUJBQUMsUUFBSyxJQUFHLFlBQVcsV0FBVSxTQUM1QixpQ0FBQyxTQUFJLFdBQVUsK0lBQ2Y7QUFBQSw2QkFBQyxTQUFJLFdBQVUsbUZBQ1osaUNBQUMsZ0JBQWEsTUFBTSxJQUFJLFdBQVUsbUJBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUQsS0FEcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsZ0NBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsWUFDYjtBQUFBLGlDQUFDLFNBQ0MsS0FBS0YsTUFBTTBCLGtCQUFrQmhDLGNBQzdCLEtBQUksV0FDSixXQUFVLDhHQUhaO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR3NIO0FBQUEsVUFFdEgsdUJBQUMsU0FBSSxXQUFVLG1HQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStHO0FBQUEsYUFOakg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUseUJBQ2I7QUFBQSxpQ0FBQyxPQUFFLFdBQVUsMkRBQTJETSxnQkFBTTJCLFlBQVksYUFBMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0c7QUFBQSxVQUNwRyx1QkFBQyxPQUFFLFdBQVUsa0RBQWtEM0IsZ0JBQU00QixTQUFTLHlCQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvRztBQUFBLGFBRnRHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWFBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxvRkFDYjtBQUFBLGlDQUFDLFVBQUssV0FBVSxpQkFBZ0IsNkJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZDO0FBQUEsVUFDN0MsdUJBQUMsVUFBSyxXQUFVLGdCQUFnQmhCO0FBQUFBO0FBQUFBLFlBQVc7QUFBQSxlQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0QztBQUFBLGFBRjlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLG9EQUNiLGlDQUFDLFNBQ0MsV0FBVSx1SUFDVixPQUFPO0FBQUEsVUFBRWlCLE9BQU8sR0FBR2pCLFVBQVU7QUFBQSxRQUFJLEtBRm5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQyxLQUpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFdBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVdBO0FBQUEsU0FoQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlDRixLQWxDQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBbUNGO0FBQUEsT0F2SEE7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXdIRjtBQUVGO0FBRUFmLEdBM0pNRCxRQUFNO0FBQUEsVUFDT3BCLGFBQ0FDLGFBQ1FlLE9BQU87QUFBQTtBQUFBc0MsS0FINUJsQztBQTRKTixTQUFTbUMsUUFBUTtBQUFBLEVBQUVoQjtBQUFBQSxFQUFNRDtBQUFBQSxFQUFNa0I7QUFBQUEsRUFBUWQ7QUFBQUEsRUFBT2UsWUFBWTtBQUFHLEdBQUc7QUFDOUQsU0FDRSx1QkFBQyxTQUNDLFdBQVcsMkdBQ1RELFNBQ0ksdUhBQ0Esc0RBQXNEQyxTQUFTLEVBQUUsSUFJdEVEO0FBQUFBLGNBQ0MsdUJBQUMsU0FBSSxXQUFVLHNFQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBa0Y7QUFBQSxJQUdwRix1QkFBQyxTQUFJLFdBQVcsMkRBQTJEQSxTQUFTLGlCQUFpQix3Q0FBd0MsSUFDMUlqQixrQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUVBLHVCQUFDLFVBQUssV0FBVSxtQ0FBbUNELGtCQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXdEO0FBQUEsSUFFdkRJLFNBQ0MsdUJBQUMsVUFBSyxXQUFVLDZKQUNiQSxtQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUdELENBQUNjLFVBQ0EsdUJBQUMsZ0JBQWEsTUFBTSxJQUFJLFdBQVUsNkdBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMkk7QUFBQSxPQXpCL0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTJCQTtBQUVKO0FBQUNFLE1BL0JRSDtBQWlDVCxlQUFlbkM7QUFBTyxJQUFBa0MsSUFBQUk7QUFBQUMsYUFBQUwsSUFBQTtBQUFBSyxhQUFBRCxLQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJMaW5rIiwidXNlTG9jYXRpb24iLCJ1c2VOYXZpZ2F0ZSIsIkhvbWUiLCJQbHVzU3F1YXJlIiwiQmVsbCIsIkZvbGRlciIsIlVzZXJzIiwiTG9nT3V0IiwiU3RhciIsIlNldHRpbmdzIiwiU2V0dGluZ3NJY29uIiwiQ2hldnJvblJpZ2h0IiwiTGF5b3V0RGFzaGJvYXJkIiwiQnJpZWZjYXNlIiwiTWVzc2FnZVNxdWFyZSIsIlVzZXJDaXJjbGUiLCJ1c2VBdXRoIiwiUHJvTWF0ZUxvZ28iLCJEdW1teVByb2ZpbGUiLCJjYWxjdWxhdGVQcm9maWxlQ29tcGxldGVuZXNzIiwiTmF2YmFyIiwiX3MiLCJsb2NhdGlvbiIsIm5hdmlnYXRlIiwidXNlciIsImxvZ291dCIsImhhbmRsZUxvZ291dCIsImdldEluaXRpYWxzIiwibmFtZSIsInNwbGl0IiwibWFwIiwibiIsImpvaW4iLCJzdWJzdHJpbmciLCJ0b1VwcGVyQ2FzZSIsInBlcmNlbnRhZ2UiLCJjb21wbGV0aW9uIiwibmF2SXRlbXMiLCJ0ZXh0IiwiaWNvbiIsInBhdGgiLCJzZWN0aW9uIiwiYmFkZ2UiLCJ0ZWFtcyIsImNvbG9yIiwiZmlsdGVyIiwiaSIsIml0ZW0iLCJwYXRobmFtZSIsInRlYW0iLCJwcm9maWxlUGljdHVyZSIsImZ1bGxOYW1lIiwiZW1haWwiLCJ3aWR0aCIsIl9jIiwiTmF2SXRlbSIsImFjdGl2ZSIsImNsYXNzTmFtZSIsIl9jMiIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIk5hdmJhci5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBMaW5rLCB1c2VMb2NhdGlvbiwgdXNlTmF2aWdhdGUgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgeyBcclxuICBIb21lLCBcclxuICBQbHVzU3F1YXJlLCBcclxuICBCZWxsLCBcclxuICBGb2xkZXIsIFxyXG4gIFVzZXJzLCBcclxuICBMb2dPdXQsIFxyXG4gIFN0YXIsIFxyXG4gIFNldHRpbmdzIGFzIFNldHRpbmdzSWNvbixcclxuICBDaGV2cm9uUmlnaHQsXHJcbiAgTGF5b3V0RGFzaGJvYXJkLFxyXG4gIEJyaWVmY2FzZSxcclxuICBNZXNzYWdlU3F1YXJlLFxyXG4gIFVzZXJDaXJjbGVcclxufSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XHJcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tICcuLi9jb250ZXh0L0F1dGhDb250ZXh0JztcclxuaW1wb3J0IFByb01hdGVMb2dvIGZyb20gJy4uL2Fzc2V0cy9pbWFnZXMvbG9nby5qcGVnJztcclxuaW1wb3J0IER1bW15UHJvZmlsZSBmcm9tICcuLi9hc3NldHMvaW1hZ2VzL3BpYzEuanBlZyc7XHJcbmltcG9ydCB7IGNhbGN1bGF0ZVByb2ZpbGVDb21wbGV0ZW5lc3MgfSBmcm9tICcuLi91dGlscy9wcm9maWxlVXRpbHMnO1xyXG5cclxuY29uc3QgTmF2YmFyID0gKCkgPT4ge1xyXG4gIGNvbnN0IGxvY2F0aW9uID0gdXNlTG9jYXRpb24oKTtcclxuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XHJcbiAgY29uc3QgeyB1c2VyLCBsb2dvdXQgfSA9IHVzZUF1dGgoKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlTG9nb3V0ID0gKCkgPT4ge1xyXG4gICAgbG9nb3V0KCk7XHJcbiAgICBuYXZpZ2F0ZSgnLycpO1xyXG4gIH07XHJcblxyXG4gIC8vIEZ1bmN0aW9uIHRvIGdldCBpbml0aWFscyBpZiBubyBwcm9maWxlIHBpY3R1cmVcclxuICBjb25zdCBnZXRJbml0aWFscyA9IChuYW1lKSA9PiBuYW1lID8gbmFtZS5zcGxpdCgnICcpLm1hcChuID0+IG5bMF0pLmpvaW4oJycpLnN1YnN0cmluZygwLCAyKS50b1VwcGVyQ2FzZSgpIDogJ1UnO1xyXG5cclxuICAvLyBQcm9maWxlIGNvbXBsZXRpb24gc2NvcmVcclxuICBjb25zdCB7IHBlcmNlbnRhZ2U6IGNvbXBsZXRpb24gfSA9IGNhbGN1bGF0ZVByb2ZpbGVDb21wbGV0ZW5lc3ModXNlcik7XHJcblxyXG4gIGNvbnN0IG5hdkl0ZW1zID0gW1xyXG4gICAgeyB0ZXh0OiBcIkRhc2hib2FyZFwiLCBpY29uOiA8TGF5b3V0RGFzaGJvYXJkIHNpemU9ezIwfSAvPiwgcGF0aDogXCIvZGFzaGJvYXJkXCIsIHNlY3Rpb246IFwiTWFpblwiIH0sXHJcbiAgICB7IHRleHQ6IFwiRGlzY292ZXIgUHJvamVjdHNcIiwgaWNvbjogPEJyaWVmY2FzZSBzaXplPXsyMH0gLz4sIHBhdGg6IFwiL2FsbC1wcm9qZWN0c1wiLCBzZWN0aW9uOiBcIk1haW5cIiB9LFxyXG4gICAgeyB0ZXh0OiBcIk5vdGlmaWNhdGlvbnNcIiwgaWNvbjogPEJlbGwgc2l6ZT17MjB9IC8+LCBiYWRnZTogXCIzXCIsIHBhdGg6IFwiL25vdGlmaWNhdGlvbnNcIiwgc2VjdGlvbjogXCJNYWluXCIgfSxcclxuICAgIHsgdGV4dDogXCJZb3VyIHByb2plY3RzXCIsIGljb246IDxGb2xkZXIgc2l6ZT17MjB9IC8+LCBwYXRoOiBcIi95b3VyLXByb2plY3RzXCIsIHNlY3Rpb246IFwiV29ya1wiIH0sXHJcbiAgICB7IHRleHQ6IFwiUmF0ZSAmIFJldmlld1wiLCBpY29uOiA8U3RhciBzaXplPXsyMH0gLz4sIHBhdGg6IFwiL2ZlZWRiYWNrc1wiLCBzZWN0aW9uOiBcIldvcmtcIiB9LFxyXG4gICAgeyB0ZXh0OiBcIlNldHRpbmdzXCIsIGljb246IDxTZXR0aW5nc0ljb24gc2l6ZT17MjB9IC8+LCBwYXRoOiBcIi9zZXR0aW5nc1wiLCBzZWN0aW9uOiBcIkFjY291bnRcIiB9XHJcbiAgXTtcclxuXHJcbiAgY29uc3QgdGVhbXMgPSBbXHJcbiAgICB7IG5hbWU6IFwiSVRQTSBwcm9qZWN0IDAwMTNcIiwgcGF0aDogXCIvdGVhbXMvaXRwbS0wMDEzXCIsIGNvbG9yOiBcImJnLWJsdWUtNTAwXCIgfSxcclxuICAgIHsgbmFtZTogXCJQQUYgcHJvamVjdCAwMDE4XCIsIHBhdGg6IFwiL3RlYW1zL3BhZi0wMDE4XCIsIGNvbG9yOiBcImJnLXBpbmstNTAwXCIgfSxcclxuICBdO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJoLXNjcmVlbiB3LTcyIGJnLXdoaXRlIGJvcmRlci1yIGJvcmRlci1ncmF5LTEwMCBmbGV4IGZsZXgtY29sIGp1c3RpZnktYmV0d2VlbiBwLTYgc2hhZG93LXhsIHNoYWRvdy1ncmF5LTIwMC81MCB6LTUwXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBoLWZ1bGwgc2Nyb2xsYmFyLW5vbmUgb3ZlcmZsb3cteS1hdXRvXCI+XHJcbiAgICAgICAgey8qIExvZ28gU2VjdGlvbiAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIG1iLTEwIGdhcC00IHB4LTJcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yIGJnLWdyYWRpZW50LXRvLWJyIGZyb20tcHJpbWFyeS8xMCB0by1zZWNvbmRhcnkvMTAgcm91bmRlZC0yeGwgc2hhZG93LWlubmVyXCI+XHJcbiAgICAgICAgICAgIDxpbWcgc3JjPXtQcm9NYXRlTG9nb30gYWx0PVwiUHJvTWF0ZSBMb2dvXCIgY2xhc3NOYW1lPVwidy0xMCBoLTEwIHJvdW5kZWQteGwgb2JqZWN0LWNvdmVyXCIgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYmxhY2sgdHJhY2tpbmctdGlnaHQgYmctY2xpcC10ZXh0IHRleHQtdHJhbnNwYXJlbnQgYmctZ3JhZGllbnQtdG8tciBmcm9tLXByaW1hcnkgdG8tc2Vjb25kYXJ5XCI+UHJvTWF0ZTwvaDI+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LWdyYXktNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlc3QgbGVhZGluZy1ub25lIG10LTFcIj5Qcm9qZWN0IFBhcnRuZXIgRmluZGVyPC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHsvKiBOYXZpZ2F0aW9uIENhdGVnb3JpZXMgKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTggZmxleC0xXCI+XHJcbiAgICAgICAgICB7LyogTWFpbiBTZWN0aW9uICovfVxyXG4gICAgICAgICAgPHNlY3Rpb24+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtYm9sZCB0ZXh0LWdyYXktNDAwIHVwcGVyY2FzZSB0cmFja2luZy1bMC4yZW1dIG1iLTQgbWwtNFwiPkV4cGxvcmU8L3A+XHJcbiAgICAgICAgICAgIDxuYXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjVcIj5cclxuICAgICAgICAgICAgICB7bmF2SXRlbXMuZmlsdGVyKGkgPT4gaS5zZWN0aW9uID09PSBcIk1haW5cIikubWFwKChpdGVtKSA9PiAoXHJcbiAgICAgICAgICAgICAgICA8TGluayBrZXk9e2l0ZW0udGV4dH0gdG89e2l0ZW0ucGF0aH0+XHJcbiAgICAgICAgICAgICAgICAgIDxOYXZJdGVtXHJcbiAgICAgICAgICAgICAgICAgICAgaWNvbj17aXRlbS5pY29ufVxyXG4gICAgICAgICAgICAgICAgICAgIHRleHQ9e2l0ZW0udGV4dH1cclxuICAgICAgICAgICAgICAgICAgICBiYWRnZT17aXRlbS5iYWRnZX1cclxuICAgICAgICAgICAgICAgICAgICBhY3RpdmU9e2xvY2F0aW9uLnBhdGhuYW1lID09PSBpdGVtLnBhdGh9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvbmF2PlxyXG4gICAgICAgICAgPC9zZWN0aW9uPlxyXG5cclxuICAgICAgICAgIHsvKiBXb3JrIFNlY3Rpb24gKi99XHJcbiAgICAgICAgICA8c2VjdGlvbj5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1ib2xkIHRleHQtZ3JheS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLVswLjJlbV0gbWItNCBtbC00XCI+TXkgd29ya3NwYWNlPC9wPlxyXG4gICAgICAgICAgICA8bmF2IGNsYXNzTmFtZT1cInNwYWNlLXktMS41XCI+XHJcbiAgICAgICAgICAgICAge25hdkl0ZW1zLmZpbHRlcihpID0+IGkuc2VjdGlvbiA9PT0gXCJXb3JrXCIpLm1hcCgoaXRlbSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgPExpbmsga2V5PXtpdGVtLnRleHR9IHRvPXtpdGVtLnBhdGh9PlxyXG4gICAgICAgICAgICAgICAgICA8TmF2SXRlbVxyXG4gICAgICAgICAgICAgICAgICAgIGljb249e2l0ZW0uaWNvbn1cclxuICAgICAgICAgICAgICAgICAgICB0ZXh0PXtpdGVtLnRleHR9XHJcbiAgICAgICAgICAgICAgICAgICAgYmFkZ2U9e2l0ZW0uYmFkZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgYWN0aXZlPXtsb2NhdGlvbi5wYXRobmFtZSA9PT0gaXRlbS5wYXRofVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICA8L25hdj5cclxuICAgICAgICAgIDwvc2VjdGlvbj5cclxuXHJcbiAgICAgICAgICB7LyogVGVhbXMgU2VjdGlvbiAqL31cclxuICAgICAgICAgIDxzZWN0aW9uPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi00IG1sLTQgcHItMlwiPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtYm9sZCB0ZXh0LWdyYXktNDAwIHVwcGVyY2FzZSB0cmFja2luZy1bMC4yZW1dXCI+QWN0aXZlIFRlYW1zPC9wPlxyXG4gICAgICAgICAgICAgIDxQbHVzU3F1YXJlIHNpemU9ezE0fSBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNDAwIGN1cnNvci1wb2ludGVyIGhvdmVyOnRleHQtcHJpbWFyeSB0cmFuc2l0aW9uLWNvbG9yc1wiIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMVwiPlxyXG4gICAgICAgICAgICAgIHt0ZWFtcy5tYXAoKHRlYW0pID0+IChcclxuICAgICAgICAgICAgICAgIDxMaW5rIGtleT17dGVhbS5uYW1lfSB0bz17dGVhbS5wYXRofSBjbGFzc05hbWU9XCJncm91cCBibG9ja1wiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHB4LTQgcHktMiByb3VuZGVkLXhsIGhvdmVyOmJnLWdyYXktNTAgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2B3LTIgaC0yIHJvdW5kZWQtZnVsbCAke3RlYW0uY29sb3J9IGdyb3VwLWhvdmVyOnNjYWxlLTEyNSB0cmFuc2l0aW9uLXRyYW5zZm9ybWB9PjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTYwMCBncm91cC1ob3Zlcjp0ZXh0LXByaW1hcnkgdHJhbnNpdGlvbi1jb2xvcnMgdHJ1bmNhdGVcIj57dGVhbS5uYW1lfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9zZWN0aW9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogQWN0aW9uIFNlY3Rpb24gKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC1hdXRvIHB0LTYgYm9yZGVyLXQgYm9yZGVyLWdyYXktMTAwIHNwYWNlLXktMVwiPlxyXG4gICAgICAgICAgPExpbmsgdG89XCIvc2V0dGluZ3NcIj5cclxuICAgICAgICAgICAgPE5hdkl0ZW0gaWNvbj17PFNldHRpbmdzSWNvbiBzaXplPXsxOH0gLz59IHRleHQ9XCJTZXR0aW5nc1wiIGFjdGl2ZT17bG9jYXRpb24ucGF0aG5hbWUgPT09IFwiL3NldHRpbmdzXCJ9IC8+XHJcbiAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICA8ZGl2IG9uQ2xpY2s9e2hhbmRsZUxvZ291dH0gY2xhc3NOYW1lPVwiZ3JvdXBcIj5cclxuICAgICAgICAgICAgPE5hdkl0ZW0gXHJcbiAgICAgICAgICAgICAgaWNvbj17PExvZ091dCBzaXplPXsxOH0gLz59IFxyXG4gICAgICAgICAgICAgIHRleHQ9XCJTaWduIE91dFwiIFxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBob3ZlcjpiZy1yZWQtNTAgaG92ZXI6dGV4dC1yZWQtNjAwXCIgXHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7LyogUHJvZmlsZSBDYXJkICovfVxyXG4gICAgICA8TGluayB0bz1cIi9wcm9maWxlXCIgY2xhc3NOYW1lPVwiYmxvY2tcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTggcC00IGJnLXNsYXRlLTUwIHJvdW5kZWQtM3hsIGJvcmRlciBib3JkZXItc2xhdGUtMTAwIHJlbGF0aXZlIGdyb3VwIG92ZXJmbG93LWhpZGRlbiBob3ZlcjpiZy1zbGF0ZS0xMDAgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC0wIHJpZ2h0LTAgcC0zIG9wYWNpdHktMCBncm91cC1ob3ZlcjpvcGFjaXR5LTEwMCB0cmFuc2l0aW9uLW9wYWNpdHlcIj5cclxuICAgICAgICAgICA8Q2hldnJvblJpZ2h0IHNpemU9ezE2fSBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNDAwXCIgLz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICBcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIG1iLTRcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cclxuICAgICAgICAgICAgPGltZ1xyXG4gICAgICAgICAgICAgIHNyYz17dXNlcj8ucHJvZmlsZVBpY3R1cmUgfHwgRHVtbXlQcm9maWxlfVxyXG4gICAgICAgICAgICAgIGFsdD1cIlByb2ZpbGVcIlxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMTIgaC0xMiByb3VuZGVkLTJ4bCBvYmplY3QtY292ZXIgcmluZy0yIHJpbmctd2hpdGUgc2hhZG93LW1kIHRyYW5zaXRpb24tdHJhbnNmb3JtIGdyb3VwLWhvdmVyOnJvdGF0ZS0zXCJcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSAtYm90dG9tLTEgLXJpZ2h0LTEgdy00IGgtNCBiZy1ncmVlbi01MDAgYm9yZGVyLTIgYm9yZGVyLXdoaXRlIHJvdW5kZWQtZnVsbCBzaGFkb3ctc21cIj48L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIG1pbi13LTBcIj5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCB0cnVuY2F0ZSB0cmFja2luZy10aWdodFwiPnt1c2VyPy5mdWxsTmFtZSB8fCAnU3R1ZGVudCd9PC9wPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIHRydW5jYXRlXCI+e3VzZXI/LmVtYWlsIHx8ICdzdHVkZW50QHByb21hdGUuY29tJ308L3A+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgey8qIENvbXBsZXRpb24gUHJvZ3Jlc3MgKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIHRleHQtWzEwcHhdIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTQwMFwiPlByb2ZpbGUgTGV2ZWw8L3NwYW4+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcHJpbWFyeVwiPntjb21wbGV0aW9ufSU8L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGJnLWdyYXktMjAwLzUwIHJvdW5kZWQtZnVsbCBoLTEuNSBwLVsxcHhdXCI+XHJcbiAgICAgICAgICAgIDxkaXYgXHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JhZGllbnQtdG8tciBmcm9tLXByaW1hcnkgdG8tc2Vjb25kYXJ5IGgtZnVsbCByb3VuZGVkLWZ1bGwgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMTAwMCBlYXNlLWluLW91dCBzaGFkb3ctc20gc2hhZG93LXByaW1hcnkvMjBcIiBcclxuICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogYCR7Y29tcGxldGlvbn0lYCB9fVxyXG4gICAgICAgICAgICA+PC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L0xpbms+XHJcbiAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbi8qIEltcHJvdmVkIE5hdiBJdGVtICovXHJcbmZ1bmN0aW9uIE5hdkl0ZW0oeyBpY29uLCB0ZXh0LCBhY3RpdmUsIGJhZGdlLCBjbGFzc05hbWUgPSBcIlwiIH0pIHtcclxuICByZXR1cm4gKFxyXG4gICAgPGRpdlxyXG4gICAgICBjbGFzc05hbWU9e2BmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBweC00IHB5LTMgcm91bmRlZC0yeGwgY3Vyc29yLXBvaW50ZXIgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIGdyb3VwIHJlbGF0aXZlICR7XHJcbiAgICAgICAgYWN0aXZlXHJcbiAgICAgICAgICA/IFwiYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1wcmltYXJ5LzEwIHRvLXNlY29uZGFyeS8xMCB0ZXh0LXByaW1hcnkgZm9udC1ib2xkIHNoYWRvdy1bMF80cHhfMTJweF9yZ2JhKDU5LDEzMCwyNDYsMC4wOCldXCJcclxuICAgICAgICAgIDogYHRleHQtZ3JheS01MDAgaG92ZXI6YmctZ3JheS01MCBob3Zlcjp0ZXh0LWdyYXktOTAwICR7Y2xhc3NOYW1lfWBcclxuICAgICAgfWB9XHJcbiAgICA+XHJcbiAgICAgIHsvKiBBY3RpdmUgSW5kaWNhdG9yIFN0cmlwICovfVxyXG4gICAgICB7YWN0aXZlICYmIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGxlZnQtMCB0b3AtMS80IGJvdHRvbS0xLzQgdy0xIGJnLXByaW1hcnkgcm91bmRlZC1yLWZ1bGxcIj48L2Rpdj5cclxuICAgICAgKX1cclxuICAgICAgXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tMzAwIGdyb3VwLWhvdmVyOnNjYWxlLTExMCAke2FjdGl2ZSA/IFwidGV4dC1wcmltYXJ5XCIgOiBcInRleHQtZ3JheS00MDAgZ3JvdXAtaG92ZXI6dGV4dC1wcmltYXJ5XCJ9YH0+XHJcbiAgICAgICAge2ljb259XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICBcclxuICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTRweF0gZmxleC0xIGxlYWRpbmctbm9uZVwiPnt0ZXh0fTwvc3Bhbj5cclxuICAgICAgXHJcbiAgICAgIHtiYWRnZSAmJiAoXHJcbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmctcHJpbWFyeSB0ZXh0LXdoaXRlIHRleHQtWzEwcHhdIHRhYnVsYXItbnVtcyBmb250LWJsYWNrIG1pbi13LVsxOHB4XSBoLVsxOHB4XSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLWZ1bGwgc2hhZG93LWxnIHNoYWRvdy1wcmltYXJ5LzIwXCI+XHJcbiAgICAgICAgICB7YmFkZ2V9XHJcbiAgICAgICAgPC9zcGFuPlxyXG4gICAgICApfVxyXG5cclxuICAgICAgeyFhY3RpdmUgJiYgKFxyXG4gICAgICAgIDxDaGV2cm9uUmlnaHQgc2l6ZT17MTR9IGNsYXNzTmFtZT1cIm9wYWNpdHktMCAtdHJhbnNsYXRlLXgtMiBncm91cC1ob3ZlcjpvcGFjaXR5LTEwMCBncm91cC1ob3Zlcjp0cmFuc2xhdGUteC0wIHRyYW5zaXRpb24tYWxsIHRleHQtZ3JheS0zMDBcIiAvPlxyXG4gICAgICApfVxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgTmF2YmFyOyJdLCJmaWxlIjoiRjovWTNTMi9JVFBNIHByb2plY3QvUHJvTWF0ZS0tUHJvamVjdC1QYXJ0bmVyLUZpbmRlci9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9OYXZiYXIuanN4In0=