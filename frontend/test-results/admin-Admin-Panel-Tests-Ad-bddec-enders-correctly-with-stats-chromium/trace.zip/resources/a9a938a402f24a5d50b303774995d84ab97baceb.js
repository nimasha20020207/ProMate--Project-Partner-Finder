import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/FAQChatbot.jsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/FAQChatbot.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=383bea9f"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"];
const FAQChatbot = () => {
  _s();
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState([]);
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef(null);
  const faqs = [{
    question: "How do I find project partners?",
    answer: "Head over to your Dashboard! You can browse through the list of registered students who are also looking for project teammates."
  }, {
    question: "How do I update my profile?",
    answer: "Click on 'My Profile' in the sidebar, and hit 'Edit Profile'. Don't forget to link your GitHub so we can show off your live stats!"
  }, {
    question: "What is Profile Completeness?",
    answer: "The Profile Completeness percentage carefully tracks how well you've filled out your information. Add more skills, roles, and availability to reach a full 100% and stand out!"
  }, {
    question: "How do I show my GitHub stats?",
    answer: "Go to 'Edit Profile' and paste your valid GitHub username or full URL in the Social Links section. We will automatically generate live commits and repository charts!"
  }, {
    question: "Can I change my Student ID/Email?",
    answer: "Currently, your university email and Student ID are strictly tied to your account upon registration to guarantee that all users are authentic students."
  }, {
    question: "I forgot my password",
    answer: "While logged out, click 'Forgot Password' on the login screen. You will instantly receive a secure, 6-digit verification OTP to your registered university email to reset it."
  }];
  useEffect(() => {
    if (isOpen && messages.length === 0) {
      setMessages([{
        sender: "bot",
        text: "Hi there! 👋 I'm your ProMate Assistant. Choose a common question below, and I'll help you out!"
      }]);
    }
  }, [isOpen, messages]);
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({
      behavior: "smooth"
    });
  }, [messages, isTyping]);
  const handleOptionClick = (faq) => {
    setMessages((prev) => [...prev, {
      sender: "user",
      text: faq.question
    }]);
    setIsTyping(true);
    setTimeout(() => {
      setIsTyping(false);
      setMessages((prev) => [...prev, {
        sender: "bot",
        text: faq.answer
      }]);
    }, 800);
  };
  return /* @__PURE__ */ jsxDEV("div", { style: {
    position: "fixed",
    bottom: "2rem",
    right: "2rem",
    zIndex: 9999,
    fontFamily: "'Sora', sans-serif"
  }, children: [
    isOpen && /* @__PURE__ */ jsxDEV("div", { className: "chatbot-container", style: {
      width: "350px",
      height: "480px",
      backgroundColor: "#ffffff",
      borderRadius: "16px",
      boxShadow: "0 10px 25px rgba(0,0,0,0.1), 0 5px 10px rgba(0,0,0,0.05)",
      display: "flex",
      flexDirection: "column",
      marginBottom: "1rem",
      overflow: "hidden",
      border: "1px solid #e2e8f0",
      animation: "chatBubbleAppear 0.3s ease-out"
    }, children: [
      /* @__PURE__ */ jsxDEV("div", { style: {
        backgroundColor: "#2563eb",
        color: "white",
        padding: "1rem",
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center"
      }, children: [
        /* @__PURE__ */ jsxDEV("div", { style: {
          display: "flex",
          alignItems: "center",
          gap: "8px"
        }, children: [
          /* @__PURE__ */ jsxDEV("div", { style: {
            fontSize: "1.5rem"
          }, children: "🤖" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/FAQChatbot.jsx",
            lineNumber: 89,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("div", { style: {
              fontWeight: 700,
              fontSize: "0.95rem"
            }, children: "ProMate Assistant" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/FAQChatbot.jsx",
              lineNumber: 93,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { style: {
              fontSize: "0.7rem",
              color: "#bfdbfe",
              display: "flex",
              alignItems: "center",
              gap: "4px"
            }, children: [
              /* @__PURE__ */ jsxDEV("span", { style: {
                width: "8px",
                height: "8px",
                backgroundColor: "#4ade80",
                borderRadius: "50%",
                display: "inline-block"
              } }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/FAQChatbot.jsx",
                lineNumber: 104,
                columnNumber: 19
              }, this),
              "Online"
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/FAQChatbot.jsx",
              lineNumber: 97,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/FAQChatbot.jsx",
            lineNumber: 92,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/FAQChatbot.jsx",
          lineNumber: 84,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("button", { onClick: () => setIsOpen(false), style: {
          background: "transparent",
          border: "none",
          color: "white",
          cursor: "pointer",
          fontSize: "1.5rem",
          lineHeight: 1,
          opacity: 0.8
        }, onMouseOver: (e) => e.currentTarget.style.opacity = 1, onMouseOut: (e) => e.currentTarget.style.opacity = 0.8, children: "×" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/FAQChatbot.jsx",
          lineNumber: 115,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/FAQChatbot.jsx",
        lineNumber: 76,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: {
        flex: 1,
        padding: "1rem",
        overflowY: "auto",
        backgroundColor: "#f8fafc",
        display: "flex",
        flexDirection: "column",
        gap: "12px"
      }, children: [
        messages.map((msg, idx) => /* @__PURE__ */ jsxDEV("div", { style: {
          alignSelf: msg.sender === "user" ? "flex-end" : "flex-start",
          backgroundColor: msg.sender === "user" ? "#2563eb" : "#ffffff",
          color: msg.sender === "user" ? "white" : "#1e293b",
          padding: "10px 14px",
          borderRadius: "12px",
          borderBottomRightRadius: msg.sender === "user" ? "2px" : "12px",
          borderBottomLeftRadius: msg.sender === "bot" ? "2px" : "12px",
          maxWidth: "85%",
          fontSize: "0.85rem",
          lineHeight: 1.5,
          boxShadow: "0 1px 2px rgba(0,0,0,0.05)",
          border: msg.sender === "bot" ? "1px solid #e2e8f0" : "none"
        }, children: msg.text }, idx, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/FAQChatbot.jsx",
          lineNumber: 138,
          columnNumber: 41
        }, this)),
        isTyping && /* @__PURE__ */ jsxDEV("div", { style: {
          alignSelf: "flex-start",
          backgroundColor: "#ffffff",
          padding: "10px 14px",
          borderRadius: "12px",
          borderBottomLeftRadius: "2px",
          border: "1px solid #e2e8f0",
          display: "flex",
          gap: "4px"
        }, children: [
          /* @__PURE__ */ jsxDEV("span", { style: {
            width: "6px",
            height: "6px",
            backgroundColor: "#94a3b8",
            borderRadius: "50%",
            animation: "chatbotBlink 1.4s infinite both"
          } }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/FAQChatbot.jsx",
            lineNumber: 165,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("span", { style: {
            width: "6px",
            height: "6px",
            backgroundColor: "#94a3b8",
            borderRadius: "50%",
            animation: "chatbotBlink 1.4s infinite both 0.2s"
          } }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/FAQChatbot.jsx",
            lineNumber: 172,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("span", { style: {
            width: "6px",
            height: "6px",
            backgroundColor: "#94a3b8",
            borderRadius: "50%",
            animation: "chatbotBlink 1.4s infinite both 0.4s"
          } }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/FAQChatbot.jsx",
            lineNumber: 179,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/FAQChatbot.jsx",
          lineNumber: 155,
          columnNumber: 26
        }, this),
        /* @__PURE__ */ jsxDEV("div", { ref: messagesEndRef }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/FAQChatbot.jsx",
          lineNumber: 187,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/FAQChatbot.jsx",
        lineNumber: 129,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { style: {
        padding: "0.75rem 1rem",
        backgroundColor: "#ffffff",
        borderTop: "1px solid #e2e8f0"
      }, children: [
        /* @__PURE__ */ jsxDEV("div", { style: {
          fontSize: "0.7rem",
          fontWeight: 600,
          color: "#64748b",
          marginBottom: "8px",
          textTransform: "uppercase"
        }, children: "Frequently Asked" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/FAQChatbot.jsx",
          lineNumber: 196,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: {
          display: "flex",
          flexDirection: "column",
          gap: "6px"
        }, children: faqs.map((faq, idx) => /* @__PURE__ */ jsxDEV("button", { onClick: () => handleOptionClick(faq), disabled: isTyping, style: {
          textAlign: "left",
          padding: "8px 12px",
          backgroundColor: "#eff6ff",
          color: "#1d4ed8",
          border: "1px solid #bfdbfe",
          borderRadius: "8px",
          fontSize: "0.8rem",
          cursor: isTyping ? "default" : "pointer",
          transition: "all 0.2s",
          opacity: isTyping ? 0.6 : 1
        }, onMouseOver: (e) => {
          if (!isTyping)
            e.currentTarget.style.backgroundColor = "#dbeafe";
        }, onMouseOut: (e) => {
          if (!isTyping)
            e.currentTarget.style.backgroundColor = "#eff6ff";
        }, children: faq.question }, idx, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/FAQChatbot.jsx",
          lineNumber: 208,
          columnNumber: 39
        }, this)) }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/FAQChatbot.jsx",
          lineNumber: 203,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/FAQChatbot.jsx",
        lineNumber: 191,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/FAQChatbot.jsx",
      lineNumber: 62,
      columnNumber: 18
    }, this),
    !isOpen && /* @__PURE__ */ jsxDEV("button", { onClick: () => setIsOpen(true), style: {
      width: "60px",
      height: "60px",
      borderRadius: "50%",
      backgroundColor: "#2563eb",
      color: "white",
      border: "none",
      boxShadow: "0 4px 14px rgba(37, 99, 235, 0.4)",
      cursor: "pointer",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      fontSize: "1.75rem",
      transition: "transform 0.2s",
      animation: "chatBubbleAppear 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275)"
    }, onMouseOver: (e) => e.currentTarget.style.transform = "scale(1.08)", onMouseOut: (e) => e.currentTarget.style.transform = "scale(1)", children: "💬" }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/FAQChatbot.jsx",
      lineNumber: 231,
      columnNumber: 19
    }, this),
    /* @__PURE__ */ jsxDEV("style", { children: `
          @keyframes chatbotBlink {
            0% { opacity: .2; }
            20% { opacity: 1; }
            100% { opacity: .2; }
          }
          @keyframes chatBubbleAppear {
            0% { transform: scale(0.5); opacity: 0; }
            100% { transform: scale(1); opacity: 1; }
          }
          @media (max-width: 480px) {
            .chatbot-container {
              width: calc(100vw - 2rem) !important;
              height: 400px !important;
              right: 1rem !important;
              bottom: 5rem !important;
            }
          }
        ` }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/FAQChatbot.jsx",
      lineNumber: 250,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/FAQChatbot.jsx",
    lineNumber: 55,
    columnNumber: 10
  }, this);
};
_s(FAQChatbot, "/nQzWf91nUdcp9YWV/qdTVjt2Yg=");
_c = FAQChatbot;
export default FAQChatbot;
var _c;
$RefreshReg$(_c, "FAQChatbot");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/FAQChatbot.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNEVjOzs7Ozs7Ozs7Ozs7Ozs7O0FBNUVkLE9BQU9BLFNBQVNDLFVBQVVDLFdBQVdDLGNBQWM7QUFFbkQsTUFBTUMsYUFBYUEsTUFBTTtBQUFBQyxLQUFBO0FBQ3ZCLFFBQU0sQ0FBQ0MsUUFBUUMsU0FBUyxJQUFJTixTQUFTLEtBQUs7QUFDMUMsUUFBTSxDQUFDTyxVQUFVQyxXQUFXLElBQUlSLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUNTLFVBQVVDLFdBQVcsSUFBSVYsU0FBUyxLQUFLO0FBQzlDLFFBQU1XLGlCQUFpQlQsT0FBTyxJQUFJO0FBRWxDLFFBQU1VLE9BQU8sQ0FDWDtBQUFBLElBQ0VDLFVBQVU7QUFBQSxJQUNWQyxRQUFRO0FBQUEsRUFDVixHQUNBO0FBQUEsSUFDRUQsVUFBVTtBQUFBLElBQ1ZDLFFBQVE7QUFBQSxFQUNWLEdBQ0E7QUFBQSxJQUNFRCxVQUFVO0FBQUEsSUFDVkMsUUFBUTtBQUFBLEVBQ1YsR0FDQTtBQUFBLElBQ0VELFVBQVU7QUFBQSxJQUNWQyxRQUFRO0FBQUEsRUFDVixHQUNBO0FBQUEsSUFDRUQsVUFBVTtBQUFBLElBQ1ZDLFFBQVE7QUFBQSxFQUNWLEdBQ0E7QUFBQSxJQUNFRCxVQUFVO0FBQUEsSUFDVkMsUUFBUTtBQUFBLEVBQ1YsQ0FBQztBQUdIYixZQUFVLE1BQU07QUFDZCxRQUFJSSxVQUFVRSxTQUFTUSxXQUFXLEdBQUc7QUFDbkNQLGtCQUFZLENBQ1Y7QUFBQSxRQUFFUSxRQUFRO0FBQUEsUUFBT0MsTUFBTTtBQUFBLE1BQWtHLENBQUMsQ0FDM0g7QUFBQSxJQUNIO0FBQUEsRUFDRixHQUFHLENBQUNaLFFBQVFFLFFBQVEsQ0FBQztBQUVyQk4sWUFBVSxNQUFNO0FBQ2RVLG1CQUFlTyxTQUFTQyxlQUFlO0FBQUEsTUFBRUMsVUFBVTtBQUFBLElBQVMsQ0FBQztBQUFBLEVBQy9ELEdBQUcsQ0FBQ2IsVUFBVUUsUUFBUSxDQUFDO0FBRXZCLFFBQU1ZLG9CQUFxQkMsU0FBUTtBQUNqQ2QsZ0JBQVllLFVBQVEsQ0FBQyxHQUFHQSxNQUFNO0FBQUEsTUFBRVAsUUFBUTtBQUFBLE1BQVFDLE1BQU1LLElBQUlUO0FBQUFBLElBQVMsQ0FBQyxDQUFDO0FBQ3JFSCxnQkFBWSxJQUFJO0FBRWhCYyxlQUFXLE1BQU07QUFDZmQsa0JBQVksS0FBSztBQUNqQkYsa0JBQVllLFVBQVEsQ0FBQyxHQUFHQSxNQUFNO0FBQUEsUUFBRVAsUUFBUTtBQUFBLFFBQU9DLE1BQU1LLElBQUlSO0FBQUFBLE1BQU8sQ0FBQyxDQUFDO0FBQUEsSUFDcEUsR0FBRyxHQUFHO0FBQUEsRUFDUjtBQUVBLFNBQ0UsdUJBQUMsU0FBSSxPQUFPO0FBQUEsSUFBRVcsVUFBVTtBQUFBLElBQVNDLFFBQVE7QUFBQSxJQUFRQyxPQUFPO0FBQUEsSUFBUUMsUUFBUTtBQUFBLElBQU1DLFlBQVk7QUFBQSxFQUFxQixHQUM1R3hCO0FBQUFBLGNBQ0MsdUJBQUMsU0FBSSxXQUFVLHFCQUFvQixPQUFPO0FBQUEsTUFDeEN5QixPQUFPO0FBQUEsTUFDUEMsUUFBUTtBQUFBLE1BQ1JDLGlCQUFpQjtBQUFBLE1BQ2pCQyxjQUFjO0FBQUEsTUFDZEMsV0FBVztBQUFBLE1BQ1hDLFNBQVM7QUFBQSxNQUNUQyxlQUFlO0FBQUEsTUFDZkMsY0FBYztBQUFBLE1BQ2RDLFVBQVU7QUFBQSxNQUNWQyxRQUFRO0FBQUEsTUFDUkMsV0FBVztBQUFBLElBQ2IsR0FFRTtBQUFBLDZCQUFDLFNBQUksT0FBTztBQUFBLFFBQUVSLGlCQUFpQjtBQUFBLFFBQVdTLE9BQU87QUFBQSxRQUFTQyxTQUFTO0FBQUEsUUFBUVAsU0FBUztBQUFBLFFBQVFRLGdCQUFnQjtBQUFBLFFBQWlCQyxZQUFZO0FBQUEsTUFBUyxHQUNoSjtBQUFBLCtCQUFDLFNBQUksT0FBTztBQUFBLFVBQUVULFNBQVM7QUFBQSxVQUFRUyxZQUFZO0FBQUEsVUFBVUMsS0FBSztBQUFBLFFBQU0sR0FDOUQ7QUFBQSxpQ0FBQyxTQUFJLE9BQU87QUFBQSxZQUFFQyxVQUFVO0FBQUEsVUFBUyxHQUFHLGtCQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzQztBQUFBLFVBQ3RDLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxTQUFJLE9BQU87QUFBQSxjQUFFQyxZQUFZO0FBQUEsY0FBS0QsVUFBVTtBQUFBLFlBQVUsR0FBRyxpQ0FBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUU7QUFBQSxZQUN2RSx1QkFBQyxTQUFJLE9BQU87QUFBQSxjQUFFQSxVQUFVO0FBQUEsY0FBVUwsT0FBTztBQUFBLGNBQVdOLFNBQVM7QUFBQSxjQUFRUyxZQUFZO0FBQUEsY0FBVUMsS0FBSztBQUFBLFlBQU0sR0FDcEc7QUFBQSxxQ0FBQyxVQUFLLE9BQU87QUFBQSxnQkFBRWYsT0FBTztBQUFBLGdCQUFPQyxRQUFRO0FBQUEsZ0JBQU9DLGlCQUFpQjtBQUFBLGdCQUFXQyxjQUFjO0FBQUEsZ0JBQU9FLFNBQVM7QUFBQSxjQUFlLEtBQXJIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXdIO0FBQUEsY0FBTztBQUFBLGlCQURqSTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsZUFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU1BO0FBQUEsYUFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0E7QUFBQSxRQUNBLHVCQUFDLFlBQ0MsU0FBUyxNQUFNN0IsVUFBVSxLQUFLLEdBQzlCLE9BQU87QUFBQSxVQUFFMEMsWUFBWTtBQUFBLFVBQWVULFFBQVE7QUFBQSxVQUFRRSxPQUFPO0FBQUEsVUFBU1EsUUFBUTtBQUFBLFVBQVdILFVBQVU7QUFBQSxVQUFVSSxZQUFZO0FBQUEsVUFBR0MsU0FBUztBQUFBLFFBQUksR0FDdkksYUFBY0MsT0FBTUEsRUFBRUMsY0FBY0MsTUFBTUgsVUFBVSxHQUNwRCxZQUFhQyxPQUFNQSxFQUFFQyxjQUFjQyxNQUFNSCxVQUFVLEtBQ3BELGlCQUxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFdBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFtQkE7QUFBQSxNQUdBLHVCQUFDLFNBQUksT0FBTztBQUFBLFFBQUVJLE1BQU07QUFBQSxRQUFHYixTQUFTO0FBQUEsUUFBUWMsV0FBVztBQUFBLFFBQVF4QixpQkFBaUI7QUFBQSxRQUFXRyxTQUFTO0FBQUEsUUFBUUMsZUFBZTtBQUFBLFFBQVVTLEtBQUs7QUFBQSxNQUFPLEdBQzFJdEM7QUFBQUEsaUJBQVNrRCxJQUFJLENBQUNDLEtBQUtDLFFBQ2xCLHVCQUFDLFNBQWMsT0FBTztBQUFBLFVBQ3BCQyxXQUFXRixJQUFJMUMsV0FBVyxTQUFTLGFBQWE7QUFBQSxVQUNoRGdCLGlCQUFpQjBCLElBQUkxQyxXQUFXLFNBQVMsWUFBWTtBQUFBLFVBQ3JEeUIsT0FBT2lCLElBQUkxQyxXQUFXLFNBQVMsVUFBVTtBQUFBLFVBQ3pDMEIsU0FBUztBQUFBLFVBQ1RULGNBQWM7QUFBQSxVQUNkNEIseUJBQXlCSCxJQUFJMUMsV0FBVyxTQUFTLFFBQVE7QUFBQSxVQUN6RDhDLHdCQUF3QkosSUFBSTFDLFdBQVcsUUFBUSxRQUFRO0FBQUEsVUFDdkQrQyxVQUFVO0FBQUEsVUFDVmpCLFVBQVU7QUFBQSxVQUNWSSxZQUFZO0FBQUEsVUFDWmhCLFdBQVc7QUFBQSxVQUNYSyxRQUFRbUIsSUFBSTFDLFdBQVcsUUFBUSxzQkFBc0I7QUFBQSxRQUN2RCxHQUNHMEMsY0FBSXpDLFFBZEcwQyxLQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFlQSxDQUNEO0FBQUEsUUFFQWxELFlBQ0MsdUJBQUMsU0FBSSxPQUFPO0FBQUEsVUFBRW1ELFdBQVc7QUFBQSxVQUFjNUIsaUJBQWlCO0FBQUEsVUFBV1UsU0FBUztBQUFBLFVBQWFULGNBQWM7QUFBQSxVQUFRNkIsd0JBQXdCO0FBQUEsVUFBT3ZCLFFBQVE7QUFBQSxVQUFxQkosU0FBUztBQUFBLFVBQVFVLEtBQUs7QUFBQSxRQUFNLEdBQ3JNO0FBQUEsaUNBQUMsVUFBSyxPQUFPO0FBQUEsWUFBRWYsT0FBTztBQUFBLFlBQU9DLFFBQVE7QUFBQSxZQUFPQyxpQkFBaUI7QUFBQSxZQUFXQyxjQUFjO0FBQUEsWUFBT08sV0FBVztBQUFBLFVBQWtDLEtBQTFJO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZJO0FBQUEsVUFDN0ksdUJBQUMsVUFBSyxPQUFPO0FBQUEsWUFBRVYsT0FBTztBQUFBLFlBQU9DLFFBQVE7QUFBQSxZQUFPQyxpQkFBaUI7QUFBQSxZQUFXQyxjQUFjO0FBQUEsWUFBT08sV0FBVztBQUFBLFVBQXVDLEtBQS9JO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtKO0FBQUEsVUFDbEosdUJBQUMsVUFBSyxPQUFPO0FBQUEsWUFBRVYsT0FBTztBQUFBLFlBQU9DLFFBQVE7QUFBQSxZQUFPQyxpQkFBaUI7QUFBQSxZQUFXQyxjQUFjO0FBQUEsWUFBT08sV0FBVztBQUFBLFVBQXVDLEtBQS9JO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtKO0FBQUEsYUFIcEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlBO0FBQUEsUUFFRix1QkFBQyxTQUFJLEtBQUs3QixrQkFBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlCO0FBQUEsV0EzQjNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE0QkE7QUFBQSxNQUdBLHVCQUFDLFNBQUksT0FBTztBQUFBLFFBQUUrQixTQUFTO0FBQUEsUUFBZ0JWLGlCQUFpQjtBQUFBLFFBQVdnQyxXQUFXO0FBQUEsTUFBb0IsR0FDaEc7QUFBQSwrQkFBQyxTQUFJLE9BQU87QUFBQSxVQUFFbEIsVUFBVTtBQUFBLFVBQVVDLFlBQVk7QUFBQSxVQUFLTixPQUFPO0FBQUEsVUFBV0osY0FBYztBQUFBLFVBQU80QixlQUFlO0FBQUEsUUFBWSxHQUFHLGdDQUF4SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdJO0FBQUEsUUFDeEksdUJBQUMsU0FBSSxPQUFPO0FBQUEsVUFBRTlCLFNBQVM7QUFBQSxVQUFRQyxlQUFlO0FBQUEsVUFBVVMsS0FBSztBQUFBLFFBQU0sR0FDaEVqQyxlQUFLNkMsSUFBSSxDQUFDbkMsS0FBS3FDLFFBQ2QsdUJBQUMsWUFFQyxTQUFTLE1BQU10QyxrQkFBa0JDLEdBQUcsR0FDcEMsVUFBVWIsVUFDVixPQUFPO0FBQUEsVUFDTHlELFdBQVc7QUFBQSxVQUNYeEIsU0FBUztBQUFBLFVBQ1RWLGlCQUFpQjtBQUFBLFVBQ2pCUyxPQUFPO0FBQUEsVUFDUEYsUUFBUTtBQUFBLFVBQ1JOLGNBQWM7QUFBQSxVQUNkYSxVQUFVO0FBQUEsVUFDVkcsUUFBUXhDLFdBQVcsWUFBWTtBQUFBLFVBQy9CMEQsWUFBWTtBQUFBLFVBQ1poQixTQUFTMUMsV0FBVyxNQUFNO0FBQUEsUUFDNUIsR0FDQSxhQUFjMkMsT0FBTTtBQUFFLGNBQUcsQ0FBQzNDO0FBQVUyQyxjQUFFQyxjQUFjQyxNQUFNdEIsa0JBQWtCO0FBQUEsUUFBVSxHQUN0RixZQUFhb0IsT0FBTTtBQUFFLGNBQUcsQ0FBQzNDO0FBQVUyQyxjQUFFQyxjQUFjQyxNQUFNdEIsa0JBQWtCO0FBQUEsUUFBVSxHQUVwRlYsY0FBSVQsWUFsQkE4QyxLQURQO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFvQkEsQ0FDRCxLQXZCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd0JBO0FBQUEsV0ExQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTJCQTtBQUFBLFNBOUZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0ErRkE7QUFBQSxJQUlELENBQUN0RCxVQUNBLHVCQUFDLFlBQ0MsU0FBUyxNQUFNQyxVQUFVLElBQUksR0FDN0IsT0FBTztBQUFBLE1BQ0x3QixPQUFPO0FBQUEsTUFDUEMsUUFBUTtBQUFBLE1BQ1JFLGNBQWM7QUFBQSxNQUNkRCxpQkFBaUI7QUFBQSxNQUNqQlMsT0FBTztBQUFBLE1BQ1BGLFFBQVE7QUFBQSxNQUNSTCxXQUFXO0FBQUEsTUFDWGUsUUFBUTtBQUFBLE1BQ1JkLFNBQVM7QUFBQSxNQUNUUyxZQUFZO0FBQUEsTUFDWkQsZ0JBQWdCO0FBQUEsTUFDaEJHLFVBQVU7QUFBQSxNQUNWcUIsWUFBWTtBQUFBLE1BQ1ozQixXQUFXO0FBQUEsSUFDYixHQUNBLGFBQWNZLE9BQU1BLEVBQUVDLGNBQWNDLE1BQU1jLFlBQVksZUFDdEQsWUFBYWhCLE9BQU1BLEVBQUVDLGNBQWNDLE1BQU1jLFlBQVksWUFDdEQsa0JBcEJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FzQkE7QUFBQSxJQUdGLHVCQUFDLFdBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBb0JBO0FBQUEsT0FuSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW9KQTtBQUVKO0FBQUVoRSxHQTlNSUQsWUFBVTtBQUFBa0UsS0FBVmxFO0FBZ05OLGVBQWVBO0FBQVcsSUFBQWtFO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsInVzZVN0YXRlIiwidXNlRWZmZWN0IiwidXNlUmVmIiwiRkFRQ2hhdGJvdCIsIl9zIiwiaXNPcGVuIiwic2V0SXNPcGVuIiwibWVzc2FnZXMiLCJzZXRNZXNzYWdlcyIsImlzVHlwaW5nIiwic2V0SXNUeXBpbmciLCJtZXNzYWdlc0VuZFJlZiIsImZhcXMiLCJxdWVzdGlvbiIsImFuc3dlciIsImxlbmd0aCIsInNlbmRlciIsInRleHQiLCJjdXJyZW50Iiwic2Nyb2xsSW50b1ZpZXciLCJiZWhhdmlvciIsImhhbmRsZU9wdGlvbkNsaWNrIiwiZmFxIiwicHJldiIsInNldFRpbWVvdXQiLCJwb3NpdGlvbiIsImJvdHRvbSIsInJpZ2h0IiwiekluZGV4IiwiZm9udEZhbWlseSIsIndpZHRoIiwiaGVpZ2h0IiwiYmFja2dyb3VuZENvbG9yIiwiYm9yZGVyUmFkaXVzIiwiYm94U2hhZG93IiwiZGlzcGxheSIsImZsZXhEaXJlY3Rpb24iLCJtYXJnaW5Cb3R0b20iLCJvdmVyZmxvdyIsImJvcmRlciIsImFuaW1hdGlvbiIsImNvbG9yIiwicGFkZGluZyIsImp1c3RpZnlDb250ZW50IiwiYWxpZ25JdGVtcyIsImdhcCIsImZvbnRTaXplIiwiZm9udFdlaWdodCIsImJhY2tncm91bmQiLCJjdXJzb3IiLCJsaW5lSGVpZ2h0Iiwib3BhY2l0eSIsImUiLCJjdXJyZW50VGFyZ2V0Iiwic3R5bGUiLCJmbGV4Iiwib3ZlcmZsb3dZIiwibWFwIiwibXNnIiwiaWR4IiwiYWxpZ25TZWxmIiwiYm9yZGVyQm90dG9tUmlnaHRSYWRpdXMiLCJib3JkZXJCb3R0b21MZWZ0UmFkaXVzIiwibWF4V2lkdGgiLCJib3JkZXJUb3AiLCJ0ZXh0VHJhbnNmb3JtIiwidGV4dEFsaWduIiwidHJhbnNpdGlvbiIsInRyYW5zZm9ybSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiRkFRQ2hhdGJvdC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QsIHVzZVJlZiB9IGZyb20gJ3JlYWN0JztcclxuXHJcbmNvbnN0IEZBUUNoYXRib3QgPSAoKSA9PiB7XHJcbiAgY29uc3QgW2lzT3Blbiwgc2V0SXNPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbbWVzc2FnZXMsIHNldE1lc3NhZ2VzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbaXNUeXBpbmcsIHNldElzVHlwaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBtZXNzYWdlc0VuZFJlZiA9IHVzZVJlZihudWxsKTtcclxuXHJcbiAgY29uc3QgZmFxcyA9IFtcclxuICAgIHtcclxuICAgICAgcXVlc3Rpb246IFwiSG93IGRvIEkgZmluZCBwcm9qZWN0IHBhcnRuZXJzP1wiLFxyXG4gICAgICBhbnN3ZXI6IFwiSGVhZCBvdmVyIHRvIHlvdXIgRGFzaGJvYXJkISBZb3UgY2FuIGJyb3dzZSB0aHJvdWdoIHRoZSBsaXN0IG9mIHJlZ2lzdGVyZWQgc3R1ZGVudHMgd2hvIGFyZSBhbHNvIGxvb2tpbmcgZm9yIHByb2plY3QgdGVhbW1hdGVzLlwiXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBxdWVzdGlvbjogXCJIb3cgZG8gSSB1cGRhdGUgbXkgcHJvZmlsZT9cIixcclxuICAgICAgYW5zd2VyOiBcIkNsaWNrIG9uICdNeSBQcm9maWxlJyBpbiB0aGUgc2lkZWJhciwgYW5kIGhpdCAnRWRpdCBQcm9maWxlJy4gRG9uJ3QgZm9yZ2V0IHRvIGxpbmsgeW91ciBHaXRIdWIgc28gd2UgY2FuIHNob3cgb2ZmIHlvdXIgbGl2ZSBzdGF0cyFcIlxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgcXVlc3Rpb246IFwiV2hhdCBpcyBQcm9maWxlIENvbXBsZXRlbmVzcz9cIixcclxuICAgICAgYW5zd2VyOiBcIlRoZSBQcm9maWxlIENvbXBsZXRlbmVzcyBwZXJjZW50YWdlIGNhcmVmdWxseSB0cmFja3MgaG93IHdlbGwgeW91J3ZlIGZpbGxlZCBvdXQgeW91ciBpbmZvcm1hdGlvbi4gQWRkIG1vcmUgc2tpbGxzLCByb2xlcywgYW5kIGF2YWlsYWJpbGl0eSB0byByZWFjaCBhIGZ1bGwgMTAwJSBhbmQgc3RhbmQgb3V0IVwiXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBxdWVzdGlvbjogXCJIb3cgZG8gSSBzaG93IG15IEdpdEh1YiBzdGF0cz9cIixcclxuICAgICAgYW5zd2VyOiBcIkdvIHRvICdFZGl0IFByb2ZpbGUnIGFuZCBwYXN0ZSB5b3VyIHZhbGlkIEdpdEh1YiB1c2VybmFtZSBvciBmdWxsIFVSTCBpbiB0aGUgU29jaWFsIExpbmtzIHNlY3Rpb24uIFdlIHdpbGwgYXV0b21hdGljYWxseSBnZW5lcmF0ZSBsaXZlIGNvbW1pdHMgYW5kIHJlcG9zaXRvcnkgY2hhcnRzIVwiXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBxdWVzdGlvbjogXCJDYW4gSSBjaGFuZ2UgbXkgU3R1ZGVudCBJRC9FbWFpbD9cIixcclxuICAgICAgYW5zd2VyOiBcIkN1cnJlbnRseSwgeW91ciB1bml2ZXJzaXR5IGVtYWlsIGFuZCBTdHVkZW50IElEIGFyZSBzdHJpY3RseSB0aWVkIHRvIHlvdXIgYWNjb3VudCB1cG9uIHJlZ2lzdHJhdGlvbiB0byBndWFyYW50ZWUgdGhhdCBhbGwgdXNlcnMgYXJlIGF1dGhlbnRpYyBzdHVkZW50cy5cIlxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgcXVlc3Rpb246IFwiSSBmb3Jnb3QgbXkgcGFzc3dvcmRcIixcclxuICAgICAgYW5zd2VyOiBcIldoaWxlIGxvZ2dlZCBvdXQsIGNsaWNrICdGb3Jnb3QgUGFzc3dvcmQnIG9uIHRoZSBsb2dpbiBzY3JlZW4uIFlvdSB3aWxsIGluc3RhbnRseSByZWNlaXZlIGEgc2VjdXJlLCA2LWRpZ2l0IHZlcmlmaWNhdGlvbiBPVFAgdG8geW91ciByZWdpc3RlcmVkIHVuaXZlcnNpdHkgZW1haWwgdG8gcmVzZXQgaXQuXCJcclxuICAgIH1cclxuICBdO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKGlzT3BlbiAmJiBtZXNzYWdlcy5sZW5ndGggPT09IDApIHtcclxuICAgICAgc2V0TWVzc2FnZXMoW1xyXG4gICAgICAgIHsgc2VuZGVyOiAnYm90JywgdGV4dDogXCJIaSB0aGVyZSEg8J+RiyBJJ20geW91ciBQcm9NYXRlIEFzc2lzdGFudC4gQ2hvb3NlIGEgY29tbW9uIHF1ZXN0aW9uIGJlbG93LCBhbmQgSSdsbCBoZWxwIHlvdSBvdXQhXCIgfVxyXG4gICAgICBdKTtcclxuICAgIH1cclxuICB9LCBbaXNPcGVuLCBtZXNzYWdlc10pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgbWVzc2FnZXNFbmRSZWYuY3VycmVudD8uc2Nyb2xsSW50b1ZpZXcoeyBiZWhhdmlvcjogJ3Ntb290aCcgfSk7XHJcbiAgfSwgW21lc3NhZ2VzLCBpc1R5cGluZ10pO1xyXG5cclxuICBjb25zdCBoYW5kbGVPcHRpb25DbGljayA9IChmYXEpID0+IHtcclxuICAgIHNldE1lc3NhZ2VzKHByZXYgPT4gWy4uLnByZXYsIHsgc2VuZGVyOiAndXNlcicsIHRleHQ6IGZhcS5xdWVzdGlvbiB9XSk7XHJcbiAgICBzZXRJc1R5cGluZyh0cnVlKTtcclxuICAgIFxyXG4gICAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgIHNldElzVHlwaW5nKGZhbHNlKTtcclxuICAgICAgc2V0TWVzc2FnZXMocHJldiA9PiBbLi4ucHJldiwgeyBzZW5kZXI6ICdib3QnLCB0ZXh0OiBmYXEuYW5zd2VyIH1dKTtcclxuICAgIH0sIDgwMCk7XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgc3R5bGU9e3sgcG9zaXRpb246ICdmaXhlZCcsIGJvdHRvbTogJzJyZW0nLCByaWdodDogJzJyZW0nLCB6SW5kZXg6IDk5OTksIGZvbnRGYW1pbHk6IFwiJ1NvcmEnLCBzYW5zLXNlcmlmXCIgfX0+XHJcbiAgICAgIHtpc09wZW4gJiYgKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2hhdGJvdC1jb250YWluZXJcIiBzdHlsZT17eyBcclxuICAgICAgICAgIHdpZHRoOiAnMzUwcHgnLCBcclxuICAgICAgICAgIGhlaWdodDogJzQ4MHB4JywgXHJcbiAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6ICcjZmZmZmZmJywgXHJcbiAgICAgICAgICBib3JkZXJSYWRpdXM6ICcxNnB4JywgXHJcbiAgICAgICAgICBib3hTaGFkb3c6ICcwIDEwcHggMjVweCByZ2JhKDAsMCwwLDAuMSksIDAgNXB4IDEwcHggcmdiYSgwLDAsMCwwLjA1KScsXHJcbiAgICAgICAgICBkaXNwbGF5OiAnZmxleCcsIFxyXG4gICAgICAgICAgZmxleERpcmVjdGlvbjogJ2NvbHVtbicsXHJcbiAgICAgICAgICBtYXJnaW5Cb3R0b206ICcxcmVtJyxcclxuICAgICAgICAgIG92ZXJmbG93OiAnaGlkZGVuJyxcclxuICAgICAgICAgIGJvcmRlcjogJzFweCBzb2xpZCAjZTJlOGYwJyxcclxuICAgICAgICAgIGFuaW1hdGlvbjogJ2NoYXRCdWJibGVBcHBlYXIgMC4zcyBlYXNlLW91dCdcclxuICAgICAgICB9fT5cclxuICAgICAgICAgIHsvKiBIZWFkZXIgKi99XHJcbiAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGJhY2tncm91bmRDb2xvcjogJyMyNTYzZWInLCBjb2xvcjogJ3doaXRlJywgcGFkZGluZzogJzFyZW0nLCBkaXNwbGF5OiAnZmxleCcsIGp1c3RpZnlDb250ZW50OiAnc3BhY2UtYmV0d2VlbicsIGFsaWduSXRlbXM6ICdjZW50ZXInIH19PlxyXG4gICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6ICdmbGV4JywgYWxpZ25JdGVtczogJ2NlbnRlcicsIGdhcDogJzhweCcgfX0+XHJcbiAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250U2l6ZTogJzEuNXJlbScgfX0+8J+kljwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnRXZWlnaHQ6IDcwMCwgZm9udFNpemU6ICcwLjk1cmVtJyB9fT5Qcm9NYXRlIEFzc2lzdGFudDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250U2l6ZTogJzAuN3JlbScsIGNvbG9yOiAnI2JmZGJmZScsIGRpc3BsYXk6ICdmbGV4JywgYWxpZ25JdGVtczogJ2NlbnRlcicsIGdhcDogJzRweCcgfX0+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IHdpZHRoOiAnOHB4JywgaGVpZ2h0OiAnOHB4JywgYmFja2dyb3VuZENvbG9yOiAnIzRhZGU4MCcsIGJvcmRlclJhZGl1czogJzUwJScsIGRpc3BsYXk6ICdpbmxpbmUtYmxvY2snIH19Pjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgT25saW5lXHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxidXR0b24gXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SXNPcGVuKGZhbHNlKX0gXHJcbiAgICAgICAgICAgICAgc3R5bGU9e3sgYmFja2dyb3VuZDogJ3RyYW5zcGFyZW50JywgYm9yZGVyOiAnbm9uZScsIGNvbG9yOiAnd2hpdGUnLCBjdXJzb3I6ICdwb2ludGVyJywgZm9udFNpemU6ICcxLjVyZW0nLCBsaW5lSGVpZ2h0OiAxLCBvcGFjaXR5OiAwLjggfX1cclxuICAgICAgICAgICAgICBvbk1vdXNlT3Zlcj17KGUpID0+IGUuY3VycmVudFRhcmdldC5zdHlsZS5vcGFjaXR5ID0gMX1cclxuICAgICAgICAgICAgICBvbk1vdXNlT3V0PXsoZSkgPT4gZS5jdXJyZW50VGFyZ2V0LnN0eWxlLm9wYWNpdHkgPSAwLjh9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAmdGltZXM7XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgey8qIENoYXQgQXJlYSAqL31cclxuICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZmxleDogMSwgcGFkZGluZzogJzFyZW0nLCBvdmVyZmxvd1k6ICdhdXRvJywgYmFja2dyb3VuZENvbG9yOiAnI2Y4ZmFmYycsIGRpc3BsYXk6ICdmbGV4JywgZmxleERpcmVjdGlvbjogJ2NvbHVtbicsIGdhcDogJzEycHgnIH19PlxyXG4gICAgICAgICAgICB7bWVzc2FnZXMubWFwKChtc2csIGlkeCkgPT4gKFxyXG4gICAgICAgICAgICAgIDxkaXYga2V5PXtpZHh9IHN0eWxlPXt7IFxyXG4gICAgICAgICAgICAgICAgYWxpZ25TZWxmOiBtc2cuc2VuZGVyID09PSAndXNlcicgPyAnZmxleC1lbmQnIDogJ2ZsZXgtc3RhcnQnLCBcclxuICAgICAgICAgICAgICAgIGJhY2tncm91bmRDb2xvcjogbXNnLnNlbmRlciA9PT0gJ3VzZXInID8gJyMyNTYzZWInIDogJyNmZmZmZmYnLFxyXG4gICAgICAgICAgICAgICAgY29sb3I6IG1zZy5zZW5kZXIgPT09ICd1c2VyJyA/ICd3aGl0ZScgOiAnIzFlMjkzYicsXHJcbiAgICAgICAgICAgICAgICBwYWRkaW5nOiAnMTBweCAxNHB4JyxcclxuICAgICAgICAgICAgICAgIGJvcmRlclJhZGl1czogJzEycHgnLFxyXG4gICAgICAgICAgICAgICAgYm9yZGVyQm90dG9tUmlnaHRSYWRpdXM6IG1zZy5zZW5kZXIgPT09ICd1c2VyJyA/ICcycHgnIDogJzEycHgnLFxyXG4gICAgICAgICAgICAgICAgYm9yZGVyQm90dG9tTGVmdFJhZGl1czogbXNnLnNlbmRlciA9PT0gJ2JvdCcgPyAnMnB4JyA6ICcxMnB4JyxcclxuICAgICAgICAgICAgICAgIG1heFdpZHRoOiAnODUlJyxcclxuICAgICAgICAgICAgICAgIGZvbnRTaXplOiAnMC44NXJlbScsXHJcbiAgICAgICAgICAgICAgICBsaW5lSGVpZ2h0OiAxLjUsXHJcbiAgICAgICAgICAgICAgICBib3hTaGFkb3c6ICcwIDFweCAycHggcmdiYSgwLDAsMCwwLjA1KScsXHJcbiAgICAgICAgICAgICAgICBib3JkZXI6IG1zZy5zZW5kZXIgPT09ICdib3QnID8gJzFweCBzb2xpZCAjZTJlOGYwJyA6ICdub25lJ1xyXG4gICAgICAgICAgICAgIH19PlxyXG4gICAgICAgICAgICAgICAge21zZy50ZXh0fVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIHtpc1R5cGluZyAmJiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBhbGlnblNlbGY6ICdmbGV4LXN0YXJ0JywgYmFja2dyb3VuZENvbG9yOiAnI2ZmZmZmZicsIHBhZGRpbmc6ICcxMHB4IDE0cHgnLCBib3JkZXJSYWRpdXM6ICcxMnB4JywgYm9yZGVyQm90dG9tTGVmdFJhZGl1czogJzJweCcsIGJvcmRlcjogJzFweCBzb2xpZCAjZTJlOGYwJywgZGlzcGxheTogJ2ZsZXgnLCBnYXA6ICc0cHgnIH19PlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgd2lkdGg6ICc2cHgnLCBoZWlnaHQ6ICc2cHgnLCBiYWNrZ3JvdW5kQ29sb3I6ICcjOTRhM2I4JywgYm9yZGVyUmFkaXVzOiAnNTAlJywgYW5pbWF0aW9uOiAnY2hhdGJvdEJsaW5rIDEuNHMgaW5maW5pdGUgYm90aCcgfX0+PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgd2lkdGg6ICc2cHgnLCBoZWlnaHQ6ICc2cHgnLCBiYWNrZ3JvdW5kQ29sb3I6ICcjOTRhM2I4JywgYm9yZGVyUmFkaXVzOiAnNTAlJywgYW5pbWF0aW9uOiAnY2hhdGJvdEJsaW5rIDEuNHMgaW5maW5pdGUgYm90aCAwLjJzJyB9fT48L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBzdHlsZT17eyB3aWR0aDogJzZweCcsIGhlaWdodDogJzZweCcsIGJhY2tncm91bmRDb2xvcjogJyM5NGEzYjgnLCBib3JkZXJSYWRpdXM6ICc1MCUnLCBhbmltYXRpb246ICdjaGF0Ym90QmxpbmsgMS40cyBpbmZpbml0ZSBib3RoIDAuNHMnIH19Pjwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPGRpdiByZWY9e21lc3NhZ2VzRW5kUmVmfSAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgey8qIE9wdGlvbnMgQXJlYSAqL31cclxuICAgICAgICAgIDxkaXYgc3R5bGU9e3sgcGFkZGluZzogJzAuNzVyZW0gMXJlbScsIGJhY2tncm91bmRDb2xvcjogJyNmZmZmZmYnLCBib3JkZXJUb3A6ICcxcHggc29saWQgI2UyZThmMCcgfX0+XHJcbiAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZm9udFNpemU6ICcwLjdyZW0nLCBmb250V2VpZ2h0OiA2MDAsIGNvbG9yOiAnIzY0NzQ4YicsIG1hcmdpbkJvdHRvbTogJzhweCcsIHRleHRUcmFuc2Zvcm06ICd1cHBlcmNhc2UnIH19PkZyZXF1ZW50bHkgQXNrZWQ8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGZsZXhEaXJlY3Rpb246ICdjb2x1bW4nLCBnYXA6ICc2cHgnIH19PlxyXG4gICAgICAgICAgICAgIHtmYXFzLm1hcCgoZmFxLCBpZHgpID0+IChcclxuICAgICAgICAgICAgICAgIDxidXR0b24gXHJcbiAgICAgICAgICAgICAgICAgIGtleT17aWR4fVxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVPcHRpb25DbGljayhmYXEpfVxyXG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNUeXBpbmd9XHJcbiAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IFxyXG4gICAgICAgICAgICAgICAgICAgIHRleHRBbGlnbjogJ2xlZnQnLCBcclxuICAgICAgICAgICAgICAgICAgICBwYWRkaW5nOiAnOHB4IDEycHgnLCBcclxuICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6ICcjZWZmNmZmJywgXHJcbiAgICAgICAgICAgICAgICAgICAgY29sb3I6ICcjMWQ0ZWQ4JywgXHJcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyOiAnMXB4IHNvbGlkICNiZmRiZmUnLCBcclxuICAgICAgICAgICAgICAgICAgICBib3JkZXJSYWRpdXM6ICc4cHgnLFxyXG4gICAgICAgICAgICAgICAgICAgIGZvbnRTaXplOiAnMC44cmVtJyxcclxuICAgICAgICAgICAgICAgICAgICBjdXJzb3I6IGlzVHlwaW5nID8gJ2RlZmF1bHQnIDogJ3BvaW50ZXInLFxyXG4gICAgICAgICAgICAgICAgICAgIHRyYW5zaXRpb246ICdhbGwgMC4ycycsXHJcbiAgICAgICAgICAgICAgICAgICAgb3BhY2l0eTogaXNUeXBpbmcgPyAwLjYgOiAxXHJcbiAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgIG9uTW91c2VPdmVyPXsoZSkgPT4geyBpZighaXNUeXBpbmcpIGUuY3VycmVudFRhcmdldC5zdHlsZS5iYWNrZ3JvdW5kQ29sb3IgPSAnI2RiZWFmZScgfX1cclxuICAgICAgICAgICAgICAgICAgb25Nb3VzZU91dD17KGUpID0+IHsgaWYoIWlzVHlwaW5nKSBlLmN1cnJlbnRUYXJnZXQuc3R5bGUuYmFja2dyb3VuZENvbG9yID0gJyNlZmY2ZmYnIH19XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIHtmYXEucXVlc3Rpb259XHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuXHJcbiAgICAgIHsvKiBGbG9hdGluZyBBY3Rpb24gQnV0dG9uICovfVxyXG4gICAgICB7IWlzT3BlbiAmJiAoXHJcbiAgICAgICAgPGJ1dHRvbiBcclxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldElzT3Blbih0cnVlKX1cclxuICAgICAgICAgIHN0eWxlPXt7IFxyXG4gICAgICAgICAgICB3aWR0aDogJzYwcHgnLCBcclxuICAgICAgICAgICAgaGVpZ2h0OiAnNjBweCcsIFxyXG4gICAgICAgICAgICBib3JkZXJSYWRpdXM6ICc1MCUnLCBcclxuICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOiAnIzI1NjNlYicsIFxyXG4gICAgICAgICAgICBjb2xvcjogJ3doaXRlJywgXHJcbiAgICAgICAgICAgIGJvcmRlcjogJ25vbmUnLCBcclxuICAgICAgICAgICAgYm94U2hhZG93OiAnMCA0cHggMTRweCByZ2JhKDM3LCA5OSwgMjM1LCAwLjQpJywgXHJcbiAgICAgICAgICAgIGN1cnNvcjogJ3BvaW50ZXInLFxyXG4gICAgICAgICAgICBkaXNwbGF5OiAnZmxleCcsXHJcbiAgICAgICAgICAgIGFsaWduSXRlbXM6ICdjZW50ZXInLFxyXG4gICAgICAgICAgICBqdXN0aWZ5Q29udGVudDogJ2NlbnRlcicsXHJcbiAgICAgICAgICAgIGZvbnRTaXplOiAnMS43NXJlbScsXHJcbiAgICAgICAgICAgIHRyYW5zaXRpb246ICd0cmFuc2Zvcm0gMC4ycycsXHJcbiAgICAgICAgICAgIGFuaW1hdGlvbjogJ2NoYXRCdWJibGVBcHBlYXIgMC41cyBjdWJpYy1iZXppZXIoMC4xNzUsIDAuODg1LCAwLjMyLCAxLjI3NSknXHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgICAgb25Nb3VzZU92ZXI9eyhlKSA9PiBlLmN1cnJlbnRUYXJnZXQuc3R5bGUudHJhbnNmb3JtID0gJ3NjYWxlKDEuMDgpJ31cclxuICAgICAgICAgIG9uTW91c2VPdXQ9eyhlKSA9PiBlLmN1cnJlbnRUYXJnZXQuc3R5bGUudHJhbnNmb3JtID0gJ3NjYWxlKDEpJ31cclxuICAgICAgICA+XHJcbiAgICAgICAgICDwn5KsXHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICl9XHJcbiAgICAgIFxyXG4gICAgICA8c3R5bGU+XHJcbiAgICAgICAge2BcclxuICAgICAgICAgIEBrZXlmcmFtZXMgY2hhdGJvdEJsaW5rIHtcclxuICAgICAgICAgICAgMCUgeyBvcGFjaXR5OiAuMjsgfVxyXG4gICAgICAgICAgICAyMCUgeyBvcGFjaXR5OiAxOyB9XHJcbiAgICAgICAgICAgIDEwMCUgeyBvcGFjaXR5OiAuMjsgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgQGtleWZyYW1lcyBjaGF0QnViYmxlQXBwZWFyIHtcclxuICAgICAgICAgICAgMCUgeyB0cmFuc2Zvcm06IHNjYWxlKDAuNSk7IG9wYWNpdHk6IDA7IH1cclxuICAgICAgICAgICAgMTAwJSB7IHRyYW5zZm9ybTogc2NhbGUoMSk7IG9wYWNpdHk6IDE7IH1cclxuICAgICAgICAgIH1cclxuICAgICAgICAgIEBtZWRpYSAobWF4LXdpZHRoOiA0ODBweCkge1xyXG4gICAgICAgICAgICAuY2hhdGJvdC1jb250YWluZXIge1xyXG4gICAgICAgICAgICAgIHdpZHRoOiBjYWxjKDEwMHZ3IC0gMnJlbSkgIWltcG9ydGFudDtcclxuICAgICAgICAgICAgICBoZWlnaHQ6IDQwMHB4ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgICAgcmlnaHQ6IDFyZW0gIWltcG9ydGFudDtcclxuICAgICAgICAgICAgICBib3R0b206IDVyZW0gIWltcG9ydGFudDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIGB9XHJcbiAgICAgIDwvc3R5bGU+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgRkFRQ2hhdGJvdDtcclxuIl0sImZpbGUiOiJGOi9ZM1MyL0lUUE0gcHJvamVjdC9Qcm9NYXRlLS1Qcm9qZWN0LVBhcnRuZXItRmluZGVyL2Zyb250ZW5kL3NyYy9jb21wb25lbnRzL0ZBUUNoYXRib3QuanN4In0=