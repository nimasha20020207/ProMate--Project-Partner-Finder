import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=383bea9f"; const React = __vite__cjsImport1_react.__esModule ? __vite__cjsImport1_react.default : __vite__cjsImport1_react;
import __vite__cjsImport2_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=383bea9f"; const ReactDOM = __vite__cjsImport2_reactDom_client.__esModule ? __vite__cjsImport2_reactDom_client.default : __vite__cjsImport2_reactDom_client;
import { RouterProvider } from "/node_modules/.vite/deps/react-router-dom.js?v=383bea9f";
import { router } from "/src/App.jsx";
import { AuthProvider } from "/src/context/AuthContext.jsx";
import "/src/tailwind.css";
import "/src/index.css";
ReactDOM.createRoot(document.getElementById("root")).render(/* @__PURE__ */ jsxDEV(React.StrictMode, { children: /* @__PURE__ */ jsxDEV(AuthProvider, { children: /* @__PURE__ */ jsxDEV(RouterProvider, { router }, void 0, false, {
  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/main.jsx",
  lineNumber: 10,
  columnNumber: 7
}, this) }, void 0, false, {
  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/main.jsx",
  lineNumber: 9,
  columnNumber: 5
}, this) }, void 0, false, {
  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/main.jsx",
  lineNumber: 8,
  columnNumber: 61
}, this));

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBWU07QUFaTixPQUFPQSxXQUFXO0FBQ2xCLE9BQU9DLGNBQWM7QUFDckIsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLGNBQWM7QUFDdkIsU0FBU0Msb0JBQW9CO0FBRTdCLE9BQU87QUFDUCxPQUFPO0FBRVBILFNBQVNJLFdBQVdDLFNBQVNDLGVBQWUsTUFBTSxDQUFDLEVBQUVDLE9BQ25ELHVCQUFDLE1BQU0sWUFBTixFQUNDLGlDQUFDLGdCQUNDLGlDQUFDLGtCQUFlLFVBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FBK0IsS0FEakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQUlBLENBQ0YiLCJuYW1lcyI6WyJSZWFjdCIsIlJlYWN0RE9NIiwiUm91dGVyUHJvdmlkZXIiLCJyb3V0ZXIiLCJBdXRoUHJvdmlkZXIiLCJjcmVhdGVSb290IiwiZG9jdW1lbnQiLCJnZXRFbGVtZW50QnlJZCIsInJlbmRlciJdLCJzb3VyY2VzIjpbIm1haW4uanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IFJlYWN0RE9NIGZyb20gXCJyZWFjdC1kb20vY2xpZW50XCI7XHJcbmltcG9ydCB7IFJvdXRlclByb3ZpZGVyIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcclxuaW1wb3J0IHsgcm91dGVyIH0gZnJvbSBcIi4vQXBwLmpzeFwiO1xyXG5pbXBvcnQgeyBBdXRoUHJvdmlkZXIgfSBmcm9tIFwiLi9jb250ZXh0L0F1dGhDb250ZXh0XCI7XHJcblxyXG5pbXBvcnQgXCIuL3RhaWx3aW5kLmNzc1wiO1xyXG5pbXBvcnQgXCIuL2luZGV4LmNzc1wiO1xyXG5cclxuUmVhY3RET00uY3JlYXRlUm9vdChkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInJvb3RcIikpLnJlbmRlcihcclxuICA8UmVhY3QuU3RyaWN0TW9kZT5cclxuICAgIDxBdXRoUHJvdmlkZXI+XHJcbiAgICAgIDxSb3V0ZXJQcm92aWRlciByb3V0ZXI9e3JvdXRlcn0gLz5cclxuICAgIDwvQXV0aFByb3ZpZGVyPlxyXG4gIDwvUmVhY3QuU3RyaWN0TW9kZT5cclxuKTtcclxuIl0sImZpbGUiOiJGOi9ZM1MyL0lUUE0gcHJvamVjdC9Qcm9NYXRlLS1Qcm9qZWN0LVBhcnRuZXItRmluZGVyL2Zyb250ZW5kL3NyYy9tYWluLmpzeCJ9