import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Users/Register.jsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=383bea9f"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { Link, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=383bea9f";
import { useAuth } from "/src/context/AuthContext.jsx";
import { CheckCircle2 } from "/node_modules/.vite/deps/lucide-react.js?v=383bea9f";
import logo from "/src/assets/images/logo.jpeg?import";
const Register = () => {
  _s();
  const {
    register,
    checkAvailability
  } = useAuth();
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [error, setError] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    department: "",
    yearOfStudy: "",
    password: "",
    confirmPassword: "",
    studentId: "",
    specialization: "",
    semester: "",
    bio: "",
    contactNumber: "",
    preferredRoles: []
  });
  const [fieldErrors, setFieldErrors] = useState({
    email: "",
    studentId: ""
  });
  const rolesOptions = ["Frontend Developer", "Backend Developer", "Fullstack Developer", "Mobile App Developer", "ML Engineer", "Data Scientist", "UI/UX Designer", "DevOps Engineer", "QA Engineer", "Project Manager"];
  const [activeDropdown, setActiveDropdown] = useState(null);
  useEffect(() => {
    const handleClickOutside = () => setActiveDropdown(null);
    document.addEventListener("click", handleClickOutside);
    return () => document.removeEventListener("click", handleClickOutside);
  }, []);
  const [agreedToTerms, setAgreedToTerms] = useState(false);
  const handleChange = (e) => {
    const {
      name,
      value
    } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
    if (error)
      setError("");
    if (fieldErrors[name])
      setFieldErrors({
        ...fieldErrors,
        [name]: ""
      });
  };
  const handleNextStep1 = async () => {
    const {
      firstName,
      lastName,
      email,
      department,
      yearOfStudy
    } = formData;
    if (!firstName || !lastName || !email || !department || !yearOfStudy) {
      setError("Please fill all required fields to continue.");
      return;
    }
    const hasNumber = /\d/;
    if (hasNumber.test(firstName) || hasNumber.test(lastName)) {
      setError("Names cannot contain numbers.");
      return;
    }
    const emailRegex = /^\S+@\S+\.\S+$/i;
    if (!emailRegex.test(email)) {
      setError("Please provide a valid email address.");
      return;
    }
    const res = await checkAvailability({
      email
    });
    if (res.available === false) {
      setFieldErrors((prev) => ({
        ...prev,
        email: res.message
      }));
      return;
    }
    if (res.success === false) {
      console.warn("Availability check failed technically:", res.message);
      setFieldErrors((prev) => ({
        ...prev,
        email: ""
      }));
    }
    setError("");
    setFieldErrors((prev) => ({
      ...prev,
      email: ""
    }));
    setStep(2);
  };
  const handleNextStep2 = () => {
    const {
      password,
      confirmPassword
    } = formData;
    if (!password || !confirmPassword) {
      setError("Please fill in and confirm your password.");
      return;
    }
    if (password !== confirmPassword) {
      setError("Passwords do not match.");
      return;
    }
    if (!agreedToTerms) {
      setError("You must agree to the Terms of Service and Privacy Policy to continue.");
      return;
    }
    setError("");
    setStep(3);
  };
  const prevStep = () => {
    setError("");
    setStep((prev) => Math.max(prev - 1, 1));
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    const {
      studentId,
      specialization,
      semester
    } = formData;
    if (!studentId || !specialization || !semester) {
      setError("Please fill all required fields to create your account.");
      return;
    }
    const studentIdRegex = /^it\d{8}$/i;
    if (!studentIdRegex.test(studentId)) {
      setError('Student ID must start with "IT" followed by exactly 8 digits.');
      return;
    }
    const resAvail = await checkAvailability({
      studentId
    });
    if (!resAvail.available) {
      setFieldErrors((prev) => ({
        ...prev,
        studentId: resAvail.message
      }));
      return;
    }
    const fullName = `${formData.firstName} ${formData.lastName}`.trim();
    const res = await register({
      fullName,
      studentId: formData.studentId,
      email: formData.email,
      password: formData.password,
      department: formData.department,
      specialization: formData.specialization,
      yearOfStudy: formData.yearOfStudy,
      semester: formData.semester,
      bio: formData.bio,
      contactNumber: formData.contactNumber,
      preferredRoles: formData.preferredRoles
    });
    if (res.success) {
      setShowSuccess(true);
    } else {
      setError(res.message);
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { id: "page-register", className: "page active", style: {
    display: "flex"
  }, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "auth-blob-1" }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
      lineNumber: 192,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "auth-blob-2" }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
      lineNumber: 193,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "reg-container", style: {
      paddingTop: "1.5rem"
    }, children: [
      /* @__PURE__ */ jsxDEV("div", { className: "auth-logo", onClick: () => navigate("/"), style: {
        cursor: "pointer",
        display: "flex",
        alignItems: "center",
        gap: "8px"
      }, children: [
        /* @__PURE__ */ jsxDEV("img", { src: logo, alt: "ProMate Logo", style: {
          width: "40px",
          height: "40px",
          borderRadius: "50%"
        } }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
          lineNumber: 203,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { style: {
          fontSize: "1.5rem",
          fontWeight: "bold",
          color: "var(--p)"
        }, children: "ProMate" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
          lineNumber: 208,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
        lineNumber: 197,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "reg-card", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "auth-header", style: {
          marginBottom: "1.25rem"
        }, children: [
          /* @__PURE__ */ jsxDEV("h2", { children: "Create your account" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
            lineNumber: 219,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { children: "Join ProjectMate and find your ideal project team" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
            lineNumber: 220,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
          lineNumber: 216,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "step-indicator", children: [
          /* @__PURE__ */ jsxDEV("div", { className: `step-dot ${step >= 1 ? step === 1 ? "current" : "done" : ""}`, children: "1" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
            lineNumber: 224,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: `step-line ${step >= 2 ? "done" : ""}` }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
            lineNumber: 225,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: `step-dot ${step >= 2 ? step === 2 ? "current" : "done" : ""}`, children: "2" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
            lineNumber: 226,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: `step-line ${step >= 3 ? "done" : ""}` }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
            lineNumber: 227,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: `step-dot ${step >= 3 ? step === 3 ? "current" : "done" : ""}`, children: "3" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
            lineNumber: 228,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
          lineNumber: 223,
          columnNumber: 11
        }, this),
        error && /* @__PURE__ */ jsxDEV("div", { className: "form-error show", style: {
          marginBottom: "1rem",
          textAlign: "center"
        }, children: error }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
          lineNumber: 231,
          columnNumber: 21
        }, this),
        step === 1 && /* @__PURE__ */ jsxDEV("div", { className: "step-panel active", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "form-row", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "form-label", children: "First Name" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                lineNumber: 239,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("input", { type: "text", className: "form-input", name: "firstName", value: formData.firstName, onChange: handleChange, placeholder: "Ashan" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                lineNumber: 240,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
              lineNumber: 238,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "form-label", children: "Last Name" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                lineNumber: 243,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("input", { type: "text", className: "form-input", name: "lastName", value: formData.lastName, onChange: handleChange, placeholder: "Kavinda" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                lineNumber: 244,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
              lineNumber: 242,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
            lineNumber: 237,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "form-label", children: "Email Address" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
              lineNumber: 248,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("input", { type: "email", className: `form-input ${fieldErrors.email ? "input-error" : ""}`, name: "email", value: formData.email, onChange: handleChange, placeholder: "student@example.com" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
              lineNumber: 249,
              columnNumber: 17
            }, this),
            fieldErrors.email && /* @__PURE__ */ jsxDEV("div", { className: "field-error", style: {
              color: "#ef4444",
              fontSize: "0.75rem",
              marginTop: "0.35rem",
              fontWeight: 500
            }, children: fieldErrors.email }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
              lineNumber: 250,
              columnNumber: 39
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "form-hint", children: "Enter your primary email address" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
              lineNumber: 256,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
            lineNumber: 247,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "form-row", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "form-label", children: "Department" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                lineNumber: 260,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("select", { className: "form-input", name: "department", value: formData.department, onChange: handleChange, children: [
                /* @__PURE__ */ jsxDEV("option", { value: "", children: "Select department" }, void 0, false, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                  lineNumber: 262,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("option", { children: "Computing" }, void 0, false, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                  lineNumber: 263,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("option", { children: "Business" }, void 0, false, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                  lineNumber: 264,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("option", { children: "Engineering" }, void 0, false, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                  lineNumber: 265,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("option", { children: "Humanities and Sciences" }, void 0, false, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                  lineNumber: 266,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("option", { children: "Architecture" }, void 0, false, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                  lineNumber: 267,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("option", { children: "Graduate Studies" }, void 0, false, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                  lineNumber: 268,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("option", { children: "SLIIT International Programmes" }, void 0, false, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                  lineNumber: 269,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                lineNumber: 261,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
              lineNumber: 259,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "form-label", children: "Year of Study" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                lineNumber: 273,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("select", { className: "form-input", name: "yearOfStudy", value: formData.yearOfStudy, onChange: handleChange, children: [
                /* @__PURE__ */ jsxDEV("option", { value: "", children: "Select year" }, void 0, false, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                  lineNumber: 275,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("option", { children: "Year 1" }, void 0, false, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                  lineNumber: 276,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("option", { children: "Year 2" }, void 0, false, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                  lineNumber: 276,
                  columnNumber: 44
                }, this),
                /* @__PURE__ */ jsxDEV("option", { children: "Year 3" }, void 0, false, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                  lineNumber: 276,
                  columnNumber: 67
                }, this),
                /* @__PURE__ */ jsxDEV("option", { children: "Year 4" }, void 0, false, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                  lineNumber: 276,
                  columnNumber: 90
                }, this)
              ] }, void 0, true, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                lineNumber: 274,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
              lineNumber: 272,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
            lineNumber: 258,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("button", { className: "btn btn-primary btn-full", style: {
            padding: ".8rem"
          }, onClick: handleNextStep1, type: "button", children: "Continue →" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
            lineNumber: 280,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "auth-footer-text", style: {
            marginTop: ".75rem"
          }, children: [
            "Already have an account? ",
            /* @__PURE__ */ jsxDEV(Link, { to: "/login", style: {
              cursor: "pointer"
            }, children: "Sign in" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
              lineNumber: 286,
              columnNumber: 42
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
            lineNumber: 283,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
          lineNumber: 236,
          columnNumber: 26
        }, this),
        step === 2 && /* @__PURE__ */ jsxDEV("div", { className: "step-panel active", children: [
          /* @__PURE__ */ jsxDEV("p", { style: {
            fontSize: ".85rem",
            color: "var(--mid)",
            marginBottom: "1.25rem"
          }, children: "Secure your account with a strong password." }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
            lineNumber: 293,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "form-label", children: "Password" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
              lineNumber: 299,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "pw-wrap", children: [
              /* @__PURE__ */ jsxDEV("input", { type: showPassword ? "text" : "password", className: "form-input", name: "password", value: formData.password, onChange: handleChange, placeholder: "Create a strong password" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                lineNumber: 301,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("button", { className: "pw-toggle", type: "button", onClick: () => setShowPassword(!showPassword), children: showPassword ? "🙈" : "👁️" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                lineNumber: 302,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
              lineNumber: 300,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "pw-label", children: "Enter a password" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
              lineNumber: 304,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
            lineNumber: 298,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "form-label", children: "Confirm Password" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
              lineNumber: 307,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "pw-wrap", children: [
              /* @__PURE__ */ jsxDEV("input", { type: showConfirmPassword ? "text" : "password", className: "form-input", name: "confirmPassword", value: formData.confirmPassword, onChange: handleChange, placeholder: "Repeat your password" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                lineNumber: 309,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("button", { className: "pw-toggle", type: "button", onClick: () => setShowConfirmPassword(!showConfirmPassword), children: showConfirmPassword ? "🙈" : "👁️" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                lineNumber: 310,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
              lineNumber: 308,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
            lineNumber: 306,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("label", { className: "agree-row", children: [
            /* @__PURE__ */ jsxDEV("input", { type: "checkbox", checked: agreedToTerms, onChange: (e) => setAgreedToTerms(e.target.checked) }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
              lineNumber: 314,
              columnNumber: 17
            }, this),
            "I agree to the ",
            /* @__PURE__ */ jsxDEV("span", { style: {
              color: "var(--p)",
              fontWeight: 600
            }, children: "Terms of Service" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
              lineNumber: 315,
              columnNumber: 32
            }, this),
            " and ",
            /* @__PURE__ */ jsxDEV("span", { style: {
              color: "var(--p)",
              fontWeight: 600
            }, children: "Privacy Policy" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
              lineNumber: 318,
              columnNumber: 44
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
            lineNumber: 313,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: {
            display: "flex",
            gap: ".6rem"
          }, children: [
            /* @__PURE__ */ jsxDEV("button", { className: "btn btn-outline", onClick: prevStep, type: "button", children: "← Back" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
              lineNumber: 327,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("button", { className: "btn btn-primary", style: {
              flex: 1,
              justifyContent: "center"
            }, onClick: handleNextStep2, type: "button", children: "Continue →" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
              lineNumber: 328,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
            lineNumber: 323,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
          lineNumber: 292,
          columnNumber: 26
        }, this),
        step === 3 && /* @__PURE__ */ jsxDEV("div", { className: "step-panel active", children: [
          /* @__PURE__ */ jsxDEV("p", { style: {
            fontSize: ".85rem",
            color: "var(--mid)",
            marginBottom: "1.25rem"
          }, children: "Almost done! A few more details to personalize your experience." }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
            lineNumber: 336,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "form-row", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "form-label", children: "Student ID" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                lineNumber: 343,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("input", { type: "text", className: `form-input ${fieldErrors.studentId ? "input-error" : ""}`, name: "studentId", value: formData.studentId, onChange: handleChange, placeholder: "e.g. IT23341968" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                lineNumber: 344,
                columnNumber: 19
              }, this),
              fieldErrors.studentId && /* @__PURE__ */ jsxDEV("div", { className: "field-error", style: {
                color: "#ef4444",
                fontSize: "0.75rem",
                marginTop: "0.35rem",
                fontWeight: 500
              }, children: fieldErrors.studentId }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                lineNumber: 345,
                columnNumber: 45
              }, this)
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
              lineNumber: 342,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "form-label", children: "Specialization" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                lineNumber: 353,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("select", { className: "form-input", name: "specialization", value: formData.specialization, onChange: handleChange, children: [
                /* @__PURE__ */ jsxDEV("option", { value: "", children: "Select specialization" }, void 0, false, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                  lineNumber: 355,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("option", { value: "Artificial Intelligence", children: "Artificial Intelligence" }, void 0, false, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                  lineNumber: 356,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("option", { value: "Software Engineering", children: "Software Engineering" }, void 0, false, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                  lineNumber: 357,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("option", { value: "Computer Science", children: "Computer Science" }, void 0, false, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                  lineNumber: 358,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("option", { value: "Information Technology", children: "Information Technology" }, void 0, false, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                  lineNumber: 359,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("option", { value: "Data Science", children: "Data Science" }, void 0, false, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                  lineNumber: 360,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("option", { value: "Cyber Security", children: "Cyber Security" }, void 0, false, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                  lineNumber: 361,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("option", { value: "Computer System & Network Engineering", children: "Computer System & Network Engineering" }, void 0, false, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                  lineNumber: 362,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("option", { value: "Information Systems Engineering", children: "Information Systems Engineering" }, void 0, false, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                  lineNumber: 363,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("option", { value: "Interactive Media", children: "Interactive Media" }, void 0, false, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                  lineNumber: 364,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("option", { value: "Computer Systems Engineering", children: "Computer Systems Engineering" }, void 0, false, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                  lineNumber: 365,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                lineNumber: 354,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
              lineNumber: 352,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
            lineNumber: 341,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "form-row", children: /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "form-label", children: "Semester" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
              lineNumber: 371,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("select", { className: "form-input", name: "semester", value: formData.semester, onChange: handleChange, children: [
              /* @__PURE__ */ jsxDEV("option", { value: "", children: "Select semester" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                lineNumber: 373,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("option", { children: "Semester 1" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                lineNumber: 374,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("option", { children: "Semester 2" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                lineNumber: 375,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
              lineNumber: 372,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
            lineNumber: 370,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
            lineNumber: 369,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "form-label", children: [
              "Bio ",
              /* @__PURE__ */ jsxDEV("span", { style: {
                fontWeight: 400,
                color: "var(--mid)"
              }, children: "(optional)" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                lineNumber: 380,
                columnNumber: 51
              }, this)
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
              lineNumber: 380,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("input", { type: "text", className: "form-input", name: "bio", value: formData.bio, onChange: handleChange, placeholder: "Tell teammates a bit about yourself..." }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
              lineNumber: 384,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
            lineNumber: 379,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "form-label", children: [
              "Contact Number ",
              /* @__PURE__ */ jsxDEV("span", { style: {
                fontWeight: 400,
                color: "var(--mid)"
              }, children: "(optional)" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                lineNumber: 388,
                columnNumber: 62
              }, this)
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
              lineNumber: 388,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("input", { type: "text", className: "form-input", name: "contactNumber", value: formData.contactNumber, onChange: handleChange, placeholder: "+94 77 123 4567" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
              lineNumber: 392,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
            lineNumber: 387,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "form-label", children: [
              "Preferred Roles ",
              /* @__PURE__ */ jsxDEV("span", { style: {
                fontWeight: 400,
                color: "var(--mid)"
              }, children: "(at least one)" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                lineNumber: 396,
                columnNumber: 63
              }, this)
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
              lineNumber: 396,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "multiselect-container", onClick: (e) => e.stopPropagation(), children: [
              /* @__PURE__ */ jsxDEV("div", { className: `multiselect-header ${activeDropdown === "roles" ? "multiselect-header-focus" : ""}`, onClick: () => setActiveDropdown(activeDropdown === "roles" ? null : "roles"), children: [
                formData.preferredRoles.length === 0 ? /* @__PURE__ */ jsxDEV("span", { className: "multiselect-placeholder", children: "Select roles..." }, void 0, false, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                  lineNumber: 402,
                  columnNumber: 61
                }, this) : formData.preferredRoles.map((role) => /* @__PURE__ */ jsxDEV("span", { className: "multiselect-chip", children: [
                  role,
                  /* @__PURE__ */ jsxDEV("span", { className: "multiselect-chip-remove", onClick: (e) => {
                    e.stopPropagation();
                    const updated = formData.preferredRoles.filter((r) => r !== role);
                    setFormData({
                      ...formData,
                      preferredRoles: updated
                    });
                  }, children: "×" }, void 0, false, {
                    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                    lineNumber: 404,
                    columnNumber: 27
                  }, this)
                ] }, role, true, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                  lineNumber: 402,
                  columnNumber: 164
                }, this)),
                /* @__PURE__ */ jsxDEV("div", { style: {
                  marginLeft: "auto",
                  opacity: 0.5
                }, children: activeDropdown === "roles" ? "▲" : "▼" }, void 0, false, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                  lineNumber: 413,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                lineNumber: 401,
                columnNumber: 19
              }, this),
              activeDropdown === "roles" && /* @__PURE__ */ jsxDEV("div", { className: "multiselect-dropdown", style: {
                backgroundColor: "white"
              }, children: rolesOptions.map((role) => {
                const isSelected = formData.preferredRoles.includes(role);
                return /* @__PURE__ */ jsxDEV("div", { className: `multiselect-option ${isSelected ? "selected" : ""}`, onClick: () => {
                  const exists = formData.preferredRoles.includes(role);
                  const updated = exists ? formData.preferredRoles.filter((r) => r !== role) : [...formData.preferredRoles, role];
                  setFormData({
                    ...formData,
                    preferredRoles: updated
                  });
                }, children: [
                  role,
                  isSelected && /* @__PURE__ */ jsxDEV("span", { children: "✓" }, void 0, false, {
                    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                    lineNumber: 433,
                    columnNumber: 44
                  }, this)
                ] }, role, true, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                  lineNumber: 424,
                  columnNumber: 26
                }, this);
              }) }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
                lineNumber: 419,
                columnNumber: 50
              }, this)
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
              lineNumber: 400,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
            lineNumber: 395,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "alert-info", style: {
            marginBottom: "1rem",
            marginTop: ".75rem"
          }, children: "ℹ️ You can add skills, interests, and availability from your profile after signing up." }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
            lineNumber: 439,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: {
            display: "flex",
            gap: ".6rem"
          }, children: [
            /* @__PURE__ */ jsxDEV("button", { className: "btn btn-outline", onClick: prevStep, type: "button", children: "← Back" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
              lineNumber: 447,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("button", { className: "btn btn-primary", style: {
              flex: 1,
              justifyContent: "center"
            }, onClick: handleSubmit, type: "button", children: "🚀 Create Account" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
              lineNumber: 448,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
            lineNumber: 443,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
          lineNumber: 335,
          columnNumber: 26
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
        lineNumber: 215,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
      lineNumber: 194,
      columnNumber: 7
    }, this),
    showSuccess && /* @__PURE__ */ jsxDEV("div", { className: "success-modal-overlay", children: /* @__PURE__ */ jsxDEV("div", { className: "success-modal-card", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "success-bounce-icon", children: /* @__PURE__ */ jsxDEV(CheckCircle2, { size: 60, color: "#10b981" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
        lineNumber: 461,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
        lineNumber: 460,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("h2", { children: "Welcome to ProMate!" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
        lineNumber: 463,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: "Your account has been created successfully. Let's find your perfect project partner." }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
        lineNumber: 464,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("button", { className: "btn btn-primary btn-full success-btn", onClick: () => navigate("/dashboard"), children: "Get Started 🚀" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
        lineNumber: 465,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
      lineNumber: 459,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
      lineNumber: 458,
      columnNumber: 23
    }, this)
  ] }, void 0, true, {
    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx",
    lineNumber: 189,
    columnNumber: 10
  }, this);
};
_s(Register, "YxC2wsnCXrJj1pO8PJSxmtnn2Xk=", false, function() {
  return [useAuth, useNavigate];
});
_c = Register;
export default Register;
var _c;
$RefreshReg$(_c, "Register");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Register.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0tNOzs7Ozs7Ozs7Ozs7Ozs7O0FBcEtOLE9BQU9BLFNBQVNDLFVBQVVDLGlCQUFpQjtBQUMzQyxTQUFTQyxNQUFNQyxtQkFBbUI7QUFDbEMsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyxvQkFBb0I7QUFDN0IsT0FBT0MsVUFBVTtBQUVqQixNQUFNQyxXQUFXQSxNQUFNO0FBQUFDLEtBQUE7QUFDckIsUUFBTTtBQUFBLElBQUVDO0FBQUFBLElBQVVDO0FBQUFBLEVBQWtCLElBQUlOLFFBQVE7QUFDaEQsUUFBTU8sV0FBV1IsWUFBWTtBQUM3QixRQUFNLENBQUNTLE1BQU1DLE9BQU8sSUFBSWIsU0FBUyxDQUFDO0FBQ2xDLFFBQU0sQ0FBQ2MsT0FBT0MsUUFBUSxJQUFJZixTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDZ0IsY0FBY0MsZUFBZSxJQUFJakIsU0FBUyxLQUFLO0FBQ3RELFFBQU0sQ0FBQ2tCLHFCQUFxQkMsc0JBQXNCLElBQUluQixTQUFTLEtBQUs7QUFDcEUsUUFBTSxDQUFDb0IsYUFBYUMsY0FBYyxJQUFJckIsU0FBUyxLQUFLO0FBRXBELFFBQU0sQ0FBQ3NCLFVBQVVDLFdBQVcsSUFBSXZCLFNBQVM7QUFBQSxJQUN2Q3dCLFdBQVc7QUFBQSxJQUNYQyxVQUFVO0FBQUEsSUFDVkMsT0FBTztBQUFBLElBQ1BDLFlBQVk7QUFBQSxJQUNaQyxhQUFhO0FBQUEsSUFDYkMsVUFBVTtBQUFBLElBQ1ZDLGlCQUFpQjtBQUFBLElBQ2pCQyxXQUFXO0FBQUEsSUFDWEMsZ0JBQWdCO0FBQUEsSUFDaEJDLFVBQVU7QUFBQSxJQUNWQyxLQUFLO0FBQUEsSUFDTEMsZUFBZTtBQUFBLElBQ2ZDLGdCQUFnQjtBQUFBLEVBQ2xCLENBQUM7QUFFRCxRQUFNLENBQUNDLGFBQWFDLGNBQWMsSUFBSXRDLFNBQVM7QUFBQSxJQUM3QzBCLE9BQU87QUFBQSxJQUNQSyxXQUFXO0FBQUEsRUFDYixDQUFDO0FBRUQsUUFBTVEsZUFBZSxDQUFDLHNCQUFzQixxQkFBcUIsdUJBQXVCLHdCQUF3QixlQUFlLGtCQUFrQixrQkFBa0IsbUJBQW1CLGVBQWUsaUJBQWlCO0FBQ3ROLFFBQU0sQ0FBQ0MsZ0JBQWdCQyxpQkFBaUIsSUFBSXpDLFNBQVMsSUFBSTtBQUd6REMsWUFBVSxNQUFNO0FBQ2QsVUFBTXlDLHFCQUFxQkEsTUFBTUQsa0JBQWtCLElBQUk7QUFDdkRFLGFBQVNDLGlCQUFpQixTQUFTRixrQkFBa0I7QUFDckQsV0FBTyxNQUFNQyxTQUFTRSxvQkFBb0IsU0FBU0gsa0JBQWtCO0FBQUEsRUFDdkUsR0FBRyxFQUFFO0FBRUwsUUFBTSxDQUFDSSxlQUFlQyxnQkFBZ0IsSUFBSS9DLFNBQVMsS0FBSztBQUV4RCxRQUFNZ0QsZUFBZ0JDLE9BQU07QUFDMUIsVUFBTTtBQUFBLE1BQUVDO0FBQUFBLE1BQU1DO0FBQUFBLElBQU0sSUFBSUYsRUFBRUc7QUFDMUI3QixnQkFBWTtBQUFBLE1BQUUsR0FBR0Q7QUFBQUEsTUFBVSxDQUFDNEIsSUFBSSxHQUFHQztBQUFBQSxJQUFNLENBQUM7QUFDMUMsUUFBSXJDO0FBQU9DLGVBQVMsRUFBRTtBQUN0QixRQUFJc0IsWUFBWWEsSUFBSTtBQUFHWixxQkFBZTtBQUFBLFFBQUUsR0FBR0Q7QUFBQUEsUUFBYSxDQUFDYSxJQUFJLEdBQUc7QUFBQSxNQUFHLENBQUM7QUFBQSxFQUN0RTtBQUVBLFFBQU1HLGtCQUFrQixZQUFZO0FBQ2xDLFVBQU07QUFBQSxNQUFFN0I7QUFBQUEsTUFBV0M7QUFBQUEsTUFBVUM7QUFBQUEsTUFBT0M7QUFBQUEsTUFBWUM7QUFBQUEsSUFBWSxJQUFJTjtBQUNoRSxRQUFJLENBQUNFLGFBQWEsQ0FBQ0MsWUFBWSxDQUFDQyxTQUFTLENBQUNDLGNBQWMsQ0FBQ0MsYUFBYTtBQUNwRWIsZUFBUyw4Q0FBOEM7QUFDdkQ7QUFBQSxJQUNGO0FBRUEsVUFBTXVDLFlBQVk7QUFDbEIsUUFBSUEsVUFBVUMsS0FBSy9CLFNBQVMsS0FBSzhCLFVBQVVDLEtBQUs5QixRQUFRLEdBQUc7QUFDekRWLGVBQVMsK0JBQStCO0FBQ3hDO0FBQUEsSUFDRjtBQUVBLFVBQU15QyxhQUFhO0FBQ25CLFFBQUksQ0FBQ0EsV0FBV0QsS0FBSzdCLEtBQUssR0FBRztBQUMzQlgsZUFBUyx1Q0FBdUM7QUFDaEQ7QUFBQSxJQUNGO0FBR0EsVUFBTTBDLE1BQU0sTUFBTS9DLGtCQUFrQjtBQUFBLE1BQUVnQjtBQUFBQSxJQUFNLENBQUM7QUFHN0MsUUFBSStCLElBQUlDLGNBQWMsT0FBTztBQUMzQnBCLHFCQUFlcUIsV0FBUztBQUFBLFFBQUUsR0FBR0E7QUFBQUEsUUFBTWpDLE9BQU8rQixJQUFJRztBQUFBQSxNQUFRLEVBQUU7QUFDeEQ7QUFBQSxJQUNGO0FBSUEsUUFBSUgsSUFBSUksWUFBWSxPQUFPO0FBQ3pCQyxjQUFRQyxLQUFLLDBDQUEwQ04sSUFBSUcsT0FBTztBQUVsRXRCLHFCQUFlcUIsV0FBUztBQUFBLFFBQUUsR0FBR0E7QUFBQUEsUUFBTWpDLE9BQU87QUFBQSxNQUFHLEVBQUU7QUFBQSxJQUNqRDtBQUVBWCxhQUFTLEVBQUU7QUFDWHVCLG1CQUFlcUIsV0FBUztBQUFBLE1BQUUsR0FBR0E7QUFBQUEsTUFBTWpDLE9BQU87QUFBQSxJQUFHLEVBQUU7QUFDL0NiLFlBQVEsQ0FBQztBQUFBLEVBQ1g7QUFFQSxRQUFNbUQsa0JBQWtCQSxNQUFNO0FBQzVCLFVBQU07QUFBQSxNQUFFbkM7QUFBQUEsTUFBVUM7QUFBQUEsSUFBZ0IsSUFBSVI7QUFDdEMsUUFBSSxDQUFDTyxZQUFZLENBQUNDLGlCQUFpQjtBQUNqQ2YsZUFBUywyQ0FBMkM7QUFDcEQ7QUFBQSxJQUNGO0FBQ0EsUUFBSWMsYUFBYUMsaUJBQWlCO0FBQ2hDZixlQUFTLHlCQUF5QjtBQUNsQztBQUFBLElBQ0Y7QUFDQSxRQUFJLENBQUMrQixlQUFlO0FBQ2xCL0IsZUFBUyx3RUFBd0U7QUFDakY7QUFBQSxJQUNGO0FBQ0FBLGFBQVMsRUFBRTtBQUNYRixZQUFRLENBQUM7QUFBQSxFQUNYO0FBRUEsUUFBTW9ELFdBQVdBLE1BQU07QUFDckJsRCxhQUFTLEVBQUU7QUFDWEYsWUFBUzhDLFVBQVNPLEtBQUtDLElBQUlSLE9BQU8sR0FBRyxDQUFDLENBQUM7QUFBQSxFQUN6QztBQUVBLFFBQU1TLGVBQWUsT0FBT25CLE1BQU07QUFDaENBLE1BQUVvQixlQUFlO0FBQ2pCLFVBQU07QUFBQSxNQUFFdEM7QUFBQUEsTUFBV0M7QUFBQUEsTUFBZ0JDO0FBQUFBLElBQVMsSUFBSVg7QUFDaEQsUUFBSSxDQUFDUyxhQUFhLENBQUNDLGtCQUFrQixDQUFDQyxVQUFVO0FBQzlDbEIsZUFBUyx5REFBeUQ7QUFDbEU7QUFBQSxJQUNGO0FBRUEsVUFBTXVELGlCQUFpQjtBQUN2QixRQUFJLENBQUNBLGVBQWVmLEtBQUt4QixTQUFTLEdBQUc7QUFDbkNoQixlQUFTLCtEQUErRDtBQUN4RTtBQUFBLElBQ0Y7QUFHQSxVQUFNd0QsV0FBVyxNQUFNN0Qsa0JBQWtCO0FBQUEsTUFBRXFCO0FBQUFBLElBQVUsQ0FBQztBQUN0RCxRQUFJLENBQUN3QyxTQUFTYixXQUFXO0FBQ3ZCcEIscUJBQWVxQixXQUFTO0FBQUEsUUFBRSxHQUFHQTtBQUFBQSxRQUFNNUIsV0FBV3dDLFNBQVNYO0FBQUFBLE1BQVEsRUFBRTtBQUNqRTtBQUFBLElBQ0Y7QUFFQSxVQUFNWSxXQUFXLEdBQUdsRCxTQUFTRSxTQUFTLElBQUlGLFNBQVNHLFFBQVEsR0FBR2dELEtBQUs7QUFFbkUsVUFBTWhCLE1BQU0sTUFBTWhELFNBQVM7QUFBQSxNQUN6QitEO0FBQUFBLE1BQ0F6QyxXQUFXVCxTQUFTUztBQUFBQSxNQUNwQkwsT0FBT0osU0FBU0k7QUFBQUEsTUFDaEJHLFVBQVVQLFNBQVNPO0FBQUFBLE1BQ25CRixZQUFZTCxTQUFTSztBQUFBQSxNQUNyQkssZ0JBQWdCVixTQUFTVTtBQUFBQSxNQUN6QkosYUFBYU4sU0FBU007QUFBQUEsTUFDdEJLLFVBQVVYLFNBQVNXO0FBQUFBLE1BQ25CQyxLQUFLWixTQUFTWTtBQUFBQSxNQUNkQyxlQUFlYixTQUFTYTtBQUFBQSxNQUN4QkMsZ0JBQWdCZCxTQUFTYztBQUFBQSxJQUMzQixDQUFDO0FBQ0QsUUFBSXFCLElBQUlJLFNBQVM7QUFDZnhDLHFCQUFlLElBQUk7QUFBQSxJQUNyQixPQUFPO0FBQ0xOLGVBQVMwQyxJQUFJRyxPQUFPO0FBQUEsSUFDdEI7QUFBQSxFQUNGO0FBRUEsU0FDRSx1QkFBQyxTQUFJLElBQUcsaUJBQWdCLFdBQVUsZUFBYyxPQUFPO0FBQUEsSUFBRWMsU0FBUztBQUFBLEVBQU8sR0FDdkU7QUFBQSwyQkFBQyxTQUFJLFdBQVUsaUJBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE2QjtBQUFBLElBQzdCLHVCQUFDLFNBQUksV0FBVSxpQkFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTZCO0FBQUEsSUFDN0IsdUJBQUMsU0FBSSxXQUFVLGlCQUFnQixPQUFPO0FBQUEsTUFBRUMsWUFBWTtBQUFBLElBQVMsR0FDM0Q7QUFBQSw2QkFBQyxTQUFJLFdBQVUsYUFBWSxTQUFTLE1BQU1oRSxTQUFTLEdBQUcsR0FBRyxPQUFPO0FBQUEsUUFBRWlFLFFBQVE7QUFBQSxRQUFXRixTQUFTO0FBQUEsUUFBUUcsWUFBWTtBQUFBLFFBQVVDLEtBQUs7QUFBQSxNQUFNLEdBQ3JJO0FBQUEsK0JBQUMsU0FBSSxLQUFLeEUsTUFBTSxLQUFJLGdCQUFlLE9BQU87QUFBQSxVQUFFeUUsT0FBTztBQUFBLFVBQVFDLFFBQVE7QUFBQSxVQUFRQyxjQUFjO0FBQUEsUUFBTSxLQUEvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlHO0FBQUEsUUFDakcsdUJBQUMsVUFBSyxPQUFPO0FBQUEsVUFBRUMsVUFBVTtBQUFBLFVBQVVDLFlBQVk7QUFBQSxVQUFRQyxPQUFPO0FBQUEsUUFBVyxHQUFHLHVCQUE1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1GO0FBQUEsV0FGckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsWUFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxlQUFjLE9BQU87QUFBQSxVQUFFQyxjQUFjO0FBQUEsUUFBVSxHQUM1RDtBQUFBLGlDQUFDLFFBQUcsbUNBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUI7QUFBQSxVQUN2Qix1QkFBQyxPQUFFLGlFQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9EO0FBQUEsYUFGdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVcsWUFBWXpFLFFBQVEsSUFBS0EsU0FBUyxJQUFJLFlBQVksU0FBVSxFQUFFLElBQUksaUJBQWxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1GO0FBQUEsVUFDbkYsdUJBQUMsU0FBSSxXQUFXLGFBQWFBLFFBQVEsSUFBSSxTQUFTLEVBQUUsTUFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0Q7QUFBQSxVQUN4RCx1QkFBQyxTQUFJLFdBQVcsWUFBWUEsUUFBUSxJQUFLQSxTQUFTLElBQUksWUFBWSxTQUFVLEVBQUUsSUFBSSxpQkFBbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUY7QUFBQSxVQUNuRix1QkFBQyxTQUFJLFdBQVcsYUFBYUEsUUFBUSxJQUFJLFNBQVMsRUFBRSxNQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3RDtBQUFBLFVBQ3hELHVCQUFDLFNBQUksV0FBVyxZQUFZQSxRQUFRLElBQUtBLFNBQVMsSUFBSSxZQUFZLFNBQVUsRUFBRSxJQUFJLGlCQUFsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRjtBQUFBLGFBTHJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNQTtBQUFBLFFBRUNFLFNBQVMsdUJBQUMsU0FBSSxXQUFVLG1CQUFrQixPQUFPO0FBQUEsVUFBRXVFLGNBQWM7QUFBQSxVQUFRQyxXQUFXO0FBQUEsUUFBUyxHQUFJeEUsbUJBQXhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEY7QUFBQSxRQUV2R0YsU0FBUyxLQUNSLHVCQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxZQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsY0FBYSwwQkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBd0M7QUFBQSxjQUN4Qyx1QkFBQyxXQUFNLE1BQUssUUFBTyxXQUFVLGNBQWEsTUFBSyxhQUFZLE9BQU9VLFNBQVNFLFdBQVcsVUFBVXdCLGNBQWMsYUFBWSxXQUExSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpSTtBQUFBLGlCQUZuSTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLHFDQUFDLFdBQU0sV0FBVSxjQUFhLHlCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF1QztBQUFBLGNBQ3ZDLHVCQUFDLFdBQU0sTUFBSyxRQUFPLFdBQVUsY0FBYSxNQUFLLFlBQVcsT0FBTzFCLFNBQVNHLFVBQVUsVUFBVXVCLGNBQWMsYUFBWSxhQUF4SDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpSTtBQUFBLGlCQUZuSTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsZUFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVNBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSxjQUFhLDZCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyQztBQUFBLFlBQzNDLHVCQUFDLFdBQU0sTUFBSyxTQUFRLFdBQVcsY0FBY1gsWUFBWVgsUUFBUSxnQkFBZ0IsRUFBRSxJQUFJLE1BQUssU0FBUSxPQUFPSixTQUFTSSxPQUFPLFVBQVVzQixjQUFjLGFBQVkseUJBQS9KO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9MO0FBQUEsWUFDbkxYLFlBQVlYLFNBQVMsdUJBQUMsU0FBSSxXQUFVLGVBQWMsT0FBTztBQUFBLGNBQUUwRCxPQUFPO0FBQUEsY0FBV0YsVUFBVTtBQUFBLGNBQVdLLFdBQVc7QUFBQSxjQUFXSixZQUFZO0FBQUEsWUFBSSxHQUFJOUMsc0JBQVlYLFNBQW5JO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlJO0FBQUEsWUFDL0osdUJBQUMsU0FBSSxXQUFVLGFBQVksZ0RBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJEO0FBQUEsZUFKN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLFlBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLHFDQUFDLFdBQU0sV0FBVSxjQUFhLDBCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3QztBQUFBLGNBQ3hDLHVCQUFDLFlBQU8sV0FBVSxjQUFhLE1BQUssY0FBYSxPQUFPSixTQUFTSyxZQUFZLFVBQVVxQixjQUNyRjtBQUFBLHVDQUFDLFlBQU8sT0FBTSxJQUFHLGlDQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFrQztBQUFBLGdCQUNsQyx1QkFBQyxZQUFPLHlCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlCO0FBQUEsZ0JBQ2pCLHVCQUFDLFlBQU8sd0JBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0I7QUFBQSxnQkFDaEIsdUJBQUMsWUFBTywyQkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFtQjtBQUFBLGdCQUNuQix1QkFBQyxZQUFPLHVDQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQStCO0FBQUEsZ0JBQy9CLHVCQUFDLFlBQU8sNEJBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBb0I7QUFBQSxnQkFDcEIsdUJBQUMsWUFBTyxnQ0FBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF3QjtBQUFBLGdCQUN4Qix1QkFBQyxZQUFPLDhDQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXNDO0FBQUEsbUJBUnhDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBU0E7QUFBQSxpQkFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVlBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLHFDQUFDLFdBQU0sV0FBVSxjQUFhLDZCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEyQztBQUFBLGNBQzNDLHVCQUFDLFlBQU8sV0FBVSxjQUFhLE1BQUssZUFBYyxPQUFPMUIsU0FBU00sYUFBYSxVQUFVb0IsY0FDdkY7QUFBQSx1Q0FBQyxZQUFPLE9BQU0sSUFBRywyQkFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNEI7QUFBQSxnQkFDNUIsdUJBQUMsWUFBTyxzQkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFjO0FBQUEsZ0JBQVMsdUJBQUMsWUFBTyxzQkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFjO0FBQUEsZ0JBQVMsdUJBQUMsWUFBTyxzQkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFjO0FBQUEsZ0JBQVMsdUJBQUMsWUFBTyxzQkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFjO0FBQUEsbUJBRnJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxpQkFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU1BO0FBQUEsZUFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFxQkE7QUFBQSxVQUNBLHVCQUFDLFlBQU8sV0FBVSw0QkFBMkIsT0FBTztBQUFBLFlBQUV3QyxTQUFTO0FBQUEsVUFBUSxHQUFHLFNBQVNuQyxpQkFBaUIsTUFBSyxVQUFTLDBCQUFsSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0SDtBQUFBLFVBQzVILHVCQUFDLFNBQUksV0FBVSxvQkFBbUIsT0FBTztBQUFBLFlBQUVrQyxXQUFXO0FBQUEsVUFBUyxHQUFHO0FBQUE7QUFBQSxZQUN2Qyx1QkFBQyxRQUFLLElBQUcsVUFBUyxPQUFPO0FBQUEsY0FBRVgsUUFBUTtBQUFBLFlBQVUsR0FBRyx1QkFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUQ7QUFBQSxlQURsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUExQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTJDQTtBQUFBLFFBR0RoRSxTQUFTLEtBQ1IsdUJBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUEsaUNBQUMsT0FBRSxPQUFPO0FBQUEsWUFBRXNFLFVBQVU7QUFBQSxZQUFVRSxPQUFPO0FBQUEsWUFBY0MsY0FBYztBQUFBLFVBQVUsR0FBRywyREFBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkg7QUFBQSxVQUMzSCx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSxjQUFhLHdCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzQztBQUFBLFlBQ3RDLHVCQUFDLFNBQUksV0FBVSxXQUNiO0FBQUEscUNBQUMsV0FBTSxNQUFNckUsZUFBZSxTQUFTLFlBQVksV0FBVSxjQUFhLE1BQUssWUFBVyxPQUFPTSxTQUFTTyxVQUFVLFVBQVVtQixjQUFjLGFBQVksOEJBQXRKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdMO0FBQUEsY0FDaEwsdUJBQUMsWUFBTyxXQUFVLGFBQVksTUFBSyxVQUFTLFNBQVMsTUFBTS9CLGdCQUFnQixDQUFDRCxZQUFZLEdBQUlBLHlCQUFlLE9BQU8sU0FBbEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBd0g7QUFBQSxpQkFGMUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLFlBQVcsZ0NBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBDO0FBQUEsZUFONUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsY0FBYSxnQ0FBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEM7QUFBQSxZQUM5Qyx1QkFBQyxTQUFJLFdBQVUsV0FDYjtBQUFBLHFDQUFDLFdBQU0sTUFBTUUsc0JBQXNCLFNBQVMsWUFBWSxXQUFVLGNBQWEsTUFBSyxtQkFBa0IsT0FBT0ksU0FBU1EsaUJBQWlCLFVBQVVrQixjQUFjLGFBQVksMEJBQTNLO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWlNO0FBQUEsY0FDak0sdUJBQUMsWUFBTyxXQUFVLGFBQVksTUFBSyxVQUFTLFNBQVMsTUFBTTdCLHVCQUF1QixDQUFDRCxtQkFBbUIsR0FBSUEsZ0NBQXNCLE9BQU8sU0FBdkk7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNkk7QUFBQSxpQkFGL0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLGVBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNQTtBQUFBLFVBQ0EsdUJBQUMsV0FBTSxXQUFVLGFBQ2Y7QUFBQSxtQ0FBQyxXQUFNLE1BQUssWUFBVyxTQUFTNEIsZUFBZSxVQUFXRyxPQUFNRixpQkFBaUJFLEVBQUVHLE9BQU9xQyxPQUFPLEtBQWpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1HO0FBQUEsWUFBRztBQUFBLFlBQ3ZGLHVCQUFDLFVBQUssT0FBTztBQUFBLGNBQUVMLE9BQU87QUFBQSxjQUFZRCxZQUFZO0FBQUEsWUFBSSxHQUFHLGdDQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxRTtBQUFBLFlBQU87QUFBQSxZQUFLLHVCQUFDLFVBQUssT0FBTztBQUFBLGNBQUVDLE9BQU87QUFBQSxjQUFZRCxZQUFZO0FBQUEsWUFBSSxHQUFHLDhCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtRTtBQUFBLGVBRnJLO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksT0FBTztBQUFBLFlBQUVULFNBQVM7QUFBQSxZQUFRSSxLQUFLO0FBQUEsVUFBUSxHQUMxQztBQUFBLG1DQUFDLFlBQU8sV0FBVSxtQkFBa0IsU0FBU2IsVUFBVSxNQUFLLFVBQVMsc0JBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJFO0FBQUEsWUFDM0UsdUJBQUMsWUFBTyxXQUFVLG1CQUFrQixPQUFPO0FBQUEsY0FBRXlCLE1BQU07QUFBQSxjQUFHQyxnQkFBZ0I7QUFBQSxZQUFTLEdBQUcsU0FBUzNCLGlCQUFpQixNQUFLLFVBQVMsMEJBQTFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9JO0FBQUEsZUFGdEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLGFBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF5QkE7QUFBQSxRQUdEcEQsU0FBUyxLQUNSLHVCQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLGlDQUFDLE9BQUUsT0FBTztBQUFBLFlBQUVzRSxVQUFVO0FBQUEsWUFBVUUsT0FBTztBQUFBLFlBQWNDLGNBQWM7QUFBQSxVQUFVLEdBQUcsK0VBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStJO0FBQUEsVUFDL0ksdUJBQUMsU0FBSSxXQUFVLFlBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLHFDQUFDLFdBQU0sV0FBVSxjQUFhLDBCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3QztBQUFBLGNBQ3hDLHVCQUFDLFdBQU0sTUFBSyxRQUFPLFdBQVcsY0FBY2hELFlBQVlOLFlBQVksZ0JBQWdCLEVBQUUsSUFBSSxNQUFLLGFBQVksT0FBT1QsU0FBU1MsV0FBVyxVQUFVaUIsY0FBYyxhQUFZLHFCQUExSztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEyTDtBQUFBLGNBQzFMWCxZQUFZTixhQUFhLHVCQUFDLFNBQUksV0FBVSxlQUFjLE9BQU87QUFBQSxnQkFBRXFELE9BQU87QUFBQSxnQkFBV0YsVUFBVTtBQUFBLGdCQUFXSyxXQUFXO0FBQUEsZ0JBQVdKLFlBQVk7QUFBQSxjQUFJLEdBQUk5QyxzQkFBWU4sYUFBbkk7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNkk7QUFBQSxpQkFIeks7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFJQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsY0FBYSw4QkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNEM7QUFBQSxjQUM1Qyx1QkFBQyxZQUFPLFdBQVUsY0FBYSxNQUFLLGtCQUFpQixPQUFPVCxTQUFTVSxnQkFBZ0IsVUFBVWdCLGNBQzdGO0FBQUEsdUNBQUMsWUFBTyxPQUFNLElBQUcscUNBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXNDO0FBQUEsZ0JBQ3RDLHVCQUFDLFlBQU8sT0FBTSwyQkFBMEIsdUNBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQStEO0FBQUEsZ0JBQy9ELHVCQUFDLFlBQU8sT0FBTSx3QkFBdUIsb0NBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXlEO0FBQUEsZ0JBQ3pELHVCQUFDLFlBQU8sT0FBTSxvQkFBbUIsZ0NBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlEO0FBQUEsZ0JBQ2pELHVCQUFDLFlBQU8sT0FBTSwwQkFBeUIsc0NBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTZEO0FBQUEsZ0JBQzdELHVCQUFDLFlBQU8sT0FBTSxnQkFBZSw0QkFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUM7QUFBQSxnQkFDekMsdUJBQUMsWUFBTyxPQUFNLGtCQUFpQiw4QkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNkM7QUFBQSxnQkFDN0MsdUJBQUMsWUFBTyxPQUFNLHlDQUF3QyxxREFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkY7QUFBQSxnQkFDM0YsdUJBQUMsWUFBTyxPQUFNLG1DQUFrQywrQ0FBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBK0U7QUFBQSxnQkFDL0UsdUJBQUMsWUFBTyxPQUFNLHFCQUFvQixpQ0FBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBbUQ7QUFBQSxnQkFDbkQsdUJBQUMsWUFBTyxPQUFNLGdDQUErQiw0Q0FBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUU7QUFBQSxtQkFYM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFZQTtBQUFBLGlCQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZUE7QUFBQSxlQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXNCQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLFlBQ2IsaUNBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsY0FBYSx3QkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0M7QUFBQSxZQUN0Qyx1QkFBQyxZQUFPLFdBQVUsY0FBYSxNQUFLLFlBQVcsT0FBTzFCLFNBQVNXLFVBQVUsVUFBVWUsY0FDakY7QUFBQSxxQ0FBQyxZQUFPLE9BQU0sSUFBRywrQkFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0M7QUFBQSxjQUNoQyx1QkFBQyxZQUFPLDBCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWtCO0FBQUEsY0FDbEIsdUJBQUMsWUFBTywwQkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFrQjtBQUFBLGlCQUhwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUlBO0FBQUEsZUFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BLEtBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFTQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsY0FBYTtBQUFBO0FBQUEsY0FBSSx1QkFBQyxVQUFLLE9BQU87QUFBQSxnQkFBRW1DLFlBQVk7QUFBQSxnQkFBS0MsT0FBTztBQUFBLGNBQWEsR0FBRywwQkFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUU7QUFBQSxpQkFBbkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEc7QUFBQSxZQUMxRyx1QkFBQyxXQUFNLE1BQUssUUFBTyxXQUFVLGNBQWEsTUFBSyxPQUFNLE9BQU85RCxTQUFTWSxLQUFLLFVBQVVjLGNBQWMsYUFBWSw0Q0FBOUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0o7QUFBQSxlQUZ4SjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSxjQUFhO0FBQUE7QUFBQSxjQUFlLHVCQUFDLFVBQUssT0FBTztBQUFBLGdCQUFFbUMsWUFBWTtBQUFBLGdCQUFLQyxPQUFPO0FBQUEsY0FBYSxHQUFHLDBCQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpRTtBQUFBLGlCQUE5RztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxSDtBQUFBLFlBQ3JILHVCQUFDLFdBQU0sTUFBSyxRQUFPLFdBQVUsY0FBYSxNQUFLLGlCQUFnQixPQUFPOUQsU0FBU2EsZUFBZSxVQUFVYSxjQUFjLGFBQVkscUJBQWxJO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1KO0FBQUEsZUFGcko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsY0FBYTtBQUFBO0FBQUEsY0FBZ0IsdUJBQUMsVUFBSyxPQUFPO0FBQUEsZ0JBQUVtQyxZQUFZO0FBQUEsZ0JBQUtDLE9BQU87QUFBQSxjQUFhLEdBQUcsOEJBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFFO0FBQUEsaUJBQW5IO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBIO0FBQUEsWUFDMUgsdUJBQUMsU0FBSSxXQUFVLHlCQUF3QixTQUFVbkMsT0FBTUEsRUFBRTJDLGdCQUFnQixHQUN2RTtBQUFBLHFDQUFDLFNBQUksV0FBVyxzQkFBc0JwRCxtQkFBbUIsVUFBVSw2QkFBNkIsRUFBRSxJQUFJLFNBQVMsTUFBTUMsa0JBQWtCRCxtQkFBbUIsVUFBVSxPQUFPLE9BQU8sR0FDL0tsQjtBQUFBQSx5QkFBU2MsZUFBZXlELFdBQVcsSUFDbEMsdUJBQUMsVUFBSyxXQUFVLDJCQUEwQiwrQkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUQsSUFFekR2RSxTQUFTYyxlQUFlMEQsSUFBSUMsVUFDMUIsdUJBQUMsVUFBZ0IsV0FBVSxvQkFDeEJBO0FBQUFBO0FBQUFBLGtCQUNELHVCQUFDLFVBQUssV0FBVSwyQkFBMEIsU0FBVTlDLE9BQU07QUFDeERBLHNCQUFFMkMsZ0JBQWdCO0FBQ2xCLDBCQUFNSSxVQUFVMUUsU0FBU2MsZUFBZTZELE9BQU9DLE9BQUtBLE1BQU1ILElBQUk7QUFDOUR4RSxnQ0FBWTtBQUFBLHNCQUFFLEdBQUdEO0FBQUFBLHNCQUFVYyxnQkFBZ0I0RDtBQUFBQSxvQkFBUSxDQUFDO0FBQUEsa0JBQ3RELEdBQUcsaUJBSkg7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFJSTtBQUFBLHFCQU5LRCxNQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBT0EsQ0FDRDtBQUFBLGdCQUVILHVCQUFDLFNBQUksT0FBTztBQUFBLGtCQUFFSSxZQUFZO0FBQUEsa0JBQVFDLFNBQVM7QUFBQSxnQkFBSSxHQUFJNUQsNkJBQW1CLFVBQVUsTUFBTSxPQUF0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEwRjtBQUFBLG1CQWY1RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWdCQTtBQUFBLGNBRUNBLG1CQUFtQixXQUNsQix1QkFBQyxTQUFJLFdBQVUsd0JBQXVCLE9BQU87QUFBQSxnQkFBRTZELGlCQUFpQjtBQUFBLGNBQVEsR0FDckU5RCx1QkFBYXVELElBQUlDLFVBQVE7QUFDeEIsc0JBQU1PLGFBQWFoRixTQUFTYyxlQUFlbUUsU0FBU1IsSUFBSTtBQUN4RCx1QkFDRSx1QkFBQyxTQUVDLFdBQVcsc0JBQXNCTyxhQUFhLGFBQWEsRUFBRSxJQUM3RCxTQUFTLE1BQU07QUFDYix3QkFBTUUsU0FBU2xGLFNBQVNjLGVBQWVtRSxTQUFTUixJQUFJO0FBQ3BELHdCQUFNQyxVQUFVUSxTQUNabEYsU0FBU2MsZUFBZTZELE9BQU9DLE9BQUtBLE1BQU1ILElBQUksSUFDOUMsQ0FBQyxHQUFHekUsU0FBU2MsZ0JBQWdCMkQsSUFBSTtBQUNyQ3hFLDhCQUFZO0FBQUEsb0JBQUUsR0FBR0Q7QUFBQUEsb0JBQVVjLGdCQUFnQjREO0FBQUFBLGtCQUFRLENBQUM7QUFBQSxnQkFDdEQsR0FFQ0Q7QUFBQUE7QUFBQUEsa0JBQ0FPLGNBQWMsdUJBQUMsVUFBSyxpQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFPO0FBQUEscUJBWGpCUCxNQURQO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBYUE7QUFBQSxjQUVKLENBQUMsS0FuQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFvQkE7QUFBQSxpQkF4Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkEwQ0E7QUFBQSxlQTVDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTZDQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLGNBQWEsT0FBTztBQUFBLFlBQUVWLGNBQWM7QUFBQSxZQUFRRSxXQUFXO0FBQUEsVUFBUyxHQUFHLHNHQUFsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3SztBQUFBLFVBQ3hLLHVCQUFDLFNBQUksT0FBTztBQUFBLFlBQUViLFNBQVM7QUFBQSxZQUFRSSxLQUFLO0FBQUEsVUFBUSxHQUMxQztBQUFBLG1DQUFDLFlBQU8sV0FBVSxtQkFBa0IsU0FBU2IsVUFBVSxNQUFLLFVBQVMsc0JBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJFO0FBQUEsWUFDM0UsdUJBQUMsWUFBTyxXQUFVLG1CQUFrQixPQUFPO0FBQUEsY0FBRXlCLE1BQU07QUFBQSxjQUFHQyxnQkFBZ0I7QUFBQSxZQUFTLEdBQUcsU0FBU3ZCLGNBQWMsTUFBSyxVQUFTLGlDQUF2SDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3STtBQUFBLGVBRjFJO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQS9GRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ0dBO0FBQUEsV0E3TEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWdNQTtBQUFBLFNBdE1GO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1TUE7QUFBQSxJQUVDaEQsZUFDQyx1QkFBQyxTQUFJLFdBQVUseUJBQ2IsaUNBQUMsU0FBSSxXQUFVLHNCQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLHVCQUNiLGlDQUFDLGdCQUFhLE1BQU0sSUFBSSxPQUFNLGFBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUMsS0FEekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxRQUFHLG1DQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUI7QUFBQSxNQUN2Qix1QkFBQyxPQUFFLG9HQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUY7QUFBQSxNQUN2Rix1QkFBQyxZQUFPLFdBQVUsd0NBQXVDLFNBQVMsTUFBTVQsU0FBUyxZQUFZLEdBQUcsOEJBQWhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNBLEtBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVdBO0FBQUEsT0F4Tko7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTBOQTtBQUVKO0FBQUVILEdBelhJRCxVQUFRO0FBQUEsVUFDNEJILFNBQ3ZCRCxXQUFXO0FBQUE7QUFBQXNHLEtBRnhCbEc7QUEyWE4sZUFBZUE7QUFBUyxJQUFBa0c7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJMaW5rIiwidXNlTmF2aWdhdGUiLCJ1c2VBdXRoIiwiQ2hlY2tDaXJjbGUyIiwibG9nbyIsIlJlZ2lzdGVyIiwiX3MiLCJyZWdpc3RlciIsImNoZWNrQXZhaWxhYmlsaXR5IiwibmF2aWdhdGUiLCJzdGVwIiwic2V0U3RlcCIsImVycm9yIiwic2V0RXJyb3IiLCJzaG93UGFzc3dvcmQiLCJzZXRTaG93UGFzc3dvcmQiLCJzaG93Q29uZmlybVBhc3N3b3JkIiwic2V0U2hvd0NvbmZpcm1QYXNzd29yZCIsInNob3dTdWNjZXNzIiwic2V0U2hvd1N1Y2Nlc3MiLCJmb3JtRGF0YSIsInNldEZvcm1EYXRhIiwiZmlyc3ROYW1lIiwibGFzdE5hbWUiLCJlbWFpbCIsImRlcGFydG1lbnQiLCJ5ZWFyT2ZTdHVkeSIsInBhc3N3b3JkIiwiY29uZmlybVBhc3N3b3JkIiwic3R1ZGVudElkIiwic3BlY2lhbGl6YXRpb24iLCJzZW1lc3RlciIsImJpbyIsImNvbnRhY3ROdW1iZXIiLCJwcmVmZXJyZWRSb2xlcyIsImZpZWxkRXJyb3JzIiwic2V0RmllbGRFcnJvcnMiLCJyb2xlc09wdGlvbnMiLCJhY3RpdmVEcm9wZG93biIsInNldEFjdGl2ZURyb3Bkb3duIiwiaGFuZGxlQ2xpY2tPdXRzaWRlIiwiZG9jdW1lbnQiLCJhZGRFdmVudExpc3RlbmVyIiwicmVtb3ZlRXZlbnRMaXN0ZW5lciIsImFncmVlZFRvVGVybXMiLCJzZXRBZ3JlZWRUb1Rlcm1zIiwiaGFuZGxlQ2hhbmdlIiwiZSIsIm5hbWUiLCJ2YWx1ZSIsInRhcmdldCIsImhhbmRsZU5leHRTdGVwMSIsImhhc051bWJlciIsInRlc3QiLCJlbWFpbFJlZ2V4IiwicmVzIiwiYXZhaWxhYmxlIiwicHJldiIsIm1lc3NhZ2UiLCJzdWNjZXNzIiwiY29uc29sZSIsIndhcm4iLCJoYW5kbGVOZXh0U3RlcDIiLCJwcmV2U3RlcCIsIk1hdGgiLCJtYXgiLCJoYW5kbGVTdWJtaXQiLCJwcmV2ZW50RGVmYXVsdCIsInN0dWRlbnRJZFJlZ2V4IiwicmVzQXZhaWwiLCJmdWxsTmFtZSIsInRyaW0iLCJkaXNwbGF5IiwicGFkZGluZ1RvcCIsImN1cnNvciIsImFsaWduSXRlbXMiLCJnYXAiLCJ3aWR0aCIsImhlaWdodCIsImJvcmRlclJhZGl1cyIsImZvbnRTaXplIiwiZm9udFdlaWdodCIsImNvbG9yIiwibWFyZ2luQm90dG9tIiwidGV4dEFsaWduIiwibWFyZ2luVG9wIiwicGFkZGluZyIsImNoZWNrZWQiLCJmbGV4IiwianVzdGlmeUNvbnRlbnQiLCJzdG9wUHJvcGFnYXRpb24iLCJsZW5ndGgiLCJtYXAiLCJyb2xlIiwidXBkYXRlZCIsImZpbHRlciIsInIiLCJtYXJnaW5MZWZ0Iiwib3BhY2l0eSIsImJhY2tncm91bmRDb2xvciIsImlzU2VsZWN0ZWQiLCJpbmNsdWRlcyIsImV4aXN0cyIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUmVnaXN0ZXIuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyBMaW5rLCB1c2VOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xyXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSAnLi4vLi4vY29udGV4dC9BdXRoQ29udGV4dCc7XHJcbmltcG9ydCB7IENoZWNrQ2lyY2xlMiB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XHJcbmltcG9ydCBsb2dvIGZyb20gJy4uLy4uL2Fzc2V0cy9pbWFnZXMvbG9nby5qcGVnJztcclxuXHJcbmNvbnN0IFJlZ2lzdGVyID0gKCkgPT4ge1xyXG4gIGNvbnN0IHsgcmVnaXN0ZXIsIGNoZWNrQXZhaWxhYmlsaXR5IH0gPSB1c2VBdXRoKCk7XHJcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xyXG4gIGNvbnN0IFtzdGVwLCBzZXRTdGVwXSA9IHVzZVN0YXRlKDEpO1xyXG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUoJycpO1xyXG4gIGNvbnN0IFtzaG93UGFzc3dvcmQsIHNldFNob3dQYXNzd29yZF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3Nob3dDb25maXJtUGFzc3dvcmQsIHNldFNob3dDb25maXJtUGFzc3dvcmRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzaG93U3VjY2Vzcywgc2V0U2hvd1N1Y2Nlc3NdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIFxyXG4gIGNvbnN0IFtmb3JtRGF0YSwgc2V0Rm9ybURhdGFdID0gdXNlU3RhdGUoe1xyXG4gICAgZmlyc3ROYW1lOiAnJyxcclxuICAgIGxhc3ROYW1lOiAnJyxcclxuICAgIGVtYWlsOiAnJyxcclxuICAgIGRlcGFydG1lbnQ6ICcnLFxyXG4gICAgeWVhck9mU3R1ZHk6ICcnLFxyXG4gICAgcGFzc3dvcmQ6ICcnLFxyXG4gICAgY29uZmlybVBhc3N3b3JkOiAnJyxcclxuICAgIHN0dWRlbnRJZDogJycsXHJcbiAgICBzcGVjaWFsaXphdGlvbjogJycsXHJcbiAgICBzZW1lc3RlcjogJycsXHJcbiAgICBiaW86ICcnLFxyXG4gICAgY29udGFjdE51bWJlcjogJycsXHJcbiAgICBwcmVmZXJyZWRSb2xlczogW11cclxuICB9KTtcclxuXHJcbiAgY29uc3QgW2ZpZWxkRXJyb3JzLCBzZXRGaWVsZEVycm9yc10gPSB1c2VTdGF0ZSh7XHJcbiAgICBlbWFpbDogJycsXHJcbiAgICBzdHVkZW50SWQ6ICcnXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IHJvbGVzT3B0aW9ucyA9IFtcIkZyb250ZW5kIERldmVsb3BlclwiLCBcIkJhY2tlbmQgRGV2ZWxvcGVyXCIsIFwiRnVsbHN0YWNrIERldmVsb3BlclwiLCBcIk1vYmlsZSBBcHAgRGV2ZWxvcGVyXCIsIFwiTUwgRW5naW5lZXJcIiwgXCJEYXRhIFNjaWVudGlzdFwiLCBcIlVJL1VYIERlc2lnbmVyXCIsIFwiRGV2T3BzIEVuZ2luZWVyXCIsIFwiUUEgRW5naW5lZXJcIiwgXCJQcm9qZWN0IE1hbmFnZXJcIl07XHJcbiAgY29uc3QgW2FjdGl2ZURyb3Bkb3duLCBzZXRBY3RpdmVEcm9wZG93bl0gPSB1c2VTdGF0ZShudWxsKTtcclxuXHJcbiAgLy8gQ2xvc2UgZHJvcGRvd25zIG9uIGNsaWNrIG91dHNpZGVcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgaGFuZGxlQ2xpY2tPdXRzaWRlID0gKCkgPT4gc2V0QWN0aXZlRHJvcGRvd24obnVsbCk7XHJcbiAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGhhbmRsZUNsaWNrT3V0c2lkZSk7XHJcbiAgICByZXR1cm4gKCkgPT4gZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcignY2xpY2snLCBoYW5kbGVDbGlja091dHNpZGUpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgY29uc3QgW2FncmVlZFRvVGVybXMsIHNldEFncmVlZFRvVGVybXNdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICBjb25zdCBoYW5kbGVDaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyBuYW1lLCB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbiAgICBzZXRGb3JtRGF0YSh7IC4uLmZvcm1EYXRhLCBbbmFtZV06IHZhbHVlIH0pO1xyXG4gICAgaWYgKGVycm9yKSBzZXRFcnJvcignJyk7XHJcbiAgICBpZiAoZmllbGRFcnJvcnNbbmFtZV0pIHNldEZpZWxkRXJyb3JzKHsgLi4uZmllbGRFcnJvcnMsIFtuYW1lXTogJycgfSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlTmV4dFN0ZXAxID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgY29uc3QgeyBmaXJzdE5hbWUsIGxhc3ROYW1lLCBlbWFpbCwgZGVwYXJ0bWVudCwgeWVhck9mU3R1ZHkgfSA9IGZvcm1EYXRhO1xyXG4gICAgaWYgKCFmaXJzdE5hbWUgfHwgIWxhc3ROYW1lIHx8ICFlbWFpbCB8fCAhZGVwYXJ0bWVudCB8fCAheWVhck9mU3R1ZHkpIHtcclxuICAgICAgc2V0RXJyb3IoJ1BsZWFzZSBmaWxsIGFsbCByZXF1aXJlZCBmaWVsZHMgdG8gY29udGludWUuJyk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuICAgIFxyXG4gICAgY29uc3QgaGFzTnVtYmVyID0gL1xcZC87XHJcbiAgICBpZiAoaGFzTnVtYmVyLnRlc3QoZmlyc3ROYW1lKSB8fCBoYXNOdW1iZXIudGVzdChsYXN0TmFtZSkpIHtcclxuICAgICAgc2V0RXJyb3IoJ05hbWVzIGNhbm5vdCBjb250YWluIG51bWJlcnMuJyk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBlbWFpbFJlZ2V4ID0gL15cXFMrQFxcUytcXC5cXFMrJC9pO1xyXG4gICAgaWYgKCFlbWFpbFJlZ2V4LnRlc3QoZW1haWwpKSB7XHJcbiAgICAgIHNldEVycm9yKCdQbGVhc2UgcHJvdmlkZSBhIHZhbGlkIGVtYWlsIGFkZHJlc3MuJyk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICAvLyBDaGVjayBhdmFpbGFiaWxpdHlcclxuICAgIGNvbnN0IHJlcyA9IGF3YWl0IGNoZWNrQXZhaWxhYmlsaXR5KHsgZW1haWwgfSk7XHJcbiAgICBcclxuICAgIC8vIE9ubHkgYmxvY2sgaWYgdGhlIGJhY2tlbmQgZXhwbGljaXRseSBjb25maXJtcyB0aGUgZW1haWwgaXMgYWxyZWFkeSByZWdpc3RlcmVkXHJcbiAgICBpZiAocmVzLmF2YWlsYWJsZSA9PT0gZmFsc2UpIHtcclxuICAgICAgc2V0RmllbGRFcnJvcnMocHJldiA9PiAoeyAuLi5wcmV2LCBlbWFpbDogcmVzLm1lc3NhZ2UgfSkpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgLy8gSWYgdGhlcmUgd2FzIGEgdGVjaG5pY2FsIGVycm9yIChzZXJ2ZXIgZXJyb3IgZHVyaW5nIGNoZWNrKSwgd2UgbG9nIGl0XHJcbiAgICAvLyBidXQgRE9OJ1QgYmxvY2sgdGhlIHVzZXIuIFRoZSBmaW5hbCBDcmVhdGUgQWNjb3VudCBjYWxsIHdpbGwgc3RpbGwgY2F0Y2ggaXQuXHJcbiAgICBpZiAocmVzLnN1Y2Nlc3MgPT09IGZhbHNlKSB7XHJcbiAgICAgIGNvbnNvbGUud2FybignQXZhaWxhYmlsaXR5IGNoZWNrIGZhaWxlZCB0ZWNobmljYWxseTonLCByZXMubWVzc2FnZSk7XHJcbiAgICAgIC8vIFdlIGNsZWFyIHRoZSBlcnJvciBzbyB0aGV5IGFyZW4ndCBzdHVjayBieSBhIDUwMCBlcnJvclxyXG4gICAgICBzZXRGaWVsZEVycm9ycyhwcmV2ID0+ICh7IC4uLnByZXYsIGVtYWlsOiAnJyB9KSk7XHJcbiAgICB9XHJcblxyXG4gICAgc2V0RXJyb3IoJycpO1xyXG4gICAgc2V0RmllbGRFcnJvcnMocHJldiA9PiAoeyAuLi5wcmV2LCBlbWFpbDogJycgfSkpO1xyXG4gICAgc2V0U3RlcCgyKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVOZXh0U3RlcDIgPSAoKSA9PiB7XHJcbiAgICBjb25zdCB7IHBhc3N3b3JkLCBjb25maXJtUGFzc3dvcmQgfSA9IGZvcm1EYXRhO1xyXG4gICAgaWYgKCFwYXNzd29yZCB8fCAhY29uZmlybVBhc3N3b3JkKSB7XHJcbiAgICAgIHNldEVycm9yKCdQbGVhc2UgZmlsbCBpbiBhbmQgY29uZmlybSB5b3VyIHBhc3N3b3JkLicpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcbiAgICBpZiAocGFzc3dvcmQgIT09IGNvbmZpcm1QYXNzd29yZCkge1xyXG4gICAgICBzZXRFcnJvcignUGFzc3dvcmRzIGRvIG5vdCBtYXRjaC4nKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgaWYgKCFhZ3JlZWRUb1Rlcm1zKSB7XHJcbiAgICAgIHNldEVycm9yKCdZb3UgbXVzdCBhZ3JlZSB0byB0aGUgVGVybXMgb2YgU2VydmljZSBhbmQgUHJpdmFjeSBQb2xpY3kgdG8gY29udGludWUuJyk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuICAgIHNldEVycm9yKCcnKTtcclxuICAgIHNldFN0ZXAoMyk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgcHJldlN0ZXAgPSAoKSA9PiB7XHJcbiAgICBzZXRFcnJvcignJyk7XHJcbiAgICBzZXRTdGVwKChwcmV2KSA9PiBNYXRoLm1heChwcmV2IC0gMSwgMSkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICBjb25zdCB7IHN0dWRlbnRJZCwgc3BlY2lhbGl6YXRpb24sIHNlbWVzdGVyIH0gPSBmb3JtRGF0YTtcclxuICAgIGlmICghc3R1ZGVudElkIHx8ICFzcGVjaWFsaXphdGlvbiB8fCAhc2VtZXN0ZXIpIHtcclxuICAgICAgc2V0RXJyb3IoJ1BsZWFzZSBmaWxsIGFsbCByZXF1aXJlZCBmaWVsZHMgdG8gY3JlYXRlIHlvdXIgYWNjb3VudC4nKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IHN0dWRlbnRJZFJlZ2V4ID0gL15pdFxcZHs4fSQvaTtcclxuICAgIGlmICghc3R1ZGVudElkUmVnZXgudGVzdChzdHVkZW50SWQpKSB7XHJcbiAgICAgIHNldEVycm9yKCdTdHVkZW50IElEIG11c3Qgc3RhcnQgd2l0aCBcIklUXCIgZm9sbG93ZWQgYnkgZXhhY3RseSA4IGRpZ2l0cy4nKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIENoZWNrIHN0dWRlbnRJZCBhdmFpbGFiaWxpdHlcclxuICAgIGNvbnN0IHJlc0F2YWlsID0gYXdhaXQgY2hlY2tBdmFpbGFiaWxpdHkoeyBzdHVkZW50SWQgfSk7XHJcbiAgICBpZiAoIXJlc0F2YWlsLmF2YWlsYWJsZSkge1xyXG4gICAgICBzZXRGaWVsZEVycm9ycyhwcmV2ID0+ICh7IC4uLnByZXYsIHN0dWRlbnRJZDogcmVzQXZhaWwubWVzc2FnZSB9KSk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuICAgIFxyXG4gICAgY29uc3QgZnVsbE5hbWUgPSBgJHtmb3JtRGF0YS5maXJzdE5hbWV9ICR7Zm9ybURhdGEubGFzdE5hbWV9YC50cmltKCk7XHJcblxyXG4gICAgY29uc3QgcmVzID0gYXdhaXQgcmVnaXN0ZXIoe1xyXG4gICAgICBmdWxsTmFtZSxcclxuICAgICAgc3R1ZGVudElkOiBmb3JtRGF0YS5zdHVkZW50SWQsXHJcbiAgICAgIGVtYWlsOiBmb3JtRGF0YS5lbWFpbCxcclxuICAgICAgcGFzc3dvcmQ6IGZvcm1EYXRhLnBhc3N3b3JkLFxyXG4gICAgICBkZXBhcnRtZW50OiBmb3JtRGF0YS5kZXBhcnRtZW50LFxyXG4gICAgICBzcGVjaWFsaXphdGlvbjogZm9ybURhdGEuc3BlY2lhbGl6YXRpb24sXHJcbiAgICAgIHllYXJPZlN0dWR5OiBmb3JtRGF0YS55ZWFyT2ZTdHVkeSxcclxuICAgICAgc2VtZXN0ZXI6IGZvcm1EYXRhLnNlbWVzdGVyLFxyXG4gICAgICBiaW86IGZvcm1EYXRhLmJpbyxcclxuICAgICAgY29udGFjdE51bWJlcjogZm9ybURhdGEuY29udGFjdE51bWJlcixcclxuICAgICAgcHJlZmVycmVkUm9sZXM6IGZvcm1EYXRhLnByZWZlcnJlZFJvbGVzXHJcbiAgICB9KTtcclxuICAgIGlmIChyZXMuc3VjY2Vzcykge1xyXG4gICAgICBzZXRTaG93U3VjY2Vzcyh0cnVlKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHNldEVycm9yKHJlcy5tZXNzYWdlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBpZD1cInBhZ2UtcmVnaXN0ZXJcIiBjbGFzc05hbWU9XCJwYWdlIGFjdGl2ZVwiIHN0eWxlPXt7IGRpc3BsYXk6ICdmbGV4JyB9fT5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJhdXRoLWJsb2ItMVwiPjwvZGl2PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImF1dGgtYmxvYi0yXCI+PC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVnLWNvbnRhaW5lclwiIHN0eWxlPXt7IHBhZGRpbmdUb3A6ICcxLjVyZW0nIH19PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYXV0aC1sb2dvXCIgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoJy8nKX0gc3R5bGU9e3sgY3Vyc29yOiAncG9pbnRlcicsIGRpc3BsYXk6ICdmbGV4JywgYWxpZ25JdGVtczogJ2NlbnRlcicsIGdhcDogJzhweCcgfX0+XHJcbiAgICAgICAgICA8aW1nIHNyYz17bG9nb30gYWx0PVwiUHJvTWF0ZSBMb2dvXCIgc3R5bGU9e3sgd2lkdGg6ICc0MHB4JywgaGVpZ2h0OiAnNDBweCcsIGJvcmRlclJhZGl1czogJzUwJScgfX0gLz5cclxuICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGZvbnRTaXplOiAnMS41cmVtJywgZm9udFdlaWdodDogJ2JvbGQnLCBjb2xvcjogJ3ZhcigtLXApJyB9fT5Qcm9NYXRlPC9zcGFuPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVnLWNhcmRcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYXV0aC1oZWFkZXJcIiBzdHlsZT17eyBtYXJnaW5Cb3R0b206ICcxLjI1cmVtJyB9fT5cclxuICAgICAgICAgICAgPGgyPkNyZWF0ZSB5b3VyIGFjY291bnQ8L2gyPlxyXG4gICAgICAgICAgICA8cD5Kb2luIFByb2plY3RNYXRlIGFuZCBmaW5kIHlvdXIgaWRlYWwgcHJvamVjdCB0ZWFtPC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdGVwLWluZGljYXRvclwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YHN0ZXAtZG90ICR7c3RlcCA+PSAxID8gKHN0ZXAgPT09IDEgPyAnY3VycmVudCcgOiAnZG9uZScpIDogJyd9YH0+MTwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YHN0ZXAtbGluZSAke3N0ZXAgPj0gMiA/ICdkb25lJyA6ICcnfWB9PjwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YHN0ZXAtZG90ICR7c3RlcCA+PSAyID8gKHN0ZXAgPT09IDIgPyAnY3VycmVudCcgOiAnZG9uZScpIDogJyd9YH0+MjwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YHN0ZXAtbGluZSAke3N0ZXAgPj0gMyA/ICdkb25lJyA6ICcnfWB9PjwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YHN0ZXAtZG90ICR7c3RlcCA+PSAzID8gKHN0ZXAgPT09IDMgPyAnY3VycmVudCcgOiAnZG9uZScpIDogJyd9YH0+MzwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAge2Vycm9yICYmIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1lcnJvciBzaG93XCIgc3R5bGU9e3sgbWFyZ2luQm90dG9tOiAnMXJlbScsIHRleHRBbGlnbjogJ2NlbnRlcicgfX0+e2Vycm9yfTwvZGl2Pn1cclxuXHJcbiAgICAgICAgICB7c3RlcCA9PT0gMSAmJiAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3RlcC1wYW5lbCBhY3RpdmVcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tcm93XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXBcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZvcm0tbGFiZWxcIj5GaXJzdCBOYW1lPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgY2xhc3NOYW1lPVwiZm9ybS1pbnB1dFwiIG5hbWU9XCJmaXJzdE5hbWVcIiB2YWx1ZT17Zm9ybURhdGEuZmlyc3ROYW1lfSBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfSBwbGFjZWhvbGRlcj1cIkFzaGFuXCIgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmb3JtLWxhYmVsXCI+TGFzdCBOYW1lPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgY2xhc3NOYW1lPVwiZm9ybS1pbnB1dFwiIG5hbWU9XCJsYXN0TmFtZVwiIHZhbHVlPXtmb3JtRGF0YS5sYXN0TmFtZX0gb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX0gcGxhY2Vob2xkZXI9XCJLYXZpbmRhXCIgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncm91cFwiPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZvcm0tbGFiZWxcIj5FbWFpbCBBZGRyZXNzPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwiZW1haWxcIiBjbGFzc05hbWU9e2Bmb3JtLWlucHV0ICR7ZmllbGRFcnJvcnMuZW1haWwgPyAnaW5wdXQtZXJyb3InIDogJyd9YH0gbmFtZT1cImVtYWlsXCIgdmFsdWU9e2Zvcm1EYXRhLmVtYWlsfSBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfSBwbGFjZWhvbGRlcj1cInN0dWRlbnRAZXhhbXBsZS5jb21cIiAvPlxyXG4gICAgICAgICAgICAgICAge2ZpZWxkRXJyb3JzLmVtYWlsICYmIDxkaXYgY2xhc3NOYW1lPVwiZmllbGQtZXJyb3JcIiBzdHlsZT17eyBjb2xvcjogJyNlZjQ0NDQnLCBmb250U2l6ZTogJzAuNzVyZW0nLCBtYXJnaW5Ub3A6ICcwLjM1cmVtJywgZm9udFdlaWdodDogNTAwIH19PntmaWVsZEVycm9ycy5lbWFpbH08L2Rpdj59XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0taGludFwiPkVudGVyIHlvdXIgcHJpbWFyeSBlbWFpbCBhZGRyZXNzPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLXJvd1wiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmb3JtLWxhYmVsXCI+RGVwYXJ0bWVudDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxzZWxlY3QgY2xhc3NOYW1lPVwiZm9ybS1pbnB1dFwiIG5hbWU9XCJkZXBhcnRtZW50XCIgdmFsdWU9e2Zvcm1EYXRhLmRlcGFydG1lbnR9IG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9PlxyXG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5TZWxlY3QgZGVwYXJ0bWVudDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24+Q29tcHV0aW5nPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbj5CdXNpbmVzczwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24+RW5naW5lZXJpbmc8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uPkh1bWFuaXRpZXMgYW5kIFNjaWVuY2VzPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbj5BcmNoaXRlY3R1cmU8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uPkdyYWR1YXRlIFN0dWRpZXM8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uPlNMSUlUIEludGVybmF0aW9uYWwgUHJvZ3JhbW1lczwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmb3JtLWxhYmVsXCI+WWVhciBvZiBTdHVkeTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxzZWxlY3QgY2xhc3NOYW1lPVwiZm9ybS1pbnB1dFwiIG5hbWU9XCJ5ZWFyT2ZTdHVkeVwiIHZhbHVlPXtmb3JtRGF0YS55ZWFyT2ZTdHVkeX0gb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX0+XHJcbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPlNlbGVjdCB5ZWFyPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbj5ZZWFyIDE8L29wdGlvbj48b3B0aW9uPlllYXIgMjwvb3B0aW9uPjxvcHRpb24+WWVhciAzPC9vcHRpb24+PG9wdGlvbj5ZZWFyIDQ8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImJ0biBidG4tcHJpbWFyeSBidG4tZnVsbFwiIHN0eWxlPXt7IHBhZGRpbmc6ICcuOHJlbScgfX0gb25DbGljaz17aGFuZGxlTmV4dFN0ZXAxfSB0eXBlPVwiYnV0dG9uXCI+Q29udGludWUg4oaSPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhdXRoLWZvb3Rlci10ZXh0XCIgc3R5bGU9e3sgbWFyZ2luVG9wOiAnLjc1cmVtJyB9fT5cclxuICAgICAgICAgICAgICAgIEFscmVhZHkgaGF2ZSBhbiBhY2NvdW50PyA8TGluayB0bz1cIi9sb2dpblwiIHN0eWxlPXt7IGN1cnNvcjogJ3BvaW50ZXInIH19PlNpZ24gaW48L0xpbms+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICB7c3RlcCA9PT0gMiAmJiAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3RlcC1wYW5lbCBhY3RpdmVcIj5cclxuICAgICAgICAgICAgICA8cCBzdHlsZT17eyBmb250U2l6ZTogJy44NXJlbScsIGNvbG9yOiAndmFyKC0tbWlkKScsIG1hcmdpbkJvdHRvbTogJzEuMjVyZW0nIH19PlNlY3VyZSB5b3VyIGFjY291bnQgd2l0aCBhIHN0cm9uZyBwYXNzd29yZC48L3A+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwXCI+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZm9ybS1sYWJlbFwiPlBhc3N3b3JkPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHctd3JhcFwiPlxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT17c2hvd1Bhc3N3b3JkID8gXCJ0ZXh0XCIgOiBcInBhc3N3b3JkXCJ9IGNsYXNzTmFtZT1cImZvcm0taW5wdXRcIiBuYW1lPVwicGFzc3dvcmRcIiB2YWx1ZT17Zm9ybURhdGEucGFzc3dvcmR9IG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9IHBsYWNlaG9sZGVyPVwiQ3JlYXRlIGEgc3Ryb25nIHBhc3N3b3JkXCIgLz5cclxuICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJwdy10b2dnbGVcIiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gc2V0U2hvd1Bhc3N3b3JkKCFzaG93UGFzc3dvcmQpfT57c2hvd1Bhc3N3b3JkID8gXCLwn5mIXCIgOiBcIvCfkYHvuI9cIn08L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdy1sYWJlbFwiPkVudGVyIGEgcGFzc3dvcmQ8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXBcIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmb3JtLWxhYmVsXCI+Q29uZmlybSBQYXNzd29yZDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB3LXdyYXBcIj5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9e3Nob3dDb25maXJtUGFzc3dvcmQgPyBcInRleHRcIiA6IFwicGFzc3dvcmRcIn0gY2xhc3NOYW1lPVwiZm9ybS1pbnB1dFwiIG5hbWU9XCJjb25maXJtUGFzc3dvcmRcIiB2YWx1ZT17Zm9ybURhdGEuY29uZmlybVBhc3N3b3JkfSBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfSBwbGFjZWhvbGRlcj1cIlJlcGVhdCB5b3VyIHBhc3N3b3JkXCIgLz5cclxuICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJwdy10b2dnbGVcIiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gc2V0U2hvd0NvbmZpcm1QYXNzd29yZCghc2hvd0NvbmZpcm1QYXNzd29yZCl9PntzaG93Q29uZmlybVBhc3N3b3JkID8gXCLwn5mIXCIgOiBcIvCfkYHvuI9cIn08L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJhZ3JlZS1yb3dcIj5cclxuICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwiY2hlY2tib3hcIiBjaGVja2VkPXthZ3JlZWRUb1Rlcm1zfSBvbkNoYW5nZT17KGUpID0+IHNldEFncmVlZFRvVGVybXMoZS50YXJnZXQuY2hlY2tlZCl9IC8+XHJcbiAgICAgICAgICAgICAgICBJIGFncmVlIHRvIHRoZSA8c3BhbiBzdHlsZT17eyBjb2xvcjogJ3ZhcigtLXApJywgZm9udFdlaWdodDogNjAwIH19PlRlcm1zIG9mIFNlcnZpY2U8L3NwYW4+IGFuZCA8c3BhbiBzdHlsZT17eyBjb2xvcjogJ3ZhcigtLXApJywgZm9udFdlaWdodDogNjAwIH19PlByaXZhY3kgUG9saWN5PC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGdhcDogJy42cmVtJyB9fT5cclxuICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYnRuIGJ0bi1vdXRsaW5lXCIgb25DbGljaz17cHJldlN0ZXB9IHR5cGU9XCJidXR0b25cIj7ihpAgQmFjazwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJidG4gYnRuLXByaW1hcnlcIiBzdHlsZT17eyBmbGV4OiAxLCBqdXN0aWZ5Q29udGVudDogJ2NlbnRlcicgfX0gb25DbGljaz17aGFuZGxlTmV4dFN0ZXAyfSB0eXBlPVwiYnV0dG9uXCI+Q29udGludWUg4oaSPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICB7c3RlcCA9PT0gMyAmJiAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3RlcC1wYW5lbCBhY3RpdmVcIj5cclxuICAgICAgICAgICAgICA8cCBzdHlsZT17eyBmb250U2l6ZTogJy44NXJlbScsIGNvbG9yOiAndmFyKC0tbWlkKScsIG1hcmdpbkJvdHRvbTogJzEuMjVyZW0nIH19PkFsbW9zdCBkb25lISBBIGZldyBtb3JlIGRldGFpbHMgdG8gcGVyc29uYWxpemUgeW91ciBleHBlcmllbmNlLjwvcD5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tcm93XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXBcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZvcm0tbGFiZWxcIj5TdHVkZW50IElEPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgY2xhc3NOYW1lPXtgZm9ybS1pbnB1dCAke2ZpZWxkRXJyb3JzLnN0dWRlbnRJZCA/ICdpbnB1dC1lcnJvcicgOiAnJ31gfSBuYW1lPVwic3R1ZGVudElkXCIgdmFsdWU9e2Zvcm1EYXRhLnN0dWRlbnRJZH0gb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX0gcGxhY2Vob2xkZXI9XCJlLmcuIElUMjMzNDE5NjhcIiAvPlxyXG4gICAgICAgICAgICAgICAgICB7ZmllbGRFcnJvcnMuc3R1ZGVudElkICYmIDxkaXYgY2xhc3NOYW1lPVwiZmllbGQtZXJyb3JcIiBzdHlsZT17eyBjb2xvcjogJyNlZjQ0NDQnLCBmb250U2l6ZTogJzAuNzVyZW0nLCBtYXJnaW5Ub3A6ICcwLjM1cmVtJywgZm9udFdlaWdodDogNTAwIH19PntmaWVsZEVycm9ycy5zdHVkZW50SWR9PC9kaXY+fVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXBcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZvcm0tbGFiZWxcIj5TcGVjaWFsaXphdGlvbjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxzZWxlY3QgY2xhc3NOYW1lPVwiZm9ybS1pbnB1dFwiIG5hbWU9XCJzcGVjaWFsaXphdGlvblwiIHZhbHVlPXtmb3JtRGF0YS5zcGVjaWFsaXphdGlvbn0gb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX0+XHJcbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPlNlbGVjdCBzcGVjaWFsaXphdGlvbjwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJBcnRpZmljaWFsIEludGVsbGlnZW5jZVwiPkFydGlmaWNpYWwgSW50ZWxsaWdlbmNlPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlNvZnR3YXJlIEVuZ2luZWVyaW5nXCI+U29mdHdhcmUgRW5naW5lZXJpbmc8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiQ29tcHV0ZXIgU2NpZW5jZVwiPkNvbXB1dGVyIFNjaWVuY2U8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiSW5mb3JtYXRpb24gVGVjaG5vbG9neVwiPkluZm9ybWF0aW9uIFRlY2hub2xvZ3k8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiRGF0YSBTY2llbmNlXCI+RGF0YSBTY2llbmNlPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkN5YmVyIFNlY3VyaXR5XCI+Q3liZXIgU2VjdXJpdHk8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiQ29tcHV0ZXIgU3lzdGVtICYgTmV0d29yayBFbmdpbmVlcmluZ1wiPkNvbXB1dGVyIFN5c3RlbSAmIE5ldHdvcmsgRW5naW5lZXJpbmc8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiSW5mb3JtYXRpb24gU3lzdGVtcyBFbmdpbmVlcmluZ1wiPkluZm9ybWF0aW9uIFN5c3RlbXMgRW5naW5lZXJpbmc8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiSW50ZXJhY3RpdmUgTWVkaWFcIj5JbnRlcmFjdGl2ZSBNZWRpYTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJDb21wdXRlciBTeXN0ZW1zIEVuZ2luZWVyaW5nXCI+Q29tcHV0ZXIgU3lzdGVtcyBFbmdpbmVlcmluZzwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1yb3dcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncm91cFwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZm9ybS1sYWJlbFwiPlNlbWVzdGVyPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPHNlbGVjdCBjbGFzc05hbWU9XCJmb3JtLWlucHV0XCIgbmFtZT1cInNlbWVzdGVyXCIgdmFsdWU9e2Zvcm1EYXRhLnNlbWVzdGVyfSBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfT5cclxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+U2VsZWN0IHNlbWVzdGVyPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbj5TZW1lc3RlciAxPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbj5TZW1lc3RlciAyPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwXCI+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZm9ybS1sYWJlbFwiPkJpbyA8c3BhbiBzdHlsZT17eyBmb250V2VpZ2h0OiA0MDAsIGNvbG9yOiAndmFyKC0tbWlkKScgfX0+KG9wdGlvbmFsKTwvc3Bhbj48L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgY2xhc3NOYW1lPVwiZm9ybS1pbnB1dFwiIG5hbWU9XCJiaW9cIiB2YWx1ZT17Zm9ybURhdGEuYmlvfSBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfSBwbGFjZWhvbGRlcj1cIlRlbGwgdGVhbW1hdGVzIGEgYml0IGFib3V0IHlvdXJzZWxmLi4uXCIgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwXCI+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZm9ybS1sYWJlbFwiPkNvbnRhY3QgTnVtYmVyIDxzcGFuIHN0eWxlPXt7IGZvbnRXZWlnaHQ6IDQwMCwgY29sb3I6ICd2YXIoLS1taWQpJyB9fT4ob3B0aW9uYWwpPC9zcGFuPjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiBjbGFzc05hbWU9XCJmb3JtLWlucHV0XCIgbmFtZT1cImNvbnRhY3ROdW1iZXJcIiB2YWx1ZT17Zm9ybURhdGEuY29udGFjdE51bWJlcn0gb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX0gcGxhY2Vob2xkZXI9XCIrOTQgNzcgMTIzIDQ1NjdcIiAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXBcIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmb3JtLWxhYmVsXCI+UHJlZmVycmVkIFJvbGVzIDxzcGFuIHN0eWxlPXt7IGZvbnRXZWlnaHQ6IDQwMCwgY29sb3I6ICd2YXIoLS1taWQpJyB9fT4oYXQgbGVhc3Qgb25lKTwvc3Bhbj48L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdWx0aXNlbGVjdC1jb250YWluZXJcIiBvbkNsaWNrPXsoZSkgPT4gZS5zdG9wUHJvcGFnYXRpb24oKX0+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgbXVsdGlzZWxlY3QtaGVhZGVyICR7YWN0aXZlRHJvcGRvd24gPT09ICdyb2xlcycgPyAnbXVsdGlzZWxlY3QtaGVhZGVyLWZvY3VzJyA6ICcnfWB9IG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZURyb3Bkb3duKGFjdGl2ZURyb3Bkb3duID09PSAncm9sZXMnID8gbnVsbCA6ICdyb2xlcycpfT5cclxuICAgICAgICAgICAgICAgICAgICB7Zm9ybURhdGEucHJlZmVycmVkUm9sZXMubGVuZ3RoID09PSAwID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibXVsdGlzZWxlY3QtcGxhY2Vob2xkZXJcIj5TZWxlY3Qgcm9sZXMuLi48L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgIGZvcm1EYXRhLnByZWZlcnJlZFJvbGVzLm1hcChyb2xlID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4ga2V5PXtyb2xlfSBjbGFzc05hbWU9XCJtdWx0aXNlbGVjdC1jaGlwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge3JvbGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibXVsdGlzZWxlY3QtY2hpcC1yZW1vdmVcIiBvbkNsaWNrPXsoZSkgPT4geyBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7IFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdXBkYXRlZCA9IGZvcm1EYXRhLnByZWZlcnJlZFJvbGVzLmZpbHRlcihyID0+IHIgIT09IHJvbGUpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEoeyAuLi5mb3JtRGF0YSwgcHJlZmVycmVkUm9sZXM6IHVwZGF0ZWQgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfX0+w5c8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICkpXHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IG1hcmdpbkxlZnQ6ICdhdXRvJywgb3BhY2l0eTogMC41IH19PnthY3RpdmVEcm9wZG93biA9PT0gJ3JvbGVzJyA/ICfilrInIDogJ+KWvCd9PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAge2FjdGl2ZURyb3Bkb3duID09PSAncm9sZXMnICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm11bHRpc2VsZWN0LWRyb3Bkb3duXCIgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiAnd2hpdGUnIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAge3JvbGVzT3B0aW9ucy5tYXAocm9sZSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGlzU2VsZWN0ZWQgPSBmb3JtRGF0YS5wcmVmZXJyZWRSb2xlcy5pbmNsdWRlcyhyb2xlKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtyb2xlfSBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YG11bHRpc2VsZWN0LW9wdGlvbiAke2lzU2VsZWN0ZWQgPyAnc2VsZWN0ZWQnIDogJyd9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgZXhpc3RzID0gZm9ybURhdGEucHJlZmVycmVkUm9sZXMuaW5jbHVkZXMocm9sZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHVwZGF0ZWQgPSBleGlzdHMgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBmb3JtRGF0YS5wcmVmZXJyZWRSb2xlcy5maWx0ZXIociA9PiByICE9PSByb2xlKSBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFsuLi5mb3JtRGF0YS5wcmVmZXJyZWRSb2xlcywgcm9sZV07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKHsgLi4uZm9ybURhdGEsIHByZWZlcnJlZFJvbGVzOiB1cGRhdGVkIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cm9sZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpc1NlbGVjdGVkICYmIDxzcGFuPuKckzwvc3Bhbj59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWxlcnQtaW5mb1wiIHN0eWxlPXt7IG1hcmdpbkJvdHRvbTogJzFyZW0nLCBtYXJnaW5Ub3A6ICcuNzVyZW0nIH19PuKEue+4jyBZb3UgY2FuIGFkZCBza2lsbHMsIGludGVyZXN0cywgYW5kIGF2YWlsYWJpbGl0eSBmcm9tIHlvdXIgcHJvZmlsZSBhZnRlciBzaWduaW5nIHVwLjwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCBnYXA6ICcuNnJlbScgfX0+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImJ0biBidG4tb3V0bGluZVwiIG9uQ2xpY2s9e3ByZXZTdGVwfSB0eXBlPVwiYnV0dG9uXCI+4oaQIEJhY2s8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYnRuIGJ0bi1wcmltYXJ5XCIgc3R5bGU9e3sgZmxleDogMSwganVzdGlmeUNvbnRlbnQ6ICdjZW50ZXInIH19IG9uQ2xpY2s9e2hhbmRsZVN1Ym1pdH0gdHlwZT1cImJ1dHRvblwiPvCfmoAgQ3JlYXRlIEFjY291bnQ8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApfVxyXG5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7c2hvd1N1Y2Nlc3MgJiYgKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3VjY2Vzcy1tb2RhbC1vdmVybGF5XCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN1Y2Nlc3MtbW9kYWwtY2FyZFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN1Y2Nlc3MtYm91bmNlLWljb25cIj5cclxuICAgICAgICAgICAgICA8Q2hlY2tDaXJjbGUyIHNpemU9ezYwfSBjb2xvcj1cIiMxMGI5ODFcIiAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGgyPldlbGNvbWUgdG8gUHJvTWF0ZSE8L2gyPlxyXG4gICAgICAgICAgICA8cD5Zb3VyIGFjY291bnQgaGFzIGJlZW4gY3JlYXRlZCBzdWNjZXNzZnVsbHkuIExldCdzIGZpbmQgeW91ciBwZXJmZWN0IHByb2plY3QgcGFydG5lci48L3A+XHJcbiAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYnRuIGJ0bi1wcmltYXJ5IGJ0bi1mdWxsIHN1Y2Nlc3MtYnRuXCIgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoJy9kYXNoYm9hcmQnKX0+XHJcbiAgICAgICAgICAgICAgR2V0IFN0YXJ0ZWQg8J+agFxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFJlZ2lzdGVyO1xyXG4iXSwiZmlsZSI6IkY6L1kzUzIvSVRQTSBwcm9qZWN0L1Byb01hdGUtLVByb2plY3QtUGFydG5lci1GaW5kZXIvZnJvbnRlbmQvc3JjL3BhZ2VzL1VzZXJzL1JlZ2lzdGVyLmpzeCJ9