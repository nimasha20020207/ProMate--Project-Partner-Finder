import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Users/ProfileView.jsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=383bea9f"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { useNavigate, useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=383bea9f";
import { useAuth } from "/src/context/AuthContext.jsx";
import { calculateProfileCompleteness } from "/src/utils/profileUtils.js";
const ProfileView = () => {
  _s();
  const navigate = useNavigate();
  const {
    id
  } = useParams();
  const {
    user: authUser,
    token
  } = useAuth();
  const [profileUser, setProfileUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [githubData, setGithubData] = useState(null);
  useEffect(() => {
    const fetchGithub = async () => {
      let username = null;
      if (profileUser?.socialLinks?.github) {
        try {
          const urlStr = profileUser.socialLinks.github;
          if (urlStr.includes("github.com/")) {
            username = new URL(urlStr).pathname.split("/").filter(Boolean).pop();
          } else {
            username = urlStr.replace("@", "");
          }
        } catch (e) {
        }
      }
      if (username) {
        try {
          const res = await fetch(`https://api.github.com/users/${username}`);
          if (res.ok) {
            const data = await res.json();
            setGithubData({
              ...data,
              extractedUsername: username
            });
          }
        } catch (err) {
          console.error("Github fetch error", err);
        }
      } else {
        setGithubData(null);
      }
    };
    if (profileUser) {
      fetchGithub();
    }
  }, [profileUser]);
  useEffect(() => {
    const fetchPublicProfile = async () => {
      try {
        const res = await fetch(`http://localhost:3000/api/profile/${id}`, {
          headers: {
            "x-auth-token": token
          }
        });
        if (res.ok) {
          const data = await res.json();
          setProfileUser(data);
        }
      } catch (err) {
        console.error("Failed to load public profile", err);
      } finally {
        setLoading(false);
      }
    };
    if (id) {
      fetchPublicProfile();
    } else {
      setProfileUser(authUser);
      setLoading(false);
    }
  }, [id, authUser, token]);
  if (loading)
    return /* @__PURE__ */ jsxDEV("div", { style: {
      padding: "2rem",
      textAlign: "center"
    }, children: "Loading Profile..." }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
      lineNumber: 78,
      columnNumber: 23
    }, this);
  if (!profileUser)
    return /* @__PURE__ */ jsxDEV("div", { style: {
      padding: "2rem",
      textAlign: "center"
    }, children: "Profile not found" }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
      lineNumber: 82,
      columnNumber: 28
    }, this);
  const user = profileUser;
  const isOwnProfile = !id || id === authUser?._id;
  const getInitials = (name) => name ? name.split(" ").map((n) => n[0]).join("").substring(0, 2).toUpperCase() : "U";
  const initials = getInitials(user?.fullName);
  const fullName = user?.fullName || "Student Name";
  const department = user?.department || "Department Not Set";
  const studentId = user?.studentId || "N/A";
  const year = user?.academicInfo?.year ? `Year ${user.academicInfo.year}` : "Year N/A";
  const bio = user?.bio || "Passionate about full-stack development and AI-powered apps. Looking for collaborative projects.";
  const {
    percentage: completeness
  } = calculateProfileCompleteness(user);
  return /* @__PURE__ */ jsxDEV("div", { id: "page-profile-view", className: "page active", style: {
    display: "block",
    paddingBottom: "3rem"
  }, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "page-hdr", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "page-hdr-left", children: /* @__PURE__ */ jsxDEV("h1", { children: "My Profile" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
        lineNumber: 104,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
        lineNumber: 103,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "page-hdr-right", children: [
        /* @__PURE__ */ jsxDEV("button", { className: "btn btn-outline btn-sm", onClick: () => navigate("/dashboard"), children: "← Dashboard" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
          lineNumber: 107,
          columnNumber: 11
        }, this),
        isOwnProfile && /* @__PURE__ */ jsxDEV("button", { className: "btn btn-primary btn-sm", onClick: () => navigate("/edit-profile"), children: "✏️ Edit Profile" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
          lineNumber: 108,
          columnNumber: 28
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
        lineNumber: 106,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
      lineNumber: 102,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "profile-hero premium-hero", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "ph-avatar premium-avatar", id: "pv-hero-avatar", style: {
        overflow: "hidden"
      }, children: user?.profilePicture ? /* @__PURE__ */ jsxDEV("img", { src: user.profilePicture, alt: "Profile", style: {
        width: "100%",
        height: "100%",
        objectFit: "cover"
      } }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
        lineNumber: 116,
        columnNumber: 35
      }, this) : initials }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
        lineNumber: 113,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "ph-info", children: [
        /* @__PURE__ */ jsxDEV("h2", { id: "pv-hero-name", className: "premium-name", children: fullName }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
          lineNumber: 123,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "ph-dept premium-dept", id: "pv-hero-dept", children: [
          "📍 ",
          department,
          " · ",
          year
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
          lineNumber: 124,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "ph-chips", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "ph-chip glass-chip", children: [
            "🎓 ",
            user?.specialization || user?.academicInfo?.specialization || "Specialization Not Set"
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
            lineNumber: 126,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "ph-chip glass-chip", children: [
            "📞 ",
            user?.contactNumber || "No Contact"
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
            lineNumber: 127,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "ph-chip glass-chip", children: "🟢 Available" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
            lineNumber: 128,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
          lineNumber: 125,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
        lineNumber: 122,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "ph-actions", children: isOwnProfile && /* @__PURE__ */ jsxDEV("button", { className: "btn btn-ghost btn-sm premium-edit-btn", onClick: () => navigate("/edit-profile"), children: "✏️ Edit" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
        lineNumber: 132,
        columnNumber: 28
      }, this) }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
        lineNumber: 131,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
      lineNumber: 112,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "profile-view-grid", children: [
      /* @__PURE__ */ jsxDEV("div", { style: {
        display: "flex",
        flexDirection: "column",
        gap: "1rem"
      }, children: [
        /* @__PURE__ */ jsxDEV("div", { className: "profile-sidebar-card shadow-card", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "pv-avatar shadow-avatar", id: "pv-sidebar-avatar", style: {
            overflow: "hidden"
          }, children: user?.profilePicture ? /* @__PURE__ */ jsxDEV("img", { src: user.profilePicture, alt: "Profile", style: {
            width: "100%",
            height: "100%",
            objectFit: "cover"
          } }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
            lineNumber: 146,
            columnNumber: 39
          }, this) : initials }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
            lineNumber: 143,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "pv-name", id: "pv-sidebar-name", children: fullName }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
            lineNumber: 152,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "pv-dept", id: "pv-sidebar-dept", children: department }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
            lineNumber: 153,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "pv-score-ring", style: {
            background: `conic-gradient(var(--p) ${completeness}%, var(--border) 0)`
          }, children: /* @__PURE__ */ jsxDEV("div", { className: "pv-score-inner", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "pv-score-num", children: [
              completeness,
              "%"
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
              lineNumber: 157,
              columnNumber: 47
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "pv-score-lbl", children: "COMPLETE" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
              lineNumber: 157,
              columnNumber: 98
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
            lineNumber: 157,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
            lineNumber: 154,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: {
            display: "flex",
            gap: ".4rem",
            justifyContent: "center",
            marginBottom: "1rem",
            flexWrap: "wrap"
          }, children: [
            /* @__PURE__ */ jsxDEV("span", { style: {
              background: "var(--pl)",
              color: "var(--p)",
              border: "1px solid #BFDBFE",
              fontSize: ".72rem",
              padding: "3px 9px",
              borderRadius: "20px",
              fontWeight: 600
            }, children: "🟢 Available" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
              lineNumber: 166,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("span", { style: {
              background: "var(--pl)",
              color: "var(--p)",
              border: "1px solid #BFDBFE",
              fontSize: ".72rem",
              padding: "3px 9px",
              borderRadius: "20px",
              fontWeight: 600
            }, children: year }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
              lineNumber: 175,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
            lineNumber: 159,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "pv-detail", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "pv-detail-lbl", children: "Department" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
              lineNumber: 185,
              columnNumber: 40
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "pv-detail-val", id: "pv-dept-val", children: department }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
              lineNumber: 185,
              columnNumber: 89
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
            lineNumber: 185,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "pv-detail", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "pv-detail-lbl", children: "Year" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
              lineNumber: 186,
              columnNumber: 40
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "pv-detail-val", id: "pv-year-val", children: year }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
              lineNumber: 186,
              columnNumber: 83
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
            lineNumber: 186,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "pv-detail", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "pv-detail-lbl", children: "Student ID" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
              lineNumber: 187,
              columnNumber: 40
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "pv-detail-val", id: "pv-id-val", children: studentId }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
              lineNumber: 187,
              columnNumber: 89
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
            lineNumber: 187,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "pv-detail", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "pv-detail-lbl", children: "Contact" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
              lineNumber: 188,
              columnNumber: 40
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "pv-detail-val", children: user?.contactNumber || "Not Provided" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
              lineNumber: 188,
              columnNumber: 86
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
            lineNumber: 188,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "pv-detail", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "pv-detail-lbl", children: "CGPA" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
              lineNumber: 189,
              columnNumber: 40
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "pv-detail-val", id: "pv-cgpa-val", children: user?.academicInfo?.cgpa || "N/A" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
              lineNumber: 189,
              columnNumber: 83
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
            lineNumber: 189,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "pv-detail", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "pv-detail-lbl", children: "Domain" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
              lineNumber: 190,
              columnNumber: 40
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "pv-detail-val", children: user?.academicInfo?.specialization || "N/A" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
              lineNumber: 190,
              columnNumber: 85
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
            lineNumber: 190,
            columnNumber: 13
          }, this),
          isOwnProfile && /* @__PURE__ */ jsxDEV("button", { className: "btn btn-primary btn-full shadow-hover-btn", style: {
            marginTop: "1rem"
          }, onClick: () => navigate("/edit-profile"), children: "✏️ Edit Profile" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
            lineNumber: 191,
            columnNumber: 30
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
          lineNumber: 142,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "card card-sm shadow-card", children: [
          /* @__PURE__ */ jsxDEV("div", { style: {
            fontFamily: "'Sora', sans-serif",
            fontSize: ".88rem",
            fontWeight: 700,
            marginBottom: ".7rem"
          }, children: "🎭 Preferred Roles" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
            lineNumber: 196,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "roles-list", children: user?.preferredRoles?.length > 0 ? user.preferredRoles.map((role) => /* @__PURE__ */ jsxDEV("div", { className: "role-row", children: [
            "✅ ",
            /* @__PURE__ */ jsxDEV("span", { children: role }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
              lineNumber: 203,
              columnNumber: 122
            }, this)
          ] }, role, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
            lineNumber: 203,
            columnNumber: 83
          }, this)) : /* @__PURE__ */ jsxDEV("div", { className: "role-row", style: {
            color: "var(--mid)"
          }, children: [
            "⬜ ",
            /* @__PURE__ */ jsxDEV("span", { children: "No roles selected" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
              lineNumber: 205,
              columnNumber: 18
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
            lineNumber: 203,
            columnNumber: 151
          }, this) }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
            lineNumber: 202,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
          lineNumber: 195,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
        lineNumber: 137,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "profile-right", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "card shadow-card", children: [
          /* @__PURE__ */ jsxDEV("div", { style: {
            fontFamily: "'Sora', sans-serif",
            fontSize: "1rem",
            fontWeight: 700,
            marginBottom: ".6rem"
          }, children: "👤 About" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
            lineNumber: 212,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { id: "pv-bio", style: {
            fontSize: ".875rem",
            color: "var(--mid)",
            lineHeight: 1.65
          }, children: bio }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
            lineNumber: 218,
            columnNumber: 13
          }, this),
          (user?.socialLinks?.github || user?.socialLinks?.linkedin || user?.socialLinks?.portfolio) && /* @__PURE__ */ jsxDEV("div", { style: {
            marginTop: "1rem",
            display: "flex",
            gap: "0.5rem",
            flexWrap: "wrap"
          }, children: [
            user.socialLinks.github && /* @__PURE__ */ jsxDEV("a", { href: user.socialLinks.github, target: "_blank", rel: "noopener noreferrer", className: "btn btn-outline btn-sm", style: {
              padding: "0.4rem 0.8rem",
              borderRadius: "20px",
              fontSize: "0.8rem"
            }, children: "🐙 GitHub" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
              lineNumber: 230,
              columnNumber: 45
            }, this),
            user.socialLinks.linkedin && /* @__PURE__ */ jsxDEV("a", { href: user.socialLinks.linkedin, target: "_blank", rel: "noopener noreferrer", className: "btn btn-outline btn-sm", style: {
              padding: "0.4rem 0.8rem",
              borderRadius: "20px",
              fontSize: "0.8rem",
              background: "#0A66C2",
              color: "white",
              border: "none"
            }, children: "💼 LinkedIn" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
              lineNumber: 235,
              columnNumber: 47
            }, this),
            user.socialLinks.portfolio && /* @__PURE__ */ jsxDEV("a", { href: user.socialLinks.portfolio, target: "_blank", rel: "noopener noreferrer", className: "btn btn-outline btn-sm", style: {
              padding: "0.4rem 0.8rem",
              borderRadius: "20px",
              fontSize: "0.8rem",
              background: "var(--dark)",
              color: "white",
              border: "none"
            }, children: "🌐 Portfolio" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
              lineNumber: 243,
              columnNumber: 48
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
            lineNumber: 224,
            columnNumber: 108
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
          lineNumber: 211,
          columnNumber: 11
        }, this),
        githubData && /* @__PURE__ */ jsxDEV("div", { className: "card shadow-card", style: {
          background: "linear-gradient(145deg, #ffffff 0%, #f8fafc 100%)",
          border: "1px solid #e2e8f0",
          borderRadius: "12px",
          padding: "1.25rem"
        }, children: [
          /* @__PURE__ */ jsxDEV("div", { style: {
            display: "flex",
            alignItems: "center",
            gap: "12px",
            marginBottom: "1.25rem"
          }, children: [
            /* @__PURE__ */ jsxDEV("img", { src: githubData.avatar_url, alt: "GitHub Avatar", style: {
              width: "45px",
              height: "45px",
              borderRadius: "50%",
              border: "2px solid #2563eb",
              padding: "2px"
            } }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
              lineNumber: 266,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("div", { style: {
                fontFamily: "'Sora', sans-serif",
                fontSize: "1rem",
                fontWeight: 700,
                color: "#1e293b"
              }, children: githubData.name || githubData.login }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
                lineNumber: 274,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("a", { href: githubData.html_url, target: "_blank", rel: "noopener noreferrer", style: {
                fontSize: "0.8rem",
                color: "#64748b",
                textDecoration: "none",
                fontWeight: 500
              }, children: [
                "@",
                githubData.login
              ] }, void 0, true, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
                lineNumber: 280,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
              lineNumber: 273,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { style: {
              marginLeft: "auto",
              background: "#e0e7ff",
              padding: "8px",
              borderRadius: "50%",
              color: "#3730A3",
              display: "flex",
              alignItems: "center",
              justifyItems: "center"
            }, children: /* @__PURE__ */ jsxDEV("svg", { height: "20", viewBox: "0 0 16 16", width: "20", fill: "currentColor", children: /* @__PURE__ */ jsxDEV("path", { fillRule: "evenodd", d: "M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0016 8c0-4.42-3.58-8-8-8z" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
              lineNumber: 297,
              columnNumber: 87
            }, this) }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
              lineNumber: 297,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
              lineNumber: 287,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
            lineNumber: 260,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: {
            display: "grid",
            gridTemplateColumns: "repeat(3, 1fr)",
            gap: "10px",
            textAlign: "center"
          }, children: [
            /* @__PURE__ */ jsxDEV("div", { style: {
              background: "#f1f5f9",
              padding: "10px",
              borderRadius: "8px",
              border: "1px solid #e2e8f0"
            }, children: [
              /* @__PURE__ */ jsxDEV("div", { style: {
                fontSize: "1.25rem",
                fontWeight: 800,
                color: "#2563eb"
              }, children: githubData.public_repos }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
                lineNumber: 313,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { style: {
                fontSize: "0.7rem",
                color: "#64748b",
                fontWeight: 700,
                textTransform: "uppercase",
                letterSpacing: "0.5px"
              }, children: "Repos" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
                lineNumber: 318,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
              lineNumber: 307,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { style: {
              background: "#f1f5f9",
              padding: "10px",
              borderRadius: "8px",
              border: "1px solid #e2e8f0"
            }, children: [
              /* @__PURE__ */ jsxDEV("div", { style: {
                fontSize: "1.25rem",
                fontWeight: 800,
                color: "#2563eb"
              }, children: githubData.followers }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
                lineNumber: 332,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { style: {
                fontSize: "0.7rem",
                color: "#64748b",
                fontWeight: 700,
                textTransform: "uppercase",
                letterSpacing: "0.5px"
              }, children: "Followers" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
                lineNumber: 337,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
              lineNumber: 326,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { style: {
              background: "#f1f5f9",
              padding: "10px",
              borderRadius: "8px",
              border: "1px solid #e2e8f0"
            }, children: [
              /* @__PURE__ */ jsxDEV("div", { style: {
                fontSize: "1.25rem",
                fontWeight: 800,
                color: "#2563eb"
              }, children: githubData.following }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
                lineNumber: 351,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { style: {
                fontSize: "0.7rem",
                color: "#64748b",
                fontWeight: 700,
                textTransform: "uppercase",
                letterSpacing: "0.5px"
              }, children: "Following" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
                lineNumber: 356,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
              lineNumber: 345,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
            lineNumber: 301,
            columnNumber: 15
          }, this),
          githubData.bio && /* @__PURE__ */ jsxDEV("div", { style: {
            marginTop: "1.25rem",
            fontSize: "0.85rem",
            color: "#475569",
            fontStyle: "italic",
            borderLeft: "3px solid #cbd5e1",
            paddingLeft: "10px",
            lineHeight: 1.5
          }, children: [
            '"',
            githubData.bio,
            '"'
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
            lineNumber: 366,
            columnNumber: 34
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
          lineNumber: 254,
          columnNumber: 26
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "card shadow-card", children: [
          /* @__PURE__ */ jsxDEV("div", { style: {
            fontFamily: "'Sora', sans-serif",
            fontSize: "1rem",
            fontWeight: 700,
            marginBottom: ".75rem"
          }, children: "🧩 Skills" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
            lineNumber: 380,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "skill-tags", id: "pv-skills", children: [
            ["languages", "frameworks", "libraries", "databases", "tools"].map((cat) => user?.skills?.[cat] && user.skills[cat].length > 0 ? user.skills[cat].map((skill) => /* @__PURE__ */ jsxDEV("span", { className: "skill-tag skill-tag-premium", children: skill }, `${cat}-${skill}`, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
              lineNumber: 387,
              columnNumber: 173
            }, this)) : null),
            !user?.skills && /* @__PURE__ */ jsxDEV("span", { className: "skill-tag", children: "No skills added" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
              lineNumber: 388,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
            lineNumber: 386,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
          lineNumber: 379,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "card shadow-card", children: [
          /* @__PURE__ */ jsxDEV("div", { style: {
            fontFamily: "'Sora', sans-serif",
            fontSize: "1rem",
            fontWeight: 700,
            marginBottom: ".75rem"
          }, children: "💡 Interests" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
            lineNumber: 393,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: {
            display: "flex",
            flexWrap: "wrap",
            gap: ".4rem"
          }, children: user?.interests?.length > 0 ? user.interests.map((int) => /* @__PURE__ */ jsxDEV("span", { className: "int-chip active premium-chip", children: int }, int, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
            lineNumber: 404,
            columnNumber: 72
          }, this)) : /* @__PURE__ */ jsxDEV("span", { className: "int-chip", children: "No interests added" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
            lineNumber: 404,
            columnNumber: 145
          }, this) }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
            lineNumber: 399,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
          lineNumber: 392,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "card shadow-card", children: [
          /* @__PURE__ */ jsxDEV("div", { style: {
            fontFamily: "'Sora', sans-serif",
            fontSize: "1rem",
            fontWeight: 700,
            marginBottom: ".75rem"
          }, children: "🕐 Availability" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
            lineNumber: 409,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "avail-grid", style: {
            marginBottom: ".75rem"
          }, children: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"].map((day) => /* @__PURE__ */ jsxDEV("div", { className: "day-block", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "day-lbl", children: day.substring(0, 3) }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
              lineNumber: 419,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: `edit-day-chip ${user?.availability?.preferredDays?.includes(day) ? "active" : ""}`, children: user?.availability?.preferredDays?.includes(day) ? "✓" : "" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
              lineNumber: 420,
              columnNumber: 19
            }, this)
          ] }, day, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
            lineNumber: 418,
            columnNumber: 106
          }, this)) }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
            lineNumber: 415,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: {
            textAlign: "center",
            fontFamily: "'Sora', sans-serif",
            fontSize: "1.5rem",
            fontWeight: 800,
            color: "var(--p)"
          }, children: [
            user?.availability?.weeklyHours || 0,
            " ",
            /* @__PURE__ */ jsxDEV("small", { style: {
              fontSize: ".75rem",
              color: "var(--mid)",
              fontFamily: "inherit",
              fontWeight: 400
            }, children: "hours / week" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
              lineNumber: 432,
              columnNumber: 54
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
            lineNumber: 425,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
          lineNumber: 408,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
        lineNumber: 210,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
      lineNumber: 136,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx",
    lineNumber: 98,
    columnNumber: 10
  }, this);
};
_s(ProfileView, "eK5MRg/zbOtpiGZMbO87EkBCx9w=", false, function() {
  return [useNavigate, useParams, useAuth];
});
_c = ProfileView;
export default ProfileView;
var _c;
$RefreshReg$(_c, "ProfileView");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ProfileView.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0VzQjs7Ozs7Ozs7Ozs7Ozs7OztBQXhFdEIsT0FBT0EsU0FBU0MsVUFBVUMsaUJBQWlCO0FBQzNDLFNBQVNDLGFBQWFDLGlCQUFpQjtBQUN2QyxTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLG9DQUFvQztBQUU3QyxNQUFNQyxjQUFjQSxNQUFNO0FBQUFDLEtBQUE7QUFDeEIsUUFBTUMsV0FBV04sWUFBWTtBQUM3QixRQUFNO0FBQUEsSUFBRU87QUFBQUEsRUFBRyxJQUFJTixVQUFVO0FBQ3pCLFFBQU07QUFBQSxJQUFFTyxNQUFNQztBQUFBQSxJQUFVQztBQUFBQSxFQUFNLElBQUlSLFFBQVE7QUFFMUMsUUFBTSxDQUFDUyxhQUFhQyxjQUFjLElBQUlkLFNBQVMsSUFBSTtBQUNuRCxRQUFNLENBQUNlLFNBQVNDLFVBQVUsSUFBSWhCLFNBQVMsSUFBSTtBQUMzQyxRQUFNLENBQUNpQixZQUFZQyxhQUFhLElBQUlsQixTQUFTLElBQUk7QUFFakRDLFlBQVUsTUFBTTtBQUNkLFVBQU1rQixjQUFjLFlBQVk7QUFDOUIsVUFBSUMsV0FBVztBQUNmLFVBQUlQLGFBQWFRLGFBQWFDLFFBQVE7QUFDcEMsWUFBSTtBQUNGLGdCQUFNQyxTQUFTVixZQUFZUSxZQUFZQztBQUN2QyxjQUFJQyxPQUFPQyxTQUFTLGFBQWEsR0FBRztBQUNsQ0osdUJBQVcsSUFBSUssSUFBSUYsTUFBTSxFQUFFRyxTQUFTQyxNQUFNLEdBQUcsRUFBRUMsT0FBT0MsT0FBTyxFQUFFQyxJQUFJO0FBQUEsVUFDckUsT0FBTztBQUNMVix1QkFBV0csT0FBT1EsUUFBUSxLQUFLLEVBQUU7QUFBQSxVQUNuQztBQUFBLFFBQ0YsU0FBU0MsR0FBRztBQUFBLFFBQUM7QUFBQSxNQUNmO0FBRUEsVUFBSVosVUFBVTtBQUNaLFlBQUk7QUFDRixnQkFBTWEsTUFBTSxNQUFNQyxNQUFNLGdDQUFnQ2QsUUFBUSxFQUFFO0FBQ2xFLGNBQUlhLElBQUlFLElBQUk7QUFDVixrQkFBTUMsT0FBTyxNQUFNSCxJQUFJSSxLQUFLO0FBQzVCbkIsMEJBQWM7QUFBQSxjQUFFLEdBQUdrQjtBQUFBQSxjQUFNRSxtQkFBbUJsQjtBQUFBQSxZQUFTLENBQUM7QUFBQSxVQUN4RDtBQUFBLFFBQ0YsU0FBU21CLEtBQUs7QUFDWkMsa0JBQVFDLE1BQU0sc0JBQXNCRixHQUFHO0FBQUEsUUFDekM7QUFBQSxNQUNGLE9BQU87QUFDTHJCLHNCQUFjLElBQUk7QUFBQSxNQUNwQjtBQUFBLElBQ0Y7QUFDQSxRQUFJTCxhQUFhO0FBQ2ZNLGtCQUFZO0FBQUEsSUFDZDtBQUFBLEVBQ0YsR0FBRyxDQUFDTixXQUFXLENBQUM7QUFFaEJaLFlBQVUsTUFBTTtBQUNkLFVBQU15QyxxQkFBcUIsWUFBWTtBQUNyQyxVQUFJO0FBQ0YsY0FBTVQsTUFBTSxNQUFNQyxNQUFNLHFDQUFxQ3pCLEVBQUUsSUFBSTtBQUFBLFVBQ2pFa0MsU0FBUztBQUFBLFlBQUUsZ0JBQWdCL0I7QUFBQUEsVUFBTTtBQUFBLFFBQ25DLENBQUM7QUFDRCxZQUFJcUIsSUFBSUUsSUFBSTtBQUNWLGdCQUFNQyxPQUFPLE1BQU1ILElBQUlJLEtBQUs7QUFDNUJ2Qix5QkFBZXNCLElBQUk7QUFBQSxRQUNyQjtBQUFBLE1BQ0YsU0FBU0csS0FBSztBQUNaQyxnQkFBUUMsTUFBTSxpQ0FBaUNGLEdBQUc7QUFBQSxNQUNwRCxVQUFDO0FBQ0N2QixtQkFBVyxLQUFLO0FBQUEsTUFDbEI7QUFBQSxJQUNGO0FBRUEsUUFBSVAsSUFBSTtBQUNOaUMseUJBQW1CO0FBQUEsSUFDckIsT0FBTztBQUNMNUIscUJBQWVILFFBQVE7QUFDdkJLLGlCQUFXLEtBQUs7QUFBQSxJQUNsQjtBQUFBLEVBQ0YsR0FBRyxDQUFDUCxJQUFJRSxVQUFVQyxLQUFLLENBQUM7QUFFeEIsTUFBSUc7QUFBUyxXQUFPLHVCQUFDLFNBQUksT0FBTztBQUFBLE1BQUU2QixTQUFTO0FBQUEsTUFBUUMsV0FBVztBQUFBLElBQVMsR0FBRyxrQ0FBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF3RTtBQUM1RixNQUFJLENBQUNoQztBQUFhLFdBQU8sdUJBQUMsU0FBSSxPQUFPO0FBQUEsTUFBRStCLFNBQVM7QUFBQSxNQUFRQyxXQUFXO0FBQUEsSUFBUyxHQUFHLGlDQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXVFO0FBRWhHLFFBQU1uQyxPQUFPRztBQUNiLFFBQU1pQyxlQUFlLENBQUNyQyxNQUFNQSxPQUFPRSxVQUFVb0M7QUFFN0MsUUFBTUMsY0FBZUMsVUFBU0EsT0FBT0EsS0FBS3RCLE1BQU0sR0FBRyxFQUFFdUIsSUFBSUMsT0FBS0EsRUFBRSxDQUFDLENBQUMsRUFBRUMsS0FBSyxFQUFFLEVBQUVDLFVBQVUsR0FBRyxDQUFDLEVBQUVDLFlBQVksSUFBSTtBQUM3RyxRQUFNQyxXQUFXUCxZQUFZdEMsTUFBTThDLFFBQVE7QUFDM0MsUUFBTUEsV0FBVzlDLE1BQU04QyxZQUFZO0FBQ25DLFFBQU1DLGFBQWEvQyxNQUFNK0MsY0FBYztBQUN2QyxRQUFNQyxZQUFZaEQsTUFBTWdELGFBQWE7QUFDckMsUUFBTUMsT0FBT2pELE1BQU1rRCxjQUFjRCxPQUFPLFFBQVFqRCxLQUFLa0QsYUFBYUQsSUFBSSxLQUFLO0FBQzNFLFFBQU1FLE1BQU1uRCxNQUFNbUQsT0FBTztBQUN6QixRQUFNO0FBQUEsSUFBRUMsWUFBWUM7QUFBQUEsRUFBYSxJQUFJMUQsNkJBQTZCSyxJQUFJO0FBRXRFLFNBQ0UsdUJBQUMsU0FBSSxJQUFHLHFCQUFvQixXQUFVLGVBQWMsT0FBTztBQUFBLElBQUVzRCxTQUFTO0FBQUEsSUFBU0MsZUFBZTtBQUFBLEVBQU8sR0FDbkc7QUFBQSwyQkFBQyxTQUFJLFdBQVUsWUFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxpQkFDYixpQ0FBQyxRQUFHLDBCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBYyxLQURoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxrQkFDYjtBQUFBLCtCQUFDLFlBQU8sV0FBVSwwQkFBeUIsU0FBUyxNQUFNekQsU0FBUyxZQUFZLEdBQUcsMkJBQWxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkY7QUFBQSxRQUM1RnNDLGdCQUFnQix1QkFBQyxZQUFPLFdBQVUsMEJBQXlCLFNBQVMsTUFBTXRDLFNBQVMsZUFBZSxHQUFHLCtCQUFyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9HO0FBQUEsV0FGdkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsU0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUE7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSw0QkFBMkIsSUFBRyxrQkFBaUIsT0FBTztBQUFBLFFBQUUwRCxVQUFVO0FBQUEsTUFBUyxHQUN2RnhELGdCQUFNeUQsaUJBQ0gsdUJBQUMsU0FBSSxLQUFLekQsS0FBS3lELGdCQUFnQixLQUFJLFdBQVUsT0FBTztBQUFBLFFBQUVDLE9BQU87QUFBQSxRQUFRQyxRQUFRO0FBQUEsUUFBUUMsV0FBVztBQUFBLE1BQVEsS0FBeEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEwRyxJQUMxR2YsWUFITjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUE7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxXQUNiO0FBQUEsK0JBQUMsUUFBRyxJQUFHLGdCQUFlLFdBQVUsZ0JBQWdCQyxzQkFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5RDtBQUFBLFFBQ3pELHVCQUFDLFNBQUksV0FBVSx3QkFBdUIsSUFBRyxnQkFBZTtBQUFBO0FBQUEsVUFBSUM7QUFBQUEsVUFBVztBQUFBLFVBQUlFO0FBQUFBLGFBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0Y7QUFBQSxRQUNoRix1QkFBQyxTQUFJLFdBQVUsWUFDYjtBQUFBLGlDQUFDLFVBQUssV0FBVSxzQkFBcUI7QUFBQTtBQUFBLFlBQUlqRCxNQUFNNkQsa0JBQWtCN0QsTUFBTWtELGNBQWNXLGtCQUFrQjtBQUFBLGVBQXZHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdJO0FBQUEsVUFDaEksdUJBQUMsVUFBSyxXQUFVLHNCQUFxQjtBQUFBO0FBQUEsWUFBSTdELE1BQU04RCxpQkFBaUI7QUFBQSxlQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2RTtBQUFBLFVBQzdFLHVCQUFDLFVBQUssV0FBVSxzQkFBcUIsNEJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlEO0FBQUEsYUFIbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlBO0FBQUEsV0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUE7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxjQUNaMUIsMEJBQWdCLHVCQUFDLFlBQU8sV0FBVSx5Q0FBd0MsU0FBUyxNQUFNdEMsU0FBUyxlQUFlLEdBQUcsdUJBQXBHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMkcsS0FEOUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWtCQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUEsNkJBQUMsU0FBSSxPQUFPO0FBQUEsUUFBRXdELFNBQVM7QUFBQSxRQUFRUyxlQUFlO0FBQUEsUUFBVUMsS0FBSztBQUFBLE1BQU8sR0FDbEU7QUFBQSwrQkFBQyxTQUFJLFdBQVUsb0NBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsMkJBQTBCLElBQUcscUJBQW9CLE9BQU87QUFBQSxZQUFFUixVQUFVO0FBQUEsVUFBUyxHQUN6RnhELGdCQUFNeUQsaUJBQ0gsdUJBQUMsU0FBSSxLQUFLekQsS0FBS3lELGdCQUFnQixLQUFJLFdBQVUsT0FBTztBQUFBLFlBQUVDLE9BQU87QUFBQSxZQUFRQyxRQUFRO0FBQUEsWUFBUUMsV0FBVztBQUFBLFVBQVEsS0FBeEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEcsSUFDMUdmLFlBSE47QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLFdBQVUsSUFBRyxtQkFBbUJDLHNCQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3RDtBQUFBLFVBQ3hELHVCQUFDLFNBQUksV0FBVSxXQUFVLElBQUcsbUJBQW1CQyx3QkFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEQ7QUFBQSxVQUMxRCx1QkFBQyxTQUFJLFdBQVUsaUJBQWdCLE9BQU87QUFBQSxZQUFFa0IsWUFBWSwyQkFBMkJaLFlBQVk7QUFBQSxVQUFzQixHQUMvRyxpQ0FBQyxTQUFJLFdBQVUsa0JBQWlCO0FBQUEsbUNBQUMsU0FBSSxXQUFVLGdCQUFnQkE7QUFBQUE7QUFBQUEsY0FBYTtBQUFBLGlCQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2QztBQUFBLFlBQU0sdUJBQUMsU0FBSSxXQUFVLGdCQUFlLHdCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzQztBQUFBLGVBQXpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStILEtBRGpJO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFNBQUksT0FBTztBQUFBLFlBQUVDLFNBQVM7QUFBQSxZQUFRVSxLQUFLO0FBQUEsWUFBU0UsZ0JBQWdCO0FBQUEsWUFBVUMsY0FBYztBQUFBLFlBQVFDLFVBQVU7QUFBQSxVQUFPLEdBQzVHO0FBQUEsbUNBQUMsVUFBSyxPQUFPO0FBQUEsY0FBRUgsWUFBWTtBQUFBLGNBQWFJLE9BQU87QUFBQSxjQUFZQyxRQUFRO0FBQUEsY0FBcUJDLFVBQVU7QUFBQSxjQUFVckMsU0FBUztBQUFBLGNBQVdzQyxjQUFjO0FBQUEsY0FBUUMsWUFBWTtBQUFBLFlBQUksR0FBRyw0QkFBeks7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUw7QUFBQSxZQUNyTCx1QkFBQyxVQUFLLE9BQU87QUFBQSxjQUFFUixZQUFZO0FBQUEsY0FBYUksT0FBTztBQUFBLGNBQVlDLFFBQVE7QUFBQSxjQUFxQkMsVUFBVTtBQUFBLGNBQVVyQyxTQUFTO0FBQUEsY0FBV3NDLGNBQWM7QUFBQSxjQUFRQyxZQUFZO0FBQUEsWUFBSSxHQUFJeEIsa0JBQTFLO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStLO0FBQUEsZUFGakw7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLGFBQVk7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsaUJBQWdCLDBCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwQztBQUFBLFlBQU8sdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixJQUFHLGVBQWVGLHdCQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2RDtBQUFBLGVBQXpJO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdKO0FBQUEsVUFDaEosdUJBQUMsU0FBSSxXQUFVLGFBQVk7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsaUJBQWdCLG9CQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvQztBQUFBLFlBQU8sdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixJQUFHLGVBQWVFLGtCQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1RDtBQUFBLGVBQTdIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9JO0FBQUEsVUFDcEksdUJBQUMsU0FBSSxXQUFVLGFBQVk7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsaUJBQWdCLDBCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwQztBQUFBLFlBQU8sdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixJQUFHLGFBQWFELHVCQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwRDtBQUFBLGVBQXRJO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZJO0FBQUEsVUFDN0ksdUJBQUMsU0FBSSxXQUFVLGFBQVk7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsaUJBQWdCLHVCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1QztBQUFBLFlBQU8sdUJBQUMsVUFBSyxXQUFVLGlCQUFpQmhELGdCQUFNOEQsaUJBQWlCLGtCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1RTtBQUFBLGVBQWhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVKO0FBQUEsVUFDdkosdUJBQUMsU0FBSSxXQUFVLGFBQVk7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsaUJBQWdCLG9CQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvQztBQUFBLFlBQU8sdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixJQUFHLGVBQWU5RCxnQkFBTWtELGNBQWN3QixRQUFRLFNBQTlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9GO0FBQUEsZUFBMUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBaUs7QUFBQSxVQUNqSyx1QkFBQyxTQUFJLFdBQVUsYUFBWTtBQUFBLG1DQUFDLFVBQUssV0FBVSxpQkFBZ0Isc0JBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNDO0FBQUEsWUFBTyx1QkFBQyxVQUFLLFdBQVUsaUJBQWlCMUUsZ0JBQU1rRCxjQUFjVyxrQkFBa0IsU0FBdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkU7QUFBQSxlQUFySjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0SjtBQUFBLFVBQzNKekIsZ0JBQWdCLHVCQUFDLFlBQU8sV0FBVSw2Q0FBNEMsT0FBTztBQUFBLFlBQUV1QyxXQUFXO0FBQUEsVUFBTyxHQUFHLFNBQVMsTUFBTTdFLFNBQVMsZUFBZSxHQUFHLCtCQUF0STtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxSjtBQUFBLGFBckJ4SztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBc0JBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsNEJBQ2I7QUFBQSxpQ0FBQyxTQUFJLE9BQU87QUFBQSxZQUFFOEUsWUFBWTtBQUFBLFlBQXNCTCxVQUFVO0FBQUEsWUFBVUUsWUFBWTtBQUFBLFlBQUtOLGNBQWM7QUFBQSxVQUFRLEdBQUcsa0NBQTlHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdJO0FBQUEsVUFDaEksdUJBQUMsU0FBSSxXQUFVLGNBQ1puRSxnQkFBTTZFLGdCQUFnQkMsU0FBUyxJQUFJOUUsS0FBSzZFLGVBQWVyQyxJQUFJdUMsVUFDekQsdUJBQUMsU0FBZSxXQUFVLFlBQVc7QUFBQTtBQUFBLFlBQUUsdUJBQUMsVUFBTUEsa0JBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBWTtBQUFBLGVBQXpDQSxNQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBELENBQzVELElBQUksdUJBQUMsU0FBSSxXQUFVLFlBQVcsT0FBTztBQUFBLFlBQUVWLE9BQU87QUFBQSxVQUFhLEdBQUc7QUFBQTtBQUFBLFlBQUUsdUJBQUMsVUFBSyxpQ0FBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1QjtBQUFBLGVBQW5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBGLEtBSGpHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSUE7QUFBQSxhQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFdBL0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFnQ0E7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxvQkFDYjtBQUFBLGlDQUFDLFNBQUksT0FBTztBQUFBLFlBQUVPLFlBQVk7QUFBQSxZQUFzQkwsVUFBVTtBQUFBLFlBQVFFLFlBQVk7QUFBQSxZQUFLTixjQUFjO0FBQUEsVUFBUSxHQUFHLHdCQUE1RztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvSDtBQUFBLFVBQ3BILHVCQUFDLE9BQUUsSUFBRyxVQUFTLE9BQU87QUFBQSxZQUFFSSxVQUFVO0FBQUEsWUFBV0YsT0FBTztBQUFBLFlBQWNXLFlBQVk7QUFBQSxVQUFLLEdBQUk3QixpQkFBdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkY7QUFBQSxXQUV6Rm5ELE1BQU1XLGFBQWFDLFVBQVVaLE1BQU1XLGFBQWFzRSxZQUFZakYsTUFBTVcsYUFBYXVFLGNBQy9FLHVCQUFDLFNBQUksT0FBTztBQUFBLFlBQUVQLFdBQVc7QUFBQSxZQUFRckIsU0FBUztBQUFBLFlBQVFVLEtBQUs7QUFBQSxZQUFVSSxVQUFVO0FBQUEsVUFBTyxHQUMvRXBFO0FBQUFBLGlCQUFLVyxZQUFZQyxVQUNoQix1QkFBQyxPQUFFLE1BQU1aLEtBQUtXLFlBQVlDLFFBQVEsUUFBTyxVQUFTLEtBQUksdUJBQXNCLFdBQVUsMEJBQXlCLE9BQU87QUFBQSxjQUFFc0IsU0FBUztBQUFBLGNBQWlCc0MsY0FBYztBQUFBLGNBQVFELFVBQVU7QUFBQSxZQUFTLEdBQUcseUJBQTlMO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVNO0FBQUEsWUFFeE12RSxLQUFLVyxZQUFZc0UsWUFDaEIsdUJBQUMsT0FBRSxNQUFNakYsS0FBS1csWUFBWXNFLFVBQVUsUUFBTyxVQUFTLEtBQUksdUJBQXNCLFdBQVUsMEJBQXlCLE9BQU87QUFBQSxjQUFFL0MsU0FBUztBQUFBLGNBQWlCc0MsY0FBYztBQUFBLGNBQVFELFVBQVU7QUFBQSxjQUFVTixZQUFZO0FBQUEsY0FBV0ksT0FBTztBQUFBLGNBQVNDLFFBQVE7QUFBQSxZQUFPLEdBQUcsMkJBQXZQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtRO0FBQUEsWUFFblF0RSxLQUFLVyxZQUFZdUUsYUFDaEIsdUJBQUMsT0FBRSxNQUFNbEYsS0FBS1csWUFBWXVFLFdBQVcsUUFBTyxVQUFTLEtBQUksdUJBQXNCLFdBQVUsMEJBQXlCLE9BQU87QUFBQSxjQUFFaEQsU0FBUztBQUFBLGNBQWlCc0MsY0FBYztBQUFBLGNBQVFELFVBQVU7QUFBQSxjQUFVTixZQUFZO0FBQUEsY0FBZUksT0FBTztBQUFBLGNBQVNDLFFBQVE7QUFBQSxZQUFPLEdBQUcsNEJBQTVQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdRO0FBQUEsZUFSNVE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQTtBQUFBLGFBZko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWlCQTtBQUFBLFFBRUMvRCxjQUNDLHVCQUFDLFNBQUksV0FBVSxvQkFBbUIsT0FBTztBQUFBLFVBQUUwRCxZQUFZO0FBQUEsVUFBcURLLFFBQVE7QUFBQSxVQUFxQkUsY0FBYztBQUFBLFVBQVF0QyxTQUFTO0FBQUEsUUFBVSxHQUNoTDtBQUFBLGlDQUFDLFNBQUksT0FBTztBQUFBLFlBQUVvQixTQUFTO0FBQUEsWUFBUTZCLFlBQVk7QUFBQSxZQUFVbkIsS0FBSztBQUFBLFlBQVFHLGNBQWM7QUFBQSxVQUFVLEdBQ3hGO0FBQUEsbUNBQUMsU0FBSSxLQUFLNUQsV0FBVzZFLFlBQVksS0FBSSxpQkFBZ0IsT0FBTztBQUFBLGNBQUUxQixPQUFPO0FBQUEsY0FBUUMsUUFBUTtBQUFBLGNBQVFhLGNBQWM7QUFBQSxjQUFPRixRQUFRO0FBQUEsY0FBcUJwQyxTQUFTO0FBQUEsWUFBTSxLQUE5SjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnSztBQUFBLFlBQ2hLLHVCQUFDLFNBQ0M7QUFBQSxxQ0FBQyxTQUFJLE9BQU87QUFBQSxnQkFBRTBDLFlBQVk7QUFBQSxnQkFBc0JMLFVBQVU7QUFBQSxnQkFBUUUsWUFBWTtBQUFBLGdCQUFLSixPQUFPO0FBQUEsY0FBVSxHQUFJOUQscUJBQVdnQyxRQUFRaEMsV0FBVzhFLFNBQXRJO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTRJO0FBQUEsY0FDNUksdUJBQUMsT0FBRSxNQUFNOUUsV0FBVytFLFVBQVUsUUFBTyxVQUFTLEtBQUksdUJBQXNCLE9BQU87QUFBQSxnQkFBRWYsVUFBVTtBQUFBLGdCQUFVRixPQUFPO0FBQUEsZ0JBQVdrQixnQkFBZ0I7QUFBQSxnQkFBUWQsWUFBWTtBQUFBLGNBQUksR0FBRztBQUFBO0FBQUEsZ0JBQUVsRSxXQUFXOEU7QUFBQUEsbUJBQS9LO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFMO0FBQUEsaUJBRnZMO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksT0FBTztBQUFBLGNBQUVHLFlBQVk7QUFBQSxjQUFRdkIsWUFBWTtBQUFBLGNBQVcvQixTQUFTO0FBQUEsY0FBT3NDLGNBQWM7QUFBQSxjQUFPSCxPQUFPO0FBQUEsY0FBV2YsU0FBUztBQUFBLGNBQVE2QixZQUFZO0FBQUEsY0FBVU0sY0FBYztBQUFBLFlBQVMsR0FDNUssaUNBQUMsU0FBSSxRQUFPLE1BQUssU0FBUSxhQUFZLE9BQU0sTUFBSyxNQUFLLGdCQUFlLGlDQUFDLFVBQUssVUFBUyxXQUFVLEdBQUUsOGpCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzbEIsS0FBMXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlxQixLQURucUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFTQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxPQUFPO0FBQUEsWUFBRW5DLFNBQVM7QUFBQSxZQUFRb0MscUJBQXFCO0FBQUEsWUFBa0IxQixLQUFLO0FBQUEsWUFBUTdCLFdBQVc7QUFBQSxVQUFTLEdBQ3JHO0FBQUEsbUNBQUMsU0FBSSxPQUFPO0FBQUEsY0FBRThCLFlBQVk7QUFBQSxjQUFXL0IsU0FBUztBQUFBLGNBQVFzQyxjQUFjO0FBQUEsY0FBT0YsUUFBUTtBQUFBLFlBQW9CLEdBQ3JHO0FBQUEscUNBQUMsU0FBSSxPQUFPO0FBQUEsZ0JBQUVDLFVBQVU7QUFBQSxnQkFBV0UsWUFBWTtBQUFBLGdCQUFLSixPQUFPO0FBQUEsY0FBVSxHQUFJOUQscUJBQVdvRixnQkFBcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUc7QUFBQSxjQUNqRyx1QkFBQyxTQUFJLE9BQU87QUFBQSxnQkFBRXBCLFVBQVU7QUFBQSxnQkFBVUYsT0FBTztBQUFBLGdCQUFXSSxZQUFZO0FBQUEsZ0JBQUttQixlQUFlO0FBQUEsZ0JBQWFDLGVBQWU7QUFBQSxjQUFRLEdBQUcscUJBQTNIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdJO0FBQUEsaUJBRmxJO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksT0FBTztBQUFBLGNBQUU1QixZQUFZO0FBQUEsY0FBVy9CLFNBQVM7QUFBQSxjQUFRc0MsY0FBYztBQUFBLGNBQU9GLFFBQVE7QUFBQSxZQUFvQixHQUNyRztBQUFBLHFDQUFDLFNBQUksT0FBTztBQUFBLGdCQUFFQyxVQUFVO0FBQUEsZ0JBQVdFLFlBQVk7QUFBQSxnQkFBS0osT0FBTztBQUFBLGNBQVUsR0FBSTlELHFCQUFXdUYsYUFBcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBOEY7QUFBQSxjQUM5Rix1QkFBQyxTQUFJLE9BQU87QUFBQSxnQkFBRXZCLFVBQVU7QUFBQSxnQkFBVUYsT0FBTztBQUFBLGdCQUFXSSxZQUFZO0FBQUEsZ0JBQUttQixlQUFlO0FBQUEsZ0JBQWFDLGVBQWU7QUFBQSxjQUFRLEdBQUcseUJBQTNIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9JO0FBQUEsaUJBRnRJO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksT0FBTztBQUFBLGNBQUU1QixZQUFZO0FBQUEsY0FBVy9CLFNBQVM7QUFBQSxjQUFRc0MsY0FBYztBQUFBLGNBQU9GLFFBQVE7QUFBQSxZQUFvQixHQUNyRztBQUFBLHFDQUFDLFNBQUksT0FBTztBQUFBLGdCQUFFQyxVQUFVO0FBQUEsZ0JBQVdFLFlBQVk7QUFBQSxnQkFBS0osT0FBTztBQUFBLGNBQVUsR0FBSTlELHFCQUFXd0YsYUFBcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBOEY7QUFBQSxjQUM5Rix1QkFBQyxTQUFJLE9BQU87QUFBQSxnQkFBRXhCLFVBQVU7QUFBQSxnQkFBVUYsT0FBTztBQUFBLGdCQUFXSSxZQUFZO0FBQUEsZ0JBQUttQixlQUFlO0FBQUEsZ0JBQWFDLGVBQWU7QUFBQSxjQUFRLEdBQUcseUJBQTNIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9JO0FBQUEsaUJBRnRJO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxlQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBYUE7QUFBQSxVQUVDdEYsV0FBVzRDLE9BQ1YsdUJBQUMsU0FBSSxPQUFPO0FBQUEsWUFBRXdCLFdBQVc7QUFBQSxZQUFXSixVQUFVO0FBQUEsWUFBV0YsT0FBTztBQUFBLFlBQVcyQixXQUFXO0FBQUEsWUFBVUMsWUFBWTtBQUFBLFlBQXFCQyxhQUFhO0FBQUEsWUFBUWxCLFlBQVk7QUFBQSxVQUFJLEdBQUc7QUFBQTtBQUFBLFlBQ3JLekUsV0FBVzRDO0FBQUFBLFlBQUk7QUFBQSxlQURuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUE5Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWdDQTtBQUFBLFFBR0YsdUJBQUMsU0FBSSxXQUFVLG9CQUNiO0FBQUEsaUNBQUMsU0FBSSxPQUFPO0FBQUEsWUFBRXlCLFlBQVk7QUFBQSxZQUFzQkwsVUFBVTtBQUFBLFlBQVFFLFlBQVk7QUFBQSxZQUFLTixjQUFjO0FBQUEsVUFBUyxHQUFHLHlCQUE3RztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzSDtBQUFBLFVBQ3RILHVCQUFDLFNBQUksV0FBVSxjQUFhLElBQUcsYUFDNUI7QUFBQSxhQUFDLGFBQWEsY0FBYyxhQUFhLGFBQWEsT0FBTyxFQUFFM0IsSUFBSTJELFNBQ2xFbkcsTUFBTW9HLFNBQVNELEdBQUcsS0FBS25HLEtBQUtvRyxPQUFPRCxHQUFHLEVBQUVyQixTQUFTLElBQUk5RSxLQUFLb0csT0FBT0QsR0FBRyxFQUFFM0QsSUFBSTZELFdBQ3hFLHVCQUFDLFVBQTZCLFdBQVUsK0JBQStCQSxtQkFBNUQsR0FBR0YsR0FBRyxJQUFJRSxLQUFLLElBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZFLENBQzlFLElBQUksSUFDTjtBQUFBLFlBQ0EsQ0FBQ3JHLE1BQU1vRyxVQUFVLHVCQUFDLFVBQUssV0FBVSxhQUFZLCtCQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyQztBQUFBLGVBTi9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0E7QUFBQSxhQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLG9CQUNiO0FBQUEsaUNBQUMsU0FBSSxPQUFPO0FBQUEsWUFBRXhCLFlBQVk7QUFBQSxZQUFzQkwsVUFBVTtBQUFBLFlBQVFFLFlBQVk7QUFBQSxZQUFLTixjQUFjO0FBQUEsVUFBUyxHQUFHLDRCQUE3RztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5SDtBQUFBLFVBQ3pILHVCQUFDLFNBQUksT0FBTztBQUFBLFlBQUViLFNBQVM7QUFBQSxZQUFRYyxVQUFVO0FBQUEsWUFBUUosS0FBSztBQUFBLFVBQVEsR0FDM0RoRSxnQkFBTXNHLFdBQVd4QixTQUFTLElBQUk5RSxLQUFLc0csVUFBVTlELElBQUkrRCxTQUNoRCx1QkFBQyxVQUFlLFdBQVUsZ0NBQWdDQSxpQkFBL0NBLEtBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEQsQ0FDL0QsSUFBSSx1QkFBQyxVQUFLLFdBQVUsWUFBVyxrQ0FBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkMsS0FIcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJQTtBQUFBLGFBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsb0JBQ2I7QUFBQSxpQ0FBQyxTQUFJLE9BQU87QUFBQSxZQUFFM0IsWUFBWTtBQUFBLFlBQXNCTCxVQUFVO0FBQUEsWUFBUUUsWUFBWTtBQUFBLFlBQUtOLGNBQWM7QUFBQSxVQUFTLEdBQUcsK0JBQTdHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRIO0FBQUEsVUFDNUgsdUJBQUMsU0FBSSxXQUFVLGNBQWEsT0FBTztBQUFBLFlBQUVBLGNBQWM7QUFBQSxVQUFTLEdBQ3pELFdBQUMsVUFBUyxXQUFVLGFBQVksWUFBVyxVQUFTLFlBQVcsUUFBUSxFQUFFM0IsSUFBSWdFLFNBQzVFLHVCQUFDLFNBQWMsV0FBVSxhQUN2QjtBQUFBLG1DQUFDLFNBQUksV0FBVSxXQUFXQSxjQUFJN0QsVUFBVSxHQUFFLENBQUMsS0FBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkM7QUFBQSxZQUM3Qyx1QkFBQyxTQUFJLFdBQVcsaUJBQWlCM0MsTUFBTXlHLGNBQWNDLGVBQWU1RixTQUFTMEYsR0FBRyxJQUFJLFdBQVcsRUFBRSxJQUM5RnhHLGdCQUFNeUcsY0FBY0MsZUFBZTVGLFNBQVMwRixHQUFHLElBQUksTUFBTSxNQUQ1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFKUUEsS0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBLENBQ0QsS0FSSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVNBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLE9BQU87QUFBQSxZQUFFckUsV0FBVztBQUFBLFlBQVV5QyxZQUFZO0FBQUEsWUFBc0JMLFVBQVU7QUFBQSxZQUFVRSxZQUFZO0FBQUEsWUFBS0osT0FBTztBQUFBLFVBQVcsR0FDekhyRTtBQUFBQSxrQkFBTXlHLGNBQWNFLGVBQWU7QUFBQSxZQUFFO0FBQUEsWUFBQyx1QkFBQyxXQUFNLE9BQU87QUFBQSxjQUFFcEMsVUFBVTtBQUFBLGNBQVVGLE9BQU87QUFBQSxjQUFjTyxZQUFZO0FBQUEsY0FBV0gsWUFBWTtBQUFBLFlBQUksR0FBRyw0QkFBbkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0c7QUFBQSxlQUR4SjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZUE7QUFBQSxXQTVGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNkZBO0FBQUEsU0FoSUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlJQTtBQUFBLE9BaEtGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FpS0E7QUFFSjtBQUFFNUUsR0F0UElELGFBQVc7QUFBQSxVQUNFSixhQUNGQyxXQUNtQkMsT0FBTztBQUFBO0FBQUFrSCxLQUhyQ2hIO0FBd1BOLGVBQWVBO0FBQVksSUFBQWdIO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsInVzZVN0YXRlIiwidXNlRWZmZWN0IiwidXNlTmF2aWdhdGUiLCJ1c2VQYXJhbXMiLCJ1c2VBdXRoIiwiY2FsY3VsYXRlUHJvZmlsZUNvbXBsZXRlbmVzcyIsIlByb2ZpbGVWaWV3IiwiX3MiLCJuYXZpZ2F0ZSIsImlkIiwidXNlciIsImF1dGhVc2VyIiwidG9rZW4iLCJwcm9maWxlVXNlciIsInNldFByb2ZpbGVVc2VyIiwibG9hZGluZyIsInNldExvYWRpbmciLCJnaXRodWJEYXRhIiwic2V0R2l0aHViRGF0YSIsImZldGNoR2l0aHViIiwidXNlcm5hbWUiLCJzb2NpYWxMaW5rcyIsImdpdGh1YiIsInVybFN0ciIsImluY2x1ZGVzIiwiVVJMIiwicGF0aG5hbWUiLCJzcGxpdCIsImZpbHRlciIsIkJvb2xlYW4iLCJwb3AiLCJyZXBsYWNlIiwiZSIsInJlcyIsImZldGNoIiwib2siLCJkYXRhIiwianNvbiIsImV4dHJhY3RlZFVzZXJuYW1lIiwiZXJyIiwiY29uc29sZSIsImVycm9yIiwiZmV0Y2hQdWJsaWNQcm9maWxlIiwiaGVhZGVycyIsInBhZGRpbmciLCJ0ZXh0QWxpZ24iLCJpc093blByb2ZpbGUiLCJfaWQiLCJnZXRJbml0aWFscyIsIm5hbWUiLCJtYXAiLCJuIiwiam9pbiIsInN1YnN0cmluZyIsInRvVXBwZXJDYXNlIiwiaW5pdGlhbHMiLCJmdWxsTmFtZSIsImRlcGFydG1lbnQiLCJzdHVkZW50SWQiLCJ5ZWFyIiwiYWNhZGVtaWNJbmZvIiwiYmlvIiwicGVyY2VudGFnZSIsImNvbXBsZXRlbmVzcyIsImRpc3BsYXkiLCJwYWRkaW5nQm90dG9tIiwib3ZlcmZsb3ciLCJwcm9maWxlUGljdHVyZSIsIndpZHRoIiwiaGVpZ2h0Iiwib2JqZWN0Rml0Iiwic3BlY2lhbGl6YXRpb24iLCJjb250YWN0TnVtYmVyIiwiZmxleERpcmVjdGlvbiIsImdhcCIsImJhY2tncm91bmQiLCJqdXN0aWZ5Q29udGVudCIsIm1hcmdpbkJvdHRvbSIsImZsZXhXcmFwIiwiY29sb3IiLCJib3JkZXIiLCJmb250U2l6ZSIsImJvcmRlclJhZGl1cyIsImZvbnRXZWlnaHQiLCJjZ3BhIiwibWFyZ2luVG9wIiwiZm9udEZhbWlseSIsInByZWZlcnJlZFJvbGVzIiwibGVuZ3RoIiwicm9sZSIsImxpbmVIZWlnaHQiLCJsaW5rZWRpbiIsInBvcnRmb2xpbyIsImFsaWduSXRlbXMiLCJhdmF0YXJfdXJsIiwibG9naW4iLCJodG1sX3VybCIsInRleHREZWNvcmF0aW9uIiwibWFyZ2luTGVmdCIsImp1c3RpZnlJdGVtcyIsImdyaWRUZW1wbGF0ZUNvbHVtbnMiLCJwdWJsaWNfcmVwb3MiLCJ0ZXh0VHJhbnNmb3JtIiwibGV0dGVyU3BhY2luZyIsImZvbGxvd2VycyIsImZvbGxvd2luZyIsImZvbnRTdHlsZSIsImJvcmRlckxlZnQiLCJwYWRkaW5nTGVmdCIsImNhdCIsInNraWxscyIsInNraWxsIiwiaW50ZXJlc3RzIiwiaW50IiwiZGF5IiwiYXZhaWxhYmlsaXR5IiwicHJlZmVycmVkRGF5cyIsIndlZWtseUhvdXJzIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJQcm9maWxlVmlldy5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IHVzZU5hdmlnYXRlLCB1c2VQYXJhbXMgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcclxuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4uLy4uL2NvbnRleHQvQXV0aENvbnRleHQnO1xyXG5pbXBvcnQgeyBjYWxjdWxhdGVQcm9maWxlQ29tcGxldGVuZXNzIH0gZnJvbSAnLi4vLi4vdXRpbHMvcHJvZmlsZVV0aWxzJztcclxuXHJcbmNvbnN0IFByb2ZpbGVWaWV3ID0gKCkgPT4ge1xyXG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcclxuICBjb25zdCB7IGlkIH0gPSB1c2VQYXJhbXMoKTtcclxuICBjb25zdCB7IHVzZXI6IGF1dGhVc2VyLCB0b2tlbiB9ID0gdXNlQXV0aCgpO1xyXG4gIFxyXG4gIGNvbnN0IFtwcm9maWxlVXNlciwgc2V0UHJvZmlsZVVzZXJdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSk7XHJcbiAgY29uc3QgW2dpdGh1YkRhdGEsIHNldEdpdGh1YkRhdGFdID0gdXNlU3RhdGUobnVsbCk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaEdpdGh1YiA9IGFzeW5jICgpID0+IHtcclxuICAgICAgbGV0IHVzZXJuYW1lID0gbnVsbDtcclxuICAgICAgaWYgKHByb2ZpbGVVc2VyPy5zb2NpYWxMaW5rcz8uZ2l0aHViKSB7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIGNvbnN0IHVybFN0ciA9IHByb2ZpbGVVc2VyLnNvY2lhbExpbmtzLmdpdGh1YjtcclxuICAgICAgICAgIGlmICh1cmxTdHIuaW5jbHVkZXMoJ2dpdGh1Yi5jb20vJykpIHtcclxuICAgICAgICAgICAgdXNlcm5hbWUgPSBuZXcgVVJMKHVybFN0cikucGF0aG5hbWUuc3BsaXQoJy8nKS5maWx0ZXIoQm9vbGVhbikucG9wKCk7XHJcbiAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB1c2VybmFtZSA9IHVybFN0ci5yZXBsYWNlKCdAJywgJycpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHt9XHJcbiAgICAgIH1cclxuICAgICAgXHJcbiAgICAgIGlmICh1c2VybmFtZSkge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaChgaHR0cHM6Ly9hcGkuZ2l0aHViLmNvbS91c2Vycy8ke3VzZXJuYW1lfWApO1xyXG4gICAgICAgICAgaWYgKHJlcy5vaykge1xyXG4gICAgICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzLmpzb24oKTtcclxuICAgICAgICAgICAgc2V0R2l0aHViRGF0YSh7IC4uLmRhdGEsIGV4dHJhY3RlZFVzZXJuYW1lOiB1c2VybmFtZSB9KTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJHaXRodWIgZmV0Y2ggZXJyb3JcIiwgZXJyKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgc2V0R2l0aHViRGF0YShudWxsKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGlmIChwcm9maWxlVXNlcikge1xyXG4gICAgICBmZXRjaEdpdGh1YigpO1xyXG4gICAgfVxyXG4gIH0sIFtwcm9maWxlVXNlcl0pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hQdWJsaWNQcm9maWxlID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKGBodHRwOi8vbG9jYWxob3N0OjMwMDAvYXBpL3Byb2ZpbGUvJHtpZH1gLCB7XHJcbiAgICAgICAgICBoZWFkZXJzOiB7IFwieC1hdXRoLXRva2VuXCI6IHRva2VuIH1cclxuICAgICAgICB9KTtcclxuICAgICAgICBpZiAocmVzLm9rKSB7XHJcbiAgICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzLmpzb24oKTtcclxuICAgICAgICAgIHNldFByb2ZpbGVVc2VyKGRhdGEpO1xyXG4gICAgICAgIH1cclxuICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBsb2FkIHB1YmxpYyBwcm9maWxlXCIsIGVycik7XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgaWYgKGlkKSB7XHJcbiAgICAgIGZldGNoUHVibGljUHJvZmlsZSgpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgc2V0UHJvZmlsZVVzZXIoYXV0aFVzZXIpO1xyXG4gICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9LCBbaWQsIGF1dGhVc2VyLCB0b2tlbl0pO1xyXG5cclxuICBpZiAobG9hZGluZykgcmV0dXJuIDxkaXYgc3R5bGU9e3sgcGFkZGluZzogJzJyZW0nLCB0ZXh0QWxpZ246ICdjZW50ZXInIH19PkxvYWRpbmcgUHJvZmlsZS4uLjwvZGl2PjtcclxuICBpZiAoIXByb2ZpbGVVc2VyKSByZXR1cm4gPGRpdiBzdHlsZT17eyBwYWRkaW5nOiAnMnJlbScsIHRleHRBbGlnbjogJ2NlbnRlcicgfX0+UHJvZmlsZSBub3QgZm91bmQ8L2Rpdj47XHJcblxyXG4gIGNvbnN0IHVzZXIgPSBwcm9maWxlVXNlcjtcclxuICBjb25zdCBpc093blByb2ZpbGUgPSAhaWQgfHwgaWQgPT09IGF1dGhVc2VyPy5faWQ7XHJcblxyXG4gIGNvbnN0IGdldEluaXRpYWxzID0gKG5hbWUpID0+IG5hbWUgPyBuYW1lLnNwbGl0KCcgJykubWFwKG4gPT4gblswXSkuam9pbignJykuc3Vic3RyaW5nKDAsIDIpLnRvVXBwZXJDYXNlKCkgOiAnVSc7XHJcbiAgY29uc3QgaW5pdGlhbHMgPSBnZXRJbml0aWFscyh1c2VyPy5mdWxsTmFtZSk7XHJcbiAgY29uc3QgZnVsbE5hbWUgPSB1c2VyPy5mdWxsTmFtZSB8fCAnU3R1ZGVudCBOYW1lJztcclxuICBjb25zdCBkZXBhcnRtZW50ID0gdXNlcj8uZGVwYXJ0bWVudCB8fCAnRGVwYXJ0bWVudCBOb3QgU2V0JztcclxuICBjb25zdCBzdHVkZW50SWQgPSB1c2VyPy5zdHVkZW50SWQgfHwgJ04vQSc7XHJcbiAgY29uc3QgeWVhciA9IHVzZXI/LmFjYWRlbWljSW5mbz8ueWVhciA/IGBZZWFyICR7dXNlci5hY2FkZW1pY0luZm8ueWVhcn1gIDogJ1llYXIgTi9BJztcclxuICBjb25zdCBiaW8gPSB1c2VyPy5iaW8gfHwgJ1Bhc3Npb25hdGUgYWJvdXQgZnVsbC1zdGFjayBkZXZlbG9wbWVudCBhbmQgQUktcG93ZXJlZCBhcHBzLiBMb29raW5nIGZvciBjb2xsYWJvcmF0aXZlIHByb2plY3RzLic7XHJcbiAgY29uc3QgeyBwZXJjZW50YWdlOiBjb21wbGV0ZW5lc3MgfSA9IGNhbGN1bGF0ZVByb2ZpbGVDb21wbGV0ZW5lc3ModXNlcik7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGlkPVwicGFnZS1wcm9maWxlLXZpZXdcIiBjbGFzc05hbWU9XCJwYWdlIGFjdGl2ZVwiIHN0eWxlPXt7IGRpc3BsYXk6ICdibG9jaycsIHBhZGRpbmdCb3R0b206ICczcmVtJyB9fT5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJwYWdlLWhkclwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGFnZS1oZHItbGVmdFwiPlxyXG4gICAgICAgICAgPGgxPk15IFByb2ZpbGU8L2gxPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGFnZS1oZHItcmlnaHRcIj5cclxuICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYnRuIGJ0bi1vdXRsaW5lIGJ0bi1zbVwiIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKCcvZGFzaGJvYXJkJyl9PuKGkCBEYXNoYm9hcmQ8L2J1dHRvbj5cclxuICAgICAgICAgIHtpc093blByb2ZpbGUgJiYgPGJ1dHRvbiBjbGFzc05hbWU9XCJidG4gYnRuLXByaW1hcnkgYnRuLXNtXCIgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoJy9lZGl0LXByb2ZpbGUnKX0+4pyP77iPIEVkaXQgUHJvZmlsZTwvYnV0dG9uPn1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInByb2ZpbGUtaGVybyBwcmVtaXVtLWhlcm9cIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBoLWF2YXRhciBwcmVtaXVtLWF2YXRhclwiIGlkPVwicHYtaGVyby1hdmF0YXJcIiBzdHlsZT17eyBvdmVyZmxvdzogJ2hpZGRlbicgfX0+XHJcbiAgICAgICAgICB7dXNlcj8ucHJvZmlsZVBpY3R1cmUgXHJcbiAgICAgICAgICAgID8gPGltZyBzcmM9e3VzZXIucHJvZmlsZVBpY3R1cmV9IGFsdD1cIlByb2ZpbGVcIiBzdHlsZT17eyB3aWR0aDogJzEwMCUnLCBoZWlnaHQ6ICcxMDAlJywgb2JqZWN0Rml0OiAnY292ZXInIH19IC8+IFxyXG4gICAgICAgICAgICA6IGluaXRpYWxzfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGgtaW5mb1wiPlxyXG4gICAgICAgICAgPGgyIGlkPVwicHYtaGVyby1uYW1lXCIgY2xhc3NOYW1lPVwicHJlbWl1bS1uYW1lXCI+e2Z1bGxOYW1lfTwvaDI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBoLWRlcHQgcHJlbWl1bS1kZXB0XCIgaWQ9XCJwdi1oZXJvLWRlcHRcIj7wn5ONIHtkZXBhcnRtZW50fSDCtyB7eWVhcn08L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGgtY2hpcHNcIj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicGgtY2hpcCBnbGFzcy1jaGlwXCI+8J+OkyB7dXNlcj8uc3BlY2lhbGl6YXRpb24gfHwgdXNlcj8uYWNhZGVtaWNJbmZvPy5zcGVjaWFsaXphdGlvbiB8fCAnU3BlY2lhbGl6YXRpb24gTm90IFNldCd9PC9zcGFuPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJwaC1jaGlwIGdsYXNzLWNoaXBcIj7wn5OeIHt1c2VyPy5jb250YWN0TnVtYmVyIHx8ICdObyBDb250YWN0J308L3NwYW4+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInBoLWNoaXAgZ2xhc3MtY2hpcFwiPvCfn6IgQXZhaWxhYmxlPC9zcGFuPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwaC1hY3Rpb25zXCI+XHJcbiAgICAgICAgICB7aXNPd25Qcm9maWxlICYmIDxidXR0b24gY2xhc3NOYW1lPVwiYnRuIGJ0bi1naG9zdCBidG4tc20gcHJlbWl1bS1lZGl0LWJ0blwiIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKCcvZWRpdC1wcm9maWxlJyl9PuKcj++4jyBFZGl0PC9idXR0b24+fVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvZmlsZS12aWV3LWdyaWRcIj5cclxuICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6ICdmbGV4JywgZmxleERpcmVjdGlvbjogJ2NvbHVtbicsIGdhcDogJzFyZW0nIH19PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm9maWxlLXNpZGViYXItY2FyZCBzaGFkb3ctY2FyZFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB2LWF2YXRhciBzaGFkb3ctYXZhdGFyXCIgaWQ9XCJwdi1zaWRlYmFyLWF2YXRhclwiIHN0eWxlPXt7IG92ZXJmbG93OiAnaGlkZGVuJyB9fT5cclxuICAgICAgICAgICAgICB7dXNlcj8ucHJvZmlsZVBpY3R1cmUgXHJcbiAgICAgICAgICAgICAgICA/IDxpbWcgc3JjPXt1c2VyLnByb2ZpbGVQaWN0dXJlfSBhbHQ9XCJQcm9maWxlXCIgc3R5bGU9e3sgd2lkdGg6ICcxMDAlJywgaGVpZ2h0OiAnMTAwJScsIG9iamVjdEZpdDogJ2NvdmVyJyB9fSAvPiBcclxuICAgICAgICAgICAgICAgIDogaW5pdGlhbHN9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB2LW5hbWVcIiBpZD1cInB2LXNpZGViYXItbmFtZVwiPntmdWxsTmFtZX08L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdi1kZXB0XCIgaWQ9XCJwdi1zaWRlYmFyLWRlcHRcIj57ZGVwYXJ0bWVudH08L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdi1zY29yZS1yaW5nXCIgc3R5bGU9e3sgYmFja2dyb3VuZDogYGNvbmljLWdyYWRpZW50KHZhcigtLXApICR7Y29tcGxldGVuZXNzfSUsIHZhcigtLWJvcmRlcikgMClgIH19PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHYtc2NvcmUtaW5uZXJcIj48ZGl2IGNsYXNzTmFtZT1cInB2LXNjb3JlLW51bVwiPntjb21wbGV0ZW5lc3N9JTwvZGl2PjxkaXYgY2xhc3NOYW1lPVwicHYtc2NvcmUtbGJsXCI+Q09NUExFVEU8L2Rpdj48L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCBnYXA6ICcuNHJlbScsIGp1c3RpZnlDb250ZW50OiAnY2VudGVyJywgbWFyZ2luQm90dG9tOiAnMXJlbScsIGZsZXhXcmFwOiAnd3JhcCcgfX0+XHJcbiAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgYmFja2dyb3VuZDogJ3ZhcigtLXBsKScsIGNvbG9yOiAndmFyKC0tcCknLCBib3JkZXI6ICcxcHggc29saWQgI0JGREJGRScsIGZvbnRTaXplOiAnLjcycmVtJywgcGFkZGluZzogJzNweCA5cHgnLCBib3JkZXJSYWRpdXM6ICcyMHB4JywgZm9udFdlaWdodDogNjAwIH19PvCfn6IgQXZhaWxhYmxlPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGJhY2tncm91bmQ6ICd2YXIoLS1wbCknLCBjb2xvcjogJ3ZhcigtLXApJywgYm9yZGVyOiAnMXB4IHNvbGlkICNCRkRCRkUnLCBmb250U2l6ZTogJy43MnJlbScsIHBhZGRpbmc6ICczcHggOXB4JywgYm9yZGVyUmFkaXVzOiAnMjBweCcsIGZvbnRXZWlnaHQ6IDYwMCB9fT57eWVhcn08L3NwYW4+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB2LWRldGFpbFwiPjxzcGFuIGNsYXNzTmFtZT1cInB2LWRldGFpbC1sYmxcIj5EZXBhcnRtZW50PC9zcGFuPjxzcGFuIGNsYXNzTmFtZT1cInB2LWRldGFpbC12YWxcIiBpZD1cInB2LWRlcHQtdmFsXCI+e2RlcGFydG1lbnR9PC9zcGFuPjwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB2LWRldGFpbFwiPjxzcGFuIGNsYXNzTmFtZT1cInB2LWRldGFpbC1sYmxcIj5ZZWFyPC9zcGFuPjxzcGFuIGNsYXNzTmFtZT1cInB2LWRldGFpbC12YWxcIiBpZD1cInB2LXllYXItdmFsXCI+e3llYXJ9PC9zcGFuPjwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB2LWRldGFpbFwiPjxzcGFuIGNsYXNzTmFtZT1cInB2LWRldGFpbC1sYmxcIj5TdHVkZW50IElEPC9zcGFuPjxzcGFuIGNsYXNzTmFtZT1cInB2LWRldGFpbC12YWxcIiBpZD1cInB2LWlkLXZhbFwiPntzdHVkZW50SWR9PC9zcGFuPjwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB2LWRldGFpbFwiPjxzcGFuIGNsYXNzTmFtZT1cInB2LWRldGFpbC1sYmxcIj5Db250YWN0PC9zcGFuPjxzcGFuIGNsYXNzTmFtZT1cInB2LWRldGFpbC12YWxcIj57dXNlcj8uY29udGFjdE51bWJlciB8fCAnTm90IFByb3ZpZGVkJ308L3NwYW4+PC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHYtZGV0YWlsXCI+PHNwYW4gY2xhc3NOYW1lPVwicHYtZGV0YWlsLWxibFwiPkNHUEE8L3NwYW4+PHNwYW4gY2xhc3NOYW1lPVwicHYtZGV0YWlsLXZhbFwiIGlkPVwicHYtY2dwYS12YWxcIj57dXNlcj8uYWNhZGVtaWNJbmZvPy5jZ3BhIHx8ICdOL0EnfTwvc3Bhbj48L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdi1kZXRhaWxcIj48c3BhbiBjbGFzc05hbWU9XCJwdi1kZXRhaWwtbGJsXCI+RG9tYWluPC9zcGFuPjxzcGFuIGNsYXNzTmFtZT1cInB2LWRldGFpbC12YWxcIj57dXNlcj8uYWNhZGVtaWNJbmZvPy5zcGVjaWFsaXphdGlvbiB8fCAnTi9BJ308L3NwYW4+PC9kaXY+XHJcbiAgICAgICAgICAgIHtpc093blByb2ZpbGUgJiYgPGJ1dHRvbiBjbGFzc05hbWU9XCJidG4gYnRuLXByaW1hcnkgYnRuLWZ1bGwgc2hhZG93LWhvdmVyLWJ0blwiIHN0eWxlPXt7IG1hcmdpblRvcDogJzFyZW0nIH19IG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKCcvZWRpdC1wcm9maWxlJyl9PuKcj++4jyBFZGl0IFByb2ZpbGU8L2J1dHRvbj59XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZCBjYXJkLXNtIHNoYWRvdy1jYXJkXCI+XHJcbiAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZm9udEZhbWlseTogXCInU29yYScsIHNhbnMtc2VyaWZcIiwgZm9udFNpemU6ICcuODhyZW0nLCBmb250V2VpZ2h0OiA3MDAsIG1hcmdpbkJvdHRvbTogJy43cmVtJyB9fT7wn46tIFByZWZlcnJlZCBSb2xlczwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvbGVzLWxpc3RcIj5cclxuICAgICAgICAgICAgICB7dXNlcj8ucHJlZmVycmVkUm9sZXM/Lmxlbmd0aCA+IDAgPyB1c2VyLnByZWZlcnJlZFJvbGVzLm1hcChyb2xlID0+IChcclxuICAgICAgICAgICAgICAgICA8ZGl2IGtleT17cm9sZX0gY2xhc3NOYW1lPVwicm9sZS1yb3dcIj7inIUgPHNwYW4+e3JvbGV9PC9zcGFuPjwvZGl2PlxyXG4gICAgICAgICAgICAgICkpIDogPGRpdiBjbGFzc05hbWU9XCJyb2xlLXJvd1wiIHN0eWxlPXt7IGNvbG9yOiAndmFyKC0tbWlkKScgfX0+4qycIDxzcGFuPk5vIHJvbGVzIHNlbGVjdGVkPC9zcGFuPjwvZGl2Pn1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm9maWxlLXJpZ2h0XCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQgc2hhZG93LWNhcmRcIj5cclxuICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250RmFtaWx5OiBcIidTb3JhJywgc2Fucy1zZXJpZlwiLCBmb250U2l6ZTogJzFyZW0nLCBmb250V2VpZ2h0OiA3MDAsIG1hcmdpbkJvdHRvbTogJy42cmVtJyB9fT7wn5GkIEFib3V0PC9kaXY+XHJcbiAgICAgICAgICAgIDxwIGlkPVwicHYtYmlvXCIgc3R5bGU9e3sgZm9udFNpemU6ICcuODc1cmVtJywgY29sb3I6ICd2YXIoLS1taWQpJywgbGluZUhlaWdodDogMS42NSB9fT57YmlvfTwvcD5cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIHsodXNlcj8uc29jaWFsTGlua3M/LmdpdGh1YiB8fCB1c2VyPy5zb2NpYWxMaW5rcz8ubGlua2VkaW4gfHwgdXNlcj8uc29jaWFsTGlua3M/LnBvcnRmb2xpbykgJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgbWFyZ2luVG9wOiAnMXJlbScsIGRpc3BsYXk6ICdmbGV4JywgZ2FwOiAnMC41cmVtJywgZmxleFdyYXA6ICd3cmFwJyB9fT5cclxuICAgICAgICAgICAgICAgIHt1c2VyLnNvY2lhbExpbmtzLmdpdGh1YiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxhIGhyZWY9e3VzZXIuc29jaWFsTGlua3MuZ2l0aHVifSB0YXJnZXQ9XCJfYmxhbmtcIiByZWw9XCJub29wZW5lciBub3JlZmVycmVyXCIgY2xhc3NOYW1lPVwiYnRuIGJ0bi1vdXRsaW5lIGJ0bi1zbVwiIHN0eWxlPXt7IHBhZGRpbmc6ICcwLjRyZW0gMC44cmVtJywgYm9yZGVyUmFkaXVzOiAnMjBweCcsIGZvbnRTaXplOiAnMC44cmVtJyB9fT7wn5CZIEdpdEh1YjwvYT5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICB7dXNlci5zb2NpYWxMaW5rcy5saW5rZWRpbiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxhIGhyZWY9e3VzZXIuc29jaWFsTGlua3MubGlua2VkaW59IHRhcmdldD1cIl9ibGFua1wiIHJlbD1cIm5vb3BlbmVyIG5vcmVmZXJyZXJcIiBjbGFzc05hbWU9XCJidG4gYnRuLW91dGxpbmUgYnRuLXNtXCIgc3R5bGU9e3sgcGFkZGluZzogJzAuNHJlbSAwLjhyZW0nLCBib3JkZXJSYWRpdXM6ICcyMHB4JywgZm9udFNpemU6ICcwLjhyZW0nLCBiYWNrZ3JvdW5kOiAnIzBBNjZDMicsIGNvbG9yOiAnd2hpdGUnLCBib3JkZXI6ICdub25lJyB9fT7wn5K8IExpbmtlZEluPC9hPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIHt1c2VyLnNvY2lhbExpbmtzLnBvcnRmb2xpbyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxhIGhyZWY9e3VzZXIuc29jaWFsTGlua3MucG9ydGZvbGlvfSB0YXJnZXQ9XCJfYmxhbmtcIiByZWw9XCJub29wZW5lciBub3JlZmVycmVyXCIgY2xhc3NOYW1lPVwiYnRuIGJ0bi1vdXRsaW5lIGJ0bi1zbVwiIHN0eWxlPXt7IHBhZGRpbmc6ICcwLjRyZW0gMC44cmVtJywgYm9yZGVyUmFkaXVzOiAnMjBweCcsIGZvbnRTaXplOiAnMC44cmVtJywgYmFja2dyb3VuZDogJ3ZhcigtLWRhcmspJywgY29sb3I6ICd3aGl0ZScsIGJvcmRlcjogJ25vbmUnIH19PvCfjJAgUG9ydGZvbGlvPC9hPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIHtnaXRodWJEYXRhICYmIChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkIHNoYWRvdy1jYXJkXCIgc3R5bGU9e3sgYmFja2dyb3VuZDogJ2xpbmVhci1ncmFkaWVudCgxNDVkZWcsICNmZmZmZmYgMCUsICNmOGZhZmMgMTAwJSknLCBib3JkZXI6ICcxcHggc29saWQgI2UyZThmMCcsIGJvcmRlclJhZGl1czogJzEycHgnLCBwYWRkaW5nOiAnMS4yNXJlbScgfX0+XHJcbiAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGFsaWduSXRlbXM6ICdjZW50ZXInLCBnYXA6ICcxMnB4JywgbWFyZ2luQm90dG9tOiAnMS4yNXJlbScgfX0+XHJcbiAgICAgICAgICAgICAgICA8aW1nIHNyYz17Z2l0aHViRGF0YS5hdmF0YXJfdXJsfSBhbHQ9XCJHaXRIdWIgQXZhdGFyXCIgc3R5bGU9e3sgd2lkdGg6ICc0NXB4JywgaGVpZ2h0OiAnNDVweCcsIGJvcmRlclJhZGl1czogJzUwJScsIGJvcmRlcjogJzJweCBzb2xpZCAjMjU2M2ViJywgcGFkZGluZzogJzJweCcgfX0gLz5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZm9udEZhbWlseTogXCInU29yYScsIHNhbnMtc2VyaWZcIiwgZm9udFNpemU6ICcxcmVtJywgZm9udFdlaWdodDogNzAwLCBjb2xvcjogJyMxZTI5M2InIH19PntnaXRodWJEYXRhLm5hbWUgfHwgZ2l0aHViRGF0YS5sb2dpbn08L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGEgaHJlZj17Z2l0aHViRGF0YS5odG1sX3VybH0gdGFyZ2V0PVwiX2JsYW5rXCIgcmVsPVwibm9vcGVuZXIgbm9yZWZlcnJlclwiIHN0eWxlPXt7IGZvbnRTaXplOiAnMC44cmVtJywgY29sb3I6ICcjNjQ3NDhiJywgdGV4dERlY29yYXRpb246ICdub25lJywgZm9udFdlaWdodDogNTAwIH19PkB7Z2l0aHViRGF0YS5sb2dpbn08L2E+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgbWFyZ2luTGVmdDogJ2F1dG8nLCBiYWNrZ3JvdW5kOiAnI2UwZTdmZicsIHBhZGRpbmc6ICc4cHgnLCBib3JkZXJSYWRpdXM6ICc1MCUnLCBjb2xvcjogJyMzNzMwQTMnLCBkaXNwbGF5OiAnZmxleCcsIGFsaWduSXRlbXM6ICdjZW50ZXInLCBqdXN0aWZ5SXRlbXM6ICdjZW50ZXInIH19PlxyXG4gICAgICAgICAgICAgICAgICA8c3ZnIGhlaWdodD1cIjIwXCIgdmlld0JveD1cIjAgMCAxNiAxNlwiIHdpZHRoPVwiMjBcIiBmaWxsPVwiY3VycmVudENvbG9yXCI+PHBhdGggZmlsbFJ1bGU9XCJldmVub2RkXCIgZD1cIk04IDBDMy41OCAwIDAgMy41OCAwIDhjMCAzLjU0IDIuMjkgNi41MyA1LjQ3IDcuNTkuNC4wNy41NS0uMTcuNTUtLjM4IDAtLjE5LS4wMS0uODItLjAxLTEuNDktMi4wMS4zNy0yLjUzLS40OS0yLjY5LS45NC0uMDktLjIzLS40OC0uOTQtLjgyLTEuMTMtLjI4LS4xNS0uNjgtLjUyLS4wMS0uNTMuNjMtLjAxIDEuMDguNTggMS4yMy44Mi43MiAxLjIxIDEuODcuODcgMi4zMy42Ni4wNy0uNTIuMjgtLjg3LjUxLTEuMDctMS43OC0uMi0zLjY0LS44OS0zLjY0LTMuOTUgMC0uODcuMzEtMS41OS44Mi0yLjE1LS4wOC0uMi0uMzYtMS4wMi4wOC0yLjEyIDAgMCAuNjctLjIxIDIuMi44Mi42NC0uMTggMS4zMi0uMjcgMi0uMjcuNjggMCAxLjM2LjA5IDIgLjI3IDEuNTMtMS4wNCAyLjItLjgyIDIuMi0uODIuNDQgMS4xLjE2IDEuOTIuMDggMi4xMi41MS41Ni44MiAxLjI3LjgyIDIuMTUgMCAzLjA3LTEuODcgMy43NS0zLjY1IDMuOTUuMjkuMjUuNTQuNzMuNTQgMS40OCAwIDEuMDctLjAxIDEuOTMtLjAxIDIuMiAwIC4yMS4xNS40Ni41NS4zOEE4LjAxMyA4LjAxMyAwIDAwMTYgOGMwLTQuNDItMy41OC04LTgtOHpcIj48L3BhdGg+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6ICdncmlkJywgZ3JpZFRlbXBsYXRlQ29sdW1uczogJ3JlcGVhdCgzLCAxZnIpJywgZ2FwOiAnMTBweCcsIHRleHRBbGlnbjogJ2NlbnRlcicgfX0+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGJhY2tncm91bmQ6ICcjZjFmNWY5JywgcGFkZGluZzogJzEwcHgnLCBib3JkZXJSYWRpdXM6ICc4cHgnLCBib3JkZXI6ICcxcHggc29saWQgI2UyZThmMCcgfX0+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZm9udFNpemU6ICcxLjI1cmVtJywgZm9udFdlaWdodDogODAwLCBjb2xvcjogJyMyNTYzZWInIH19PntnaXRodWJEYXRhLnB1YmxpY19yZXBvc308L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250U2l6ZTogJzAuN3JlbScsIGNvbG9yOiAnIzY0NzQ4YicsIGZvbnRXZWlnaHQ6IDcwMCwgdGV4dFRyYW5zZm9ybTogJ3VwcGVyY2FzZScsIGxldHRlclNwYWNpbmc6ICcwLjVweCcgfX0+UmVwb3M8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBiYWNrZ3JvdW5kOiAnI2YxZjVmOScsIHBhZGRpbmc6ICcxMHB4JywgYm9yZGVyUmFkaXVzOiAnOHB4JywgYm9yZGVyOiAnMXB4IHNvbGlkICNlMmU4ZjAnIH19PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnRTaXplOiAnMS4yNXJlbScsIGZvbnRXZWlnaHQ6IDgwMCwgY29sb3I6ICcjMjU2M2ViJyB9fT57Z2l0aHViRGF0YS5mb2xsb3dlcnN9PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZm9udFNpemU6ICcwLjdyZW0nLCBjb2xvcjogJyM2NDc0OGInLCBmb250V2VpZ2h0OiA3MDAsIHRleHRUcmFuc2Zvcm06ICd1cHBlcmNhc2UnLCBsZXR0ZXJTcGFjaW5nOiAnMC41cHgnIH19PkZvbGxvd2VyczwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGJhY2tncm91bmQ6ICcjZjFmNWY5JywgcGFkZGluZzogJzEwcHgnLCBib3JkZXJSYWRpdXM6ICc4cHgnLCBib3JkZXI6ICcxcHggc29saWQgI2UyZThmMCcgfX0+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZm9udFNpemU6ICcxLjI1cmVtJywgZm9udFdlaWdodDogODAwLCBjb2xvcjogJyMyNTYzZWInIH19PntnaXRodWJEYXRhLmZvbGxvd2luZ308L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250U2l6ZTogJzAuN3JlbScsIGNvbG9yOiAnIzY0NzQ4YicsIGZvbnRXZWlnaHQ6IDcwMCwgdGV4dFRyYW5zZm9ybTogJ3VwcGVyY2FzZScsIGxldHRlclNwYWNpbmc6ICcwLjVweCcgfX0+Rm9sbG93aW5nPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICB7Z2l0aHViRGF0YS5iaW8gJiYgKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBtYXJnaW5Ub3A6ICcxLjI1cmVtJywgZm9udFNpemU6ICcwLjg1cmVtJywgY29sb3I6ICcjNDc1NTY5JywgZm9udFN0eWxlOiAnaXRhbGljJywgYm9yZGVyTGVmdDogJzNweCBzb2xpZCAjY2JkNWUxJywgcGFkZGluZ0xlZnQ6ICcxMHB4JywgbGluZUhlaWdodDogMS41IH19PlxyXG4gICAgICAgICAgICAgICAgICBcIntnaXRodWJEYXRhLmJpb31cIlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQgc2hhZG93LWNhcmRcIj5cclxuICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250RmFtaWx5OiBcIidTb3JhJywgc2Fucy1zZXJpZlwiLCBmb250U2l6ZTogJzFyZW0nLCBmb250V2VpZ2h0OiA3MDAsIG1hcmdpbkJvdHRvbTogJy43NXJlbScgfX0+8J+nqSBTa2lsbHM8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJza2lsbC10YWdzXCIgaWQ9XCJwdi1za2lsbHNcIj5cclxuICAgICAgICAgICAgICB7WydsYW5ndWFnZXMnLCAnZnJhbWV3b3JrcycsICdsaWJyYXJpZXMnLCAnZGF0YWJhc2VzJywgJ3Rvb2xzJ10ubWFwKGNhdCA9PiAoXHJcbiAgICAgICAgICAgICAgICB1c2VyPy5za2lsbHM/LltjYXRdICYmIHVzZXIuc2tpbGxzW2NhdF0ubGVuZ3RoID4gMCA/IHVzZXIuc2tpbGxzW2NhdF0ubWFwKHNraWxsID0+IChcclxuICAgICAgICAgICAgICAgICAgPHNwYW4ga2V5PXtgJHtjYXR9LSR7c2tpbGx9YH0gY2xhc3NOYW1lPVwic2tpbGwtdGFnIHNraWxsLXRhZy1wcmVtaXVtXCI+e3NraWxsfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICkpIDogbnVsbFxyXG4gICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgIHshdXNlcj8uc2tpbGxzICYmIDxzcGFuIGNsYXNzTmFtZT1cInNraWxsLXRhZ1wiPk5vIHNraWxscyBhZGRlZDwvc3Bhbj59XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZCBzaGFkb3ctY2FyZFwiPlxyXG4gICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnRGYW1pbHk6IFwiJ1NvcmEnLCBzYW5zLXNlcmlmXCIsIGZvbnRTaXplOiAnMXJlbScsIGZvbnRXZWlnaHQ6IDcwMCwgbWFyZ2luQm90dG9tOiAnLjc1cmVtJyB9fT7wn5KhIEludGVyZXN0czwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGRpc3BsYXk6ICdmbGV4JywgZmxleFdyYXA6ICd3cmFwJywgZ2FwOiAnLjRyZW0nIH19PlxyXG4gICAgICAgICAgICAgIHt1c2VyPy5pbnRlcmVzdHM/Lmxlbmd0aCA+IDAgPyB1c2VyLmludGVyZXN0cy5tYXAoaW50ID0+IChcclxuICAgICAgICAgICAgICAgIDxzcGFuIGtleT17aW50fSBjbGFzc05hbWU9XCJpbnQtY2hpcCBhY3RpdmUgcHJlbWl1bS1jaGlwXCI+e2ludH08L3NwYW4+XHJcbiAgICAgICAgICAgICAgKSkgOiA8c3BhbiBjbGFzc05hbWU9XCJpbnQtY2hpcFwiPk5vIGludGVyZXN0cyBhZGRlZDwvc3Bhbj59XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZCBzaGFkb3ctY2FyZFwiPlxyXG4gICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnRGYW1pbHk6IFwiJ1NvcmEnLCBzYW5zLXNlcmlmXCIsIGZvbnRTaXplOiAnMXJlbScsIGZvbnRXZWlnaHQ6IDcwMCwgbWFyZ2luQm90dG9tOiAnLjc1cmVtJyB9fT7wn5WQIEF2YWlsYWJpbGl0eTwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImF2YWlsLWdyaWRcIiBzdHlsZT17eyBtYXJnaW5Cb3R0b206ICcuNzVyZW0nIH19PlxyXG4gICAgICAgICAgICAgIHtbJ01vbmRheScsJ1R1ZXNkYXknLCdXZWRuZXNkYXknLCdUaHVyc2RheScsJ0ZyaWRheScsJ1NhdHVyZGF5JywnU3VuZGF5J10ubWFwKGRheSA9PiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGtleT17ZGF5fSBjbGFzc05hbWU9XCJkYXktYmxvY2tcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkYXktbGJsXCI+e2RheS5zdWJzdHJpbmcoMCwzKX08L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2BlZGl0LWRheS1jaGlwICR7dXNlcj8uYXZhaWxhYmlsaXR5Py5wcmVmZXJyZWREYXlzPy5pbmNsdWRlcyhkYXkpID8gJ2FjdGl2ZScgOiAnJ31gfT5cclxuICAgICAgICAgICAgICAgICAgICB7dXNlcj8uYXZhaWxhYmlsaXR5Py5wcmVmZXJyZWREYXlzPy5pbmNsdWRlcyhkYXkpID8gJ+KckycgOiAnJ31cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgdGV4dEFsaWduOiAnY2VudGVyJywgZm9udEZhbWlseTogXCInU29yYScsIHNhbnMtc2VyaWZcIiwgZm9udFNpemU6ICcxLjVyZW0nLCBmb250V2VpZ2h0OiA4MDAsIGNvbG9yOiAndmFyKC0tcCknIH19PlxyXG4gICAgICAgICAgICAgIHt1c2VyPy5hdmFpbGFiaWxpdHk/LndlZWtseUhvdXJzIHx8IDB9IDxzbWFsbCBzdHlsZT17eyBmb250U2l6ZTogJy43NXJlbScsIGNvbG9yOiAndmFyKC0tbWlkKScsIGZvbnRGYW1pbHk6ICdpbmhlcml0JywgZm9udFdlaWdodDogNDAwIH19PmhvdXJzIC8gd2Vlazwvc21hbGw+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFByb2ZpbGVWaWV3O1xyXG4iXSwiZmlsZSI6IkY6L1kzUzIvSVRQTSBwcm9qZWN0L1Byb01hdGUtLVByb2plY3QtUGFydG5lci1GaW5kZXIvZnJvbnRlbmQvc3JjL3BhZ2VzL1VzZXJzL1Byb2ZpbGVWaWV3LmpzeCJ9