import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ProjectCard.jsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/ProjectCard.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=383bea9f"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import "/src/components/ProjectCard.css";
const ProjectCard = ({
  project,
  onView
}) => {
  return /* @__PURE__ */ jsxDEV("div", { className: "project-card", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "project-card-body", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "project-card-header", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "project-title", title: project.displayTitle || project.title, children: project.displayTitle || project.title }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/ProjectCard.jsx",
          lineNumber: 10,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "project-type-badge", children: project.projectType || "Project" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/ProjectCard.jsx",
          lineNumber: 11,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/ProjectCard.jsx",
        lineNumber: 9,
        columnNumber: 9
      }, this),
      project.itNumber && /* @__PURE__ */ jsxDEV("div", { style: {
        fontSize: "13px",
        color: "#64748b",
        marginBottom: "12px",
        fontWeight: "500"
      }, children: [
        "IT Number: ",
        /* @__PURE__ */ jsxDEV("span", { style: {
          color: "#1e293b"
        }, children: project.itNumber }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/ProjectCard.jsx",
          lineNumber: 20,
          columnNumber: 24
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/ProjectCard.jsx",
        lineNumber: 14,
        columnNumber: 30
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "project-desc", children: project.description || "No description provided." }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/ProjectCard.jsx",
        lineNumber: 25,
        columnNumber: 9
      }, this),
      project.dueDate && /* @__PURE__ */ jsxDEV("div", { style: {
        fontSize: "13px",
        color: "#ef4444",
        marginBottom: "12px",
        fontWeight: "600"
      }, children: [
        "Due Date: ",
        /* @__PURE__ */ jsxDEV("span", { children: new Date(project.dueDate).toLocaleDateString("en-GB") }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/ProjectCard.jsx",
          lineNumber: 35,
          columnNumber: 23
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/ProjectCard.jsx",
        lineNumber: 29,
        columnNumber: 29
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "project-stats", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "stat", children: [
          /* @__PURE__ */ jsxDEV("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", children: [
            /* @__PURE__ */ jsxDEV("path", { d: "M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/ProjectCard.jsx",
              lineNumber: 40,
              columnNumber: 133
            }, this),
            /* @__PURE__ */ jsxDEV("circle", { cx: "9", cy: "7", r: "4" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/ProjectCard.jsx",
              lineNumber: 40,
              columnNumber: 192
            }, this),
            /* @__PURE__ */ jsxDEV("path", { d: "M23 21v-2a4 4 0 0 0-3-3.87" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/ProjectCard.jsx",
              lineNumber: 40,
              columnNumber: 229
            }, this),
            /* @__PURE__ */ jsxDEV("path", { d: "M16 3.13a4 4 0 0 1 0 7.75" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/ProjectCard.jsx",
              lineNumber: 40,
              columnNumber: 273
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/ProjectCard.jsx",
            lineNumber: 40,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: [
            "Team: ",
            /* @__PURE__ */ jsxDEV("strong", { children: project.teamSize || "Any" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/ProjectCard.jsx",
              lineNumber: 41,
              columnNumber: 25
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/ProjectCard.jsx",
            lineNumber: 41,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/ProjectCard.jsx",
          lineNumber: 39,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "stat", children: [
          /* @__PURE__ */ jsxDEV("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", children: /* @__PURE__ */ jsxDEV("path", { d: "M22 12h-4l-3 9L9 3l-3 9H2" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/ProjectCard.jsx",
            lineNumber: 44,
            columnNumber: 133
          }, this) }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/ProjectCard.jsx",
            lineNumber: 44,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { children: [
            "CGPA: ",
            /* @__PURE__ */ jsxDEV("strong", { children: project.minimumCGPA || "None" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/ProjectCard.jsx",
              lineNumber: 45,
              columnNumber: 25
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/ProjectCard.jsx",
            lineNumber: 45,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/ProjectCard.jsx",
          lineNumber: 43,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/ProjectCard.jsx",
        lineNumber: 38,
        columnNumber: 9
      }, this),
      project.domain && project.domain.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "project-domains", children: [
        project.domain.slice(0, 3).map((dom, i) => /* @__PURE__ */ jsxDEV("span", { className: "domain-tag", children: dom }, i, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/ProjectCard.jsx",
          lineNumber: 50,
          columnNumber: 57
        }, this)),
        project.domain.length > 3 && /* @__PURE__ */ jsxDEV("span", { className: "domain-tag-more", children: [
          "+",
          project.domain.length - 3
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/ProjectCard.jsx",
          lineNumber: 51,
          columnNumber: 43
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/ProjectCard.jsx",
        lineNumber: 49,
        columnNumber: 57
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/ProjectCard.jsx",
      lineNumber: 8,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "project-card-footer", children: /* @__PURE__ */ jsxDEV("button", { className: "view-btn", onClick: () => onView(project), children: "View Details" }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/ProjectCard.jsx",
      lineNumber: 56,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/ProjectCard.jsx",
      lineNumber: 55,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/ProjectCard.jsx",
    lineNumber: 7,
    columnNumber: 10
  }, this);
};
_c = ProjectCard;
export default ProjectCard;
var _c;
$RefreshReg$(_c, "ProjectCard");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/ProjectCard.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBUVU7QUFSVixPQUFPQSxvQkFBa0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ3pCLE9BQU87QUFFUCxNQUFNQyxjQUFjQSxDQUFDO0FBQUEsRUFBRUM7QUFBQUEsRUFBU0M7QUFBTyxNQUFNO0FBQzNDLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLGdCQUNiO0FBQUEsMkJBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLHVCQUNiO0FBQUEsK0JBQUMsUUFBRyxXQUFVLGlCQUFnQixPQUFPRCxRQUFRRSxnQkFBZ0JGLFFBQVFHLE9BQVFILGtCQUFRRSxnQkFBZ0JGLFFBQVFHLFNBQTdHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUg7QUFBQSxRQUNuSCx1QkFBQyxVQUFLLFdBQVUsc0JBQXNCSCxrQkFBUUksZUFBZSxhQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVFO0FBQUEsV0FGekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFFQ0osUUFBUUssWUFDUCx1QkFBQyxTQUFJLE9BQU87QUFBQSxRQUFFQyxVQUFVO0FBQUEsUUFBUUMsT0FBTztBQUFBLFFBQVdDLGNBQWM7QUFBQSxRQUFRQyxZQUFZO0FBQUEsTUFBTSxHQUFHO0FBQUE7QUFBQSxRQUNoRix1QkFBQyxVQUFLLE9BQU87QUFBQSxVQUFFRixPQUFPO0FBQUEsUUFBVSxHQUFJUCxrQkFBUUssWUFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxRDtBQUFBLFdBRGxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BR0YsdUJBQUMsT0FBRSxXQUFVLGdCQUNWTCxrQkFBUVUsZUFBZSw4QkFEMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFFQ1YsUUFBUVcsV0FDUCx1QkFBQyxTQUFJLE9BQU87QUFBQSxRQUFFTCxVQUFVO0FBQUEsUUFBUUMsT0FBTztBQUFBLFFBQVdDLGNBQWM7QUFBQSxRQUFRQyxZQUFZO0FBQUEsTUFBTSxHQUFHO0FBQUE7QUFBQSxRQUNqRix1QkFBQyxVQUFNLGNBQUlHLEtBQUtaLFFBQVFXLE9BQU8sRUFBRUUsbUJBQW1CLE9BQU8sS0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2RDtBQUFBLFdBRHpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BR0YsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSxpQ0FBQyxTQUFJLFNBQVEsYUFBWSxNQUFLLFFBQU8sUUFBTyxnQkFBZSxhQUFZLEtBQUksZUFBYyxTQUFRLGdCQUFlLFNBQVE7QUFBQSxtQ0FBQyxVQUFLLEdBQUUsK0NBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0Q7QUFBQSxZQUFPLHVCQUFDLFlBQU8sSUFBRyxLQUFJLElBQUcsS0FBSSxHQUFFLE9BQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRCO0FBQUEsWUFBUyx1QkFBQyxVQUFLLEdBQUUsZ0NBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUM7QUFBQSxZQUFPLHVCQUFDLFVBQUssR0FBRSwrQkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvQztBQUFBLGVBQXhTO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStTO0FBQUEsVUFDL1MsdUJBQUMsVUFBSztBQUFBO0FBQUEsWUFBTSx1QkFBQyxZQUFRYixrQkFBUWMsWUFBWSxTQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtQztBQUFBLGVBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdEO0FBQUEsYUFGMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLGlDQUFDLFNBQUksU0FBUSxhQUFZLE1BQUssUUFBTyxRQUFPLGdCQUFlLGFBQVksS0FBSSxlQUFjLFNBQVEsZ0JBQWUsU0FBUSxpQ0FBQyxVQUFLLEdBQUUsK0JBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0MsS0FBNUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUs7QUFBQSxVQUNuSyx1QkFBQyxVQUFLO0FBQUE7QUFBQSxZQUFNLHVCQUFDLFlBQVFkLGtCQUFRZSxlQUFlLFVBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVDO0FBQUEsZUFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEQ7QUFBQSxhQUY5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxXQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLE1BRUNmLFFBQVFnQixVQUFVaEIsUUFBUWdCLE9BQU9DLFNBQVMsS0FDekMsdUJBQUMsU0FBSSxXQUFVLG1CQUNaakI7QUFBQUEsZ0JBQVFnQixPQUFPRSxNQUFNLEdBQUcsQ0FBQyxFQUFFQyxJQUFJLENBQUNDLEtBQUtDLE1BQ3BDLHVCQUFDLFVBQWEsV0FBVSxjQUFjRCxpQkFBM0JDLEdBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwQyxDQUMzQztBQUFBLFFBQ0FyQixRQUFRZ0IsT0FBT0MsU0FBUyxLQUN2Qix1QkFBQyxVQUFLLFdBQVUsbUJBQWtCO0FBQUE7QUFBQSxVQUFFakIsUUFBUWdCLE9BQU9DLFNBQVM7QUFBQSxhQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThEO0FBQUEsV0FMbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsU0F6Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTJDQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLHVCQUNiLGlDQUFDLFlBQU8sV0FBVSxZQUFXLFNBQVMsTUFBTWhCLE9BQU9ELE9BQU8sR0FBRyw0QkFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlBO0FBQUEsT0FsREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW1EQTtBQUVKO0FBQUVzQixLQXZESXZCO0FBeUROLGVBQWVBO0FBQVksSUFBQXVCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsIlByb2plY3RDYXJkIiwicHJvamVjdCIsIm9uVmlldyIsImRpc3BsYXlUaXRsZSIsInRpdGxlIiwicHJvamVjdFR5cGUiLCJpdE51bWJlciIsImZvbnRTaXplIiwiY29sb3IiLCJtYXJnaW5Cb3R0b20iLCJmb250V2VpZ2h0IiwiZGVzY3JpcHRpb24iLCJkdWVEYXRlIiwiRGF0ZSIsInRvTG9jYWxlRGF0ZVN0cmluZyIsInRlYW1TaXplIiwibWluaW11bUNHUEEiLCJkb21haW4iLCJsZW5ndGgiLCJzbGljZSIsIm1hcCIsImRvbSIsImkiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlByb2plY3RDYXJkLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgJy4vUHJvamVjdENhcmQuY3NzJztcclxuXHJcbmNvbnN0IFByb2plY3RDYXJkID0gKHsgcHJvamVjdCwgb25WaWV3IH0pID0+IHtcclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJwcm9qZWN0LWNhcmRcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm9qZWN0LWNhcmQtYm9keVwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvamVjdC1jYXJkLWhlYWRlclwiPlxyXG4gICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInByb2plY3QtdGl0bGVcIiB0aXRsZT17cHJvamVjdC5kaXNwbGF5VGl0bGUgfHwgcHJvamVjdC50aXRsZX0+e3Byb2plY3QuZGlzcGxheVRpdGxlIHx8IHByb2plY3QudGl0bGV9PC9oMz5cclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInByb2plY3QtdHlwZS1iYWRnZVwiPntwcm9qZWN0LnByb2plY3RUeXBlIHx8ICdQcm9qZWN0J308L3NwYW4+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgXHJcbiAgICAgICAge3Byb2plY3QuaXROdW1iZXIgJiYgKFxyXG4gICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250U2l6ZTogJzEzcHgnLCBjb2xvcjogJyM2NDc0OGInLCBtYXJnaW5Cb3R0b206ICcxMnB4JywgZm9udFdlaWdodDogJzUwMCcgfX0+XHJcbiAgICAgICAgICAgIElUIE51bWJlcjogPHNwYW4gc3R5bGU9e3sgY29sb3I6ICcjMWUyOTNiJyB9fT57cHJvamVjdC5pdE51bWJlcn08L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApfVxyXG5cclxuICAgICAgICA8cCBjbGFzc05hbWU9XCJwcm9qZWN0LWRlc2NcIj5cclxuICAgICAgICAgIHtwcm9qZWN0LmRlc2NyaXB0aW9uIHx8ICdObyBkZXNjcmlwdGlvbiBwcm92aWRlZC4nfVxyXG4gICAgICAgIDwvcD5cclxuXHJcbiAgICAgICAge3Byb2plY3QuZHVlRGF0ZSAmJiAoXHJcbiAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnRTaXplOiAnMTNweCcsIGNvbG9yOiAnI2VmNDQ0NCcsIG1hcmdpbkJvdHRvbTogJzEycHgnLCBmb250V2VpZ2h0OiAnNjAwJyB9fT5cclxuICAgICAgICAgICAgRHVlIERhdGU6IDxzcGFuPntuZXcgRGF0ZShwcm9qZWN0LmR1ZURhdGUpLnRvTG9jYWxlRGF0ZVN0cmluZygnZW4tR0InKX08L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApfVxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByb2plY3Qtc3RhdHNcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3RhdFwiPlxyXG4gICAgICAgICAgICA8c3ZnIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHN0cm9rZVdpZHRoPVwiMlwiIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIj48cGF0aCBkPVwiTTE3IDIxdi0yYTQgNCAwIDAgMC00LTRINWE0IDQgMCAwIDAtNCA0djJcIj48L3BhdGg+PGNpcmNsZSBjeD1cIjlcIiBjeT1cIjdcIiByPVwiNFwiPjwvY2lyY2xlPjxwYXRoIGQ9XCJNMjMgMjF2LTJhNCA0IDAgMCAwLTMtMy44N1wiPjwvcGF0aD48cGF0aCBkPVwiTTE2IDMuMTNhNCA0IDAgMCAxIDAgNy43NVwiPjwvcGF0aD48L3N2Zz5cclxuICAgICAgICAgICAgPHNwYW4+VGVhbTogPHN0cm9uZz57cHJvamVjdC50ZWFtU2l6ZSB8fCAnQW55J308L3N0cm9uZz48L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3RhdFwiPlxyXG4gICAgICAgICAgICA8c3ZnIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHN0cm9rZVdpZHRoPVwiMlwiIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIj48cGF0aCBkPVwiTTIyIDEyaC00bC0zIDlMOSAzbC0zIDlIMlwiPjwvcGF0aD48L3N2Zz5cclxuICAgICAgICAgICAgPHNwYW4+Q0dQQTogPHN0cm9uZz57cHJvamVjdC5taW5pbXVtQ0dQQSB8fCAnTm9uZSd9PC9zdHJvbmc+PC9zcGFuPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHtwcm9qZWN0LmRvbWFpbiAmJiBwcm9qZWN0LmRvbWFpbi5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvamVjdC1kb21haW5zXCI+XHJcbiAgICAgICAgICAgIHtwcm9qZWN0LmRvbWFpbi5zbGljZSgwLCAzKS5tYXAoKGRvbSwgaSkgPT4gKFxyXG4gICAgICAgICAgICAgIDxzcGFuIGtleT17aX0gY2xhc3NOYW1lPVwiZG9tYWluLXRhZ1wiPntkb219PC9zcGFuPlxyXG4gICAgICAgICAgICApKX1cclxuICAgICAgICAgICAge3Byb2plY3QuZG9tYWluLmxlbmd0aCA+IDMgJiYgKFxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImRvbWFpbi10YWctbW9yZVwiPit7cHJvamVjdC5kb21haW4ubGVuZ3RoIC0gM308L3NwYW4+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApfVxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvamVjdC1jYXJkLWZvb3RlclwiPlxyXG4gICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwidmlldy1idG5cIiBvbkNsaWNrPXsoKSA9PiBvblZpZXcocHJvamVjdCl9PlxyXG4gICAgICAgICAgVmlldyBEZXRhaWxzXHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFByb2plY3RDYXJkO1xyXG4iXSwiZmlsZSI6IkY6L1kzUzIvSVRQTSBwcm9qZWN0L1Byb01hdGUtLVByb2plY3QtUGFydG5lci1GaW5kZXIvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvUHJvamVjdENhcmQuanN4In0=