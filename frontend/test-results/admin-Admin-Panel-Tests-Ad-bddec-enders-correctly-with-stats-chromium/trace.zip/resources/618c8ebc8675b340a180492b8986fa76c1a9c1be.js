import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");import { Fragment, jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=383bea9f"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import { createBrowserRouter, Navigate, Outlet } from "/node_modules/.vite/deps/react-router-dom.js?v=383bea9f";
import { AuthProvider } from "/src/context/AuthContext.jsx";
import Navbar from "/src/components/Navbar.jsx";
import FAQChatbot from "/src/components/FAQChatbot.jsx";
import Landing from "/src/pages/Landing.jsx";
import Login from "/src/pages/Users/Login.jsx";
import Register from "/src/pages/Users/Register.jsx";
import Dashboard from "/src/pages/Users/Dashboard.jsx";
import ProfileView from "/src/pages/Users/ProfileView.jsx";
import EditProfile from "/src/pages/Users/EditProfile.jsx";
import Settings from "/src/pages/Users/Settings.jsx";
import ChangePassword from "/src/pages/Users/ChangePassword.jsx";
import ForgotPassword from "/src/pages/Users/ForgotPassword.jsx";
import VerifyOTP from "/src/pages/Users/VerifyOTP.jsx";
import ResetPassword from "/src/pages/Users/ResetPassword.jsx";
import Recommendations from "/src/pages/RecEngine/ProjectRecommendations.jsx";
import Candidates from "/src/pages/RecEngine/StudentRecommendations.jsx";
import Feedbacks from "/src/pages/RecEngine/Feedbacks.jsx";
import RecProjects from "/src/pages/RecEngine/RecProjects.jsx";
import ProjectView from "/src/pages/RecEngine/ProjectView.jsx";
import InsertPost from "/src/pages/Projects/InsertProject.jsx";
import UpdateProject from "/src/pages/Projects/UpdateProject.jsx";
import YourProjects from "/src/pages/Projects/YourProjects.jsx";
import AllProjects from "/src/pages/Projects/AllProjects.jsx";
import ProjectDetailsView from "/src/pages/Projects/ProjectDetailsView.jsx";
import Notifications from "/src/pages/Notifications/Notifications.jsx";
import Admindashboard from "/src/pages/Admin/Admindashboard.jsx";
import Projectmanagement from "/src/pages/Admin/Projectmanagement.jsx";
import Studentmanagement from "/src/pages/Admin/Studentmanagement.jsx";
import Requestmanagement from "/src/pages/Admin/Requestmanagement.jsx";
import AdminFeedbacks from "/src/pages/Admin/AdminFeedbacks.jsx";
import History from "/src/pages/Admin/History.jsx";
import "/src/App.css";
import ProtectedRoute from "/src/components/ProtectedRoute.jsx";
const BaseLayout = () => /* @__PURE__ */ jsxDEV(Fragment, { children: [
  /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
    lineNumber: 48,
    columnNumber: 5
  }, this),
  /* @__PURE__ */ jsxDEV(FAQChatbot, {}, void 0, false, {
    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
    lineNumber: 49,
    columnNumber: 5
  }, this)
] }, void 0, true, {
  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
  lineNumber: 47,
  columnNumber: 26
}, this);
_c = BaseLayout;
export const router = createBrowserRouter([{
  path: "/",
  element: /* @__PURE__ */ jsxDEV(BaseLayout, {}, void 0, false, {
    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
    lineNumber: 54,
    columnNumber: 12
  }, this),
  children: [
    {
      index: true,
      element: /* @__PURE__ */ jsxDEV(Landing, {}, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 57,
        columnNumber: 14
      }, this)
    },
    {
      path: "login",
      element: /* @__PURE__ */ jsxDEV(Login, {}, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 60,
        columnNumber: 14
      }, this)
    },
    {
      path: "register",
      element: /* @__PURE__ */ jsxDEV(Register, {}, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 63,
        columnNumber: 14
      }, this)
    },
    {
      path: "forgot-password",
      element: /* @__PURE__ */ jsxDEV(ForgotPassword, {}, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 66,
        columnNumber: 14
      }, this)
    },
    {
      path: "verify-otp",
      element: /* @__PURE__ */ jsxDEV(VerifyOTP, {}, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 69,
        columnNumber: 14
      }, this)
    },
    {
      path: "reset-password",
      element: /* @__PURE__ */ jsxDEV(ResetPassword, {}, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 72,
        columnNumber: 14
      }, this)
    },
    // 👤 Student & Admin Routes (Protected routes handle their own Navbars)
    {
      path: "dashboard",
      element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { allowedRoles: ["student"], children: /* @__PURE__ */ jsxDEV(Dashboard, {}, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 77,
        columnNumber: 57
      }, this) }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 77,
        columnNumber: 14
      }, this)
    },
    {
      path: "change-password",
      element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { allowedRoles: ["student"], children: /* @__PURE__ */ jsxDEV(ChangePassword, {}, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 80,
        columnNumber: 57
      }, this) }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 80,
        columnNumber: 14
      }, this)
    },
    {
      path: "profile",
      element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { allowedRoles: ["student"], children: /* @__PURE__ */ jsxDEV(ProfileView, {}, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 83,
        columnNumber: 57
      }, this) }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 83,
        columnNumber: 14
      }, this)
    },
    {
      path: "profile/:id",
      element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { allowedRoles: ["student", "admin"], children: /* @__PURE__ */ jsxDEV(ProfileView, {}, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 86,
        columnNumber: 66
      }, this) }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 86,
        columnNumber: 14
      }, this)
    },
    {
      path: "edit-profile",
      element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { allowedRoles: ["student"], children: /* @__PURE__ */ jsxDEV(EditProfile, {}, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 89,
        columnNumber: 57
      }, this) }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 89,
        columnNumber: 14
      }, this)
    },
    {
      path: "settings",
      element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { allowedRoles: ["student"], children: /* @__PURE__ */ jsxDEV(Settings, {}, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 92,
        columnNumber: 57
      }, this) }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 92,
        columnNumber: 14
      }, this)
    },
    {
      path: "recs",
      element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { allowedRoles: ["student"], children: /* @__PURE__ */ jsxDEV(Recommendations, {}, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 95,
        columnNumber: 57
      }, this) }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 95,
        columnNumber: 14
      }, this)
    },
    {
      path: "sturecs",
      element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { allowedRoles: ["student"], children: /* @__PURE__ */ jsxDEV(Candidates, {}, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 98,
        columnNumber: 57
      }, this) }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 98,
        columnNumber: 14
      }, this)
    },
    {
      path: "feedbacks",
      element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { allowedRoles: ["student"], children: /* @__PURE__ */ jsxDEV(Feedbacks, {}, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 101,
        columnNumber: 57
      }, this) }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 101,
        columnNumber: 14
      }, this)
    },
    {
      path: "recprojects",
      element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { allowedRoles: ["student"], children: /* @__PURE__ */ jsxDEV(RecProjects, {}, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 104,
        columnNumber: 57
      }, this) }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 104,
        columnNumber: 14
      }, this)
    },
    {
      path: "projectview",
      element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { allowedRoles: ["student"], children: /* @__PURE__ */ jsxDEV(ProjectView, {}, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 107,
        columnNumber: 57
      }, this) }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 107,
        columnNumber: 14
      }, this)
    },
    {
      path: "insert-project",
      element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { allowedRoles: ["student"], children: /* @__PURE__ */ jsxDEV(InsertPost, {}, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 110,
        columnNumber: 57
      }, this) }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 110,
        columnNumber: 14
      }, this)
    },
    {
      path: "update-project/:id",
      element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { allowedRoles: ["student"], children: /* @__PURE__ */ jsxDEV(UpdateProject, {}, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 113,
        columnNumber: 57
      }, this) }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 113,
        columnNumber: 14
      }, this)
    },
    {
      path: "your-projects",
      element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { allowedRoles: ["student"], children: /* @__PURE__ */ jsxDEV(YourProjects, {}, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 116,
        columnNumber: 57
      }, this) }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 116,
        columnNumber: 14
      }, this)
    },
    {
      path: "all-projects",
      element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { allowedRoles: ["student"], children: /* @__PURE__ */ jsxDEV(AllProjects, {}, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 119,
        columnNumber: 57
      }, this) }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 119,
        columnNumber: 14
      }, this)
    },
    {
      path: "projects/:id",
      element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { allowedRoles: ["student"], children: /* @__PURE__ */ jsxDEV(ProjectDetailsView, {}, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 122,
        columnNumber: 57
      }, this) }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 122,
        columnNumber: 14
      }, this)
    },
    {
      path: "notifications",
      element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { allowedRoles: ["student"], children: /* @__PURE__ */ jsxDEV(Notifications, {}, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 125,
        columnNumber: 57
      }, this) }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 125,
        columnNumber: 14
      }, this)
    },
    {
      path: "admindashboard",
      element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { allowedRoles: ["admin"], children: /* @__PURE__ */ jsxDEV(Admindashboard, {}, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 128,
        columnNumber: 55
      }, this) }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 128,
        columnNumber: 14
      }, this)
    },
    {
      path: "projectman",
      element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { allowedRoles: ["admin"], children: /* @__PURE__ */ jsxDEV(Projectmanagement, {}, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 131,
        columnNumber: 55
      }, this) }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 131,
        columnNumber: 14
      }, this)
    },
    {
      path: "studentman",
      element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { allowedRoles: ["admin"], children: /* @__PURE__ */ jsxDEV(Studentmanagement, {}, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 134,
        columnNumber: 55
      }, this) }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 134,
        columnNumber: 14
      }, this)
    },
    {
      path: "requestman",
      element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { allowedRoles: ["admin"], children: /* @__PURE__ */ jsxDEV(Requestmanagement, {}, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 137,
        columnNumber: 55
      }, this) }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 137,
        columnNumber: 14
      }, this)
    },
    {
      path: "adminfeedbacks",
      element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { allowedRoles: ["admin"], children: /* @__PURE__ */ jsxDEV(AdminFeedbacks, {}, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 140,
        columnNumber: 55
      }, this) }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 140,
        columnNumber: 14
      }, this)
    },
    {
      path: "history",
      element: /* @__PURE__ */ jsxDEV(ProtectedRoute, { allowedRoles: ["admin"], children: /* @__PURE__ */ jsxDEV(History, {}, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 143,
        columnNumber: 55
      }, this) }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 143,
        columnNumber: 14
      }, this)
    },
    // 🚫 Fallback
    {
      path: "*",
      element: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center h-screen bg-slate-50", children: /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold text-gray-500", children: "404 - Page Not Found" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 148,
        columnNumber: 85
      }, this) }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx",
        lineNumber: 148,
        columnNumber: 14
      }, this)
    }
  ]
}]);
export default function App() {
  return null;
}
_c2 = App;
var _c, _c2;
$RefreshReg$(_c, "BaseLayout");
$RefreshReg$(_c2, "App");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0RFLG1CQUNFLGNBREY7QUFoREYsT0FBT0Esb0JBQWtCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUN6QixTQUFTQyxxQkFBcUJDLFVBQVVDLGNBQWM7QUFDdEQsU0FBU0Msb0JBQW9CO0FBQzdCLE9BQU9DLFlBQVk7QUFDbkIsT0FBT0MsZ0JBQWdCO0FBR3ZCLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsV0FBVztBQUNsQixPQUFPQyxjQUFjO0FBQ3JCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0MsaUJBQWlCO0FBQ3hCLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxjQUFjO0FBQ3JCLE9BQU9DLG9CQUFvQjtBQUMzQixPQUFPQyxvQkFBb0I7QUFDM0IsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxtQkFBbUI7QUFHMUIsT0FBT0MscUJBQXFCO0FBQzVCLE9BQU9DLGdCQUFnQjtBQUN2QixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxpQkFBaUI7QUFFeEIsT0FBT0MsZ0JBQWdCO0FBQ3ZCLE9BQU9DLG1CQUFtQjtBQUMxQixPQUFPQyxrQkFBa0I7QUFDekIsT0FBT0MsaUJBQWlCO0FBQ3hCLE9BQU9DLHdCQUF3QjtBQUMvQixPQUFPQyxtQkFBbUI7QUFHMUIsT0FBT0Msb0JBQW9CO0FBQzNCLE9BQU9DLHVCQUF1QjtBQUM5QixPQUFPQyx1QkFBdUI7QUFDOUIsT0FBT0MsdUJBQXVCO0FBQzlCLE9BQU9DLG9CQUFvQjtBQUMzQixPQUFPQyxhQUFhO0FBRXBCLE9BQU87QUFHUCxPQUFPQyxvQkFBb0I7QUFHM0IsTUFBTUMsYUFBYUEsTUFDakIsbUNBQ0U7QUFBQSx5QkFBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBTztBQUFBLEVBQ1AsdUJBQUMsZ0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFXO0FBQUEsS0FGYjtBQUFBO0FBQUE7QUFBQTtBQUFBLE9BR0E7QUFDQUMsS0FMSUQ7QUFPQyxhQUFNRSxTQUFTckMsb0JBQW9CLENBQ3hDO0FBQUEsRUFDRXNDLE1BQU07QUFBQSxFQUNOQyxTQUFTLHVCQUFDLGdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBVztBQUFBLEVBQ3BCQyxVQUFVO0FBQUEsSUFDUjtBQUFBLE1BQUVDLE9BQU87QUFBQSxNQUFNRixTQUFTLHVCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFRO0FBQUEsSUFBSTtBQUFBLElBQ3BDO0FBQUEsTUFBRUQsTUFBTTtBQUFBLE1BQVNDLFNBQVMsdUJBQUMsV0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQU07QUFBQSxJQUFJO0FBQUEsSUFDcEM7QUFBQSxNQUFFRCxNQUFNO0FBQUEsTUFBWUMsU0FBUyx1QkFBQyxjQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBUztBQUFBLElBQUk7QUFBQSxJQUMxQztBQUFBLE1BQUVELE1BQU07QUFBQSxNQUFtQkMsU0FBUyx1QkFBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWU7QUFBQSxJQUFJO0FBQUEsSUFDdkQ7QUFBQSxNQUFFRCxNQUFNO0FBQUEsTUFBY0MsU0FBUyx1QkFBQyxlQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBVTtBQUFBLElBQUk7QUFBQSxJQUM3QztBQUFBLE1BQUVELE1BQU07QUFBQSxNQUFrQkMsU0FBUyx1QkFBQyxtQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWM7QUFBQSxJQUFJO0FBQUE7QUFBQSxJQUdyRDtBQUFBLE1BQUVELE1BQU07QUFBQSxNQUFhQyxTQUFTLHVCQUFDLGtCQUFlLGNBQWMsQ0FBQyxTQUFTLEdBQUcsaUNBQUMsZUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVUsS0FBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3RDtBQUFBLElBQWtCO0FBQUEsSUFDeEc7QUFBQSxNQUFFRCxNQUFNO0FBQUEsTUFBbUJDLFNBQVMsdUJBQUMsa0JBQWUsY0FBYyxDQUFDLFNBQVMsR0FBRyxpQ0FBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWUsS0FBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2RDtBQUFBLElBQWtCO0FBQUEsSUFDbkg7QUFBQSxNQUFFRCxNQUFNO0FBQUEsTUFBV0MsU0FBUyx1QkFBQyxrQkFBZSxjQUFjLENBQUMsU0FBUyxHQUFHLGlDQUFDLGlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBWSxLQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBEO0FBQUEsSUFBa0I7QUFBQSxJQUN4RztBQUFBLE1BQUVELE1BQU07QUFBQSxNQUFlQyxTQUFTLHVCQUFDLGtCQUFlLGNBQWMsQ0FBQyxXQUFXLE9BQU8sR0FBRyxpQ0FBQyxpQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVksS0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtRTtBQUFBLElBQWtCO0FBQUEsSUFDckg7QUFBQSxNQUFFRCxNQUFNO0FBQUEsTUFBZ0JDLFNBQVMsdUJBQUMsa0JBQWUsY0FBYyxDQUFDLFNBQVMsR0FBRyxpQ0FBQyxpQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVksS0FBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEwRDtBQUFBLElBQWtCO0FBQUEsSUFDN0c7QUFBQSxNQUFFRCxNQUFNO0FBQUEsTUFBWUMsU0FBUyx1QkFBQyxrQkFBZSxjQUFjLENBQUMsU0FBUyxHQUFHLGlDQUFDLGNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFTLEtBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUQ7QUFBQSxJQUFrQjtBQUFBLElBQ3RHO0FBQUEsTUFBRUQsTUFBTTtBQUFBLE1BQVFDLFNBQVMsdUJBQUMsa0JBQWUsY0FBYyxDQUFDLFNBQVMsR0FBRyxpQ0FBQyxxQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdCLEtBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBOEQ7QUFBQSxJQUFrQjtBQUFBLElBQ3pHO0FBQUEsTUFBRUQsTUFBTTtBQUFBLE1BQVdDLFNBQVMsdUJBQUMsa0JBQWUsY0FBYyxDQUFDLFNBQVMsR0FBRyxpQ0FBQyxnQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVcsS0FBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5RDtBQUFBLElBQWtCO0FBQUEsSUFDdkc7QUFBQSxNQUFFRCxNQUFNO0FBQUEsTUFBYUMsU0FBUyx1QkFBQyxrQkFBZSxjQUFjLENBQUMsU0FBUyxHQUFHLGlDQUFDLGVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFVLEtBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0Q7QUFBQSxJQUFrQjtBQUFBLElBQ3hHO0FBQUEsTUFBRUQsTUFBTTtBQUFBLE1BQWVDLFNBQVMsdUJBQUMsa0JBQWUsY0FBYyxDQUFDLFNBQVMsR0FBRyxpQ0FBQyxpQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVksS0FBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEwRDtBQUFBLElBQWtCO0FBQUEsSUFDNUc7QUFBQSxNQUFFRCxNQUFNO0FBQUEsTUFBZUMsU0FBUyx1QkFBQyxrQkFBZSxjQUFjLENBQUMsU0FBUyxHQUFHLGlDQUFDLGlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBWSxLQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBEO0FBQUEsSUFBa0I7QUFBQSxJQUM1RztBQUFBLE1BQUVELE1BQU07QUFBQSxNQUFrQkMsU0FBUyx1QkFBQyxrQkFBZSxjQUFjLENBQUMsU0FBUyxHQUFHLGlDQUFDLGdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBVyxLQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlEO0FBQUEsSUFBa0I7QUFBQSxJQUM5RztBQUFBLE1BQUVELE1BQU07QUFBQSxNQUFzQkMsU0FBUyx1QkFBQyxrQkFBZSxjQUFjLENBQUMsU0FBUyxHQUFHLGlDQUFDLG1CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBYyxLQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTREO0FBQUEsSUFBa0I7QUFBQSxJQUNySDtBQUFBLE1BQUVELE1BQU07QUFBQSxNQUFpQkMsU0FBUyx1QkFBQyxrQkFBZSxjQUFjLENBQUMsU0FBUyxHQUFHLGlDQUFDLGtCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBYSxLQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTJEO0FBQUEsSUFBa0I7QUFBQSxJQUMvRztBQUFBLE1BQUVELE1BQU07QUFBQSxNQUFnQkMsU0FBUyx1QkFBQyxrQkFBZSxjQUFjLENBQUMsU0FBUyxHQUFHLGlDQUFDLGlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBWSxLQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBEO0FBQUEsSUFBa0I7QUFBQSxJQUM3RztBQUFBLE1BQUVELE1BQU07QUFBQSxNQUFnQkMsU0FBUyx1QkFBQyxrQkFBZSxjQUFjLENBQUMsU0FBUyxHQUFHLGlDQUFDLHdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUIsS0FBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpRTtBQUFBLElBQWtCO0FBQUEsSUFDcEg7QUFBQSxNQUFFRCxNQUFNO0FBQUEsTUFBaUJDLFNBQVMsdUJBQUMsa0JBQWUsY0FBYyxDQUFDLFNBQVMsR0FBRyxpQ0FBQyxtQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWMsS0FBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0RDtBQUFBLElBQWtCO0FBQUEsSUFDaEg7QUFBQSxNQUFFRCxNQUFNO0FBQUEsTUFBa0JDLFNBQVMsdUJBQUMsa0JBQWUsY0FBYyxDQUFDLE9BQU8sR0FBRyxpQ0FBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWUsS0FBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyRDtBQUFBLElBQWtCO0FBQUEsSUFDaEg7QUFBQSxNQUFFRCxNQUFNO0FBQUEsTUFBY0MsU0FBUyx1QkFBQyxrQkFBZSxjQUFjLENBQUMsT0FBTyxHQUFHLGlDQUFDLHVCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0IsS0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4RDtBQUFBLElBQWtCO0FBQUEsSUFDL0c7QUFBQSxNQUFFRCxNQUFNO0FBQUEsTUFBY0MsU0FBUyx1QkFBQyxrQkFBZSxjQUFjLENBQUMsT0FBTyxHQUFHLGlDQUFDLHVCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0IsS0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4RDtBQUFBLElBQWtCO0FBQUEsSUFDL0c7QUFBQSxNQUFFRCxNQUFNO0FBQUEsTUFBY0MsU0FBUyx1QkFBQyxrQkFBZSxjQUFjLENBQUMsT0FBTyxHQUFHLGlDQUFDLHVCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0IsS0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4RDtBQUFBLElBQWtCO0FBQUEsSUFDL0c7QUFBQSxNQUFFRCxNQUFNO0FBQUEsTUFBa0JDLFNBQVMsdUJBQUMsa0JBQWUsY0FBYyxDQUFDLE9BQU8sR0FBRyxpQ0FBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWUsS0FBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyRDtBQUFBLElBQWtCO0FBQUEsSUFDaEg7QUFBQSxNQUFFRCxNQUFNO0FBQUEsTUFBV0MsU0FBUyx1QkFBQyxrQkFBZSxjQUFjLENBQUMsT0FBTyxHQUFHLGlDQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFRLEtBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0Q7QUFBQSxJQUFrQjtBQUFBO0FBQUEsSUFHbEc7QUFBQSxNQUFFRCxNQUFNO0FBQUEsTUFBS0MsU0FBUyx1QkFBQyxTQUFJLFdBQVUseURBQXdELGlDQUFDLFFBQUcsV0FBVSxvQ0FBbUMsb0NBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUUsS0FBNUk7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpSjtBQUFBLElBQU87QUFBQSxFQUFDO0FBRW5MLENBQUMsQ0FDRjtBQUVELHdCQUF3QkcsTUFBTTtBQUM1QixTQUFPO0FBQ1Q7QUFBQ0MsTUFGdUJEO0FBQUcsSUFBQU4sSUFBQU87QUFBQUMsYUFBQVIsSUFBQTtBQUFBUSxhQUFBRCxLQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJjcmVhdGVCcm93c2VyUm91dGVyIiwiTmF2aWdhdGUiLCJPdXRsZXQiLCJBdXRoUHJvdmlkZXIiLCJOYXZiYXIiLCJGQVFDaGF0Ym90IiwiTGFuZGluZyIsIkxvZ2luIiwiUmVnaXN0ZXIiLCJEYXNoYm9hcmQiLCJQcm9maWxlVmlldyIsIkVkaXRQcm9maWxlIiwiU2V0dGluZ3MiLCJDaGFuZ2VQYXNzd29yZCIsIkZvcmdvdFBhc3N3b3JkIiwiVmVyaWZ5T1RQIiwiUmVzZXRQYXNzd29yZCIsIlJlY29tbWVuZGF0aW9ucyIsIkNhbmRpZGF0ZXMiLCJGZWVkYmFja3MiLCJSZWNQcm9qZWN0cyIsIlByb2plY3RWaWV3IiwiSW5zZXJ0UG9zdCIsIlVwZGF0ZVByb2plY3QiLCJZb3VyUHJvamVjdHMiLCJBbGxQcm9qZWN0cyIsIlByb2plY3REZXRhaWxzVmlldyIsIk5vdGlmaWNhdGlvbnMiLCJBZG1pbmRhc2hib2FyZCIsIlByb2plY3RtYW5hZ2VtZW50IiwiU3R1ZGVudG1hbmFnZW1lbnQiLCJSZXF1ZXN0bWFuYWdlbWVudCIsIkFkbWluRmVlZGJhY2tzIiwiSGlzdG9yeSIsIlByb3RlY3RlZFJvdXRlIiwiQmFzZUxheW91dCIsIl9jIiwicm91dGVyIiwicGF0aCIsImVsZW1lbnQiLCJjaGlsZHJlbiIsImluZGV4IiwiQXBwIiwiX2MyIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQXBwLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyBjcmVhdGVCcm93c2VyUm91dGVyLCBOYXZpZ2F0ZSwgT3V0bGV0IH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XHJcbmltcG9ydCB7IEF1dGhQcm92aWRlciB9IGZyb20gJy4vY29udGV4dC9BdXRoQ29udGV4dCc7XHJcbmltcG9ydCBOYXZiYXIgZnJvbSAnLi9jb21wb25lbnRzL05hdmJhcic7XHJcbmltcG9ydCBGQVFDaGF0Ym90IGZyb20gJy4vY29tcG9uZW50cy9GQVFDaGF0Ym90JztcclxuXHJcbi8vIEF1dGggJiBVc2VyIFBhZ2VzXHJcbmltcG9ydCBMYW5kaW5nIGZyb20gJy4vcGFnZXMvTGFuZGluZyc7XHJcbmltcG9ydCBMb2dpbiBmcm9tICcuL3BhZ2VzL1VzZXJzL0xvZ2luJztcclxuaW1wb3J0IFJlZ2lzdGVyIGZyb20gJy4vcGFnZXMvVXNlcnMvUmVnaXN0ZXInO1xyXG5pbXBvcnQgRGFzaGJvYXJkIGZyb20gJy4vcGFnZXMvVXNlcnMvRGFzaGJvYXJkJztcclxuaW1wb3J0IFByb2ZpbGVWaWV3IGZyb20gJy4vcGFnZXMvVXNlcnMvUHJvZmlsZVZpZXcnO1xyXG5pbXBvcnQgRWRpdFByb2ZpbGUgZnJvbSAnLi9wYWdlcy9Vc2Vycy9FZGl0UHJvZmlsZSc7XHJcbmltcG9ydCBTZXR0aW5ncyBmcm9tICcuL3BhZ2VzL1VzZXJzL1NldHRpbmdzJztcclxuaW1wb3J0IENoYW5nZVBhc3N3b3JkIGZyb20gJy4vcGFnZXMvVXNlcnMvQ2hhbmdlUGFzc3dvcmQnO1xyXG5pbXBvcnQgRm9yZ290UGFzc3dvcmQgZnJvbSAnLi9wYWdlcy9Vc2Vycy9Gb3Jnb3RQYXNzd29yZCc7XHJcbmltcG9ydCBWZXJpZnlPVFAgZnJvbSAnLi9wYWdlcy9Vc2Vycy9WZXJpZnlPVFAnO1xyXG5pbXBvcnQgUmVzZXRQYXNzd29yZCBmcm9tICcuL3BhZ2VzL1VzZXJzL1Jlc2V0UGFzc3dvcmQnO1xyXG5cclxuLy8gUmVjb21tZW5kYXRpb24gUGFnZXNcclxuaW1wb3J0IFJlY29tbWVuZGF0aW9ucyBmcm9tICcuL3BhZ2VzL1JlY0VuZ2luZS9Qcm9qZWN0UmVjb21tZW5kYXRpb25zJztcclxuaW1wb3J0IENhbmRpZGF0ZXMgZnJvbSAnLi9wYWdlcy9SZWNFbmdpbmUvU3R1ZGVudFJlY29tbWVuZGF0aW9ucyc7XHJcbmltcG9ydCBGZWVkYmFja3MgZnJvbSAnLi9wYWdlcy9SZWNFbmdpbmUvRmVlZGJhY2tzJztcclxuaW1wb3J0IFJlY1Byb2plY3RzIGZyb20gJy4vcGFnZXMvUmVjRW5naW5lL1JlY1Byb2plY3RzJztcclxuaW1wb3J0IFByb2plY3RWaWV3IGZyb20gJy4vcGFnZXMvUmVjRW5naW5lL1Byb2plY3RWaWV3JztcclxuLy8gUHJvamVjdCBQYWdlc1xyXG5pbXBvcnQgSW5zZXJ0UG9zdCBmcm9tICcuL3BhZ2VzL1Byb2plY3RzL0luc2VydFByb2plY3QnO1xyXG5pbXBvcnQgVXBkYXRlUHJvamVjdCBmcm9tICcuL3BhZ2VzL1Byb2plY3RzL1VwZGF0ZVByb2plY3QnO1xyXG5pbXBvcnQgWW91clByb2plY3RzIGZyb20gJy4vcGFnZXMvUHJvamVjdHMvWW91clByb2plY3RzJztcclxuaW1wb3J0IEFsbFByb2plY3RzIGZyb20gJy4vcGFnZXMvUHJvamVjdHMvQWxsUHJvamVjdHMnO1xyXG5pbXBvcnQgUHJvamVjdERldGFpbHNWaWV3IGZyb20gJy4vcGFnZXMvUHJvamVjdHMvUHJvamVjdERldGFpbHNWaWV3JztcclxuaW1wb3J0IE5vdGlmaWNhdGlvbnMgZnJvbSAnLi9wYWdlcy9Ob3RpZmljYXRpb25zL05vdGlmaWNhdGlvbnMnO1xyXG5cclxuLy8gQWRtaW4gUGFnZXNcclxuaW1wb3J0IEFkbWluZGFzaGJvYXJkIGZyb20gJy4vcGFnZXMvQWRtaW4vQWRtaW5kYXNoYm9hcmQnO1xyXG5pbXBvcnQgUHJvamVjdG1hbmFnZW1lbnQgZnJvbSAnLi9wYWdlcy9BZG1pbi9Qcm9qZWN0bWFuYWdlbWVudCc7XHJcbmltcG9ydCBTdHVkZW50bWFuYWdlbWVudCBmcm9tICcuL3BhZ2VzL0FkbWluL1N0dWRlbnRtYW5hZ2VtZW50JztcclxuaW1wb3J0IFJlcXVlc3RtYW5hZ2VtZW50IGZyb20gJy4vcGFnZXMvQWRtaW4vUmVxdWVzdG1hbmFnZW1lbnQnO1xyXG5pbXBvcnQgQWRtaW5GZWVkYmFja3MgZnJvbSAnLi9wYWdlcy9BZG1pbi9BZG1pbkZlZWRiYWNrcyc7XHJcbmltcG9ydCBIaXN0b3J5IGZyb20gJy4vcGFnZXMvQWRtaW4vSGlzdG9yeSdcclxuXHJcbmltcG9ydCAnLi9BcHAuY3NzJztcclxuXHJcbi8vIPCflJAgUHJvdGVjdGVkIFJvdXRlIENvbXBvbmVudFxyXG5pbXBvcnQgUHJvdGVjdGVkUm91dGUgZnJvbSAnLi9jb21wb25lbnRzL1Byb3RlY3RlZFJvdXRlJztcclxuXHJcbi8vIFNpbXBsZSBMYXlvdXQgZm9yIHBhZ2VzIHRoYXQgTkVFRCB0aGUgRkFRIENoYXRib3QgYnV0IE5PIGV4dHJhIE5hdmJhclxyXG5jb25zdCBCYXNlTGF5b3V0ID0gKCkgPT4gKFxyXG4gIDw+XHJcbiAgICA8T3V0bGV0IC8+XHJcbiAgICA8RkFRQ2hhdGJvdCAvPlxyXG4gIDwvPlxyXG4pO1xyXG5cclxuZXhwb3J0IGNvbnN0IHJvdXRlciA9IGNyZWF0ZUJyb3dzZXJSb3V0ZXIoW1xyXG4gIHtcclxuICAgIHBhdGg6IFwiL1wiLFxyXG4gICAgZWxlbWVudDogPEJhc2VMYXlvdXQgLz4sXHJcbiAgICBjaGlsZHJlbjogW1xyXG4gICAgICB7IGluZGV4OiB0cnVlLCBlbGVtZW50OiA8TGFuZGluZyAvPiB9LFxyXG4gICAgICB7IHBhdGg6IFwibG9naW5cIiwgZWxlbWVudDogPExvZ2luIC8+IH0sXHJcbiAgICAgIHsgcGF0aDogXCJyZWdpc3RlclwiLCBlbGVtZW50OiA8UmVnaXN0ZXIgLz4gfSxcclxuICAgICAgeyBwYXRoOiBcImZvcmdvdC1wYXNzd29yZFwiLCBlbGVtZW50OiA8Rm9yZ290UGFzc3dvcmQgLz4gfSxcclxuICAgICAgeyBwYXRoOiBcInZlcmlmeS1vdHBcIiwgZWxlbWVudDogPFZlcmlmeU9UUCAvPiB9LFxyXG4gICAgICB7IHBhdGg6IFwicmVzZXQtcGFzc3dvcmRcIiwgZWxlbWVudDogPFJlc2V0UGFzc3dvcmQgLz4gfSxcclxuXHJcbiAgICAgIC8vIPCfkaQgU3R1ZGVudCAmIEFkbWluIFJvdXRlcyAoUHJvdGVjdGVkIHJvdXRlcyBoYW5kbGUgdGhlaXIgb3duIE5hdmJhcnMpXHJcbiAgICAgIHsgcGF0aDogXCJkYXNoYm9hcmRcIiwgZWxlbWVudDogPFByb3RlY3RlZFJvdXRlIGFsbG93ZWRSb2xlcz17WydzdHVkZW50J119PjxEYXNoYm9hcmQgLz48L1Byb3RlY3RlZFJvdXRlPiB9LFxyXG4gICAgICB7IHBhdGg6IFwiY2hhbmdlLXBhc3N3b3JkXCIsIGVsZW1lbnQ6IDxQcm90ZWN0ZWRSb3V0ZSBhbGxvd2VkUm9sZXM9e1snc3R1ZGVudCddfT48Q2hhbmdlUGFzc3dvcmQgLz48L1Byb3RlY3RlZFJvdXRlPiB9LFxyXG4gICAgICB7IHBhdGg6IFwicHJvZmlsZVwiLCBlbGVtZW50OiA8UHJvdGVjdGVkUm91dGUgYWxsb3dlZFJvbGVzPXtbJ3N0dWRlbnQnXX0+PFByb2ZpbGVWaWV3IC8+PC9Qcm90ZWN0ZWRSb3V0ZT4gfSxcclxuICAgICAgeyBwYXRoOiBcInByb2ZpbGUvOmlkXCIsIGVsZW1lbnQ6IDxQcm90ZWN0ZWRSb3V0ZSBhbGxvd2VkUm9sZXM9e1snc3R1ZGVudCcsICdhZG1pbiddfT48UHJvZmlsZVZpZXcgLz48L1Byb3RlY3RlZFJvdXRlPiB9LFxyXG4gICAgICB7IHBhdGg6IFwiZWRpdC1wcm9maWxlXCIsIGVsZW1lbnQ6IDxQcm90ZWN0ZWRSb3V0ZSBhbGxvd2VkUm9sZXM9e1snc3R1ZGVudCddfT48RWRpdFByb2ZpbGUgLz48L1Byb3RlY3RlZFJvdXRlPiB9LFxyXG4gICAgICB7IHBhdGg6IFwic2V0dGluZ3NcIiwgZWxlbWVudDogPFByb3RlY3RlZFJvdXRlIGFsbG93ZWRSb2xlcz17WydzdHVkZW50J119PjxTZXR0aW5ncyAvPjwvUHJvdGVjdGVkUm91dGU+IH0sXHJcbiAgICAgIHsgcGF0aDogXCJyZWNzXCIsIGVsZW1lbnQ6IDxQcm90ZWN0ZWRSb3V0ZSBhbGxvd2VkUm9sZXM9e1snc3R1ZGVudCddfT48UmVjb21tZW5kYXRpb25zIC8+PC9Qcm90ZWN0ZWRSb3V0ZT4gfSxcclxuICAgICAgeyBwYXRoOiBcInN0dXJlY3NcIiwgZWxlbWVudDogPFByb3RlY3RlZFJvdXRlIGFsbG93ZWRSb2xlcz17WydzdHVkZW50J119PjxDYW5kaWRhdGVzIC8+PC9Qcm90ZWN0ZWRSb3V0ZT4gfSxcclxuICAgICAgeyBwYXRoOiBcImZlZWRiYWNrc1wiLCBlbGVtZW50OiA8UHJvdGVjdGVkUm91dGUgYWxsb3dlZFJvbGVzPXtbJ3N0dWRlbnQnXX0+PEZlZWRiYWNrcyAvPjwvUHJvdGVjdGVkUm91dGU+IH0sXHJcbiAgICAgIHsgcGF0aDogXCJyZWNwcm9qZWN0c1wiLCBlbGVtZW50OiA8UHJvdGVjdGVkUm91dGUgYWxsb3dlZFJvbGVzPXtbJ3N0dWRlbnQnXX0+PFJlY1Byb2plY3RzIC8+PC9Qcm90ZWN0ZWRSb3V0ZT4gfSxcclxuICAgICAgeyBwYXRoOiBcInByb2plY3R2aWV3XCIsIGVsZW1lbnQ6IDxQcm90ZWN0ZWRSb3V0ZSBhbGxvd2VkUm9sZXM9e1snc3R1ZGVudCddfT48UHJvamVjdFZpZXcgLz48L1Byb3RlY3RlZFJvdXRlPiB9LFxyXG4gICAgICB7IHBhdGg6IFwiaW5zZXJ0LXByb2plY3RcIiwgZWxlbWVudDogPFByb3RlY3RlZFJvdXRlIGFsbG93ZWRSb2xlcz17WydzdHVkZW50J119PjxJbnNlcnRQb3N0IC8+PC9Qcm90ZWN0ZWRSb3V0ZT4gfSxcclxuICAgICAgeyBwYXRoOiBcInVwZGF0ZS1wcm9qZWN0LzppZFwiLCBlbGVtZW50OiA8UHJvdGVjdGVkUm91dGUgYWxsb3dlZFJvbGVzPXtbJ3N0dWRlbnQnXX0+PFVwZGF0ZVByb2plY3QgLz48L1Byb3RlY3RlZFJvdXRlPiB9LFxyXG4gICAgICB7IHBhdGg6IFwieW91ci1wcm9qZWN0c1wiLCBlbGVtZW50OiA8UHJvdGVjdGVkUm91dGUgYWxsb3dlZFJvbGVzPXtbJ3N0dWRlbnQnXX0+PFlvdXJQcm9qZWN0cyAvPjwvUHJvdGVjdGVkUm91dGU+IH0sXHJcbiAgICAgIHsgcGF0aDogXCJhbGwtcHJvamVjdHNcIiwgZWxlbWVudDogPFByb3RlY3RlZFJvdXRlIGFsbG93ZWRSb2xlcz17WydzdHVkZW50J119PjxBbGxQcm9qZWN0cyAvPjwvUHJvdGVjdGVkUm91dGU+IH0sXHJcbiAgICAgIHsgcGF0aDogXCJwcm9qZWN0cy86aWRcIiwgZWxlbWVudDogPFByb3RlY3RlZFJvdXRlIGFsbG93ZWRSb2xlcz17WydzdHVkZW50J119PjxQcm9qZWN0RGV0YWlsc1ZpZXcgLz48L1Byb3RlY3RlZFJvdXRlPiB9LFxyXG4gICAgICB7IHBhdGg6IFwibm90aWZpY2F0aW9uc1wiLCBlbGVtZW50OiA8UHJvdGVjdGVkUm91dGUgYWxsb3dlZFJvbGVzPXtbJ3N0dWRlbnQnXX0+PE5vdGlmaWNhdGlvbnMgLz48L1Byb3RlY3RlZFJvdXRlPiB9LFxyXG4gICAgICB7IHBhdGg6IFwiYWRtaW5kYXNoYm9hcmRcIiwgZWxlbWVudDogPFByb3RlY3RlZFJvdXRlIGFsbG93ZWRSb2xlcz17WydhZG1pbiddfT48QWRtaW5kYXNoYm9hcmQgLz48L1Byb3RlY3RlZFJvdXRlPiB9LFxyXG4gICAgICB7IHBhdGg6IFwicHJvamVjdG1hblwiLCBlbGVtZW50OiA8UHJvdGVjdGVkUm91dGUgYWxsb3dlZFJvbGVzPXtbJ2FkbWluJ119PjxQcm9qZWN0bWFuYWdlbWVudCAvPjwvUHJvdGVjdGVkUm91dGU+IH0sXHJcbiAgICAgIHsgcGF0aDogXCJzdHVkZW50bWFuXCIsIGVsZW1lbnQ6IDxQcm90ZWN0ZWRSb3V0ZSBhbGxvd2VkUm9sZXM9e1snYWRtaW4nXX0+PFN0dWRlbnRtYW5hZ2VtZW50IC8+PC9Qcm90ZWN0ZWRSb3V0ZT4gfSxcclxuICAgICAgeyBwYXRoOiBcInJlcXVlc3RtYW5cIiwgZWxlbWVudDogPFByb3RlY3RlZFJvdXRlIGFsbG93ZWRSb2xlcz17WydhZG1pbiddfT48UmVxdWVzdG1hbmFnZW1lbnQgLz48L1Byb3RlY3RlZFJvdXRlPiB9LFxyXG4gICAgICB7IHBhdGg6IFwiYWRtaW5mZWVkYmFja3NcIiwgZWxlbWVudDogPFByb3RlY3RlZFJvdXRlIGFsbG93ZWRSb2xlcz17WydhZG1pbiddfT48QWRtaW5GZWVkYmFja3MgLz48L1Byb3RlY3RlZFJvdXRlPiB9LFxyXG4gICAgICB7IHBhdGg6IFwiaGlzdG9yeVwiLCBlbGVtZW50OiA8UHJvdGVjdGVkUm91dGUgYWxsb3dlZFJvbGVzPXtbJ2FkbWluJ119PjxIaXN0b3J5IC8+PC9Qcm90ZWN0ZWRSb3V0ZT4gfSxcclxuXHJcbiAgICAgIC8vIPCfmqsgRmFsbGJhY2tcclxuICAgICAgeyBwYXRoOiBcIipcIiwgZWxlbWVudDogPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBoLXNjcmVlbiBiZy1zbGF0ZS01MFwiPjxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ncmF5LTUwMFwiPjQwNCAtIFBhZ2UgTm90IEZvdW5kPC9oMT48L2Rpdj4gfVxyXG4gICAgXVxyXG4gIH1cclxuXSk7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBBcHAoKSB7XHJcbiAgcmV0dXJuIG51bGw7XHJcbn1cclxuIl0sImZpbGUiOiJGOi9ZM1MyL0lUUE0gcHJvamVjdC9Qcm9NYXRlLS1Qcm9qZWN0LVBhcnRuZXItRmluZGVyL2Zyb250ZW5kL3NyYy9BcHAuanN4In0=