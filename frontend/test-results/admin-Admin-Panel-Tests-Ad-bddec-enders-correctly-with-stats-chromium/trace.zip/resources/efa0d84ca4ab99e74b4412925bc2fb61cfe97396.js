import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/AdminNavbar.jsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/AdminNavbar.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=383bea9f"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import { Link, useLocation, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=383bea9f";
import { Home, PlusSquare, Bell, Folder, Users, LogOut, Star, LayoutDashboard, Users as StudentsIcon, Briefcase, Activity, MessageSquare, ChevronRight } from "/node_modules/.vite/deps/lucide-react.js?v=383bea9f";
import { useAuth } from "/src/context/AuthContext.jsx";
import ProMateLogo from "/src/assets/images/logo.jpeg?import";
import DummyProfile from "/src/assets/images/pic1.jpeg?import";
const AdminNavbar = () => {
  _s();
  const location = useLocation();
  const navigate = useNavigate();
  const {
    logout
  } = useAuth();
  const handleLogout = () => {
    logout();
    navigate("/");
  };
  const navItems = [{
    text: "Dashboard",
    icon: /* @__PURE__ */ jsxDEV(LayoutDashboard, { size: 20 }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/AdminNavbar.jsx",
      lineNumber: 22,
      columnNumber: 11
    }, this),
    path: "/admindashboard",
    section: "Management"
  }, {
    text: "Students",
    icon: /* @__PURE__ */ jsxDEV(StudentsIcon, { size: 20 }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/AdminNavbar.jsx",
      lineNumber: 27,
      columnNumber: 11
    }, this),
    path: "/studentman",
    section: "Management"
  }, {
    text: "Projects",
    icon: /* @__PURE__ */ jsxDEV(Briefcase, { size: 20 }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/AdminNavbar.jsx",
      lineNumber: 32,
      columnNumber: 11
    }, this),
    badge: "3",
    path: "/projectman",
    section: "Management"
  }, {
    text: "Activity",
    icon: /* @__PURE__ */ jsxDEV(Activity, { size: 20 }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/AdminNavbar.jsx",
      lineNumber: 38,
      columnNumber: 11
    }, this),
    path: "/history",
    section: "Operations"
  }, {
    text: "Ratings & Feedbacks",
    icon: /* @__PURE__ */ jsxDEV(Star, { size: 20 }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/AdminNavbar.jsx",
      lineNumber: 43,
      columnNumber: 11
    }, this),
    path: "/adminfeedbacks",
    section: "Operations"
  }];
  return /* @__PURE__ */ jsxDEV("div", { className: "h-screen w-72 bg-white border-r border-gray-100 flex flex-col justify-between p-6 shadow-xl shadow-gray-200/50 z-50", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col h-full scrollbar-none overflow-y-auto", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center mb-10 gap-4 px-2", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "p-2 bg-gradient-to-br from-primary/10 to-secondary/10 rounded-2xl shadow-inner", children: /* @__PURE__ */ jsxDEV("img", { src: ProMateLogo, alt: "ProMate Logo", className: "w-10 h-10 rounded-xl object-cover" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/AdminNavbar.jsx",
          lineNumber: 52,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/AdminNavbar.jsx",
          lineNumber: 51,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-black tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-primary to-secondary", children: "ProMate" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/AdminNavbar.jsx",
            lineNumber: 55,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-[10px] font-bold text-gray-400 uppercase tracking-widest leading-none mt-1", children: "Admin Control Panel" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/AdminNavbar.jsx",
            lineNumber: 56,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/AdminNavbar.jsx",
          lineNumber: 54,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/AdminNavbar.jsx",
        lineNumber: 50,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-8 flex-1", children: [
        /* @__PURE__ */ jsxDEV("section", { children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] font-bold text-gray-400 uppercase tracking-[0.2em] mb-4 ml-4", children: "Management" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/AdminNavbar.jsx",
            lineNumber: 64,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("nav", { className: "space-y-1.5", children: navItems.filter((i) => i.section === "Management").map((item) => /* @__PURE__ */ jsxDEV(Link, { to: item.path, children: /* @__PURE__ */ jsxDEV(NavItem, { icon: item.icon, text: item.text, badge: item.badge, active: location.pathname === item.path }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/AdminNavbar.jsx",
            lineNumber: 67,
            columnNumber: 19
          }, this) }, item.text, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/AdminNavbar.jsx",
            lineNumber: 66,
            columnNumber: 77
          }, this)) }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/AdminNavbar.jsx",
            lineNumber: 65,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/AdminNavbar.jsx",
          lineNumber: 63,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("section", { children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] font-bold text-gray-400 uppercase tracking-[0.2em] mb-4 ml-4", children: "Operations" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/AdminNavbar.jsx",
            lineNumber: 74,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("nav", { className: "space-y-1.5", children: navItems.filter((i) => i.section === "Operations").map((item) => /* @__PURE__ */ jsxDEV(Link, { to: item.path, children: /* @__PURE__ */ jsxDEV(NavItem, { icon: item.icon, text: item.text, badge: item.badge, active: location.pathname === item.path }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/AdminNavbar.jsx",
            lineNumber: 77,
            columnNumber: 19
          }, this) }, item.text, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/AdminNavbar.jsx",
            lineNumber: 76,
            columnNumber: 77
          }, this)) }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/AdminNavbar.jsx",
            lineNumber: 75,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/AdminNavbar.jsx",
          lineNumber: 73,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/AdminNavbar.jsx",
        lineNumber: 61,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-auto pt-6 border-t border-gray-100 space-y-1", children: /* @__PURE__ */ jsxDEV("div", { onClick: handleLogout, className: "group", children: /* @__PURE__ */ jsxDEV(NavItem, { icon: /* @__PURE__ */ jsxDEV(LogOut, { size: 18 }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/AdminNavbar.jsx",
        lineNumber: 86,
        columnNumber: 28
      }, this), text: "Sign Out", className: "text-red-500 hover:bg-red-50 hover:text-red-600" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/AdminNavbar.jsx",
        lineNumber: 86,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/AdminNavbar.jsx",
        lineNumber: 85,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/AdminNavbar.jsx",
        lineNumber: 84,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/AdminNavbar.jsx",
      lineNumber: 48,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "mt-8 p-4 bg-slate-900 rounded-3xl border border-slate-800 relative group overflow-hidden", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
        /* @__PURE__ */ jsxDEV("img", { src: DummyProfile, alt: "Profile", className: "w-12 h-12 rounded-2xl object-cover ring-2 ring-slate-800 shadow-md" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/AdminNavbar.jsx",
          lineNumber: 95,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "absolute -bottom-1 -right-1 w-4 h-4 bg-primary border-2 border-slate-900 rounded-full shadow-sm" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/AdminNavbar.jsx",
          lineNumber: 96,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/AdminNavbar.jsx",
        lineNumber: 94,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col min-w-0", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-bold text-white truncate tracking-tight", children: "System Admin" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/AdminNavbar.jsx",
          lineNumber: 99,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] font-medium text-slate-400 truncate", children: "admin@promate.com" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/AdminNavbar.jsx",
          lineNumber: 100,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/AdminNavbar.jsx",
        lineNumber: 98,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/AdminNavbar.jsx",
      lineNumber: 93,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/AdminNavbar.jsx",
      lineNumber: 92,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/AdminNavbar.jsx",
    lineNumber: 47,
    columnNumber: 10
  }, this);
};
_s(AdminNavbar, "1cMEyQbvC7HLZshZzxQqghZdlfE=", false, function() {
  return [useLocation, useNavigate, useAuth];
});
_c = AdminNavbar;
function NavItem({
  icon,
  text,
  active,
  badge,
  className = ""
}) {
  return /* @__PURE__ */ jsxDEV("div", { className: `flex items-center gap-3 px-4 py-3 rounded-2xl cursor-pointer transition-all duration-300 group relative ${active ? "bg-gradient-to-br from-primary/10 to-secondary/10 text-primary font-bold shadow-[0_4px_12px_rgba(59,130,246,0.08)]" : `text-gray-500 hover:bg-gray-50 hover:text-gray-900 ${className}`}`, children: [
    active && /* @__PURE__ */ jsxDEV("div", { className: "absolute left-0 top-1/4 bottom-1/4 w-1 bg-primary rounded-r-full" }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/AdminNavbar.jsx",
      lineNumber: 121,
      columnNumber: 18
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: `transition-transform duration-300 group-hover:scale-110 ${active ? "text-primary" : "text-gray-400 group-hover:text-primary"}`, children: icon }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/AdminNavbar.jsx",
      lineNumber: 123,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("span", { className: "text-[14px] flex-1 leading-none", children: text }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/AdminNavbar.jsx",
      lineNumber: 127,
      columnNumber: 7
    }, this),
    badge && /* @__PURE__ */ jsxDEV("span", { className: "bg-primary text-white text-[10px] tabular-nums font-black min-w-[18px] h-[18px] flex items-center justify-center rounded-full shadow-lg shadow-primary/20", children: badge }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/AdminNavbar.jsx",
      lineNumber: 129,
      columnNumber: 17
    }, this),
    !active && /* @__PURE__ */ jsxDEV(ChevronRight, { size: 14, className: "opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all text-gray-300" }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/AdminNavbar.jsx",
      lineNumber: 133,
      columnNumber: 19
    }, this)
  ] }, void 0, true, {
    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/AdminNavbar.jsx",
    lineNumber: 119,
    columnNumber: 10
  }, this);
}
_c2 = NavItem;
export default AdminNavbar;
var _c, _c2;
$RefreshReg$(_c, "AdminNavbar");
$RefreshReg$(_c2, "NavItem");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/AdminNavbar.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0MrQjs7Ozs7Ozs7Ozs7Ozs7OztBQWhDL0IsT0FBT0EsV0FBVztBQUNsQixTQUFTQyxNQUFNQyxhQUFhQyxtQkFBbUI7QUFDL0MsU0FDRUMsTUFDQUMsWUFDQUMsTUFDQUMsUUFDQUMsT0FDQUMsUUFDQUMsTUFDQUMsaUJBQ0FILFNBQVNJLGNBQ1RDLFdBQ0FDLFVBQ0FDLGVBQ0FDLG9CQUNLO0FBQ1AsU0FBU0MsZUFBZTtBQUN4QixPQUFPQyxpQkFBaUI7QUFDeEIsT0FBT0Msa0JBQWtCO0FBRXpCLE1BQU1DLGNBQWNBLE1BQU07QUFBQUMsS0FBQTtBQUN4QixRQUFNQyxXQUFXcEIsWUFBWTtBQUM3QixRQUFNcUIsV0FBV3BCLFlBQVk7QUFDN0IsUUFBTTtBQUFBLElBQUVxQjtBQUFBQSxFQUFPLElBQUlQLFFBQVE7QUFFM0IsUUFBTVEsZUFBZUEsTUFBTTtBQUN6QkQsV0FBTztBQUNQRCxhQUFTLEdBQUc7QUFBQSxFQUNkO0FBRUEsUUFBTUcsV0FBVyxDQUNmO0FBQUEsSUFBRUMsTUFBTTtBQUFBLElBQWFDLE1BQU0sdUJBQUMsbUJBQWdCLE1BQU0sTUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwQjtBQUFBLElBQUtDLE1BQU07QUFBQSxJQUFtQkMsU0FBUztBQUFBLEVBQWEsR0FDekc7QUFBQSxJQUFFSCxNQUFNO0FBQUEsSUFBWUMsTUFBTSx1QkFBQyxnQkFBYSxNQUFNLE1BQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBdUI7QUFBQSxJQUFLQyxNQUFNO0FBQUEsSUFBZUMsU0FBUztBQUFBLEVBQWEsR0FDakc7QUFBQSxJQUFFSCxNQUFNO0FBQUEsSUFBWUMsTUFBTSx1QkFBQyxhQUFVLE1BQU0sTUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFvQjtBQUFBLElBQUtHLE9BQU87QUFBQSxJQUFLRixNQUFNO0FBQUEsSUFBZUMsU0FBUztBQUFBLEVBQWEsR0FDMUc7QUFBQSxJQUFFSCxNQUFNO0FBQUEsSUFBWUMsTUFBTSx1QkFBQyxZQUFTLE1BQU0sTUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFtQjtBQUFBLElBQUtDLE1BQU07QUFBQSxJQUFZQyxTQUFTO0FBQUEsRUFBYSxHQUMxRjtBQUFBLElBQUVILE1BQU07QUFBQSxJQUF1QkMsTUFBTSx1QkFBQyxRQUFLLE1BQU0sTUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWU7QUFBQSxJQUFLQyxNQUFNO0FBQUEsSUFBbUJDLFNBQVM7QUFBQSxFQUFhLENBQUM7QUFHM0csU0FDRSx1QkFBQyxTQUFJLFdBQVUsdUhBQ2I7QUFBQSwyQkFBQyxTQUFJLFdBQVUsdURBRWI7QUFBQSw2QkFBQyxTQUFJLFdBQVUsc0NBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsa0ZBQ2IsaUNBQUMsU0FBSSxLQUFLWixhQUFhLEtBQUksZ0JBQWUsV0FBVSx1Q0FBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1RixLQUR6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsK0dBQThHLHVCQUE1SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtSTtBQUFBLFVBQ25JLHVCQUFDLE9BQUUsV0FBVSxtRkFBa0YsbUNBQS9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtIO0FBQUEsYUFGcEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsV0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUE7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSxvQkFFYjtBQUFBLCtCQUFDLGFBQ0M7QUFBQSxpQ0FBQyxPQUFFLFdBQVUsNEVBQTJFLDBCQUF4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrRztBQUFBLFVBQ2xHLHVCQUFDLFNBQUksV0FBVSxlQUNaUSxtQkFBU00sT0FBT0MsT0FBS0EsRUFBRUgsWUFBWSxZQUFZLEVBQUVJLElBQUtDLFVBQ3JELHVCQUFDLFFBQXFCLElBQUlBLEtBQUtOLE1BQzdCLGlDQUFDLFdBQ0MsTUFBTU0sS0FBS1AsTUFDWCxNQUFNTyxLQUFLUixNQUNYLE9BQU9RLEtBQUtKLE9BQ1osUUFBUVQsU0FBU2MsYUFBYUQsS0FBS04sUUFKckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJMEMsS0FMakNNLEtBQUtSLE1BQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0EsQ0FDRCxLQVZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBV0E7QUFBQSxhQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFjQTtBQUFBLFFBR0EsdUJBQUMsYUFDQztBQUFBLGlDQUFDLE9BQUUsV0FBVSw0RUFBMkUsMEJBQXhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtHO0FBQUEsVUFDbEcsdUJBQUMsU0FBSSxXQUFVLGVBQ1pELG1CQUFTTSxPQUFPQyxPQUFLQSxFQUFFSCxZQUFZLFlBQVksRUFBRUksSUFBS0MsVUFDckQsdUJBQUMsUUFBcUIsSUFBSUEsS0FBS04sTUFDN0IsaUNBQUMsV0FDQyxNQUFNTSxLQUFLUCxNQUNYLE1BQU1PLEtBQUtSLE1BQ1gsT0FBT1EsS0FBS0osT0FDWixRQUFRVCxTQUFTYyxhQUFhRCxLQUFLTixRQUpyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUkwQyxLQUxqQ00sS0FBS1IsTUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQSxDQUNELEtBVkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFXQTtBQUFBLGFBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWNBO0FBQUEsV0FqQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWtDQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxXQUFVLG1EQUNiLGlDQUFDLFNBQUksU0FBU0YsY0FBYyxXQUFVLFNBQ3BDLGlDQUFDLFdBQ0MsTUFBTSx1QkFBQyxVQUFPLE1BQU0sTUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlCLEdBQ3ZCLE1BQUssWUFDTCxXQUFVLHFEQUhaO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHNkQsS0FKL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1BLEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsU0ExREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTJEQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLDRGQUNiLGlDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxZQUNiO0FBQUEsK0JBQUMsU0FDQyxLQUFLTixjQUNMLEtBQUksV0FDSixXQUFVLHdFQUhaO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHZ0Y7QUFBQSxRQUVoRix1QkFBQyxTQUFJLFdBQVUscUdBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpSDtBQUFBLFdBTm5IO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLHlCQUNiO0FBQUEsK0JBQUMsT0FBRSxXQUFVLHdEQUF1RCw0QkFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnRjtBQUFBLFFBQ2hGLHVCQUFDLE9BQUUsV0FBVSxtREFBa0QsaUNBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0Y7QUFBQSxXQUZsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxTQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FhQSxLQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FlQTtBQUFBLE9BOUVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0ErRUE7QUFFSjtBQUVBRSxHQXRHTUQsYUFBVztBQUFBLFVBQ0VsQixhQUNBQyxhQUNFYyxPQUFPO0FBQUE7QUFBQW9CLEtBSHRCakI7QUF1R04sU0FBU2tCLFFBQVE7QUFBQSxFQUFFVjtBQUFBQSxFQUFNRDtBQUFBQSxFQUFNWTtBQUFBQSxFQUFRUjtBQUFBQSxFQUFPUyxZQUFZO0FBQUcsR0FBRztBQUM5RCxTQUNFLHVCQUFDLFNBQ0MsV0FBVywyR0FDVEQsU0FDSSx1SEFDQSxzREFBc0RDLFNBQVMsRUFBRSxJQUl0RUQ7QUFBQUEsY0FDQyx1QkFBQyxTQUFJLFdBQVUsc0VBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFrRjtBQUFBLElBR3BGLHVCQUFDLFNBQUksV0FBVywyREFBMkRBLFNBQVMsaUJBQWlCLHdDQUF3QyxJQUMxSVgsa0JBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFFQSx1QkFBQyxVQUFLLFdBQVUsbUNBQW1DRCxrQkFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF3RDtBQUFBLElBRXZESSxTQUNDLHVCQUFDLFVBQUssV0FBVSw2SkFDYkEsbUJBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFHRCxDQUFDUSxVQUNBLHVCQUFDLGdCQUFhLE1BQU0sSUFBSSxXQUFVLDZHQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTJJO0FBQUEsT0F6Qi9JO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EyQkE7QUFFSjtBQUFDRSxNQS9CUUg7QUFpQ1QsZUFBZWxCO0FBQVksSUFBQWlCLElBQUFJO0FBQUFDLGFBQUFMLElBQUE7QUFBQUssYUFBQUQsS0FBQSIsIm5hbWVzIjpbIlJlYWN0IiwiTGluayIsInVzZUxvY2F0aW9uIiwidXNlTmF2aWdhdGUiLCJIb21lIiwiUGx1c1NxdWFyZSIsIkJlbGwiLCJGb2xkZXIiLCJVc2VycyIsIkxvZ091dCIsIlN0YXIiLCJMYXlvdXREYXNoYm9hcmQiLCJTdHVkZW50c0ljb24iLCJCcmllZmNhc2UiLCJBY3Rpdml0eSIsIk1lc3NhZ2VTcXVhcmUiLCJDaGV2cm9uUmlnaHQiLCJ1c2VBdXRoIiwiUHJvTWF0ZUxvZ28iLCJEdW1teVByb2ZpbGUiLCJBZG1pbk5hdmJhciIsIl9zIiwibG9jYXRpb24iLCJuYXZpZ2F0ZSIsImxvZ291dCIsImhhbmRsZUxvZ291dCIsIm5hdkl0ZW1zIiwidGV4dCIsImljb24iLCJwYXRoIiwic2VjdGlvbiIsImJhZGdlIiwiZmlsdGVyIiwiaSIsIm1hcCIsIml0ZW0iLCJwYXRobmFtZSIsIl9jIiwiTmF2SXRlbSIsImFjdGl2ZSIsImNsYXNzTmFtZSIsIl9jMiIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkFkbWluTmF2YmFyLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IExpbmssIHVzZUxvY2F0aW9uLCB1c2VOYXZpZ2F0ZSB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCB7IFxyXG4gIEhvbWUsIFxyXG4gIFBsdXNTcXVhcmUsIFxyXG4gIEJlbGwsIFxyXG4gIEZvbGRlciwgXHJcbiAgVXNlcnMsIFxyXG4gIExvZ091dCwgXHJcbiAgU3RhcixcclxuICBMYXlvdXREYXNoYm9hcmQsXHJcbiAgVXNlcnMgYXMgU3R1ZGVudHNJY29uLFxyXG4gIEJyaWVmY2FzZSxcclxuICBBY3Rpdml0eSxcclxuICBNZXNzYWdlU3F1YXJlLFxyXG4gIENoZXZyb25SaWdodFxyXG59IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcclxuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4uL2NvbnRleHQvQXV0aENvbnRleHQnO1xyXG5pbXBvcnQgUHJvTWF0ZUxvZ28gZnJvbSAnLi4vYXNzZXRzL2ltYWdlcy9sb2dvLmpwZWcnO1xyXG5pbXBvcnQgRHVtbXlQcm9maWxlIGZyb20gJy4uL2Fzc2V0cy9pbWFnZXMvcGljMS5qcGVnJztcclxuXHJcbmNvbnN0IEFkbWluTmF2YmFyID0gKCkgPT4ge1xyXG4gIGNvbnN0IGxvY2F0aW9uID0gdXNlTG9jYXRpb24oKTtcclxuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XHJcbiAgY29uc3QgeyBsb2dvdXQgfSA9IHVzZUF1dGgoKTsgLy8gQXNzdW1pbmcgYWRtaW4gdXNlcyB0aGUgc2FtZSBsb2dvdXRcclxuXHJcbiAgY29uc3QgaGFuZGxlTG9nb3V0ID0gKCkgPT4ge1xyXG4gICAgbG9nb3V0KCk7XHJcbiAgICBuYXZpZ2F0ZSgnLycpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IG5hdkl0ZW1zID0gW1xyXG4gICAgeyB0ZXh0OiBcIkRhc2hib2FyZFwiLCBpY29uOiA8TGF5b3V0RGFzaGJvYXJkIHNpemU9ezIwfSAvPiwgcGF0aDogXCIvYWRtaW5kYXNoYm9hcmRcIiwgc2VjdGlvbjogXCJNYW5hZ2VtZW50XCIgfSxcclxuICAgIHsgdGV4dDogXCJTdHVkZW50c1wiLCBpY29uOiA8U3R1ZGVudHNJY29uIHNpemU9ezIwfSAvPiwgcGF0aDogXCIvc3R1ZGVudG1hblwiLCBzZWN0aW9uOiBcIk1hbmFnZW1lbnRcIiB9LFxyXG4gICAgeyB0ZXh0OiBcIlByb2plY3RzXCIsIGljb246IDxCcmllZmNhc2Ugc2l6ZT17MjB9IC8+LCBiYWRnZTogXCIzXCIsIHBhdGg6IFwiL3Byb2plY3RtYW5cIiwgc2VjdGlvbjogXCJNYW5hZ2VtZW50XCIgfSxcclxuICAgIHsgdGV4dDogXCJBY3Rpdml0eVwiLCBpY29uOiA8QWN0aXZpdHkgc2l6ZT17MjB9IC8+LCBwYXRoOiBcIi9oaXN0b3J5XCIsIHNlY3Rpb246IFwiT3BlcmF0aW9uc1wiIH0sXHJcbiAgICB7IHRleHQ6IFwiUmF0aW5ncyAmIEZlZWRiYWNrc1wiLCBpY29uOiA8U3RhciBzaXplPXsyMH0gLz4sIHBhdGg6IFwiL2FkbWluZmVlZGJhY2tzXCIsIHNlY3Rpb246IFwiT3BlcmF0aW9uc1wiIH0sXHJcbiAgXTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiaC1zY3JlZW4gdy03MiBiZy13aGl0ZSBib3JkZXItciBib3JkZXItZ3JheS0xMDAgZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWJldHdlZW4gcC02IHNoYWRvdy14bCBzaGFkb3ctZ3JheS0yMDAvNTAgei01MFwiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaC1mdWxsIHNjcm9sbGJhci1ub25lIG92ZXJmbG93LXktYXV0b1wiPlxyXG4gICAgICAgIHsvKiBMb2dvIFNlY3Rpb24gKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBtYi0xMCBnYXAtNCBweC0yXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMiBiZy1ncmFkaWVudC10by1iciBmcm9tLXByaW1hcnkvMTAgdG8tc2Vjb25kYXJ5LzEwIHJvdW5kZWQtMnhsIHNoYWRvdy1pbm5lclwiPlxyXG4gICAgICAgICAgICA8aW1nIHNyYz17UHJvTWF0ZUxvZ299IGFsdD1cIlByb01hdGUgTG9nb1wiIGNsYXNzTmFtZT1cInctMTAgaC0xMCByb3VuZGVkLXhsIG9iamVjdC1jb3ZlclwiIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJsYWNrIHRyYWNraW5nLXRpZ2h0IGJnLWNsaXAtdGV4dCB0ZXh0LXRyYW5zcGFyZW50IGJnLWdyYWRpZW50LXRvLXIgZnJvbS1wcmltYXJ5IHRvLXNlY29uZGFyeVwiPlByb01hdGU8L2gyPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1ncmF5LTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXN0IGxlYWRpbmctbm9uZSBtdC0xXCI+QWRtaW4gQ29udHJvbCBQYW5lbDwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogTmF2aWdhdGlvbiBDYXRlZ29yaWVzICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS04IGZsZXgtMVwiPlxyXG4gICAgICAgICAgey8qIE1hbmFnZW1lbnQgU2VjdGlvbiAqL31cclxuICAgICAgICAgIDxzZWN0aW9uPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LWJvbGQgdGV4dC1ncmF5LTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctWzAuMmVtXSBtYi00IG1sLTRcIj5NYW5hZ2VtZW50PC9wPlxyXG4gICAgICAgICAgICA8bmF2IGNsYXNzTmFtZT1cInNwYWNlLXktMS41XCI+XHJcbiAgICAgICAgICAgICAge25hdkl0ZW1zLmZpbHRlcihpID0+IGkuc2VjdGlvbiA9PT0gXCJNYW5hZ2VtZW50XCIpLm1hcCgoaXRlbSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgPExpbmsga2V5PXtpdGVtLnRleHR9IHRvPXtpdGVtLnBhdGh9PlxyXG4gICAgICAgICAgICAgICAgICA8TmF2SXRlbVxyXG4gICAgICAgICAgICAgICAgICAgIGljb249e2l0ZW0uaWNvbn1cclxuICAgICAgICAgICAgICAgICAgICB0ZXh0PXtpdGVtLnRleHR9XHJcbiAgICAgICAgICAgICAgICAgICAgYmFkZ2U9e2l0ZW0uYmFkZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgYWN0aXZlPXtsb2NhdGlvbi5wYXRobmFtZSA9PT0gaXRlbS5wYXRofVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICA8L25hdj5cclxuICAgICAgICAgIDwvc2VjdGlvbj5cclxuXHJcbiAgICAgICAgICB7LyogT3BlcmF0aW9ucyBTZWN0aW9uICovfVxyXG4gICAgICAgICAgPHNlY3Rpb24+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtYm9sZCB0ZXh0LWdyYXktNDAwIHVwcGVyY2FzZSB0cmFja2luZy1bMC4yZW1dIG1iLTQgbWwtNFwiPk9wZXJhdGlvbnM8L3A+XHJcbiAgICAgICAgICAgIDxuYXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjVcIj5cclxuICAgICAgICAgICAgICB7bmF2SXRlbXMuZmlsdGVyKGkgPT4gaS5zZWN0aW9uID09PSBcIk9wZXJhdGlvbnNcIikubWFwKChpdGVtKSA9PiAoXHJcbiAgICAgICAgICAgICAgICA8TGluayBrZXk9e2l0ZW0udGV4dH0gdG89e2l0ZW0ucGF0aH0+XHJcbiAgICAgICAgICAgICAgICAgIDxOYXZJdGVtXHJcbiAgICAgICAgICAgICAgICAgICAgaWNvbj17aXRlbS5pY29ufVxyXG4gICAgICAgICAgICAgICAgICAgIHRleHQ9e2l0ZW0udGV4dH1cclxuICAgICAgICAgICAgICAgICAgICBiYWRnZT17aXRlbS5iYWRnZX1cclxuICAgICAgICAgICAgICAgICAgICBhY3RpdmU9e2xvY2F0aW9uLnBhdGhuYW1lID09PSBpdGVtLnBhdGh9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvbmF2PlxyXG4gICAgICAgICAgPC9zZWN0aW9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogQWN0aW9uIFNlY3Rpb24gKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC1hdXRvIHB0LTYgYm9yZGVyLXQgYm9yZGVyLWdyYXktMTAwIHNwYWNlLXktMVwiPlxyXG4gICAgICAgICAgPGRpdiBvbkNsaWNrPXtoYW5kbGVMb2dvdXR9IGNsYXNzTmFtZT1cImdyb3VwXCI+XHJcbiAgICAgICAgICAgIDxOYXZJdGVtIFxyXG4gICAgICAgICAgICAgIGljb249ezxMb2dPdXQgc2l6ZT17MTh9IC8+fSBcclxuICAgICAgICAgICAgICB0ZXh0PVwiU2lnbiBPdXRcIiBcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgaG92ZXI6YmctcmVkLTUwIGhvdmVyOnRleHQtcmVkLTYwMFwiIFxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgey8qIEFkbWluIFByb2ZpbGUgQ2FyZCAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC04IHAtNCBiZy1zbGF0ZS05MDAgcm91bmRlZC0zeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcmVsYXRpdmUgZ3JvdXAgb3ZlcmZsb3ctaGlkZGVuXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxyXG4gICAgICAgICAgICA8aW1nXHJcbiAgICAgICAgICAgICAgc3JjPXtEdW1teVByb2ZpbGV9XHJcbiAgICAgICAgICAgICAgYWx0PVwiUHJvZmlsZVwiXHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0xMiBoLTEyIHJvdW5kZWQtMnhsIG9iamVjdC1jb3ZlciByaW5nLTIgcmluZy1zbGF0ZS04MDAgc2hhZG93LW1kXCJcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSAtYm90dG9tLTEgLXJpZ2h0LTEgdy00IGgtNCBiZy1wcmltYXJ5IGJvcmRlci0yIGJvcmRlci1zbGF0ZS05MDAgcm91bmRlZC1mdWxsIHNoYWRvdy1zbVwiPjwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgbWluLXctMFwiPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LXdoaXRlIHRydW5jYXRlIHRyYWNraW5nLXRpZ2h0XCI+U3lzdGVtIEFkbWluPC9wPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTQwMCB0cnVuY2F0ZVwiPmFkbWluQHByb21hdGUuY29tPC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbi8qIEltcHJvdmVkIE5hdiBJdGVtICovXHJcbmZ1bmN0aW9uIE5hdkl0ZW0oeyBpY29uLCB0ZXh0LCBhY3RpdmUsIGJhZGdlLCBjbGFzc05hbWUgPSBcIlwiIH0pIHtcclxuICByZXR1cm4gKFxyXG4gICAgPGRpdlxyXG4gICAgICBjbGFzc05hbWU9e2BmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBweC00IHB5LTMgcm91bmRlZC0yeGwgY3Vyc29yLXBvaW50ZXIgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIGdyb3VwIHJlbGF0aXZlICR7XHJcbiAgICAgICAgYWN0aXZlXHJcbiAgICAgICAgICA/IFwiYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1wcmltYXJ5LzEwIHRvLXNlY29uZGFyeS8xMCB0ZXh0LXByaW1hcnkgZm9udC1ib2xkIHNoYWRvdy1bMF80cHhfMTJweF9yZ2JhKDU5LDEzMCwyNDYsMC4wOCldXCJcclxuICAgICAgICAgIDogYHRleHQtZ3JheS01MDAgaG92ZXI6YmctZ3JheS01MCBob3Zlcjp0ZXh0LWdyYXktOTAwICR7Y2xhc3NOYW1lfWBcclxuICAgICAgfWB9XHJcbiAgICA+XHJcbiAgICAgIHsvKiBBY3RpdmUgSW5kaWNhdG9yIFN0cmlwICovfVxyXG4gICAgICB7YWN0aXZlICYmIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGxlZnQtMCB0b3AtMS80IGJvdHRvbS0xLzQgdy0xIGJnLXByaW1hcnkgcm91bmRlZC1yLWZ1bGxcIj48L2Rpdj5cclxuICAgICAgKX1cclxuICAgICAgXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tMzAwIGdyb3VwLWhvdmVyOnNjYWxlLTExMCAke2FjdGl2ZSA/IFwidGV4dC1wcmltYXJ5XCIgOiBcInRleHQtZ3JheS00MDAgZ3JvdXAtaG92ZXI6dGV4dC1wcmltYXJ5XCJ9YH0+XHJcbiAgICAgICAge2ljb259XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICBcclxuICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTRweF0gZmxleC0xIGxlYWRpbmctbm9uZVwiPnt0ZXh0fTwvc3Bhbj5cclxuICAgICAgXHJcbiAgICAgIHtiYWRnZSAmJiAoXHJcbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmctcHJpbWFyeSB0ZXh0LXdoaXRlIHRleHQtWzEwcHhdIHRhYnVsYXItbnVtcyBmb250LWJsYWNrIG1pbi13LVsxOHB4XSBoLVsxOHB4XSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLWZ1bGwgc2hhZG93LWxnIHNoYWRvdy1wcmltYXJ5LzIwXCI+XHJcbiAgICAgICAgICB7YmFkZ2V9XHJcbiAgICAgICAgPC9zcGFuPlxyXG4gICAgICApfVxyXG5cclxuICAgICAgeyFhY3RpdmUgJiYgKFxyXG4gICAgICAgIDxDaGV2cm9uUmlnaHQgc2l6ZT17MTR9IGNsYXNzTmFtZT1cIm9wYWNpdHktMCAtdHJhbnNsYXRlLXgtMiBncm91cC1ob3ZlcjpvcGFjaXR5LTEwMCBncm91cC1ob3Zlcjp0cmFuc2xhdGUteC0wIHRyYW5zaXRpb24tYWxsIHRleHQtZ3JheS0zMDBcIiAvPlxyXG4gICAgICApfVxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgQWRtaW5OYXZiYXI7Il0sImZpbGUiOiJGOi9ZM1MyL0lUUE0gcHJvamVjdC9Qcm9NYXRlLS1Qcm9qZWN0LVBhcnRuZXItRmluZGVyL2Zyb250ZW5kL3NyYy9jb21wb25lbnRzL0FkbWluTmF2YmFyLmpzeCJ9