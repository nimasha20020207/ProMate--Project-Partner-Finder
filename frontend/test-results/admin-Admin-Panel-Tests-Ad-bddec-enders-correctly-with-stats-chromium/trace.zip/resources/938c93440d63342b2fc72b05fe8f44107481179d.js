import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/RecEngine/StudentRecommendations.jsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/StudentRecommendations.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=383bea9f"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Navbar from "/src/components/Navbar.jsx";
import DummyProfile from "/src/assets/images/pic1.jpeg?import";
const StudentRecommendations = () => {
  _s();
  const [students, setStudents] = useState([]);
  useEffect(() => {
    fetch("http://localhost:3000/api/recommendations/students/P3").then((res) => res.json()).then((data) => setStudents(data));
  }, []);
  const maxScore = students.length > 0 ? Math.max(...students.map((s) => s.score)) : 0;
  return /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-screen bg-gray-100", children: /* @__PURE__ */ jsxDEV("div", { className: "flex-1 p-6 bg-surface", children: /* @__PURE__ */ jsxDEV("div", { className: "p-6", children: [
    /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-bold mb-6", children: "👨‍🎓 Top Matched Students" }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/StudentRecommendations.jsx",
      lineNumber: 21,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid md:grid-cols-2 lg:grid-cols-3 gap-6", children: students.map((item, i) => {
      const percentage = (item.score * 100).toFixed(0);
      const isTopMatch = item.score === maxScore;
      return /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-5 rounded-xl shadow-lg relative hover:shadow-xl transition-shadow duration-300", children: [
        isTopMatch && /* @__PURE__ */ jsxDEV("div", { className: "absolute top-2 left-2 bg-gradient-to-r from-secondary to-accent text-white text-xs font-bold px-2 py-1 rounded-full shadow-md z-10", children: "🌟 Top Match" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/StudentRecommendations.jsx",
          lineNumber: 32,
          columnNumber: 34
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "absolute top-3 right-3 w-20 h-20 rounded-full p-[2px] bg-gradient-to-r from-primary to-secondary", children: /* @__PURE__ */ jsxDEV("img", { src: DummyProfile, alt: item.student.fullName, className: "w-full h-full rounded-full object-cover" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/StudentRecommendations.jsx",
          lineNumber: 38,
          columnNumber: 21
        }, this) }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/StudentRecommendations.jsx",
          lineNumber: 37,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold mt-10", children: item.student.fullName }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/StudentRecommendations.jsx",
          lineNumber: 42,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 mb-3 mt-2", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "relative w-12 h-12", children: [
            /* @__PURE__ */ jsxDEV("svg", { className: "w-12 h-12 transform -rotate-90", children: [
              /* @__PURE__ */ jsxDEV("circle", { cx: "24", cy: "24", r: "20", className: "stroke-gray-200", strokeWidth: "5", fill: "none" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/StudentRecommendations.jsx",
                lineNumber: 48,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("circle", { cx: "24", cy: "24", r: "20", stroke: "url(#grad)", strokeWidth: "5", fill: "none", strokeDasharray: 2 * Math.PI * 20, strokeDashoffset: 2 * Math.PI * 20 * (1 - percentage / 100), strokeLinecap: "round" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/StudentRecommendations.jsx",
                lineNumber: 49,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("defs", { children: /* @__PURE__ */ jsxDEV("linearGradient", { id: "grad", children: [
                /* @__PURE__ */ jsxDEV("stop", { offset: "0%", stopColor: "#3B82F6" }, void 0, false, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/StudentRecommendations.jsx",
                  lineNumber: 52,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("stop", { offset: "50%", stopColor: "#F472B6" }, void 0, false, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/StudentRecommendations.jsx",
                  lineNumber: 53,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("stop", { offset: "100%", stopColor: "#FACC15" }, void 0, false, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/StudentRecommendations.jsx",
                  lineNumber: 54,
                  columnNumber: 29
                }, this)
              ] }, void 0, true, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/StudentRecommendations.jsx",
                lineNumber: 51,
                columnNumber: 27
              }, this) }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/StudentRecommendations.jsx",
                lineNumber: 50,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/StudentRecommendations.jsx",
              lineNumber: 47,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 flex items-center justify-center text-xs font-bold text-gray-800", children: [
              percentage,
              "%"
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/StudentRecommendations.jsx",
              lineNumber: 58,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/StudentRecommendations.jsx",
            lineNumber: 46,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "text-sm", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500", children: "Match Score" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/StudentRecommendations.jsx",
              lineNumber: 65,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent", children: [
              percentage,
              "%"
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/StudentRecommendations.jsx",
              lineNumber: 66,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/StudentRecommendations.jsx",
            lineNumber: 64,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/StudentRecommendations.jsx",
          lineNumber: 45,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2 mt-2", children: item.details?.matchedSkills?.map((skill, idx) => /* @__PURE__ */ jsxDEV("span", { className: "text-xs bg-blue-100 text-blue-600 px-2 py-1 rounded", children: skill }, idx, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/StudentRecommendations.jsx",
          lineNumber: 74,
          columnNumber: 71
        }, this)) }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/StudentRecommendations.jsx",
          lineNumber: 73,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm", children: item.details?.availability?.isEnough ? "✔ Available" : "⚠ Not enough availability" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/StudentRecommendations.jsx",
          lineNumber: 80,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-xs mt-2 text-gray-600", children: item.explanation }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/StudentRecommendations.jsx",
          lineNumber: 85,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV("button", { className: "w-full py-2 mt-3 rounded-lg font-medium text-white bg-primary hover:from-secondary hover:to-primary transition-all duration-300 shadow-sm hover:shadow-md text-sm", children: "View Profile" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/StudentRecommendations.jsx",
          lineNumber: 88,
          columnNumber: 19
        }, this)
      ] }, i, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/StudentRecommendations.jsx",
        lineNumber: 29,
        columnNumber: 20
      }, this);
    }) }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/StudentRecommendations.jsx",
      lineNumber: 25,
      columnNumber: 11
    }, this)
  ] }, void 0, true, {
    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/StudentRecommendations.jsx",
    lineNumber: 20,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/StudentRecommendations.jsx",
    lineNumber: 19,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/StudentRecommendations.jsx",
    lineNumber: 15,
    columnNumber: 10
  }, this);
};
_s(StudentRecommendations, "Xxsbsc/n21pueGlfwfykfeIEF1E=");
_c = StudentRecommendations;
export default StudentRecommendations;
var _c;
$RefreshReg$(_c, "StudentRecommendations");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/StudentRecommendations.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUJVOzs7Ozs7Ozs7Ozs7Ozs7O0FBdkJWLE9BQU9BLFNBQVNDLFdBQVdDLGdCQUFnQjtBQUMzQyxPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLGtCQUFrQjtBQUV6QixNQUFNQyx5QkFBeUJBLE1BQU07QUFBQUMsS0FBQTtBQUNuQyxRQUFNLENBQUNDLFVBQVVDLFdBQVcsSUFBSU4sU0FBUyxFQUFFO0FBRTNDRCxZQUFVLE1BQU07QUFDZFEsVUFBTSx1REFBdUQsRUFDMURDLEtBQUtDLFNBQU9BLElBQUlDLEtBQUssQ0FBQyxFQUN0QkYsS0FBS0csVUFBUUwsWUFBWUssSUFBSSxDQUFDO0FBQUEsRUFDbkMsR0FBRyxFQUFFO0FBR0wsUUFBTUMsV0FBV1AsU0FBU1EsU0FBUyxJQUFJQyxLQUFLQyxJQUFJLEdBQUdWLFNBQVNXLElBQUlDLE9BQUtBLEVBQUVDLEtBQUssQ0FBQyxJQUFJO0FBRWpGLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLGlDQUliLGlDQUFDLFNBQUksV0FBVSx5QkFDYixpQ0FBQyxTQUFJLFdBQVUsT0FDYjtBQUFBLDJCQUFDLFFBQUcsV0FBVSwyQkFBMEIsMENBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLDRDQUNaYixtQkFBU1csSUFBSSxDQUFDRyxNQUFNQyxNQUFNO0FBQ3pCLFlBQU1DLGNBQWNGLEtBQUtELFFBQVEsS0FBS0ksUUFBUSxDQUFDO0FBQy9DLFlBQU1DLGFBQWFKLEtBQUtELFVBQVVOO0FBRWxDLGFBQ0UsdUJBQUMsU0FBWSxXQUFVLDZGQUdwQlc7QUFBQUEsc0JBQ0MsdUJBQUMsU0FBSSxXQUFVLHNJQUFxSSw0QkFBcEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFJRix1QkFBQyxTQUFJLFdBQVUsb0dBQ2IsaUNBQUMsU0FDQyxLQUFLckIsY0FDTCxLQUFLaUIsS0FBS0ssUUFBUUMsVUFDbEIsV0FBVSw2Q0FIWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR3FELEtBSnZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNQTtBQUFBLFFBR0EsdUJBQUMsUUFBRyxXQUFVLCtCQUErQk4sZUFBS0ssUUFBUUMsWUFBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtRTtBQUFBLFFBR25FLHVCQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxzQkFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSxrQ0FDYjtBQUFBLHFDQUFDLFlBQ0MsSUFBRyxNQUNILElBQUcsTUFDSCxHQUFFLE1BQ0YsV0FBVSxtQkFDVixhQUFZLEtBQ1osTUFBSyxVQU5QO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBTWE7QUFBQSxjQUViLHVCQUFDLFlBQ0MsSUFBRyxNQUNILElBQUcsTUFDSCxHQUFFLE1BQ0YsUUFBTyxjQUNQLGFBQVksS0FDWixNQUFLLFFBQ0wsaUJBQWlCLElBQUlYLEtBQUtZLEtBQUssSUFDL0Isa0JBQWtCLElBQUlaLEtBQUtZLEtBQUssTUFBTSxJQUFJTCxhQUFhLE1BQ3ZELGVBQWMsV0FUaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFTdUI7QUFBQSxjQUV2Qix1QkFBQyxVQUNDLGlDQUFDLG9CQUFlLElBQUcsUUFDakI7QUFBQSx1Q0FBQyxVQUFLLFFBQU8sTUFBSyxXQUFVLGFBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXFDO0FBQUEsZ0JBQ3JDLHVCQUFDLFVBQUssUUFBTyxPQUFNLFdBQVUsYUFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBc0M7QUFBQSxnQkFDdEMsdUJBQUMsVUFBSyxRQUFPLFFBQU8sV0FBVSxhQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF1QztBQUFBLG1CQUh6QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUlBLEtBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFNQTtBQUFBLGlCQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTJCQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHFGQUNaQTtBQUFBQTtBQUFBQSxjQUFXO0FBQUEsaUJBRGQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBL0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZ0NBO0FBQUEsVUFHQSx1QkFBQyxTQUFJLFdBQVUsV0FDYjtBQUFBLG1DQUFDLE9BQUUsV0FBVSxpQkFBZ0IsMkJBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdDO0FBQUEsWUFDeEMsdUJBQUMsT0FBRSxXQUFVLHNGQUNWQTtBQUFBQTtBQUFBQSxjQUFXO0FBQUEsaUJBRGQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLGFBekNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEwQ0E7QUFBQSxRQUdBLHVCQUFDLFNBQUksV0FBVSw2QkFDWkYsZUFBS1EsU0FBU0MsZUFBZVosSUFBSSxDQUFDYSxPQUFPQyxRQUN4Qyx1QkFBQyxVQUVDLFdBQVUsdURBRVRELG1CQUhJQyxLQURQO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQSxDQUNELEtBUkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsUUFHQSx1QkFBQyxPQUFFLFdBQVUsZ0JBQ1ZYLGVBQUtRLFNBQVNJLGNBQWNDLFdBQ3pCLGdCQUNBLCtCQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQTtBQUFBLFFBR0EsdUJBQUMsT0FBRSxXQUFVLDhCQUE4QmIsZUFBS2MsZUFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0RDtBQUFBLFFBRzVELHVCQUFDLFlBQU8sV0FBVSxxS0FBb0ssNEJBQXRMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBM0ZRYixHQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE0RkE7QUFBQSxJQUVKLENBQUMsS0FwR0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXFHQTtBQUFBLE9BMUdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EyR0EsS0E1R0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTZHQSxLQWpIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBa0hBO0FBRUo7QUFBRWhCLEdBaklJRCx3QkFBc0I7QUFBQStCLEtBQXRCL0I7QUFtSU4sZUFBZUE7QUFBdUIsSUFBQStCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiTmF2YmFyIiwiRHVtbXlQcm9maWxlIiwiU3R1ZGVudFJlY29tbWVuZGF0aW9ucyIsIl9zIiwic3R1ZGVudHMiLCJzZXRTdHVkZW50cyIsImZldGNoIiwidGhlbiIsInJlcyIsImpzb24iLCJkYXRhIiwibWF4U2NvcmUiLCJsZW5ndGgiLCJNYXRoIiwibWF4IiwibWFwIiwicyIsInNjb3JlIiwiaXRlbSIsImkiLCJwZXJjZW50YWdlIiwidG9GaXhlZCIsImlzVG9wTWF0Y2giLCJzdHVkZW50IiwiZnVsbE5hbWUiLCJQSSIsImRldGFpbHMiLCJtYXRjaGVkU2tpbGxzIiwic2tpbGwiLCJpZHgiLCJhdmFpbGFiaWxpdHkiLCJpc0Vub3VnaCIsImV4cGxhbmF0aW9uIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJTdHVkZW50UmVjb21tZW5kYXRpb25zLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi8uLi9jb21wb25lbnRzL05hdmJhclwiO1xyXG5pbXBvcnQgRHVtbXlQcm9maWxlIGZyb20gJy4uLy4uL2Fzc2V0cy9pbWFnZXMvcGljMS5qcGVnJzsgLy8gZHVtbXkgcHJvZmlsZSBpbWFnZVxyXG5cclxuY29uc3QgU3R1ZGVudFJlY29tbWVuZGF0aW9ucyA9ICgpID0+IHtcclxuICBjb25zdCBbc3R1ZGVudHMsIHNldFN0dWRlbnRzXSA9IHVzZVN0YXRlKFtdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGZldGNoKFwiaHR0cDovL2xvY2FsaG9zdDozMDAwL2FwaS9yZWNvbW1lbmRhdGlvbnMvc3R1ZGVudHMvUDNcIilcclxuICAgICAgLnRoZW4ocmVzID0+IHJlcy5qc29uKCkpXHJcbiAgICAgIC50aGVuKGRhdGEgPT4gc2V0U3R1ZGVudHMoZGF0YSkpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgLy8gRmluZCB0aGUgaGlnaGVzdCBzY29yZSBmb3IgdGhlIFRvcCBNYXRjaCBiYWRnZVxyXG4gIGNvbnN0IG1heFNjb3JlID0gc3R1ZGVudHMubGVuZ3RoID4gMCA/IE1hdGgubWF4KC4uLnN0dWRlbnRzLm1hcChzID0+IHMuc2NvcmUpKSA6IDA7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbWluLWgtc2NyZWVuIGJnLWdyYXktMTAwXCI+XHJcblxyXG5cclxuICAgICAgey8qIE1haW4gY29udGVudCAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgcC02IGJnLXN1cmZhY2VcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNlwiPlxyXG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCBtYi02XCI+XHJcbiAgICAgICAgICAgIPCfkajigI3wn46TIFRvcCBNYXRjaGVkIFN0dWRlbnRzXHJcbiAgICAgICAgICA8L2gyPlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBtZDpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtMyBnYXAtNlwiPlxyXG4gICAgICAgICAgICB7c3R1ZGVudHMubWFwKChpdGVtLCBpKSA9PiB7XHJcbiAgICAgICAgICAgICAgY29uc3QgcGVyY2VudGFnZSA9IChpdGVtLnNjb3JlICogMTAwKS50b0ZpeGVkKDApO1xyXG4gICAgICAgICAgICAgIGNvbnN0IGlzVG9wTWF0Y2ggPSBpdGVtLnNjb3JlID09PSBtYXhTY29yZTtcclxuXHJcbiAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgIDxkaXYga2V5PXtpfSBjbGFzc05hbWU9XCJiZy13aGl0ZSBwLTUgcm91bmRlZC14bCBzaGFkb3ctbGcgcmVsYXRpdmUgaG92ZXI6c2hhZG93LXhsIHRyYW5zaXRpb24tc2hhZG93IGR1cmF0aW9uLTMwMFwiPlxyXG5cclxuICAgICAgICAgICAgICAgICAgey8qIFRvcCBNYXRjaCBCYWRnZSAqL31cclxuICAgICAgICAgICAgICAgICAge2lzVG9wTWF0Y2ggJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTIgbGVmdC0yIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1zZWNvbmRhcnkgdG8tYWNjZW50IHRleHQtd2hpdGUgdGV4dC14cyBmb250LWJvbGQgcHgtMiBweS0xIHJvdW5kZWQtZnVsbCBzaGFkb3ctbWQgei0xMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAg8J+MnyBUb3AgTWF0Y2hcclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgIHsvKiBQcm9maWxlIEltYWdlIC0gVG9wIFJpZ2h0ICovfVxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC0zIHJpZ2h0LTMgdy0yMCBoLTIwIHJvdW5kZWQtZnVsbCBwLVsycHhdIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1wcmltYXJ5IHRvLXNlY29uZGFyeVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgICAgICAgICAgIHNyYz17RHVtbXlQcm9maWxlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgYWx0PXtpdGVtLnN0dWRlbnQuZnVsbE5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC1mdWxsIHJvdW5kZWQtZnVsbCBvYmplY3QtY292ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgey8qIE5hbWUgKi99XHJcbiAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgbXQtMTBcIj57aXRlbS5zdHVkZW50LmZ1bGxOYW1lfTwvaDM+XHJcblxyXG4gICAgICAgICAgICAgICAgICB7LyogU2NvcmUgU2VjdGlvbiAqL31cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNCBtYi0zIG10LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHctMTIgaC0xMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTEyIGgtMTIgdHJhbnNmb3JtIC1yb3RhdGUtOTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGNpcmNsZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGN4PVwiMjRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGN5PVwiMjRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHI9XCIyMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3Ryb2tlLWdyYXktMjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzdHJva2VXaWR0aD1cIjVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGZpbGw9XCJub25lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGNpcmNsZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGN4PVwiMjRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGN5PVwiMjRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHI9XCIyMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlPVwidXJsKCNncmFkKVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9XCI1XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBmaWxsPVwibm9uZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlRGFzaGFycmF5PXsyICogTWF0aC5QSSAqIDIwfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZURhc2hvZmZzZXQ9ezIgKiBNYXRoLlBJICogMjAgKiAoMSAtIHBlcmNlbnRhZ2UgLyAxMDApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkZWZzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxsaW5lYXJHcmFkaWVudCBpZD1cImdyYWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzdG9wIG9mZnNldD1cIjAlXCIgc3RvcENvbG9yPVwiIzNCODJGNlwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3RvcCBvZmZzZXQ9XCI1MCVcIiBzdG9wQ29sb3I9XCIjRjQ3MkI2XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzdG9wIG9mZnNldD1cIjEwMCVcIiBzdG9wQ29sb3I9XCIjRkFDQzE1XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xpbmVhckdyYWRpZW50PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2RlZnM+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtwZXJjZW50YWdlfSVcclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7LyogU2NvcmUgVGV4dCAqL31cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc21cIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDBcIj5NYXRjaCBTY29yZTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtYm9sZCBiZy1ncmFkaWVudC10by1yIGZyb20tcHJpbWFyeSB0by1zZWNvbmRhcnkgYmctY2xpcC10ZXh0IHRleHQtdHJhbnNwYXJlbnRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3BlcmNlbnRhZ2V9JVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHsvKiBNYXRjaGVkIFNraWxscyAqL31cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBnYXAtMiBtdC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2l0ZW0uZGV0YWlscz8ubWF0Y2hlZFNraWxscz8ubWFwKChza2lsbCwgaWR4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2lkeH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC14cyBiZy1ibHVlLTEwMCB0ZXh0LWJsdWUtNjAwIHB4LTIgcHktMSByb3VuZGVkXCJcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3NraWxsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHsvKiBBdmFpbGFiaWxpdHkgKi99XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtpdGVtLmRldGFpbHM/LmF2YWlsYWJpbGl0eT8uaXNFbm91Z2hcclxuICAgICAgICAgICAgICAgICAgICAgID8gXCLinJQgQXZhaWxhYmxlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIDogXCLimqAgTm90IGVub3VnaCBhdmFpbGFiaWxpdHlcIn1cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG5cclxuICAgICAgICAgICAgICAgICAgey8qIEV4cGxhbmF0aW9uICovfVxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIG10LTIgdGV4dC1ncmF5LTYwMFwiPntpdGVtLmV4cGxhbmF0aW9ufTwvcD5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHsvKiBWaWV3IFByb2ZpbGUgQnV0dG9uICovfVxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cInctZnVsbCBweS0yIG10LTMgcm91bmRlZC1sZyBmb250LW1lZGl1bSB0ZXh0LXdoaXRlIGJnLXByaW1hcnkgaG92ZXI6ZnJvbS1zZWNvbmRhcnkgaG92ZXI6dG8tcHJpbWFyeSB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgc2hhZG93LXNtIGhvdmVyOnNoYWRvdy1tZCB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgVmlldyBQcm9maWxlXHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgU3R1ZGVudFJlY29tbWVuZGF0aW9uczsiXSwiZmlsZSI6IkY6L1kzUzIvSVRQTSBwcm9qZWN0L1Byb01hdGUtLVByb2plY3QtUGFydG5lci1GaW5kZXIvZnJvbnRlbmQvc3JjL3BhZ2VzL1JlY0VuZ2luZS9TdHVkZW50UmVjb21tZW5kYXRpb25zLmpzeCJ9