import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Projects/UpdateProject.jsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=383bea9f"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { useAuth } from "/src/context/AuthContext.jsx";
import { useParams, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=383bea9f";
import "/src/pages/Projects/InsertProject.css";
const CheckboxGroup = ({
  options,
  selectedValues = [],
  onChange
}) => {
  const handleCheckboxChange = (option) => {
    if (selectedValues.includes(option)) {
      onChange(selectedValues.filter((item) => item !== option));
    } else {
      onChange([...selectedValues, option]);
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "checkbox-group-ip", children: options.map((option) => /* @__PURE__ */ jsxDEV("label", { className: "checkbox-label-ip", children: [
    /* @__PURE__ */ jsxDEV("input", { type: "checkbox", checked: selectedValues.includes(option), onChange: () => handleCheckboxChange(option) }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
      lineNumber: 20,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV("span", { className: "update-checkbox-text", children: option }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
      lineNumber: 21,
      columnNumber: 11
    }, this)
  ] }, option, true, {
    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
    lineNumber: 19,
    columnNumber: 30
  }, this)) }, void 0, false, {
    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
    lineNumber: 18,
    columnNumber: 10
  }, this);
};
_c = CheckboxGroup;
const UpdateProject = () => {
  _s();
  const {
    id
  } = useParams();
  const navigate = useNavigate();
  const {
    token
  } = useAuth();
  const [isLoading, setIsLoading] = useState(true);
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    projectType: "",
    domain: [],
    essentialSkills: {
      languages: [],
      frameworks: [],
      databases: [],
      libraries: [],
      tools: []
    },
    optionalSkills: {
      languages: [],
      frameworks: [],
      databases: [],
      libraries: [],
      tools: []
    },
    requiredRoles: [],
    teamSize: "",
    minimumCGPA: "",
    availabilityRequirement: {
      durationWeeks: "",
      weeklyHours: "",
      meetingDays: []
    },
    dueDate: ""
  });
  useEffect(() => {
    const fetchProject = async () => {
      try {
        const res = await fetch(`http://localhost:3000/api/posts/${id}`);
        if (res.ok) {
          const fetchedProject = await res.json();
          setFormData({
            ...fetchedProject,
            title: fetchedProject.title || "",
            description: fetchedProject.description || "",
            projectType: fetchedProject.projectType || "",
            domain: fetchedProject.domain || [],
            essentialSkills: {
              languages: fetchedProject.essentialSkills?.languages || [],
              frameworks: fetchedProject.essentialSkills?.frameworks || [],
              databases: fetchedProject.essentialSkills?.databases || [],
              libraries: fetchedProject.essentialSkills?.libraries || [],
              tools: fetchedProject.essentialSkills?.tools || []
            },
            optionalSkills: {
              languages: fetchedProject.optionalSkills?.languages || [],
              frameworks: fetchedProject.optionalSkills?.frameworks || [],
              databases: fetchedProject.optionalSkills?.databases || [],
              libraries: fetchedProject.optionalSkills?.libraries || [],
              tools: fetchedProject.optionalSkills?.tools || []
            },
            requiredRoles: fetchedProject.requiredRoles || [],
            teamSize: fetchedProject.teamSize || "",
            minimumCGPA: fetchedProject.minimumCGPA || "",
            availabilityRequirement: {
              durationWeeks: fetchedProject.availabilityRequirement?.durationWeeks || "",
              weeklyHours: fetchedProject.availabilityRequirement?.weeklyHours || "",
              meetingDays: fetchedProject.availabilityRequirement?.meetingDays || []
            },
            dueDate: fetchedProject.dueDate ? new Date(fetchedProject.dueDate).toISOString().split("T")[0] : ""
          });
        }
      } catch (err) {
        console.error("Failed to fetch project for update", err);
      } finally {
        setIsLoading(false);
      }
    };
    fetchProject();
  }, [id]);
  const handleChange = (e) => {
    const {
      name,
      value
    } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));
  };
  const handleNestedChange = (parent, field, value) => {
    setFormData((prev) => ({
      ...prev,
      [parent]: {
        ...prev[parent],
        [field]: value
      }
    }));
  };
  const handleSkillChange = (type, category, values) => {
    setFormData((prev) => ({
      ...prev,
      [type]: {
        ...prev[type],
        [category]: values
      }
    }));
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (formData.domain.length === 0) {
      alert("Please select at least one domain.");
      return;
    }
    if (!formData.dueDate) {
      alert("Please select a due date.");
      return;
    }
    const selectedDate = new Date(formData.dueDate);
    const today = /* @__PURE__ */ new Date();
    today.setHours(0, 0, 0, 0);
    if (selectedDate <= today) {
      alert("Due date must be a future date.");
      return;
    }
    try {
      const response = await fetch(`http://localhost:3000/api/posts/${id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          "x-auth-token": token
        },
        body: JSON.stringify(formData)
      });
      if (response.ok) {
        alert("Project updated successfully!");
        navigate("/projects/" + id);
      } else {
        const errorData = await response.json();
        alert(`Failed to update project: ${errorData.msg || "Unknown error"}`);
      }
    } catch (error) {
      console.error("Error updating project:", error);
      alert("An error occurred while updating the project.");
    }
  };
  if (isLoading) {
    return /* @__PURE__ */ jsxDEV("div", { className: "loading-spinner", children: "Loading project data..." }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
      lineNumber: 177,
      columnNumber: 12
    }, this);
  }
  const todayStr = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
  return /* @__PURE__ */ jsxDEV("div", { className: "insert-project-container-ip", style: {
    paddingTop: "40px",
    maxWidth: "900px",
    margin: "0 auto"
  }, children: [
    /* @__PURE__ */ jsxDEV("button", { onClick: () => navigate(-1), style: {
      marginBottom: "20px",
      background: "none",
      border: "none",
      color: "#3B82F6",
      cursor: "pointer",
      fontWeight: "600",
      fontSize: "15px"
    }, children: "← Cancel" }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
      lineNumber: 186,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "insert-project-card-ip", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "insert-project-title-ip", children: "Update Project Details" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
        lineNumber: 199,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "insert-project-subtitle-ip", children: "Modify the fields and hit save to update the database." }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
        lineNumber: 200,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, className: "insert-project-form-ip", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "form-section-ip", children: [
          /* @__PURE__ */ jsxDEV("h2", { children: "Basic Information" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
            lineNumber: 205,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "form-group-ip", children: [
            /* @__PURE__ */ jsxDEV("label", { children: "Project Title *" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
              lineNumber: 208,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("input", { type: "text", name: "title", value: formData.title, onChange: handleChange, required: true, placeholder: "Enter project title" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
              lineNumber: 209,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
            lineNumber: 207,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "form-group-ip", children: [
            /* @__PURE__ */ jsxDEV("label", { children: "Description *" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
              lineNumber: 213,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("textarea", { name: "description", value: formData.description, onChange: handleChange, required: true, placeholder: "What is this project about? Provide some context and goals.", rows: "4" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
              lineNumber: 214,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
            lineNumber: 212,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "form-row-ip", children: /* @__PURE__ */ jsxDEV("div", { className: "form-group-ip", children: [
            /* @__PURE__ */ jsxDEV("label", { children: "Project Type *" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
              lineNumber: 219,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("select", { name: "projectType", value: formData.projectType, onChange: handleChange, required: true, children: [
              /* @__PURE__ */ jsxDEV("option", { value: "", disabled: true, children: "Select Type" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
                lineNumber: 221,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("option", { value: "Academic", children: "Academic" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
                lineNumber: 222,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("option", { value: "Hackathon", children: "Hackathon" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
                lineNumber: 223,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("option", { value: "Research", children: "Research" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
                lineNumber: 224,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("option", { value: "Startup/Side Hustle", children: "Startup/Side Hustle" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
                lineNumber: 225,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("option", { value: "Open Source", children: "Open Source" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
                lineNumber: 226,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
              lineNumber: 220,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
            lineNumber: 218,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
            lineNumber: 217,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "form-group-ip", children: [
            /* @__PURE__ */ jsxDEV("label", { children: "Domain *" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
              lineNumber: 232,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(CheckboxGroup, { options: ["AI/ML", "Web Development", "Mobile Apps", "Cybersecurity", "Data Science", "IoT", "Blockchain", "Game Dev"], selectedValues: formData.domain, onChange: (values) => setFormData((prev) => ({
              ...prev,
              domain: values
            })) }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
              lineNumber: 233,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
            lineNumber: 231,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "form-group-ip", children: [
            /* @__PURE__ */ jsxDEV("label", { children: "Due Date *" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
              lineNumber: 240,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("input", { type: "date", name: "dueDate", value: formData.dueDate, onChange: handleChange, min: todayStr, required: true }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
              lineNumber: 241,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
            lineNumber: 239,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
          lineNumber: 204,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "form-section-ip", children: [
          /* @__PURE__ */ jsxDEV("h2", { children: "Academic Requirements & Constraints (Auto-filled from Profile)" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
            lineNumber: 246,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "form-row-ip", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "form-group-ip", children: [
              /* @__PURE__ */ jsxDEV("label", { children: "Team Size Limit *" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
                lineNumber: 249,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("input", { type: "number", name: "teamSize", value: formData.teamSize, onChange: handleChange, required: true, min: "1", placeholder: "e.g. 4" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
                lineNumber: 250,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
              lineNumber: 248,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "form-group-ip", children: [
              /* @__PURE__ */ jsxDEV("label", { children: "Minimum CGPA (Optional)" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
                lineNumber: 253,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("input", { type: "number", name: "minimumCGPA", value: formData.minimumCGPA, onChange: handleChange, step: "0.01", min: "0", max: "4", placeholder: "e.g. 3.0" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
                lineNumber: 254,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
              lineNumber: 252,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
            lineNumber: 247,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
          lineNumber: 245,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "form-section-ip", children: [
          /* @__PURE__ */ jsxDEV("h2", { children: "Essential Skills (Must Have)" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
            lineNumber: 260,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "form-group-ip", children: [
            /* @__PURE__ */ jsxDEV("label", { children: "Languages" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
              lineNumber: 262,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(CheckboxGroup, { options: ["JavaScript", "TypeScript", "Python", "Java", "C", "C++", "C#", "Go", "Rust", "Kotlin", "Swift", "PHP", "Ruby", "Dart", "R", "MATLAB"], selectedValues: formData.essentialSkills.languages, onChange: (values) => handleSkillChange("essentialSkills", "languages", values) }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
              lineNumber: 263,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
            lineNumber: 261,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "form-group-ip", children: [
            /* @__PURE__ */ jsxDEV("label", { children: "Frameworks" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
              lineNumber: 266,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(CheckboxGroup, { options: ["React", "Angular", "Vue.js", "Next.js", "Nuxt.js", "Node.js", "Express.js", "Django", "Flask", "Spring Boot", "ASP.NET", "Laravel", "Ruby on Rails", "Flutter", "React Native"], selectedValues: formData.essentialSkills.frameworks, onChange: (values) => handleSkillChange("essentialSkills", "frameworks", values) }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
              lineNumber: 267,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
            lineNumber: 265,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "form-group-ip", children: [
            /* @__PURE__ */ jsxDEV("label", { children: "Databases" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
              lineNumber: 270,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(CheckboxGroup, { options: ["MongoDB", "MySQL", "PostgreSQL", "SQLite", "Oracle", "Microsoft SQL Server", "Firebase", "Redis", "Cassandra", "DynamoDB", "Neo4j"], selectedValues: formData.essentialSkills.databases, onChange: (values) => handleSkillChange("essentialSkills", "databases", values) }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
              lineNumber: 271,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
            lineNumber: 269,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "form-group-ip", children: [
            /* @__PURE__ */ jsxDEV("label", { children: "Libraries" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
              lineNumber: 275,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(CheckboxGroup, { options: ["Redux", "Axios", "jQuery", "Lodash", "TensorFlow", "Keras", "PyTorch", "Scikit-learn", "Pandas", "NumPy", "Chart.js", "D3.js", "Three.js", "Socket.io", "Bootstrap"], selectedValues: formData.essentialSkills.libraries, onChange: (values) => handleSkillChange("essentialSkills", "libraries", values) }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
              lineNumber: 276,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
            lineNumber: 274,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "form-group-ip", children: [
            /* @__PURE__ */ jsxDEV("label", { children: "Tools" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
              lineNumber: 280,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(CheckboxGroup, { options: ["Git", "GitHub", "GitLab", "Docker", "Kubernetes", "Postman", "Jira", "Trello", "Figma", "Adobe XD", "VS Code", "IntelliJ IDEA", "Eclipse", "Webpack", "Babel"], selectedValues: formData.essentialSkills.tools, onChange: (values) => handleSkillChange("essentialSkills", "tools", values) }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
              lineNumber: 281,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
            lineNumber: 279,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
          lineNumber: 259,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "form-section-ip", children: [
          /* @__PURE__ */ jsxDEV("h2", { children: "Optional Skills (Nice to Have)" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
            lineNumber: 287,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "form-group-ip", children: [
            /* @__PURE__ */ jsxDEV("label", { children: "Languages" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
              lineNumber: 289,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(CheckboxGroup, { options: ["JavaScript", "TypeScript", "Python", "Java", "C", "C++", "C#", "Go", "Rust", "Kotlin", "Swift", "PHP", "Ruby", "Dart", "R", "MATLAB"], selectedValues: formData.optionalSkills.languages, onChange: (values) => handleSkillChange("optionalSkills", "languages", values) }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
              lineNumber: 290,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
            lineNumber: 288,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "form-group-ip", children: [
            /* @__PURE__ */ jsxDEV("label", { children: "Frameworks" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
              lineNumber: 293,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(CheckboxGroup, { options: ["React", "Angular", "Vue.js", "Next.js", "Nuxt.js", "Node.js", "Express.js", "Django", "Flask", "Spring Boot", "ASP.NET", "Laravel", "Ruby on Rails", "Flutter", "React Native"], selectedValues: formData.optionalSkills.frameworks, onChange: (values) => handleSkillChange("optionalSkills", "frameworks", values) }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
              lineNumber: 294,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
            lineNumber: 292,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "form-group-ip", children: [
            /* @__PURE__ */ jsxDEV("label", { children: "Databases" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
              lineNumber: 297,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(CheckboxGroup, { options: ["MongoDB", "MySQL", "PostgreSQL", "SQLite", "Oracle", "Microsoft SQL Server", "Firebase", "Redis", "Cassandra", "DynamoDB", "Neo4j"], selectedValues: formData.optionalSkills.databases, onChange: (values) => handleSkillChange("optionalSkills", "databases", values) }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
              lineNumber: 298,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
            lineNumber: 296,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "form-group-ip", children: [
            /* @__PURE__ */ jsxDEV("label", { children: "Libraries" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
              lineNumber: 302,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(CheckboxGroup, { options: ["Redux", "Axios", "jQuery", "Lodash", "TensorFlow", "Keras", "PyTorch", "Scikit-learn", "Pandas", "NumPy", "Chart.js", "D3.js", "Three.js", "Socket.io", "Bootstrap"], selectedValues: formData.optionalSkills.libraries, onChange: (values) => handleSkillChange("optionalSkills", "libraries", values) }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
              lineNumber: 303,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
            lineNumber: 301,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "form-group-ip", children: [
            /* @__PURE__ */ jsxDEV("label", { children: "Tools" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
              lineNumber: 307,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(CheckboxGroup, { options: ["Git", "GitHub", "GitLab", "Docker", "Kubernetes", "Postman", "Jira", "Trello", "Figma", "Adobe XD", "VS Code", "IntelliJ IDEA", "Eclipse", "Webpack", "Babel"], selectedValues: formData.optionalSkills.tools, onChange: (values) => handleSkillChange("optionalSkills", "tools", values) }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
              lineNumber: 308,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
            lineNumber: 306,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
          lineNumber: 286,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "form-section-ip", children: [
          /* @__PURE__ */ jsxDEV("h2", { children: "Roles & Availability" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
            lineNumber: 314,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "form-group-ip", children: [
            /* @__PURE__ */ jsxDEV("label", { children: "Required Roles *" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
              lineNumber: 316,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(CheckboxGroup, { options: ["Frontend Developer", "Backend Developer", "Full Stack Developer", "UI/UX Designer", "QA Engineer", "Data Scientist", "DevOps Engineer", "Product Manager"], selectedValues: formData.requiredRoles, onChange: (values) => setFormData((prev) => ({
              ...prev,
              requiredRoles: values
            })) }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
              lineNumber: 317,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
            lineNumber: 315,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "form-row-ip", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "form-group-ip", children: [
              /* @__PURE__ */ jsxDEV("label", { children: "Weekly Hours Required *" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
                lineNumber: 325,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("input", { type: "number", value: formData.availabilityRequirement.weeklyHours, onChange: (e) => handleNestedChange("availabilityRequirement", "weeklyHours", e.target.value), required: true, min: "1", placeholder: "e.g. 10" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
                lineNumber: 326,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
              lineNumber: 324,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "form-group-ip", children: [
              /* @__PURE__ */ jsxDEV("label", { children: "Duration (Weeks) *" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
                lineNumber: 329,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("input", { type: "number", value: formData.availabilityRequirement.durationWeeks, onChange: (e) => handleNestedChange("availabilityRequirement", "durationWeeks", e.target.value), required: true, min: "1", placeholder: "e.g. 12" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
                lineNumber: 330,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
              lineNumber: 328,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
            lineNumber: 323,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "form-group-ip", children: [
            /* @__PURE__ */ jsxDEV("label", { children: "Preferred Meeting Days" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
              lineNumber: 335,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(CheckboxGroup, { options: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"], selectedValues: formData.availabilityRequirement.meetingDays, onChange: (values) => handleNestedChange("availabilityRequirement", "meetingDays", values) }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
              lineNumber: 336,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
            lineNumber: 334,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
          lineNumber: 313,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "form-actions-ip", children: /* @__PURE__ */ jsxDEV("button", { type: "submit", className: "submit-btn-ip", children: "Save Changes" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
          lineNumber: 341,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
          lineNumber: 340,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
        lineNumber: 202,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
      lineNumber: 198,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx",
    lineNumber: 180,
    columnNumber: 10
  }, this);
};
_s(UpdateProject, "aMpRy0GX1Oe9jEbrL+AiTvKYtKk=", false, function() {
  return [useParams, useNavigate, useAuth];
});
_c2 = UpdateProject;
export default UpdateProject;
var _c, _c2;
$RefreshReg$(_c, "CheckboxGroup");
$RefreshReg$(_c2, "UpdateProject");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/UpdateProject.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0JVOzs7Ozs7Ozs7Ozs7Ozs7O0FBbEJWLE9BQU9BLFNBQVNDLFVBQVVDLGlCQUFpQjtBQUMzQyxTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLFdBQVdDLG1CQUFtQjtBQUN2QyxPQUFPO0FBRVAsTUFBTUMsZ0JBQWdCQSxDQUFDO0FBQUEsRUFBRUM7QUFBQUEsRUFBU0MsaUJBQWlCO0FBQUEsRUFBSUM7QUFBUyxNQUFNO0FBQ3BFLFFBQU1DLHVCQUF3QkMsWUFBVztBQUN2QyxRQUFJSCxlQUFlSSxTQUFTRCxNQUFNLEdBQUc7QUFDbkNGLGVBQVNELGVBQWVLLE9BQU9DLFVBQVFBLFNBQVNILE1BQU0sQ0FBQztBQUFBLElBQ3pELE9BQU87QUFDTEYsZUFBUyxDQUFDLEdBQUdELGdCQUFnQkcsTUFBTSxDQUFDO0FBQUEsSUFDdEM7QUFBQSxFQUNGO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUscUJBQ1pKLGtCQUFRUSxJQUFJSixZQUNYLHVCQUFDLFdBQW1CLFdBQVUscUJBQzVCO0FBQUEsMkJBQUMsV0FDQyxNQUFLLFlBQ0wsU0FBU0gsZUFBZUksU0FBU0QsTUFBTSxHQUN2QyxVQUFVLE1BQU1ELHFCQUFxQkMsTUFBTSxLQUg3QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRytDO0FBQUEsSUFFL0MsdUJBQUMsVUFBSyxXQUFVLHdCQUF3QkEsb0JBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBK0M7QUFBQSxPQU5yQ0EsUUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBT0EsQ0FDRCxLQVZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FXQTtBQUVKO0FBQUVLLEtBdkJJVjtBQXlCTixNQUFNVyxnQkFBZ0JBLE1BQU07QUFBQUMsS0FBQTtBQUMxQixRQUFNO0FBQUEsSUFBRUM7QUFBQUEsRUFBRyxJQUFJZixVQUFVO0FBQ3pCLFFBQU1nQixXQUFXZixZQUFZO0FBQzdCLFFBQU07QUFBQSxJQUFFZ0I7QUFBQUEsRUFBTSxJQUFJbEIsUUFBUTtBQUMxQixRQUFNLENBQUNtQixXQUFXQyxZQUFZLElBQUl0QixTQUFTLElBQUk7QUFDL0MsUUFBTSxDQUFDdUIsVUFBVUMsV0FBVyxJQUFJeEIsU0FBUztBQUFBLElBQ3ZDeUIsT0FBTztBQUFBLElBQ1BDLGFBQWE7QUFBQSxJQUNiQyxhQUFhO0FBQUEsSUFDYkMsUUFBUTtBQUFBLElBQ1JDLGlCQUFpQjtBQUFBLE1BQUVDLFdBQVc7QUFBQSxNQUFJQyxZQUFZO0FBQUEsTUFBSUMsV0FBVztBQUFBLE1BQUlDLFdBQVc7QUFBQSxNQUFJQyxPQUFPO0FBQUEsSUFBRztBQUFBLElBQzFGQyxnQkFBZ0I7QUFBQSxNQUFFTCxXQUFXO0FBQUEsTUFBSUMsWUFBWTtBQUFBLE1BQUlDLFdBQVc7QUFBQSxNQUFJQyxXQUFXO0FBQUEsTUFBSUMsT0FBTztBQUFBLElBQUc7QUFBQSxJQUN6RkUsZUFBZTtBQUFBLElBQ2ZDLFVBQVU7QUFBQSxJQUNWQyxhQUFhO0FBQUEsSUFDYkMseUJBQXlCO0FBQUEsTUFBRUMsZUFBZTtBQUFBLE1BQUlDLGFBQWE7QUFBQSxNQUFJQyxhQUFhO0FBQUEsSUFBRztBQUFBLElBQy9FQyxTQUFTO0FBQUEsRUFDWCxDQUFDO0FBRUQxQyxZQUFVLE1BQU07QUFDZCxVQUFNMkMsZUFBZSxZQUFZO0FBQy9CLFVBQUk7QUFDRixjQUFNQyxNQUFNLE1BQU1DLE1BQU0sbUNBQW1DNUIsRUFBRSxFQUFFO0FBQy9ELFlBQUkyQixJQUFJRSxJQUFJO0FBQ1YsZ0JBQU1DLGlCQUFpQixNQUFNSCxJQUFJSSxLQUFLO0FBQ3RDekIsc0JBQVk7QUFBQSxZQUNWLEdBQUd3QjtBQUFBQSxZQUNIdkIsT0FBT3VCLGVBQWV2QixTQUFTO0FBQUEsWUFDL0JDLGFBQWFzQixlQUFldEIsZUFBZTtBQUFBLFlBQzNDQyxhQUFhcUIsZUFBZXJCLGVBQWU7QUFBQSxZQUMzQ0MsUUFBUW9CLGVBQWVwQixVQUFVO0FBQUEsWUFDakNDLGlCQUFpQjtBQUFBLGNBQ2ZDLFdBQVdrQixlQUFlbkIsaUJBQWlCQyxhQUFhO0FBQUEsY0FDeERDLFlBQVlpQixlQUFlbkIsaUJBQWlCRSxjQUFjO0FBQUEsY0FDMURDLFdBQVdnQixlQUFlbkIsaUJBQWlCRyxhQUFhO0FBQUEsY0FDeERDLFdBQVdlLGVBQWVuQixpQkFBaUJJLGFBQWE7QUFBQSxjQUN4REMsT0FBT2MsZUFBZW5CLGlCQUFpQkssU0FBUztBQUFBLFlBQ2xEO0FBQUEsWUFDQUMsZ0JBQWdCO0FBQUEsY0FDZEwsV0FBV2tCLGVBQWViLGdCQUFnQkwsYUFBYTtBQUFBLGNBQ3ZEQyxZQUFZaUIsZUFBZWIsZ0JBQWdCSixjQUFjO0FBQUEsY0FDekRDLFdBQVdnQixlQUFlYixnQkFBZ0JILGFBQWE7QUFBQSxjQUN2REMsV0FBV2UsZUFBZWIsZ0JBQWdCRixhQUFhO0FBQUEsY0FDdkRDLE9BQU9jLGVBQWViLGdCQUFnQkQsU0FBUztBQUFBLFlBQ2pEO0FBQUEsWUFDQUUsZUFBZVksZUFBZVosaUJBQWlCO0FBQUEsWUFDL0NDLFVBQVVXLGVBQWVYLFlBQVk7QUFBQSxZQUNyQ0MsYUFBYVUsZUFBZVYsZUFBZTtBQUFBLFlBQzNDQyx5QkFBeUI7QUFBQSxjQUN2QkMsZUFBZVEsZUFBZVQseUJBQXlCQyxpQkFBaUI7QUFBQSxjQUN4RUMsYUFBYU8sZUFBZVQseUJBQXlCRSxlQUFlO0FBQUEsY0FDcEVDLGFBQWFNLGVBQWVULHlCQUF5QkcsZUFBZTtBQUFBLFlBQ3RFO0FBQUEsWUFDQUMsU0FBU0ssZUFBZUwsVUFBVSxJQUFJTyxLQUFLRixlQUFlTCxPQUFPLEVBQUVRLFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQyxJQUFJO0FBQUEsVUFDbkcsQ0FBQztBQUFBLFFBQ0g7QUFBQSxNQUNGLFNBQVNDLEtBQUs7QUFDWkMsZ0JBQVFDLE1BQU0sc0NBQXNDRixHQUFHO0FBQUEsTUFDekQsVUFBQztBQUNDL0IscUJBQWEsS0FBSztBQUFBLE1BQ3BCO0FBQUEsSUFDRjtBQUNBc0IsaUJBQWE7QUFBQSxFQUNmLEdBQUcsQ0FBQzFCLEVBQUUsQ0FBQztBQUVQLFFBQU1zQyxlQUFnQkMsT0FBTTtBQUMxQixVQUFNO0FBQUEsTUFBRUM7QUFBQUEsTUFBTUM7QUFBQUEsSUFBTSxJQUFJRixFQUFFRztBQUMxQnBDLGdCQUFZcUMsV0FBUztBQUFBLE1BQUUsR0FBR0E7QUFBQUEsTUFBTSxDQUFDSCxJQUFJLEdBQUdDO0FBQUFBLElBQU0sRUFBRTtBQUFBLEVBQ2xEO0FBRUEsUUFBTUcscUJBQXFCQSxDQUFDQyxRQUFRQyxPQUFPTCxVQUFVO0FBQ25EbkMsZ0JBQVlxQyxXQUFTO0FBQUEsTUFDbkIsR0FBR0E7QUFBQUEsTUFDSCxDQUFDRSxNQUFNLEdBQUc7QUFBQSxRQUFFLEdBQUdGLEtBQUtFLE1BQU07QUFBQSxRQUFHLENBQUNDLEtBQUssR0FBR0w7QUFBQUEsTUFBTTtBQUFBLElBQzlDLEVBQUU7QUFBQSxFQUNKO0FBRUEsUUFBTU0sb0JBQW9CQSxDQUFDQyxNQUFNQyxVQUFVQyxXQUFXO0FBQ3BENUMsZ0JBQVlxQyxXQUFTO0FBQUEsTUFDbkIsR0FBR0E7QUFBQUEsTUFDSCxDQUFDSyxJQUFJLEdBQUc7QUFBQSxRQUFFLEdBQUdMLEtBQUtLLElBQUk7QUFBQSxRQUFHLENBQUNDLFFBQVEsR0FBR0M7QUFBQUEsTUFBTztBQUFBLElBQzlDLEVBQUU7QUFBQSxFQUNKO0FBRUEsUUFBTUMsZUFBZSxPQUFPWixNQUFNO0FBQ2hDQSxNQUFFYSxlQUFlO0FBQ2pCLFFBQUkvQyxTQUFTSyxPQUFPMkMsV0FBVyxHQUFHO0FBQ2hDQyxZQUFNLG9DQUFvQztBQUMxQztBQUFBLElBQ0Y7QUFDQSxRQUFJLENBQUNqRCxTQUFTb0IsU0FBUztBQUNyQjZCLFlBQU0sMkJBQTJCO0FBQ2pDO0FBQUEsSUFDRjtBQUNBLFVBQU1DLGVBQWUsSUFBSXZCLEtBQUszQixTQUFTb0IsT0FBTztBQUM5QyxVQUFNK0IsUUFBUSxvQkFBSXhCLEtBQUs7QUFDdkJ3QixVQUFNQyxTQUFTLEdBQUcsR0FBRyxHQUFHLENBQUM7QUFDekIsUUFBSUYsZ0JBQWdCQyxPQUFPO0FBQ3pCRixZQUFNLGlDQUFpQztBQUN2QztBQUFBLElBQ0Y7QUFFQSxRQUFJO0FBQ0YsWUFBTUksV0FBVyxNQUFNOUIsTUFBTSxtQ0FBbUM1QixFQUFFLElBQUk7QUFBQSxRQUNwRTJELFFBQVE7QUFBQSxRQUNSQyxTQUFTO0FBQUEsVUFDUCxnQkFBZ0I7QUFBQSxVQUNoQixnQkFBZ0IxRDtBQUFBQSxRQUNsQjtBQUFBLFFBQ0EyRCxNQUFNQyxLQUFLQyxVQUFVMUQsUUFBUTtBQUFBLE1BQy9CLENBQUM7QUFFRCxVQUFJcUQsU0FBUzdCLElBQUk7QUFDZnlCLGNBQU0sK0JBQStCO0FBQ3JDckQsaUJBQVMsZUFBZUQsRUFBRTtBQUFBLE1BQzVCLE9BQU87QUFDTCxjQUFNZ0UsWUFBWSxNQUFNTixTQUFTM0IsS0FBSztBQUN0Q3VCLGNBQU0sNkJBQTZCVSxVQUFVQyxPQUFPLGVBQWUsRUFBRTtBQUFBLE1BQ3ZFO0FBQUEsSUFDRixTQUFTNUIsT0FBTztBQUNkRCxjQUFRQyxNQUFNLDJCQUEyQkEsS0FBSztBQUM5Q2lCLFlBQU0sK0NBQStDO0FBQUEsSUFDdkQ7QUFBQSxFQUNGO0FBRUEsTUFBSW5ELFdBQVc7QUFDYixXQUFPLHVCQUFDLFNBQUksV0FBVSxtQkFBa0IsdUNBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBd0Q7QUFBQSxFQUNqRTtBQUVBLFFBQU0rRCxZQUFXLG9CQUFJbEMsS0FBSyxHQUFFQyxZQUFZLEVBQUVDLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFFdEQsU0FDRSx1QkFBQyxTQUFJLFdBQVUsK0JBQThCLE9BQU87QUFBQSxJQUFFaUMsWUFBWTtBQUFBLElBQVFDLFVBQVU7QUFBQSxJQUFTQyxRQUFRO0FBQUEsRUFBUyxHQUU1RztBQUFBLDJCQUFDLFlBQ0MsU0FBUyxNQUFNcEUsU0FBUyxFQUFFLEdBQzFCLE9BQU87QUFBQSxNQUFFcUUsY0FBYztBQUFBLE1BQVFDLFlBQVk7QUFBQSxNQUFRQyxRQUFRO0FBQUEsTUFBUUMsT0FBTztBQUFBLE1BQVdDLFFBQVE7QUFBQSxNQUFXQyxZQUFZO0FBQUEsTUFBT0MsVUFBVTtBQUFBLElBQU8sR0FDN0ksd0JBSEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQSw2QkFBQyxRQUFHLFdBQVUsMkJBQTBCLHNDQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThEO0FBQUEsTUFDOUQsdUJBQUMsT0FBRSxXQUFVLDhCQUE2QixzRUFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnRztBQUFBLE1BRWhHLHVCQUFDLFVBQUssVUFBVXpCLGNBQWMsV0FBVSwwQkFFdEM7QUFBQSwrQkFBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQSxpQ0FBQyxRQUFHLGlDQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFCO0FBQUEsVUFFckIsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsbUNBQUMsV0FBTSwrQkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzQjtBQUFBLFlBQ3RCLHVCQUFDLFdBQU0sTUFBSyxRQUFPLE1BQUssU0FBUSxPQUFPOUMsU0FBU0UsT0FBTyxVQUFVK0IsY0FBYyxVQUFRLE1BQUMsYUFBWSx5QkFBcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUg7QUFBQSxlQUYzSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSxtQ0FBQyxXQUFNLDZCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9CO0FBQUEsWUFDcEIsdUJBQUMsY0FBUyxNQUFLLGVBQWMsT0FBT2pDLFNBQVNHLGFBQWEsVUFBVThCLGNBQWMsVUFBUSxNQUFDLGFBQVksK0RBQThELE1BQUssT0FBMUs7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEs7QUFBQSxlQUZoTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsZUFDYixpQ0FBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSxtQ0FBQyxXQUFNLDhCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFCO0FBQUEsWUFDckIsdUJBQUMsWUFBTyxNQUFLLGVBQWMsT0FBT2pDLFNBQVNJLGFBQWEsVUFBVTZCLGNBQWMsVUFBUSxNQUN0RjtBQUFBLHFDQUFDLFlBQU8sT0FBTSxJQUFHLFVBQVEsTUFBQywyQkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUM7QUFBQSxjQUNyQyx1QkFBQyxZQUFPLE9BQU0sWUFBVyx3QkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUM7QUFBQSxjQUNqQyx1QkFBQyxZQUFPLE9BQU0sYUFBWSx5QkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbUM7QUFBQSxjQUNuQyx1QkFBQyxZQUFPLE9BQU0sWUFBVyx3QkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUM7QUFBQSxjQUNqQyx1QkFBQyxZQUFPLE9BQU0sdUJBQXNCLG1DQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF1RDtBQUFBLGNBQ3ZELHVCQUFDLFlBQU8sT0FBTSxlQUFjLDJCQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF1QztBQUFBLGlCQU56QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU9BO0FBQUEsZUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVVBLEtBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFZQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsbUNBQUMsV0FBTSx3QkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFlO0FBQUEsWUFDZix1QkFBQyxpQkFDQyxTQUFTLENBQUMsU0FBUyxtQkFBbUIsZUFBZSxpQkFBaUIsZ0JBQWdCLE9BQU8sY0FBYyxVQUFVLEdBQ3JILGdCQUFnQmpDLFNBQVNLLFFBQ3pCLFVBQVd3QyxZQUFXNUMsWUFBWXFDLFdBQVM7QUFBQSxjQUFFLEdBQUdBO0FBQUFBLGNBQU1qQyxRQUFRd0M7QUFBQUEsWUFBTyxFQUFFLEtBSHpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRzJFO0FBQUEsZUFMN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsbUNBQUMsV0FBTSwwQkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpQjtBQUFBLFlBQ2pCLHVCQUFDLFdBQU0sTUFBSyxRQUFPLE1BQUssV0FBVSxPQUFPN0MsU0FBU29CLFNBQVMsVUFBVWEsY0FBYyxLQUFLNEIsVUFBVSxVQUFRLFFBQTFHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBHO0FBQUEsZUFGNUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLGFBdkNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF3Q0E7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSxtQkFDYjtBQUFBLGlDQUFDLFFBQUcsOEVBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0U7QUFBQSxVQUNsRSx1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLHFDQUFDLFdBQU0saUNBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBd0I7QUFBQSxjQUN4Qix1QkFBQyxXQUFNLE1BQUssVUFBUyxNQUFLLFlBQVcsT0FBTzdELFNBQVNjLFVBQVUsVUFBVW1CLGNBQWMsVUFBUSxNQUFDLEtBQUksS0FBSSxhQUFZLFlBQXBIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTRIO0FBQUEsaUJBRjlIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLHFDQUFDLFdBQU0sdUNBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBOEI7QUFBQSxjQUM5Qix1QkFBQyxXQUFNLE1BQUssVUFBUyxNQUFLLGVBQWMsT0FBT2pDLFNBQVNlLGFBQWEsVUFBVWtCLGNBQWMsTUFBSyxRQUFPLEtBQUksS0FBSSxLQUFJLEtBQUksYUFBWSxjQUFySTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErSTtBQUFBLGlCQUZqSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsZUFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVNBO0FBQUEsYUFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBWUE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSxtQkFDYjtBQUFBLGlDQUFDLFFBQUcsNENBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0M7QUFBQSxVQUNoQyx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSxtQ0FBQyxXQUFNLHlCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdCO0FBQUEsWUFDaEIsdUJBQUMsaUJBQ0MsU0FBUyxDQUFDLGNBQWMsY0FBYyxVQUFVLFFBQVEsS0FBSyxPQUFPLE1BQU0sTUFBTSxRQUFRLFVBQVUsU0FBUyxPQUFPLFFBQVEsUUFBUSxLQUFLLFFBQVEsR0FDL0ksZ0JBQWdCakMsU0FBU00sZ0JBQWdCQyxXQUN6QyxVQUFXc0MsWUFBV0gsa0JBQWtCLG1CQUFtQixhQUFhRyxNQUFNLEtBSGhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR2tGO0FBQUEsZUFMcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsbUNBQUMsV0FBTSwwQkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpQjtBQUFBLFlBQ2pCLHVCQUFDLGlCQUNDLFNBQVMsQ0FBQyxTQUFTLFdBQVcsVUFBVSxXQUFXLFdBQVcsV0FBVyxjQUFjLFVBQVUsU0FBUyxlQUFlLFdBQVcsV0FBVyxpQkFBaUIsV0FBVyxjQUFjLEdBQ3pMLGdCQUFnQjdDLFNBQVNNLGdCQUFnQkUsWUFDekMsVUFBV3FDLFlBQVdILGtCQUFrQixtQkFBbUIsY0FBY0csTUFBTSxLQUhqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdtRjtBQUFBLGVBTHJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLG1DQUFDLFdBQU0seUJBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0I7QUFBQSxZQUNoQix1QkFBQyxpQkFDQyxTQUFTLENBQUMsV0FBVyxTQUFTLGNBQWMsVUFBVSxVQUFVLHdCQUF3QixZQUFZLFNBQVMsYUFBYSxZQUFZLE9BQU8sR0FDN0ksZ0JBQWdCN0MsU0FBU00sZ0JBQWdCRyxXQUN6QyxVQUFXb0MsWUFBV0gsa0JBQWtCLG1CQUFtQixhQUFhRyxNQUFNLEtBSGhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR2tGO0FBQUEsZUFMcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsbUNBQUMsV0FBTSx5QkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnQjtBQUFBLFlBQ2hCLHVCQUFDLGlCQUNDLFNBQVMsQ0FBQyxTQUFTLFNBQVMsVUFBVSxVQUFVLGNBQWMsU0FBUyxXQUFXLGdCQUFnQixVQUFVLFNBQVMsWUFBWSxTQUFTLFlBQVksYUFBYSxXQUFXLEdBQzlLLGdCQUFnQjdDLFNBQVNNLGdCQUFnQkksV0FDekMsVUFBV21DLFlBQVdILGtCQUFrQixtQkFBbUIsYUFBYUcsTUFBTSxLQUhoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdrRjtBQUFBLGVBTHBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0E7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLG1DQUFDLFdBQU0scUJBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBWTtBQUFBLFlBQ1osdUJBQUMsaUJBQ0MsU0FBUyxDQUFDLE9BQU8sVUFBVSxVQUFVLFVBQVUsY0FBYyxXQUFXLFFBQVEsVUFBVSxTQUFTLFlBQVksV0FBVyxpQkFBaUIsV0FBVyxXQUFXLE9BQU8sR0FDeEssZ0JBQWdCN0MsU0FBU00sZ0JBQWdCSyxPQUN6QyxVQUFXa0MsWUFBV0gsa0JBQWtCLG1CQUFtQixTQUFTRyxNQUFNLEtBSDVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRzhFO0FBQUEsZUFMaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLGFBM0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE0Q0E7QUFBQSxRQUdBLHVCQUFDLFNBQUksV0FBVSxtQkFDYjtBQUFBLGlDQUFDLFFBQUcsOENBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0M7QUFBQSxVQUNsQyx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSxtQ0FBQyxXQUFNLHlCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdCO0FBQUEsWUFDaEIsdUJBQUMsaUJBQ0MsU0FBUyxDQUFDLGNBQWMsY0FBYyxVQUFVLFFBQVEsS0FBSyxPQUFPLE1BQU0sTUFBTSxRQUFRLFVBQVUsU0FBUyxPQUFPLFFBQVEsUUFBUSxLQUFLLFFBQVEsR0FDL0ksZ0JBQWdCN0MsU0FBU1ksZUFBZUwsV0FDeEMsVUFBV3NDLFlBQVdILGtCQUFrQixrQkFBa0IsYUFBYUcsTUFBTSxLQUgvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdpRjtBQUFBLGVBTG5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0E7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLG1DQUFDLFdBQU0sMEJBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUI7QUFBQSxZQUNqQix1QkFBQyxpQkFDQyxTQUFTLENBQUMsU0FBUyxXQUFXLFVBQVUsV0FBVyxXQUFXLFdBQVcsY0FBYyxVQUFVLFNBQVMsZUFBZSxXQUFXLFdBQVcsaUJBQWlCLFdBQVcsY0FBYyxHQUN6TCxnQkFBZ0I3QyxTQUFTWSxlQUFlSixZQUN4QyxVQUFXcUMsWUFBV0gsa0JBQWtCLGtCQUFrQixjQUFjRyxNQUFNLEtBSGhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR2tGO0FBQUEsZUFMcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsbUNBQUMsV0FBTSx5QkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnQjtBQUFBLFlBQ2hCLHVCQUFDLGlCQUNDLFNBQVMsQ0FBQyxXQUFXLFNBQVMsY0FBYyxVQUFVLFVBQVUsd0JBQXdCLFlBQVksU0FBUyxhQUFhLFlBQVksT0FBTyxHQUM3SSxnQkFBZ0I3QyxTQUFTWSxlQUFlSCxXQUN4QyxVQUFXb0MsWUFBV0gsa0JBQWtCLGtCQUFrQixhQUFhRyxNQUFNLEtBSC9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR2lGO0FBQUEsZUFMbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsbUNBQUMsV0FBTSx5QkFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnQjtBQUFBLFlBQ2hCLHVCQUFDLGlCQUNDLFNBQVMsQ0FBQyxTQUFTLFNBQVMsVUFBVSxVQUFVLGNBQWMsU0FBUyxXQUFXLGdCQUFnQixVQUFVLFNBQVMsWUFBWSxTQUFTLFlBQVksYUFBYSxXQUFXLEdBQzlLLGdCQUFnQjdDLFNBQVNZLGVBQWVGLFdBQ3hDLFVBQVdtQyxZQUFXSCxrQkFBa0Isa0JBQWtCLGFBQWFHLE1BQU0sS0FIL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHaUY7QUFBQSxlQUxuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSxtQ0FBQyxXQUFNLHFCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQVk7QUFBQSxZQUNaLHVCQUFDLGlCQUNDLFNBQVMsQ0FBQyxPQUFPLFVBQVUsVUFBVSxVQUFVLGNBQWMsV0FBVyxRQUFRLFVBQVUsU0FBUyxZQUFZLFdBQVcsaUJBQWlCLFdBQVcsV0FBVyxPQUFPLEdBQ3hLLGdCQUFnQjdDLFNBQVNZLGVBQWVELE9BQ3hDLFVBQVdrQyxZQUFXSCxrQkFBa0Isa0JBQWtCLFNBQVNHLE1BQU0sS0FIM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHNkU7QUFBQSxlQUwvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsYUEzQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTRDQTtBQUFBLFFBR0EsdUJBQUMsU0FBSSxXQUFVLG1CQUNiO0FBQUEsaUNBQUMsUUFBRyxvQ0FBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3QjtBQUFBLFVBQ3hCLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLG1DQUFDLFdBQU0sZ0NBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUI7QUFBQSxZQUN2Qix1QkFBQyxpQkFDQyxTQUFTLENBQUMsc0JBQXNCLHFCQUFxQix3QkFBd0Isa0JBQWtCLGVBQWUsa0JBQWtCLG1CQUFtQixpQkFBaUIsR0FDcEssZ0JBQWdCN0MsU0FBU2EsZUFDekIsVUFBV2dDLFlBQVc1QyxZQUFZcUMsV0FBUztBQUFBLGNBQUUsR0FBR0E7QUFBQUEsY0FBTXpCLGVBQWVnQztBQUFBQSxZQUFPLEVBQUUsS0FIaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHa0Y7QUFBQSxlQUxwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLHFDQUFDLFdBQU0sdUNBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBOEI7QUFBQSxjQUM5Qix1QkFBQyxXQUFNLE1BQUssVUFBUyxPQUFPN0MsU0FBU2dCLHdCQUF3QkUsYUFBYSxVQUFXZ0IsT0FBTUssbUJBQW1CLDJCQUEyQixlQUFlTCxFQUFFRyxPQUFPRCxLQUFLLEdBQUcsVUFBUSxNQUFDLEtBQUksS0FBSSxhQUFZLGFBQXRNO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQStNO0FBQUEsaUJBRmpOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLHFDQUFDLFdBQU0sa0NBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBeUI7QUFBQSxjQUN6Qix1QkFBQyxXQUFNLE1BQUssVUFBUyxPQUFPcEMsU0FBU2dCLHdCQUF3QkMsZUFBZSxVQUFXaUIsT0FBTUssbUJBQW1CLDJCQUEyQixpQkFBaUJMLEVBQUVHLE9BQU9ELEtBQUssR0FBRyxVQUFRLE1BQUMsS0FBSSxLQUFJLGFBQVksYUFBMU07QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbU47QUFBQSxpQkFGck47QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLGVBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFTQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsbUNBQUMsV0FBTSxzQ0FBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2QjtBQUFBLFlBQzdCLHVCQUFDLGlCQUNDLFNBQVMsQ0FBQyxVQUFVLFdBQVcsYUFBYSxZQUFZLFVBQVUsWUFBWSxRQUFRLEdBQ3RGLGdCQUFnQnBDLFNBQVNnQix3QkFBd0JHLGFBQ2pELFVBQVcwQixZQUFXTixtQkFBbUIsMkJBQTJCLGVBQWVNLE1BQU0sS0FIM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHNkY7QUFBQSxlQUwvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsYUE3QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQThCQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLG1CQUNiLGlDQUFDLFlBQU8sTUFBSyxVQUFTLFdBQVUsaUJBQWdCLDRCQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRELEtBRDlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBMUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEyTEE7QUFBQSxTQS9MRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZ01BO0FBQUEsT0F6TUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTBNQTtBQUVKO0FBQUVuRCxHQWhWSUQsZUFBYTtBQUFBLFVBQ0ZiLFdBQ0VDLGFBQ0NGLE9BQU87QUFBQTtBQUFBNkYsTUFIckIvRTtBQWtWTixlQUFlQTtBQUFjLElBQUFELElBQUFnRjtBQUFBQyxhQUFBakYsSUFBQTtBQUFBaUYsYUFBQUQsS0FBQSIsIm5hbWVzIjpbIlJlYWN0IiwidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJ1c2VBdXRoIiwidXNlUGFyYW1zIiwidXNlTmF2aWdhdGUiLCJDaGVja2JveEdyb3VwIiwib3B0aW9ucyIsInNlbGVjdGVkVmFsdWVzIiwib25DaGFuZ2UiLCJoYW5kbGVDaGVja2JveENoYW5nZSIsIm9wdGlvbiIsImluY2x1ZGVzIiwiZmlsdGVyIiwiaXRlbSIsIm1hcCIsIl9jIiwiVXBkYXRlUHJvamVjdCIsIl9zIiwiaWQiLCJuYXZpZ2F0ZSIsInRva2VuIiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwiZm9ybURhdGEiLCJzZXRGb3JtRGF0YSIsInRpdGxlIiwiZGVzY3JpcHRpb24iLCJwcm9qZWN0VHlwZSIsImRvbWFpbiIsImVzc2VudGlhbFNraWxscyIsImxhbmd1YWdlcyIsImZyYW1ld29ya3MiLCJkYXRhYmFzZXMiLCJsaWJyYXJpZXMiLCJ0b29scyIsIm9wdGlvbmFsU2tpbGxzIiwicmVxdWlyZWRSb2xlcyIsInRlYW1TaXplIiwibWluaW11bUNHUEEiLCJhdmFpbGFiaWxpdHlSZXF1aXJlbWVudCIsImR1cmF0aW9uV2Vla3MiLCJ3ZWVrbHlIb3VycyIsIm1lZXRpbmdEYXlzIiwiZHVlRGF0ZSIsImZldGNoUHJvamVjdCIsInJlcyIsImZldGNoIiwib2siLCJmZXRjaGVkUHJvamVjdCIsImpzb24iLCJEYXRlIiwidG9JU09TdHJpbmciLCJzcGxpdCIsImVyciIsImNvbnNvbGUiLCJlcnJvciIsImhhbmRsZUNoYW5nZSIsImUiLCJuYW1lIiwidmFsdWUiLCJ0YXJnZXQiLCJwcmV2IiwiaGFuZGxlTmVzdGVkQ2hhbmdlIiwicGFyZW50IiwiZmllbGQiLCJoYW5kbGVTa2lsbENoYW5nZSIsInR5cGUiLCJjYXRlZ29yeSIsInZhbHVlcyIsImhhbmRsZVN1Ym1pdCIsInByZXZlbnREZWZhdWx0IiwibGVuZ3RoIiwiYWxlcnQiLCJzZWxlY3RlZERhdGUiLCJ0b2RheSIsInNldEhvdXJzIiwicmVzcG9uc2UiLCJtZXRob2QiLCJoZWFkZXJzIiwiYm9keSIsIkpTT04iLCJzdHJpbmdpZnkiLCJlcnJvckRhdGEiLCJtc2ciLCJ0b2RheVN0ciIsInBhZGRpbmdUb3AiLCJtYXhXaWR0aCIsIm1hcmdpbiIsIm1hcmdpbkJvdHRvbSIsImJhY2tncm91bmQiLCJib3JkZXIiLCJjb2xvciIsImN1cnNvciIsImZvbnRXZWlnaHQiLCJmb250U2l6ZSIsIl9jMiIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlVwZGF0ZVByb2plY3QuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSAnLi4vLi4vY29udGV4dC9BdXRoQ29udGV4dCc7XHJcbmltcG9ydCB7IHVzZVBhcmFtcywgdXNlTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcclxuaW1wb3J0ICcuL0luc2VydFByb2plY3QuY3NzJztcclxuXHJcbmNvbnN0IENoZWNrYm94R3JvdXAgPSAoeyBvcHRpb25zLCBzZWxlY3RlZFZhbHVlcyA9IFtdLCBvbkNoYW5nZSB9KSA9PiB7XHJcbiAgY29uc3QgaGFuZGxlQ2hlY2tib3hDaGFuZ2UgPSAob3B0aW9uKSA9PiB7XHJcbiAgICBpZiAoc2VsZWN0ZWRWYWx1ZXMuaW5jbHVkZXMob3B0aW9uKSkge1xyXG4gICAgICBvbkNoYW5nZShzZWxlY3RlZFZhbHVlcy5maWx0ZXIoaXRlbSA9PiBpdGVtICE9PSBvcHRpb24pKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIG9uQ2hhbmdlKFsuLi5zZWxlY3RlZFZhbHVlcywgb3B0aW9uXSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiY2hlY2tib3gtZ3JvdXAtaXBcIj5cclxuICAgICAge29wdGlvbnMubWFwKG9wdGlvbiA9PiAoXHJcbiAgICAgICAgPGxhYmVsIGtleT17b3B0aW9ufSBjbGFzc05hbWU9XCJjaGVja2JveC1sYWJlbC1pcFwiPlxyXG4gICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgIGNoZWNrZWQ9e3NlbGVjdGVkVmFsdWVzLmluY2x1ZGVzKG9wdGlvbil9XHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoKSA9PiBoYW5kbGVDaGVja2JveENoYW5nZShvcHRpb24pfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInVwZGF0ZS1jaGVja2JveC10ZXh0XCI+e29wdGlvbn08L3NwYW4+XHJcbiAgICAgICAgPC9sYWJlbD5cclxuICAgICAgKSl9XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuY29uc3QgVXBkYXRlUHJvamVjdCA9ICgpID0+IHtcclxuICBjb25zdCB7IGlkIH0gPSB1c2VQYXJhbXMoKTtcclxuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XHJcbiAgY29uc3QgeyB0b2tlbiB9ID0gdXNlQXV0aCgpO1xyXG4gIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKTtcclxuICBjb25zdCBbZm9ybURhdGEsIHNldEZvcm1EYXRhXSA9IHVzZVN0YXRlKHtcclxuICAgIHRpdGxlOiAnJyxcclxuICAgIGRlc2NyaXB0aW9uOiAnJyxcclxuICAgIHByb2plY3RUeXBlOiAnJyxcclxuICAgIGRvbWFpbjogW10sXHJcbiAgICBlc3NlbnRpYWxTa2lsbHM6IHsgbGFuZ3VhZ2VzOiBbXSwgZnJhbWV3b3JrczogW10sIGRhdGFiYXNlczogW10sIGxpYnJhcmllczogW10sIHRvb2xzOiBbXSB9LFxyXG4gICAgb3B0aW9uYWxTa2lsbHM6IHsgbGFuZ3VhZ2VzOiBbXSwgZnJhbWV3b3JrczogW10sIGRhdGFiYXNlczogW10sIGxpYnJhcmllczogW10sIHRvb2xzOiBbXSB9LFxyXG4gICAgcmVxdWlyZWRSb2xlczogW10sXHJcbiAgICB0ZWFtU2l6ZTogJycsXHJcbiAgICBtaW5pbXVtQ0dQQTogJycsXHJcbiAgICBhdmFpbGFiaWxpdHlSZXF1aXJlbWVudDogeyBkdXJhdGlvbldlZWtzOiAnJywgd2Vla2x5SG91cnM6ICcnLCBtZWV0aW5nRGF5czogW10gfSxcclxuICAgIGR1ZURhdGU6ICcnXHJcbiAgfSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaFByb2plY3QgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goYGh0dHA6Ly9sb2NhbGhvc3Q6MzAwMC9hcGkvcG9zdHMvJHtpZH1gKTtcclxuICAgICAgICBpZiAocmVzLm9rKSB7XHJcbiAgICAgICAgICBjb25zdCBmZXRjaGVkUHJvamVjdCA9IGF3YWl0IHJlcy5qc29uKCk7XHJcbiAgICAgICAgICBzZXRGb3JtRGF0YSh7XHJcbiAgICAgICAgICAgIC4uLmZldGNoZWRQcm9qZWN0LFxyXG4gICAgICAgICAgICB0aXRsZTogZmV0Y2hlZFByb2plY3QudGl0bGUgfHwgJycsXHJcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBmZXRjaGVkUHJvamVjdC5kZXNjcmlwdGlvbiB8fCAnJyxcclxuICAgICAgICAgICAgcHJvamVjdFR5cGU6IGZldGNoZWRQcm9qZWN0LnByb2plY3RUeXBlIHx8ICcnLFxyXG4gICAgICAgICAgICBkb21haW46IGZldGNoZWRQcm9qZWN0LmRvbWFpbiB8fCBbXSxcclxuICAgICAgICAgICAgZXNzZW50aWFsU2tpbGxzOiB7XHJcbiAgICAgICAgICAgICAgbGFuZ3VhZ2VzOiBmZXRjaGVkUHJvamVjdC5lc3NlbnRpYWxTa2lsbHM/Lmxhbmd1YWdlcyB8fCBbXSxcclxuICAgICAgICAgICAgICBmcmFtZXdvcmtzOiBmZXRjaGVkUHJvamVjdC5lc3NlbnRpYWxTa2lsbHM/LmZyYW1ld29ya3MgfHwgW10sXHJcbiAgICAgICAgICAgICAgZGF0YWJhc2VzOiBmZXRjaGVkUHJvamVjdC5lc3NlbnRpYWxTa2lsbHM/LmRhdGFiYXNlcyB8fCBbXSxcclxuICAgICAgICAgICAgICBsaWJyYXJpZXM6IGZldGNoZWRQcm9qZWN0LmVzc2VudGlhbFNraWxscz8ubGlicmFyaWVzIHx8IFtdLFxyXG4gICAgICAgICAgICAgIHRvb2xzOiBmZXRjaGVkUHJvamVjdC5lc3NlbnRpYWxTa2lsbHM/LnRvb2xzIHx8IFtdXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIG9wdGlvbmFsU2tpbGxzOiB7XHJcbiAgICAgICAgICAgICAgbGFuZ3VhZ2VzOiBmZXRjaGVkUHJvamVjdC5vcHRpb25hbFNraWxscz8ubGFuZ3VhZ2VzIHx8IFtdLFxyXG4gICAgICAgICAgICAgIGZyYW1ld29ya3M6IGZldGNoZWRQcm9qZWN0Lm9wdGlvbmFsU2tpbGxzPy5mcmFtZXdvcmtzIHx8IFtdLFxyXG4gICAgICAgICAgICAgIGRhdGFiYXNlczogZmV0Y2hlZFByb2plY3Qub3B0aW9uYWxTa2lsbHM/LmRhdGFiYXNlcyB8fCBbXSxcclxuICAgICAgICAgICAgICBsaWJyYXJpZXM6IGZldGNoZWRQcm9qZWN0Lm9wdGlvbmFsU2tpbGxzPy5saWJyYXJpZXMgfHwgW10sXHJcbiAgICAgICAgICAgICAgdG9vbHM6IGZldGNoZWRQcm9qZWN0Lm9wdGlvbmFsU2tpbGxzPy50b29scyB8fCBbXVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICByZXF1aXJlZFJvbGVzOiBmZXRjaGVkUHJvamVjdC5yZXF1aXJlZFJvbGVzIHx8IFtdLFxyXG4gICAgICAgICAgICB0ZWFtU2l6ZTogZmV0Y2hlZFByb2plY3QudGVhbVNpemUgfHwgJycsXHJcbiAgICAgICAgICAgIG1pbmltdW1DR1BBOiBmZXRjaGVkUHJvamVjdC5taW5pbXVtQ0dQQSB8fCAnJyxcclxuICAgICAgICAgICAgYXZhaWxhYmlsaXR5UmVxdWlyZW1lbnQ6IHtcclxuICAgICAgICAgICAgICBkdXJhdGlvbldlZWtzOiBmZXRjaGVkUHJvamVjdC5hdmFpbGFiaWxpdHlSZXF1aXJlbWVudD8uZHVyYXRpb25XZWVrcyB8fCAnJyxcclxuICAgICAgICAgICAgICB3ZWVrbHlIb3VyczogZmV0Y2hlZFByb2plY3QuYXZhaWxhYmlsaXR5UmVxdWlyZW1lbnQ/LndlZWtseUhvdXJzIHx8ICcnLFxyXG4gICAgICAgICAgICAgIG1lZXRpbmdEYXlzOiBmZXRjaGVkUHJvamVjdC5hdmFpbGFiaWxpdHlSZXF1aXJlbWVudD8ubWVldGluZ0RheXMgfHwgW11cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgZHVlRGF0ZTogZmV0Y2hlZFByb2plY3QuZHVlRGF0ZSA/IG5ldyBEYXRlKGZldGNoZWRQcm9qZWN0LmR1ZURhdGUpLnRvSVNPU3RyaW5nKCkuc3BsaXQoJ1QnKVswXSA6ICcnXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggcHJvamVjdCBmb3IgdXBkYXRlXCIsIGVycik7XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGZldGNoUHJvamVjdCgpO1xyXG4gIH0sIFtpZF0pO1xyXG5cclxuICBjb25zdCBoYW5kbGVDaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyBuYW1lLCB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbiAgICBzZXRGb3JtRGF0YShwcmV2ID0+ICh7IC4uLnByZXYsIFtuYW1lXTogdmFsdWUgfSkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZU5lc3RlZENoYW5nZSA9IChwYXJlbnQsIGZpZWxkLCB2YWx1ZSkgPT4ge1xyXG4gICAgc2V0Rm9ybURhdGEocHJldiA9PiAoe1xyXG4gICAgICAuLi5wcmV2LFxyXG4gICAgICBbcGFyZW50XTogeyAuLi5wcmV2W3BhcmVudF0sIFtmaWVsZF06IHZhbHVlIH1cclxuICAgIH0pKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVTa2lsbENoYW5nZSA9ICh0eXBlLCBjYXRlZ29yeSwgdmFsdWVzKSA9PiB7XHJcbiAgICBzZXRGb3JtRGF0YShwcmV2ID0+ICh7XHJcbiAgICAgIC4uLnByZXYsXHJcbiAgICAgIFt0eXBlXTogeyAuLi5wcmV2W3R5cGVdLCBbY2F0ZWdvcnldOiB2YWx1ZXMgfVxyXG4gICAgfSkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICBpZiAoZm9ybURhdGEuZG9tYWluLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgICBhbGVydCgnUGxlYXNlIHNlbGVjdCBhdCBsZWFzdCBvbmUgZG9tYWluLicpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcbiAgICBpZiAoIWZvcm1EYXRhLmR1ZURhdGUpIHtcclxuICAgICAgYWxlcnQoJ1BsZWFzZSBzZWxlY3QgYSBkdWUgZGF0ZS4nKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgY29uc3Qgc2VsZWN0ZWREYXRlID0gbmV3IERhdGUoZm9ybURhdGEuZHVlRGF0ZSk7XHJcbiAgICBjb25zdCB0b2RheSA9IG5ldyBEYXRlKCk7XHJcbiAgICB0b2RheS5zZXRIb3VycygwLCAwLCAwLCAwKTtcclxuICAgIGlmIChzZWxlY3RlZERhdGUgPD0gdG9kYXkpIHtcclxuICAgICAgYWxlcnQoJ0R1ZSBkYXRlIG11c3QgYmUgYSBmdXR1cmUgZGF0ZS4nKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYGh0dHA6Ly9sb2NhbGhvc3Q6MzAwMC9hcGkvcG9zdHMvJHtpZH1gLCB7XHJcbiAgICAgICAgbWV0aG9kOiAnUFVUJyxcclxuICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxyXG4gICAgICAgICAgJ3gtYXV0aC10b2tlbic6IHRva2VuXHJcbiAgICAgICAgfSxcclxuICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeShmb3JtRGF0YSlcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBpZiAocmVzcG9uc2Uub2spIHtcclxuICAgICAgICBhbGVydCgnUHJvamVjdCB1cGRhdGVkIHN1Y2Nlc3NmdWxseSEnKTtcclxuICAgICAgICBuYXZpZ2F0ZSgnL3Byb2plY3RzLycgKyBpZCk7IC8vIE5hdmlnYXRlIGJhY2sgdG8gZGV0YWlsc1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGNvbnN0IGVycm9yRGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcclxuICAgICAgICBhbGVydChgRmFpbGVkIHRvIHVwZGF0ZSBwcm9qZWN0OiAke2Vycm9yRGF0YS5tc2cgfHwgJ1Vua25vd24gZXJyb3InfWApO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgdXBkYXRpbmcgcHJvamVjdDpcIiwgZXJyb3IpO1xyXG4gICAgICBhbGVydCgnQW4gZXJyb3Igb2NjdXJyZWQgd2hpbGUgdXBkYXRpbmcgdGhlIHByb2plY3QuJyk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgaWYgKGlzTG9hZGluZykge1xyXG4gICAgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwibG9hZGluZy1zcGlubmVyXCI+TG9hZGluZyBwcm9qZWN0IGRhdGEuLi48L2Rpdj47XHJcbiAgfVxyXG5cclxuICBjb25zdCB0b2RheVN0ciA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zcGxpdCgnVCcpWzBdO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJpbnNlcnQtcHJvamVjdC1jb250YWluZXItaXBcIiBzdHlsZT17eyBwYWRkaW5nVG9wOiAnNDBweCcsIG1heFdpZHRoOiAnOTAwcHgnLCBtYXJnaW46ICcwIGF1dG8nIH19PlxyXG4gICAgICB7LyogQmFjayBCdXR0b24gKi99XHJcbiAgICAgIDxidXR0b25cclxuICAgICAgICBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZSgtMSl9XHJcbiAgICAgICAgc3R5bGU9e3sgbWFyZ2luQm90dG9tOiAnMjBweCcsIGJhY2tncm91bmQ6ICdub25lJywgYm9yZGVyOiAnbm9uZScsIGNvbG9yOiAnIzNCODJGNicsIGN1cnNvcjogJ3BvaW50ZXInLCBmb250V2VpZ2h0OiAnNjAwJywgZm9udFNpemU6ICcxNXB4JyB9fVxyXG4gICAgICA+XHJcbiAgICAgICAg4oaQIENhbmNlbFxyXG4gICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5zZXJ0LXByb2plY3QtY2FyZC1pcFwiPlxyXG4gICAgICAgIDxoMSBjbGFzc05hbWU9XCJpbnNlcnQtcHJvamVjdC10aXRsZS1pcFwiPlVwZGF0ZSBQcm9qZWN0IERldGFpbHM8L2gxPlxyXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cImluc2VydC1wcm9qZWN0LXN1YnRpdGxlLWlwXCI+TW9kaWZ5IHRoZSBmaWVsZHMgYW5kIGhpdCBzYXZlIHRvIHVwZGF0ZSB0aGUgZGF0YWJhc2UuPC9wPlxyXG5cclxuICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU3VibWl0fSBjbGFzc05hbWU9XCJpbnNlcnQtcHJvamVjdC1mb3JtLWlwXCI+XHJcbiAgICAgICAgICB7LyogU2VjdGlvbjogQmFzaWMgSW5mbyAqL31cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1zZWN0aW9uLWlwXCI+XHJcbiAgICAgICAgICAgIDxoMj5CYXNpYyBJbmZvcm1hdGlvbjwvaDI+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXAtaXBcIj5cclxuICAgICAgICAgICAgICA8bGFiZWw+UHJvamVjdCBUaXRsZSAqPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiBuYW1lPVwidGl0bGVcIiB2YWx1ZT17Zm9ybURhdGEudGl0bGV9IG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9IHJlcXVpcmVkIHBsYWNlaG9sZGVyPVwiRW50ZXIgcHJvamVjdCB0aXRsZVwiIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwLWlwXCI+XHJcbiAgICAgICAgICAgICAgPGxhYmVsPkRlc2NyaXB0aW9uICo8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDx0ZXh0YXJlYSBuYW1lPVwiZGVzY3JpcHRpb25cIiB2YWx1ZT17Zm9ybURhdGEuZGVzY3JpcHRpb259IG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9IHJlcXVpcmVkIHBsYWNlaG9sZGVyPVwiV2hhdCBpcyB0aGlzIHByb2plY3QgYWJvdXQ/IFByb3ZpZGUgc29tZSBjb250ZXh0IGFuZCBnb2Fscy5cIiByb3dzPVwiNFwiPjwvdGV4dGFyZWE+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLXJvdy1pcFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncm91cC1pcFwiPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsPlByb2plY3QgVHlwZSAqPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxzZWxlY3QgbmFtZT1cInByb2plY3RUeXBlXCIgdmFsdWU9e2Zvcm1EYXRhLnByb2plY3RUeXBlfSBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfSByZXF1aXJlZD5cclxuICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiIGRpc2FibGVkPlNlbGVjdCBUeXBlPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJBY2FkZW1pY1wiPkFjYWRlbWljPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJIYWNrYXRob25cIj5IYWNrYXRob248L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlJlc2VhcmNoXCI+UmVzZWFyY2g8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlN0YXJ0dXAvU2lkZSBIdXN0bGVcIj5TdGFydHVwL1NpZGUgSHVzdGxlPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJPcGVuIFNvdXJjZVwiPk9wZW4gU291cmNlPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXAtaXBcIj5cclxuICAgICAgICAgICAgICA8bGFiZWw+RG9tYWluICo8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxDaGVja2JveEdyb3VwXHJcbiAgICAgICAgICAgICAgICBvcHRpb25zPXtbJ0FJL01MJywgJ1dlYiBEZXZlbG9wbWVudCcsICdNb2JpbGUgQXBwcycsICdDeWJlcnNlY3VyaXR5JywgJ0RhdGEgU2NpZW5jZScsICdJb1QnLCAnQmxvY2tjaGFpbicsICdHYW1lIERldiddfVxyXG4gICAgICAgICAgICAgICAgc2VsZWN0ZWRWYWx1ZXM9e2Zvcm1EYXRhLmRvbWFpbn1cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWVzKSA9PiBzZXRGb3JtRGF0YShwcmV2ID0+ICh7IC4uLnByZXYsIGRvbWFpbjogdmFsdWVzIH0pKX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncm91cC1pcFwiPlxyXG4gICAgICAgICAgICAgIDxsYWJlbD5EdWUgRGF0ZSAqPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cImRhdGVcIiBuYW1lPVwiZHVlRGF0ZVwiIHZhbHVlPXtmb3JtRGF0YS5kdWVEYXRlfSBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfSBtaW49e3RvZGF5U3RyfSByZXF1aXJlZCAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1zZWN0aW9uLWlwXCI+XHJcbiAgICAgICAgICAgIDxoMj5BY2FkZW1pYyBSZXF1aXJlbWVudHMgJiBDb25zdHJhaW50cyAoQXV0by1maWxsZWQgZnJvbSBQcm9maWxlKTwvaDI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1yb3ctaXBcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXAtaXBcIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbD5UZWFtIFNpemUgTGltaXQgKjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cIm51bWJlclwiIG5hbWU9XCJ0ZWFtU2l6ZVwiIHZhbHVlPXtmb3JtRGF0YS50ZWFtU2l6ZX0gb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX0gcmVxdWlyZWQgbWluPVwiMVwiIHBsYWNlaG9sZGVyPVwiZS5nLiA0XCIgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXAtaXBcIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbD5NaW5pbXVtIENHUEEgKE9wdGlvbmFsKTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cIm51bWJlclwiIG5hbWU9XCJtaW5pbXVtQ0dQQVwiIHZhbHVlPXtmb3JtRGF0YS5taW5pbXVtQ0dQQX0gb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX0gc3RlcD1cIjAuMDFcIiBtaW49XCIwXCIgbWF4PVwiNFwiIHBsYWNlaG9sZGVyPVwiZS5nLiAzLjBcIiAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1zZWN0aW9uLWlwXCI+XHJcbiAgICAgICAgICAgIDxoMj5Fc3NlbnRpYWwgU2tpbGxzIChNdXN0IEhhdmUpPC9oMj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwLWlwXCI+XHJcbiAgICAgICAgICAgICAgPGxhYmVsPkxhbmd1YWdlczwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPENoZWNrYm94R3JvdXBcclxuICAgICAgICAgICAgICAgIG9wdGlvbnM9e1tcIkphdmFTY3JpcHRcIiwgXCJUeXBlU2NyaXB0XCIsIFwiUHl0aG9uXCIsIFwiSmF2YVwiLCBcIkNcIiwgXCJDKytcIiwgXCJDI1wiLCBcIkdvXCIsIFwiUnVzdFwiLCBcIktvdGxpblwiLCBcIlN3aWZ0XCIsIFwiUEhQXCIsIFwiUnVieVwiLCBcIkRhcnRcIiwgXCJSXCIsIFwiTUFUTEFCXCJdfVxyXG4gICAgICAgICAgICAgICAgc2VsZWN0ZWRWYWx1ZXM9e2Zvcm1EYXRhLmVzc2VudGlhbFNraWxscy5sYW5ndWFnZXN9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlcykgPT4gaGFuZGxlU2tpbGxDaGFuZ2UoJ2Vzc2VudGlhbFNraWxscycsICdsYW5ndWFnZXMnLCB2YWx1ZXMpfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXAtaXBcIj5cclxuICAgICAgICAgICAgICA8bGFiZWw+RnJhbWV3b3JrczwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPENoZWNrYm94R3JvdXBcclxuICAgICAgICAgICAgICAgIG9wdGlvbnM9e1tcIlJlYWN0XCIsIFwiQW5ndWxhclwiLCBcIlZ1ZS5qc1wiLCBcIk5leHQuanNcIiwgXCJOdXh0LmpzXCIsIFwiTm9kZS5qc1wiLCBcIkV4cHJlc3MuanNcIiwgXCJEamFuZ29cIiwgXCJGbGFza1wiLCBcIlNwcmluZyBCb290XCIsIFwiQVNQLk5FVFwiLCBcIkxhcmF2ZWxcIiwgXCJSdWJ5IG9uIFJhaWxzXCIsIFwiRmx1dHRlclwiLCBcIlJlYWN0IE5hdGl2ZVwiXX1cclxuICAgICAgICAgICAgICAgIHNlbGVjdGVkVmFsdWVzPXtmb3JtRGF0YS5lc3NlbnRpYWxTa2lsbHMuZnJhbWV3b3Jrc31cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWVzKSA9PiBoYW5kbGVTa2lsbENoYW5nZSgnZXNzZW50aWFsU2tpbGxzJywgJ2ZyYW1ld29ya3MnLCB2YWx1ZXMpfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXAtaXBcIj5cclxuICAgICAgICAgICAgICA8bGFiZWw+RGF0YWJhc2VzPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8Q2hlY2tib3hHcm91cFxyXG4gICAgICAgICAgICAgICAgb3B0aW9ucz17W1wiTW9uZ29EQlwiLCBcIk15U1FMXCIsIFwiUG9zdGdyZVNRTFwiLCBcIlNRTGl0ZVwiLCBcIk9yYWNsZVwiLCBcIk1pY3Jvc29mdCBTUUwgU2VydmVyXCIsIFwiRmlyZWJhc2VcIiwgXCJSZWRpc1wiLCBcIkNhc3NhbmRyYVwiLCBcIkR5bmFtb0RCXCIsIFwiTmVvNGpcIl19XHJcbiAgICAgICAgICAgICAgICBzZWxlY3RlZFZhbHVlcz17Zm9ybURhdGEuZXNzZW50aWFsU2tpbGxzLmRhdGFiYXNlc31cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWVzKSA9PiBoYW5kbGVTa2lsbENoYW5nZSgnZXNzZW50aWFsU2tpbGxzJywgJ2RhdGFiYXNlcycsIHZhbHVlcyl9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXAtaXBcIj5cclxuICAgICAgICAgICAgICA8bGFiZWw+TGlicmFyaWVzPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8Q2hlY2tib3hHcm91cFxyXG4gICAgICAgICAgICAgICAgb3B0aW9ucz17W1wiUmVkdXhcIiwgXCJBeGlvc1wiLCBcImpRdWVyeVwiLCBcIkxvZGFzaFwiLCBcIlRlbnNvckZsb3dcIiwgXCJLZXJhc1wiLCBcIlB5VG9yY2hcIiwgXCJTY2lraXQtbGVhcm5cIiwgXCJQYW5kYXNcIiwgXCJOdW1QeVwiLCBcIkNoYXJ0LmpzXCIsIFwiRDMuanNcIiwgXCJUaHJlZS5qc1wiLCBcIlNvY2tldC5pb1wiLCBcIkJvb3RzdHJhcFwiXX1cclxuICAgICAgICAgICAgICAgIHNlbGVjdGVkVmFsdWVzPXtmb3JtRGF0YS5lc3NlbnRpYWxTa2lsbHMubGlicmFyaWVzfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZXMpID0+IGhhbmRsZVNraWxsQ2hhbmdlKCdlc3NlbnRpYWxTa2lsbHMnLCAnbGlicmFyaWVzJywgdmFsdWVzKX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncm91cC1pcFwiPlxyXG4gICAgICAgICAgICAgIDxsYWJlbD5Ub29sczwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPENoZWNrYm94R3JvdXBcclxuICAgICAgICAgICAgICAgIG9wdGlvbnM9e1tcIkdpdFwiLCBcIkdpdEh1YlwiLCBcIkdpdExhYlwiLCBcIkRvY2tlclwiLCBcIkt1YmVybmV0ZXNcIiwgXCJQb3N0bWFuXCIsIFwiSmlyYVwiLCBcIlRyZWxsb1wiLCBcIkZpZ21hXCIsIFwiQWRvYmUgWERcIiwgXCJWUyBDb2RlXCIsIFwiSW50ZWxsaUogSURFQVwiLCBcIkVjbGlwc2VcIiwgXCJXZWJwYWNrXCIsIFwiQmFiZWxcIl19XHJcbiAgICAgICAgICAgICAgICBzZWxlY3RlZFZhbHVlcz17Zm9ybURhdGEuZXNzZW50aWFsU2tpbGxzLnRvb2xzfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZXMpID0+IGhhbmRsZVNraWxsQ2hhbmdlKCdlc3NlbnRpYWxTa2lsbHMnLCAndG9vbHMnLCB2YWx1ZXMpfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1zZWN0aW9uLWlwXCI+XHJcbiAgICAgICAgICAgIDxoMj5PcHRpb25hbCBTa2lsbHMgKE5pY2UgdG8gSGF2ZSk8L2gyPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXAtaXBcIj5cclxuICAgICAgICAgICAgICA8bGFiZWw+TGFuZ3VhZ2VzPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8Q2hlY2tib3hHcm91cFxyXG4gICAgICAgICAgICAgICAgb3B0aW9ucz17W1wiSmF2YVNjcmlwdFwiLCBcIlR5cGVTY3JpcHRcIiwgXCJQeXRob25cIiwgXCJKYXZhXCIsIFwiQ1wiLCBcIkMrK1wiLCBcIkMjXCIsIFwiR29cIiwgXCJSdXN0XCIsIFwiS290bGluXCIsIFwiU3dpZnRcIiwgXCJQSFBcIiwgXCJSdWJ5XCIsIFwiRGFydFwiLCBcIlJcIiwgXCJNQVRMQUJcIl19XHJcbiAgICAgICAgICAgICAgICBzZWxlY3RlZFZhbHVlcz17Zm9ybURhdGEub3B0aW9uYWxTa2lsbHMubGFuZ3VhZ2VzfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZXMpID0+IGhhbmRsZVNraWxsQ2hhbmdlKCdvcHRpb25hbFNraWxscycsICdsYW5ndWFnZXMnLCB2YWx1ZXMpfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXAtaXBcIj5cclxuICAgICAgICAgICAgICA8bGFiZWw+RnJhbWV3b3JrczwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPENoZWNrYm94R3JvdXBcclxuICAgICAgICAgICAgICAgIG9wdGlvbnM9e1tcIlJlYWN0XCIsIFwiQW5ndWxhclwiLCBcIlZ1ZS5qc1wiLCBcIk5leHQuanNcIiwgXCJOdXh0LmpzXCIsIFwiTm9kZS5qc1wiLCBcIkV4cHJlc3MuanNcIiwgXCJEamFuZ29cIiwgXCJGbGFza1wiLCBcIlNwcmluZyBCb290XCIsIFwiQVNQLk5FVFwiLCBcIkxhcmF2ZWxcIiwgXCJSdWJ5IG9uIFJhaWxzXCIsIFwiRmx1dHRlclwiLCBcIlJlYWN0IE5hdGl2ZVwiXX1cclxuICAgICAgICAgICAgICAgIHNlbGVjdGVkVmFsdWVzPXtmb3JtRGF0YS5vcHRpb25hbFNraWxscy5mcmFtZXdvcmtzfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZXMpID0+IGhhbmRsZVNraWxsQ2hhbmdlKCdvcHRpb25hbFNraWxscycsICdmcmFtZXdvcmtzJywgdmFsdWVzKX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwLWlwXCI+XHJcbiAgICAgICAgICAgICAgPGxhYmVsPkRhdGFiYXNlczwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPENoZWNrYm94R3JvdXBcclxuICAgICAgICAgICAgICAgIG9wdGlvbnM9e1tcIk1vbmdvREJcIiwgXCJNeVNRTFwiLCBcIlBvc3RncmVTUUxcIiwgXCJTUUxpdGVcIiwgXCJPcmFjbGVcIiwgXCJNaWNyb3NvZnQgU1FMIFNlcnZlclwiLCBcIkZpcmViYXNlXCIsIFwiUmVkaXNcIiwgXCJDYXNzYW5kcmFcIiwgXCJEeW5hbW9EQlwiLCBcIk5lbzRqXCJdfVxyXG4gICAgICAgICAgICAgICAgc2VsZWN0ZWRWYWx1ZXM9e2Zvcm1EYXRhLm9wdGlvbmFsU2tpbGxzLmRhdGFiYXNlc31cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWVzKSA9PiBoYW5kbGVTa2lsbENoYW5nZSgnb3B0aW9uYWxTa2lsbHMnLCAnZGF0YWJhc2VzJywgdmFsdWVzKX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncm91cC1pcFwiPlxyXG4gICAgICAgICAgICAgIDxsYWJlbD5MaWJyYXJpZXM8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxDaGVja2JveEdyb3VwXHJcbiAgICAgICAgICAgICAgICBvcHRpb25zPXtbXCJSZWR1eFwiLCBcIkF4aW9zXCIsIFwialF1ZXJ5XCIsIFwiTG9kYXNoXCIsIFwiVGVuc29yRmxvd1wiLCBcIktlcmFzXCIsIFwiUHlUb3JjaFwiLCBcIlNjaWtpdC1sZWFyblwiLCBcIlBhbmRhc1wiLCBcIk51bVB5XCIsIFwiQ2hhcnQuanNcIiwgXCJEMy5qc1wiLCBcIlRocmVlLmpzXCIsIFwiU29ja2V0LmlvXCIsIFwiQm9vdHN0cmFwXCJdfVxyXG4gICAgICAgICAgICAgICAgc2VsZWN0ZWRWYWx1ZXM9e2Zvcm1EYXRhLm9wdGlvbmFsU2tpbGxzLmxpYnJhcmllc31cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWVzKSA9PiBoYW5kbGVTa2lsbENoYW5nZSgnb3B0aW9uYWxTa2lsbHMnLCAnbGlicmFyaWVzJywgdmFsdWVzKX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncm91cC1pcFwiPlxyXG4gICAgICAgICAgICAgIDxsYWJlbD5Ub29sczwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPENoZWNrYm94R3JvdXBcclxuICAgICAgICAgICAgICAgIG9wdGlvbnM9e1tcIkdpdFwiLCBcIkdpdEh1YlwiLCBcIkdpdExhYlwiLCBcIkRvY2tlclwiLCBcIkt1YmVybmV0ZXNcIiwgXCJQb3N0bWFuXCIsIFwiSmlyYVwiLCBcIlRyZWxsb1wiLCBcIkZpZ21hXCIsIFwiQWRvYmUgWERcIiwgXCJWUyBDb2RlXCIsIFwiSW50ZWxsaUogSURFQVwiLCBcIkVjbGlwc2VcIiwgXCJXZWJwYWNrXCIsIFwiQmFiZWxcIl19XHJcbiAgICAgICAgICAgICAgICBzZWxlY3RlZFZhbHVlcz17Zm9ybURhdGEub3B0aW9uYWxTa2lsbHMudG9vbHN9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlcykgPT4gaGFuZGxlU2tpbGxDaGFuZ2UoJ29wdGlvbmFsU2tpbGxzJywgJ3Rvb2xzJywgdmFsdWVzKX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tc2VjdGlvbi1pcFwiPlxyXG4gICAgICAgICAgICA8aDI+Um9sZXMgJiBBdmFpbGFiaWxpdHk8L2gyPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXAtaXBcIj5cclxuICAgICAgICAgICAgICA8bGFiZWw+UmVxdWlyZWQgUm9sZXMgKjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPENoZWNrYm94R3JvdXBcclxuICAgICAgICAgICAgICAgIG9wdGlvbnM9e1snRnJvbnRlbmQgRGV2ZWxvcGVyJywgJ0JhY2tlbmQgRGV2ZWxvcGVyJywgJ0Z1bGwgU3RhY2sgRGV2ZWxvcGVyJywgJ1VJL1VYIERlc2lnbmVyJywgJ1FBIEVuZ2luZWVyJywgJ0RhdGEgU2NpZW50aXN0JywgJ0Rldk9wcyBFbmdpbmVlcicsICdQcm9kdWN0IE1hbmFnZXInXX1cclxuICAgICAgICAgICAgICAgIHNlbGVjdGVkVmFsdWVzPXtmb3JtRGF0YS5yZXF1aXJlZFJvbGVzfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZXMpID0+IHNldEZvcm1EYXRhKHByZXYgPT4gKHsgLi4ucHJldiwgcmVxdWlyZWRSb2xlczogdmFsdWVzIH0pKX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1yb3ctaXBcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXAtaXBcIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbD5XZWVrbHkgSG91cnMgUmVxdWlyZWQgKjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cIm51bWJlclwiIHZhbHVlPXtmb3JtRGF0YS5hdmFpbGFiaWxpdHlSZXF1aXJlbWVudC53ZWVrbHlIb3Vyc30gb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVOZXN0ZWRDaGFuZ2UoJ2F2YWlsYWJpbGl0eVJlcXVpcmVtZW50JywgJ3dlZWtseUhvdXJzJywgZS50YXJnZXQudmFsdWUpfSByZXF1aXJlZCBtaW49XCIxXCIgcGxhY2Vob2xkZXI9XCJlLmcuIDEwXCIgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXAtaXBcIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbD5EdXJhdGlvbiAoV2Vla3MpICo8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJudW1iZXJcIiB2YWx1ZT17Zm9ybURhdGEuYXZhaWxhYmlsaXR5UmVxdWlyZW1lbnQuZHVyYXRpb25XZWVrc30gb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVOZXN0ZWRDaGFuZ2UoJ2F2YWlsYWJpbGl0eVJlcXVpcmVtZW50JywgJ2R1cmF0aW9uV2Vla3MnLCBlLnRhcmdldC52YWx1ZSl9IHJlcXVpcmVkIG1pbj1cIjFcIiBwbGFjZWhvbGRlcj1cImUuZy4gMTJcIiAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncm91cC1pcFwiPlxyXG4gICAgICAgICAgICAgIDxsYWJlbD5QcmVmZXJyZWQgTWVldGluZyBEYXlzPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8Q2hlY2tib3hHcm91cFxyXG4gICAgICAgICAgICAgICAgb3B0aW9ucz17WydNb25kYXknLCAnVHVlc2RheScsICdXZWRuZXNkYXknLCAnVGh1cnNkYXknLCAnRnJpZGF5JywgJ1NhdHVyZGF5JywgJ1N1bmRheSddfVxyXG4gICAgICAgICAgICAgICAgc2VsZWN0ZWRWYWx1ZXM9e2Zvcm1EYXRhLmF2YWlsYWJpbGl0eVJlcXVpcmVtZW50Lm1lZXRpbmdEYXlzfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZXMpID0+IGhhbmRsZU5lc3RlZENoYW5nZSgnYXZhaWxhYmlsaXR5UmVxdWlyZW1lbnQnLCAnbWVldGluZ0RheXMnLCB2YWx1ZXMpfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWFjdGlvbnMtaXBcIj5cclxuICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCIgY2xhc3NOYW1lPVwic3VibWl0LWJ0bi1pcFwiPlNhdmUgQ2hhbmdlczwvYnV0dG9uPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9mb3JtPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBVcGRhdGVQcm9qZWN0O1xyXG4iXSwiZmlsZSI6IkY6L1kzUzIvSVRQTSBwcm9qZWN0L1Byb01hdGUtLVByb2plY3QtUGFydG5lci1GaW5kZXIvZnJvbnRlbmQvc3JjL3BhZ2VzL1Byb2plY3RzL1VwZGF0ZVByb2plY3QuanN4In0=