import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Users/ResetPassword.jsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ResetPassword.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=383bea9f"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"];
import { useLocation, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=383bea9f";
const ResetPassword = () => {
  _s();
  const navigate = useNavigate();
  const location = useLocation();
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [loading, setLoading] = useState(false);
  const email = location.state?.email;
  const otp = location.state?.otp;
  if (!email || !otp) {
    navigate("/forgot-password");
    return null;
  }
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    if (password.length < 8) {
      setError("Password must be at least 8 characters long.");
      return;
    }
    if (password !== confirmPassword) {
      setError("Passwords do not match.");
      return;
    }
    setLoading(true);
    try {
      const res = await fetch("http://localhost:3000/api/auth/reset-password", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          email,
          otp,
          newPassword: password
        })
      });
      const data = await res.json();
      if (res.ok) {
        setSuccess("Password updated successfully! Redirecting to login...");
        setTimeout(() => navigate("/login"), 2e3);
      } else {
        setError(data.message || "Failed to update password. Code may have expired.");
      }
    } catch (err) {
      setError("Server error.");
    } finally {
      setLoading(false);
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "page active", style: {
    display: "flex",
    minHeight: "100vh",
    alignItems: "center",
    justifyContent: "center"
  }, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "auth-blob-1" }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ResetPassword.jsx",
      lineNumber: 62,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "auth-blob-2" }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ResetPassword.jsx",
      lineNumber: 63,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "auth-card", style: {
      zIndex: 10
    }, children: [
      /* @__PURE__ */ jsxDEV("div", { className: "auth-header", style: {
        marginBottom: "1.5rem",
        textAlign: "center"
      }, children: [
        /* @__PURE__ */ jsxDEV("h2", { children: "Set New Password" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ResetPassword.jsx",
          lineNumber: 71,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: "Create a secure new password for your account" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ResetPassword.jsx",
          lineNumber: 72,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ResetPassword.jsx",
        lineNumber: 67,
        columnNumber: 9
      }, this),
      error && /* @__PURE__ */ jsxDEV("div", { className: "form-error show", style: {
        marginBottom: "1rem",
        textAlign: "center"
      }, children: error }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ResetPassword.jsx",
        lineNumber: 75,
        columnNumber: 19
      }, this),
      success && /* @__PURE__ */ jsxDEV("div", { style: {
        marginBottom: "1rem",
        textAlign: "center",
        color: "var(--success)",
        fontWeight: "600",
        fontSize: ".9rem"
      }, children: success }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ResetPassword.jsx",
        lineNumber: 79,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, children: [
        /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "form-label", children: "New Password" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ResetPassword.jsx",
            lineNumber: 89,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("input", { type: "password", className: "form-input", value: password, onChange: (e) => setPassword(e.target.value), placeholder: "Minimum 8 characters" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ResetPassword.jsx",
            lineNumber: 90,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ResetPassword.jsx",
          lineNumber: 88,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "form-label", children: "Confirm New Password" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ResetPassword.jsx",
            lineNumber: 93,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("input", { type: "password", className: "form-input", value: confirmPassword, onChange: (e) => setConfirmPassword(e.target.value), placeholder: "Repeat your new password" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ResetPassword.jsx",
            lineNumber: 94,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ResetPassword.jsx",
          lineNumber: 92,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("button", { type: "submit", className: "btn btn-primary btn-full flex justify-center mt-4", style: {
          padding: ".8rem"
        }, disabled: loading || success, children: loading ? "Saving..." : "Reset Password" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ResetPassword.jsx",
          lineNumber: 96,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ResetPassword.jsx",
        lineNumber: 87,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ResetPassword.jsx",
      lineNumber: 64,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ResetPassword.jsx",
    lineNumber: 56,
    columnNumber: 10
  }, this);
};
_s(ResetPassword, "9cw7BHcM4OVF/rqTN9enCX2hNGQ=", false, function() {
  return [useNavigate, useLocation];
});
_c = ResetPassword;
export default ResetPassword;
var _c;
$RefreshReg$(_c, "ResetPassword");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ResetPassword.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeURNOzs7Ozs7Ozs7Ozs7Ozs7O0FBekROLE9BQU9BLFNBQVNDLGdCQUFnQjtBQUNoQyxTQUFTQyxhQUFhQyxtQkFBbUI7QUFFekMsTUFBTUMsZ0JBQWdCQSxNQUFNO0FBQUFDLEtBQUE7QUFDMUIsUUFBTUMsV0FBV0gsWUFBWTtBQUM3QixRQUFNSSxXQUFXTCxZQUFZO0FBQzdCLFFBQU0sQ0FBQ00sVUFBVUMsV0FBVyxJQUFJUixTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDUyxpQkFBaUJDLGtCQUFrQixJQUFJVixTQUFTLEVBQUU7QUFDekQsUUFBTSxDQUFDVyxPQUFPQyxRQUFRLElBQUlaLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUNhLFNBQVNDLFVBQVUsSUFBSWQsU0FBUyxFQUFFO0FBQ3pDLFFBQU0sQ0FBQ2UsU0FBU0MsVUFBVSxJQUFJaEIsU0FBUyxLQUFLO0FBRTVDLFFBQU1pQixRQUFRWCxTQUFTWSxPQUFPRDtBQUM5QixRQUFNRSxNQUFNYixTQUFTWSxPQUFPQztBQUU1QixNQUFJLENBQUNGLFNBQVMsQ0FBQ0UsS0FBSztBQUNsQmQsYUFBUyxrQkFBa0I7QUFDM0IsV0FBTztBQUFBLEVBQ1Q7QUFFQSxRQUFNZSxlQUFlLE9BQU9DLE1BQU07QUFDaENBLE1BQUVDLGVBQWU7QUFDakJWLGFBQVMsRUFBRTtBQUVYLFFBQUlMLFNBQVNnQixTQUFTLEdBQUc7QUFDdkJYLGVBQVMsOENBQThDO0FBQ3ZEO0FBQUEsSUFDRjtBQUNBLFFBQUlMLGFBQWFFLGlCQUFpQjtBQUNoQ0csZUFBUyx5QkFBeUI7QUFDbEM7QUFBQSxJQUNGO0FBRUFJLGVBQVcsSUFBSTtBQUNmLFFBQUk7QUFDRixZQUFNUSxNQUFNLE1BQU1DLE1BQU0saURBQWlEO0FBQUEsUUFDdkVDLFFBQVE7QUFBQSxRQUNSQyxTQUFTO0FBQUEsVUFBRSxnQkFBZ0I7QUFBQSxRQUFtQjtBQUFBLFFBQzlDQyxNQUFNQyxLQUFLQyxVQUFVO0FBQUEsVUFBRWI7QUFBQUEsVUFBT0U7QUFBQUEsVUFBS1ksYUFBYXhCO0FBQUFBLFFBQVMsQ0FBQztBQUFBLE1BQzVELENBQUM7QUFDRCxZQUFNeUIsT0FBTyxNQUFNUixJQUFJUyxLQUFLO0FBRTVCLFVBQUlULElBQUlVLElBQUk7QUFDVnBCLG1CQUFXLHdEQUF3RDtBQUNuRXFCLG1CQUFXLE1BQU05QixTQUFTLFFBQVEsR0FBRyxHQUFJO0FBQUEsTUFDM0MsT0FBTztBQUNMTyxpQkFBU29CLEtBQUtJLFdBQVcsbURBQW1EO0FBQUEsTUFDOUU7QUFBQSxJQUNGLFNBQVNDLEtBQUs7QUFDWnpCLGVBQVMsZUFBZTtBQUFBLElBQzFCLFVBQUM7QUFDQ0ksaUJBQVcsS0FBSztBQUFBLElBQ2xCO0FBQUEsRUFDRjtBQUVBLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLGVBQWMsT0FBTztBQUFBLElBQUVzQixTQUFTO0FBQUEsSUFBUUMsV0FBVztBQUFBLElBQVNDLFlBQVk7QUFBQSxJQUFVQyxnQkFBZ0I7QUFBQSxFQUFTLEdBQ3hIO0FBQUEsMkJBQUMsU0FBSSxXQUFVLGlCQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNkI7QUFBQSxJQUM3Qix1QkFBQyxTQUFJLFdBQVUsaUJBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE2QjtBQUFBLElBQzdCLHVCQUFDLFNBQUksV0FBVSxhQUFZLE9BQU87QUFBQSxNQUFFQyxRQUFRO0FBQUEsSUFBRyxHQUM3QztBQUFBLDZCQUFDLFNBQUksV0FBVSxlQUFjLE9BQU87QUFBQSxRQUFFQyxjQUFjO0FBQUEsUUFBVUMsV0FBVztBQUFBLE1BQVMsR0FDaEY7QUFBQSwrQkFBQyxRQUFHLGdDQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0I7QUFBQSxRQUNwQix1QkFBQyxPQUFFLDZEQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0Q7QUFBQSxXQUZsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUVDakMsU0FBUyx1QkFBQyxTQUFJLFdBQVUsbUJBQWtCLE9BQU87QUFBQSxRQUFFZ0MsY0FBYztBQUFBLFFBQVFDLFdBQVc7QUFBQSxNQUFTLEdBQUlqQyxtQkFBeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4RjtBQUFBLE1BQ3ZHRSxXQUFXLHVCQUFDLFNBQUksT0FBTztBQUFBLFFBQUU4QixjQUFjO0FBQUEsUUFBUUMsV0FBVztBQUFBLFFBQVVDLE9BQU87QUFBQSxRQUFrQkMsWUFBWTtBQUFBLFFBQU9DLFVBQVU7QUFBQSxNQUFRLEdBQUlsQyxxQkFBM0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtSTtBQUFBLE1BRS9JLHVCQUFDLFVBQUssVUFBVU8sY0FDZDtBQUFBLCtCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsaUNBQUMsV0FBTSxXQUFVLGNBQWEsNEJBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBDO0FBQUEsVUFDMUMsdUJBQUMsV0FDQyxNQUFLLFlBQ0wsV0FBVSxjQUNWLE9BQU9iLFVBQ1AsVUFBV2MsT0FBTWIsWUFBWWEsRUFBRTJCLE9BQU9DLEtBQUssR0FDM0MsYUFBWSwwQkFMZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtvQztBQUFBLGFBUHRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFTQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsY0FBYSxvQ0FBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0Q7QUFBQSxVQUNsRCx1QkFBQyxXQUNDLE1BQUssWUFDTCxXQUFVLGNBQ1YsT0FBT3hDLGlCQUNQLFVBQVdZLE9BQU1YLG1CQUFtQlcsRUFBRTJCLE9BQU9DLEtBQUssR0FDbEQsYUFBWSw4QkFMZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUt3QztBQUFBLGFBUDFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFTQTtBQUFBLFFBQ0EsdUJBQUMsWUFBTyxNQUFLLFVBQVMsV0FBVSxxREFBb0QsT0FBTztBQUFBLFVBQUVDLFNBQVM7QUFBQSxRQUFRLEdBQUcsVUFBVW5DLFdBQVdGLFNBQ25JRSxvQkFBVSxjQUFjLG9CQUQzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBd0JBO0FBQUEsU0FqQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWtDQTtBQUFBLE9BckNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FzQ0E7QUFFSjtBQUFFWCxHQTdGSUQsZUFBYTtBQUFBLFVBQ0FELGFBQ0FELFdBQVc7QUFBQTtBQUFBa0QsS0FGeEJoRDtBQStGTixlQUFlQTtBQUFjLElBQUFnRDtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJ1c2VTdGF0ZSIsInVzZUxvY2F0aW9uIiwidXNlTmF2aWdhdGUiLCJSZXNldFBhc3N3b3JkIiwiX3MiLCJuYXZpZ2F0ZSIsImxvY2F0aW9uIiwicGFzc3dvcmQiLCJzZXRQYXNzd29yZCIsImNvbmZpcm1QYXNzd29yZCIsInNldENvbmZpcm1QYXNzd29yZCIsImVycm9yIiwic2V0RXJyb3IiLCJzdWNjZXNzIiwic2V0U3VjY2VzcyIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwiZW1haWwiLCJzdGF0ZSIsIm90cCIsImhhbmRsZVN1Ym1pdCIsImUiLCJwcmV2ZW50RGVmYXVsdCIsImxlbmd0aCIsInJlcyIsImZldGNoIiwibWV0aG9kIiwiaGVhZGVycyIsImJvZHkiLCJKU09OIiwic3RyaW5naWZ5IiwibmV3UGFzc3dvcmQiLCJkYXRhIiwianNvbiIsIm9rIiwic2V0VGltZW91dCIsIm1lc3NhZ2UiLCJlcnIiLCJkaXNwbGF5IiwibWluSGVpZ2h0IiwiYWxpZ25JdGVtcyIsImp1c3RpZnlDb250ZW50IiwiekluZGV4IiwibWFyZ2luQm90dG9tIiwidGV4dEFsaWduIiwiY29sb3IiLCJmb250V2VpZ2h0IiwiZm9udFNpemUiLCJ0YXJnZXQiLCJ2YWx1ZSIsInBhZGRpbmciLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlJlc2V0UGFzc3dvcmQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgdXNlTG9jYXRpb24sIHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XHJcblxyXG5jb25zdCBSZXNldFBhc3N3b3JkID0gKCkgPT4ge1xyXG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcclxuICBjb25zdCBsb2NhdGlvbiA9IHVzZUxvY2F0aW9uKCk7XHJcbiAgY29uc3QgW3Bhc3N3b3JkLCBzZXRQYXNzd29yZF0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgY29uc3QgW2NvbmZpcm1QYXNzd29yZCwgc2V0Q29uZmlybVBhc3N3b3JkXSA9IHVzZVN0YXRlKCcnKTtcclxuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKCcnKTtcclxuICBjb25zdCBbc3VjY2Vzcywgc2V0U3VjY2Vzc10gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIFxyXG4gIGNvbnN0IGVtYWlsID0gbG9jYXRpb24uc3RhdGU/LmVtYWlsO1xyXG4gIGNvbnN0IG90cCA9IGxvY2F0aW9uLnN0YXRlPy5vdHA7XHJcblxyXG4gIGlmICghZW1haWwgfHwgIW90cCkge1xyXG4gICAgbmF2aWdhdGUoJy9mb3Jnb3QtcGFzc3dvcmQnKTtcclxuICAgIHJldHVybiBudWxsO1xyXG4gIH1cclxuXHJcbiAgY29uc3QgaGFuZGxlU3VibWl0ID0gYXN5bmMgKGUpID0+IHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgIHNldEVycm9yKCcnKTtcclxuXHJcbiAgICBpZiAocGFzc3dvcmQubGVuZ3RoIDwgOCkge1xyXG4gICAgICBzZXRFcnJvcignUGFzc3dvcmQgbXVzdCBiZSBhdCBsZWFzdCA4IGNoYXJhY3RlcnMgbG9uZy4nKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgaWYgKHBhc3N3b3JkICE9PSBjb25maXJtUGFzc3dvcmQpIHtcclxuICAgICAgc2V0RXJyb3IoJ1Bhc3N3b3JkcyBkbyBub3QgbWF0Y2guJyk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBzZXRMb2FkaW5nKHRydWUpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goJ2h0dHA6Ly9sb2NhbGhvc3Q6MzAwMC9hcGkvYXV0aC9yZXNldC1wYXNzd29yZCcsIHtcclxuICAgICAgICBtZXRob2Q6ICdQT1NUJyxcclxuICAgICAgICBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSxcclxuICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7IGVtYWlsLCBvdHAsIG5ld1Bhc3N3b3JkOiBwYXNzd29yZCB9KVxyXG4gICAgICB9KTtcclxuICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlcy5qc29uKCk7XHJcbiAgICAgIFxyXG4gICAgICBpZiAocmVzLm9rKSB7XHJcbiAgICAgICAgc2V0U3VjY2VzcygnUGFzc3dvcmQgdXBkYXRlZCBzdWNjZXNzZnVsbHkhIFJlZGlyZWN0aW5nIHRvIGxvZ2luLi4uJyk7XHJcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiBuYXZpZ2F0ZSgnL2xvZ2luJyksIDIwMDApO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHNldEVycm9yKGRhdGEubWVzc2FnZSB8fCAnRmFpbGVkIHRvIHVwZGF0ZSBwYXNzd29yZC4gQ29kZSBtYXkgaGF2ZSBleHBpcmVkLicpO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgc2V0RXJyb3IoJ1NlcnZlciBlcnJvci4nKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInBhZ2UgYWN0aXZlXCIgc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCBtaW5IZWlnaHQ6ICcxMDB2aCcsIGFsaWduSXRlbXM6ICdjZW50ZXInLCBqdXN0aWZ5Q29udGVudDogJ2NlbnRlcicgfX0+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYXV0aC1ibG9iLTFcIj48L2Rpdj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJhdXRoLWJsb2ItMlwiPjwvZGl2PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImF1dGgtY2FyZFwiIHN0eWxlPXt7IHpJbmRleDogMTAgfX0+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhdXRoLWhlYWRlclwiIHN0eWxlPXt7IG1hcmdpbkJvdHRvbTogJzEuNXJlbScsIHRleHRBbGlnbjogJ2NlbnRlcicgfX0+XHJcbiAgICAgICAgICA8aDI+U2V0IE5ldyBQYXNzd29yZDwvaDI+XHJcbiAgICAgICAgICA8cD5DcmVhdGUgYSBzZWN1cmUgbmV3IHBhc3N3b3JkIGZvciB5b3VyIGFjY291bnQ8L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgXHJcbiAgICAgICAge2Vycm9yICYmIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1lcnJvciBzaG93XCIgc3R5bGU9e3sgbWFyZ2luQm90dG9tOiAnMXJlbScsIHRleHRBbGlnbjogJ2NlbnRlcicgfX0+e2Vycm9yfTwvZGl2Pn1cclxuICAgICAgICB7c3VjY2VzcyAmJiA8ZGl2IHN0eWxlPXt7IG1hcmdpbkJvdHRvbTogJzFyZW0nLCB0ZXh0QWxpZ246ICdjZW50ZXInLCBjb2xvcjogJ3ZhcigtLXN1Y2Nlc3MpJywgZm9udFdlaWdodDogJzYwMCcsIGZvbnRTaXplOiAnLjlyZW0nIH19PntzdWNjZXNzfTwvZGl2Pn1cclxuICAgICAgICBcclxuICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU3VibWl0fT5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncm91cFwiPlxyXG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZm9ybS1sYWJlbFwiPk5ldyBQYXNzd29yZDwvbGFiZWw+XHJcbiAgICAgICAgICAgIDxpbnB1dCBcclxuICAgICAgICAgICAgICB0eXBlPVwicGFzc3dvcmRcIiBcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmb3JtLWlucHV0XCIgXHJcbiAgICAgICAgICAgICAgdmFsdWU9e3Bhc3N3b3JkfSBcclxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFBhc3N3b3JkKGUudGFyZ2V0LnZhbHVlKX0gXHJcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJNaW5pbXVtIDggY2hhcmFjdGVyc1wiIFxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXBcIj5cclxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZvcm0tbGFiZWxcIj5Db25maXJtIE5ldyBQYXNzd29yZDwvbGFiZWw+XHJcbiAgICAgICAgICAgIDxpbnB1dCBcclxuICAgICAgICAgICAgICB0eXBlPVwicGFzc3dvcmRcIiBcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmb3JtLWlucHV0XCIgXHJcbiAgICAgICAgICAgICAgdmFsdWU9e2NvbmZpcm1QYXNzd29yZH0gXHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRDb25maXJtUGFzc3dvcmQoZS50YXJnZXQudmFsdWUpfSBcclxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlJlcGVhdCB5b3VyIG5ldyBwYXNzd29yZFwiIFxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBjbGFzc05hbWU9XCJidG4gYnRuLXByaW1hcnkgYnRuLWZ1bGwgZmxleCBqdXN0aWZ5LWNlbnRlciBtdC00XCIgc3R5bGU9e3sgcGFkZGluZzogJy44cmVtJyB9fSBkaXNhYmxlZD17bG9hZGluZyB8fCBzdWNjZXNzfT5cclxuICAgICAgICAgICAge2xvYWRpbmcgPyAnU2F2aW5nLi4uJyA6ICdSZXNldCBQYXNzd29yZCd9XHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICA8L2Zvcm0+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFJlc2V0UGFzc3dvcmQ7XHJcbiJdLCJmaWxlIjoiRjovWTNTMi9JVFBNIHByb2plY3QvUHJvTWF0ZS0tUHJvamVjdC1QYXJ0bmVyLUZpbmRlci9mcm9udGVuZC9zcmMvcGFnZXMvVXNlcnMvUmVzZXRQYXNzd29yZC5qc3gifQ==