import {
  require_react
} from "/node_modules/.vite/deps/chunk-SNNC5QQA.js?v=383bea9f";
import "/node_modules/.vite/deps/chunk-USJHI7ER.js?v=383bea9f";
export default require_react();
//# sourceMappingURL=react.js.map
