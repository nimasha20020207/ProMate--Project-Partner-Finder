import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Users/Dashboard.jsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=383bea9f"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=383bea9f";
import { useAuth } from "/src/context/AuthContext.jsx";
const Dashboard = () => {
  _s();
  const navigate = useNavigate();
  const {
    user
  } = useAuth();
  const firstName = user?.fullName ? user.fullName.split(" ")[0] : "User";
  const getInitials = (name) => name ? name.split(" ").map((n) => n[0]).join("").substring(0, 2).toUpperCase() : "U";
  const initials = getInitials(user?.fullName);
  return /* @__PURE__ */ jsxDEV("div", { id: "page-dashboard", className: "page active", style: {
    display: "block"
  }, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "page-hdr", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "page-hdr-left", children: [
        /* @__PURE__ */ jsxDEV("h1", { children: [
          "Welcome back, ",
          firstName,
          " 👋"
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
          lineNumber: 19,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: "Here's your project partner activity" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
          lineNumber: 20,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
        lineNumber: 18,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "page-hdr-right", children: [
        /* @__PURE__ */ jsxDEV("button", { className: "btn btn-outline btn-sm", onClick: () => navigate("/profile"), children: "View Profile" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
          lineNumber: 23,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("button", { className: "btn btn-primary btn-sm", onClick: () => navigate("/edit-profile"), children: "✏️ Edit Profile" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
          lineNumber: 24,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
        lineNumber: 22,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
      lineNumber: 17,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "profile-hero", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "ph-avatar", style: {
        overflow: "hidden"
      }, children: user?.profilePicture ? /* @__PURE__ */ jsxDEV("img", { src: user.profilePicture, alt: "Profile", style: {
        width: "100%",
        height: "100%",
        objectFit: "cover"
      } }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
        lineNumber: 32,
        columnNumber: 35
      }, this) : initials }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
        lineNumber: 29,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "ph-info", children: [
        /* @__PURE__ */ jsxDEV("h2", { children: user?.fullName || "Student" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
          lineNumber: 39,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "ph-dept", children: [
          "📍 ",
          user?.department || "Dept. Unassigned",
          " · ",
          user?.academicInfo?.year ? `Year ${user.academicInfo.year}` : "Year N/A"
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
          lineNumber: 40,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "ph-chips", children: [
          (user?.specialization || user?.academicInfo?.specialization) && /* @__PURE__ */ jsxDEV("span", { className: "ph-chip", children: [
            "🎓 ",
            user.specialization || user.academicInfo.specialization
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
            lineNumber: 42,
            columnNumber: 78
          }, this),
          user?.availability?.weeklyHours && /* @__PURE__ */ jsxDEV("span", { className: "ph-chip", children: [
            "⏰ ",
            user.availability.weeklyHours,
            " hrs/week"
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
            lineNumber: 43,
            columnNumber: 49
          }, this),
          user?.availability?.preferredDays?.length > 0 && /* @__PURE__ */ jsxDEV("span", { className: "ph-chip", children: "🟢 Available" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
            lineNumber: 44,
            columnNumber: 63
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
          lineNumber: 41,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
        lineNumber: 38,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "ph-actions", children: [
        /* @__PURE__ */ jsxDEV("button", { className: "btn btn-ghost btn-sm", onClick: () => navigate("/edit-profile"), children: "✏️ Edit" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
          lineNumber: 48,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("button", { className: "btn btn-ghost btn-sm", onClick: () => navigate("/profile"), children: "👁️ Preview" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
          lineNumber: 49,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
        lineNumber: 47,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
      lineNumber: 28,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "stats-row", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "stat-card-sm", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "sc-label", children: "Skills Listed" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
          lineNumber: 55,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "sc-value", children: (user?.skills?.languages?.length || 0) + (user?.skills?.frameworks?.length || 0) + (user?.skills?.tools?.length || 0) + (user?.skills?.databases?.length || 0) + (user?.skills?.libraries?.length || 0) }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
          lineNumber: 56,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "sc-sub", children: "Add more to match better" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
          lineNumber: 59,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
        lineNumber: 54,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "stat-card-sm", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "sc-label", children: "Projects Applied" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
          lineNumber: 61,
          columnNumber: 39
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "sc-value", children: "0" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
          lineNumber: 61,
          columnNumber: 87
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "sc-sub", children: "0 accepted · 0 pending" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
          lineNumber: 61,
          columnNumber: 120
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
        lineNumber: 61,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "stat-card-sm", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "sc-label", children: "Match Score Avg" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
          lineNumber: 62,
          columnNumber: 39
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "sc-value", children: "N/A" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
          lineNumber: 62,
          columnNumber: 86
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "sc-sub", children: "New Profile" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
          lineNumber: 62,
          columnNumber: 121
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
        lineNumber: 62,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
      lineNumber: 53,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "ai-banner", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "ai-banner-icon", children: "🤖" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
        lineNumber: 66,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "ai-banner-body", children: [
        /* @__PURE__ */ jsxDEV("h4", { children: "AI Skill Suggestions · Web Development Domain" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
          lineNumber: 68,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: "Based on your skills, you may also know these. Click to add:" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
          lineNumber: 69,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "ai-tags", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "ai-tag", children: "+ TypeScript" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
            lineNumber: 71,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "ai-tag", children: "+ REST APIs" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
            lineNumber: 72,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "ai-tag", children: "+ Git & GitHub" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
            lineNumber: 73,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "ai-tag", children: "+ Tailwind CSS" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
            lineNumber: 74,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
          lineNumber: 70,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
        lineNumber: 67,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
      lineNumber: 65,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid-2", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "card card-sm", style: {
        display: "flex",
        flexDirection: "column",
        gap: ".6rem"
      }, children: [
        /* @__PURE__ */ jsxDEV("div", { style: {
          fontFamily: "'Sora', sans-serif",
          fontSize: ".95rem",
          fontWeight: 700,
          marginBottom: ".25rem"
        }, children: "🔔 Recent Requests" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
          lineNumber: 85,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: {
          fontSize: ".85rem",
          color: "var(--mid)",
          padding: "1rem",
          textAlign: "center",
          background: "var(--bg)",
          borderRadius: "10px"
        }, children: "No recent requests currently." }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
          lineNumber: 91,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
        lineNumber: 80,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "card card-sm", children: [
        /* @__PURE__ */ jsxDEV("div", { style: {
          fontFamily: "'Sora', sans-serif",
          fontSize: ".95rem",
          fontWeight: 700,
          marginBottom: ".75rem"
        }, children: "⚡ Quick Actions" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
          lineNumber: 103,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: {
          display: "flex",
          flexDirection: "column",
          gap: ".5rem"
        }, children: [
          /* @__PURE__ */ jsxDEV("button", { className: "btn btn-outline btn-full", style: {
            color: "var(--mid)"
          }, onClick: () => navigate("/profile"), type: "button", children: "📋 Browse Projects" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
            lineNumber: 114,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("button", { className: "btn btn-outline btn-full", style: {
            color: "var(--mid)"
          }, onClick: () => navigate("/recprojects"), type: "button", children: "⭐ View Matches" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
            lineNumber: 117,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("button", { className: "btn btn-primary btn-full", onClick: () => navigate("/edit-profile"), type: "button", children: "✏️ Edit My Profile" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
            lineNumber: 120,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("button", { className: "btn btn-outline btn-full", onClick: () => navigate("/profile"), type: "button", children: "👁️ Preview Profile" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
            lineNumber: 121,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
          lineNumber: 109,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
        lineNumber: 102,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
      lineNumber: 79,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx",
    lineNumber: 14,
    columnNumber: 10
  }, this);
};
_s(Dashboard, "aMAerdHTUl+s1UWmXA6CSCwiXuE=", false, function() {
  return [useNavigate, useAuth];
});
_c = Dashboard;
export default Dashboard;
var _c;
$RefreshReg$(_c, "Dashboard");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Dashboard.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0JVOzs7Ozs7Ozs7Ozs7Ozs7O0FBaEJWLE9BQU9BLFdBQVc7QUFDbEIsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLGVBQWU7QUFFeEIsTUFBTUMsWUFBWUEsTUFBTTtBQUFBQyxLQUFBO0FBQ3RCLFFBQU1DLFdBQVdKLFlBQVk7QUFDN0IsUUFBTTtBQUFBLElBQUVLO0FBQUFBLEVBQUssSUFBSUosUUFBUTtBQUV6QixRQUFNSyxZQUFZRCxNQUFNRSxXQUFXRixLQUFLRSxTQUFTQyxNQUFNLEdBQUcsRUFBRSxDQUFDLElBQUk7QUFDakUsUUFBTUMsY0FBZUMsVUFBU0EsT0FBT0EsS0FBS0YsTUFBTSxHQUFHLEVBQUVHLElBQUlDLE9BQUtBLEVBQUUsQ0FBQyxDQUFDLEVBQUVDLEtBQUssRUFBRSxFQUFFQyxVQUFVLEdBQUcsQ0FBQyxFQUFFQyxZQUFZLElBQUk7QUFDN0csUUFBTUMsV0FBV1AsWUFBWUosTUFBTUUsUUFBUTtBQUUzQyxTQUNFLHVCQUFDLFNBQUksSUFBRyxrQkFBaUIsV0FBVSxlQUFjLE9BQU87QUFBQSxJQUFFVSxTQUFTO0FBQUEsRUFBUSxHQUN6RTtBQUFBLDJCQUFDLFNBQUksV0FBVSxZQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsK0JBQUMsUUFBRztBQUFBO0FBQUEsVUFBZVg7QUFBQUEsVUFBVTtBQUFBLGFBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0M7QUFBQSxRQUNoQyx1QkFBQyxPQUFFLG9EQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBdUM7QUFBQSxXQUZ6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxrQkFDYjtBQUFBLCtCQUFDLFlBQU8sV0FBVSwwQkFBeUIsU0FBUyxNQUFNRixTQUFTLFVBQVUsR0FBRyw0QkFBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0RjtBQUFBLFFBQzVGLHVCQUFDLFlBQU8sV0FBVSwwQkFBeUIsU0FBUyxNQUFNQSxTQUFTLGVBQWUsR0FBRywrQkFBckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvRztBQUFBLFdBRnRHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLFNBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsZ0JBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsYUFBWSxPQUFPO0FBQUEsUUFBRWMsVUFBVTtBQUFBLE1BQVMsR0FDcERiLGdCQUFNYyxpQkFDTCx1QkFBQyxTQUFJLEtBQUtkLEtBQUtjLGdCQUFnQixLQUFJLFdBQVUsT0FBTztBQUFBLFFBQUVDLE9BQU87QUFBQSxRQUFRQyxRQUFRO0FBQUEsUUFBUUMsV0FBVztBQUFBLE1BQVEsS0FBeEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEwRyxJQUUxR04sWUFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTUE7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxXQUNiO0FBQUEsK0JBQUMsUUFBSVgsZ0JBQU1FLFlBQVksYUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpQztBQUFBLFFBQ2pDLHVCQUFDLFNBQUksV0FBVSxXQUFVO0FBQUE7QUFBQSxVQUFJRixNQUFNa0IsY0FBYztBQUFBLFVBQW1CO0FBQUEsVUFBSWxCLE1BQU1tQixjQUFjQyxPQUFPLFFBQVFwQixLQUFLbUIsYUFBYUMsSUFBSSxLQUFLO0FBQUEsYUFBdEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpSjtBQUFBLFFBQ2pKLHVCQUFDLFNBQUksV0FBVSxZQUNYcEI7QUFBQUEsaUJBQU1xQixrQkFBa0JyQixNQUFNbUIsY0FBY0UsbUJBQW1CLHVCQUFDLFVBQUssV0FBVSxXQUFVO0FBQUE7QUFBQSxZQUFJckIsS0FBS3FCLGtCQUFrQnJCLEtBQUttQixhQUFhRTtBQUFBQSxlQUF2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzRjtBQUFBLFVBQ3RKckIsTUFBTXNCLGNBQWNDLGVBQWUsdUJBQUMsVUFBSyxXQUFVLFdBQVU7QUFBQTtBQUFBLFlBQUd2QixLQUFLc0IsYUFBYUM7QUFBQUEsWUFBWTtBQUFBLGVBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9FO0FBQUEsVUFDdkd2QixNQUFNc0IsY0FBY0UsZUFBZUMsU0FBUyxLQUFLLHVCQUFDLFVBQUssV0FBVSxXQUFVLDRCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzQztBQUFBLGFBSDFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQTtBQUFBLFdBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLCtCQUFDLFlBQU8sV0FBVSx3QkFBdUIsU0FBUyxNQUFNMUIsU0FBUyxlQUFlLEdBQUcsdUJBQW5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEY7QUFBQSxRQUMxRix1QkFBQyxZQUFPLFdBQVUsd0JBQXVCLFNBQVMsTUFBTUEsU0FBUyxVQUFVLEdBQUcsMkJBQTlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUY7QUFBQSxXQUYzRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxTQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBcUJBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxnQkFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxZQUFXLDZCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVDO0FBQUEsUUFDdkMsdUJBQUMsU0FBSSxXQUFVLFlBQ1hDLGlCQUFNMEIsUUFBUUMsV0FBV0YsVUFBVSxNQUFNekIsTUFBTTBCLFFBQVFFLFlBQVlILFVBQVUsTUFBTXpCLE1BQU0wQixRQUFRRyxPQUFPSixVQUFVLE1BQU16QixNQUFNMEIsUUFBUUksV0FBV0wsVUFBVSxNQUFNekIsTUFBTTBCLFFBQVFLLFdBQVdOLFVBQVUsTUFEeE07QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsVUFBUyx3Q0FBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnRDtBQUFBLFdBTGxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFNQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGdCQUFlO0FBQUEsK0JBQUMsU0FBSSxXQUFVLFlBQVcsZ0NBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEM7QUFBQSxRQUFNLHVCQUFDLFNBQUksV0FBVSxZQUFXLGlCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJCO0FBQUEsUUFBTSx1QkFBQyxTQUFJLFdBQVUsVUFBUyxzQ0FBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4QztBQUFBLFdBQTdKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBbUs7QUFBQSxNQUNuSyx1QkFBQyxTQUFJLFdBQVUsZ0JBQWU7QUFBQSwrQkFBQyxTQUFJLFdBQVUsWUFBVywrQkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5QztBQUFBLFFBQU0sdUJBQUMsU0FBSSxXQUFVLFlBQVcsbUJBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkI7QUFBQSxRQUFNLHVCQUFDLFNBQUksV0FBVSxVQUFTLDJCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1DO0FBQUEsV0FBbko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5SjtBQUFBLFNBVDNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsa0JBQWlCLGtCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtDO0FBQUEsTUFDbEMsdUJBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEsK0JBQUMsUUFBRyw2REFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlEO0FBQUEsUUFDakQsdUJBQUMsT0FBRSw0RUFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStEO0FBQUEsUUFDL0QsdUJBQUMsU0FBSSxXQUFVLFdBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsVUFBUyw0QkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUM7QUFBQSxVQUNyQyx1QkFBQyxVQUFLLFdBQVUsVUFBUywyQkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBb0M7QUFBQSxVQUNwQyx1QkFBQyxVQUFLLFdBQVUsVUFBUyw4QkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUM7QUFBQSxVQUN2Qyx1QkFBQyxVQUFLLFdBQVUsVUFBUyw4QkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUM7QUFBQSxhQUp6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxXQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLFNBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVlBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxnQkFBZSxPQUFPO0FBQUEsUUFBRWIsU0FBUztBQUFBLFFBQVFvQixlQUFlO0FBQUEsUUFBVUMsS0FBSztBQUFBLE1BQVEsR0FDNUY7QUFBQSwrQkFBQyxTQUFJLE9BQU87QUFBQSxVQUFFQyxZQUFZO0FBQUEsVUFBc0JDLFVBQVU7QUFBQSxVQUFVQyxZQUFZO0FBQUEsVUFBS0MsY0FBYztBQUFBLFFBQVMsR0FBRyxrQ0FBL0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpSTtBQUFBLFFBQ2pJLHVCQUFDLFNBQUksT0FBTztBQUFBLFVBQUVGLFVBQVU7QUFBQSxVQUFVRyxPQUFPO0FBQUEsVUFBY0MsU0FBUztBQUFBLFVBQVFDLFdBQVc7QUFBQSxVQUFVQyxZQUFZO0FBQUEsVUFBYUMsY0FBYztBQUFBLFFBQU8sR0FBRyw2Q0FBOUk7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxnQkFDYjtBQUFBLCtCQUFDLFNBQUksT0FBTztBQUFBLFVBQUVSLFlBQVk7QUFBQSxVQUFzQkMsVUFBVTtBQUFBLFVBQVVDLFlBQVk7QUFBQSxVQUFLQyxjQUFjO0FBQUEsUUFBUyxHQUFHLCtCQUEvRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThIO0FBQUEsUUFDOUgsdUJBQUMsU0FBSSxPQUFPO0FBQUEsVUFBRXpCLFNBQVM7QUFBQSxVQUFRb0IsZUFBZTtBQUFBLFVBQVVDLEtBQUs7QUFBQSxRQUFRLEdBQ25FO0FBQUEsaUNBQUMsWUFBTyxXQUFVLDRCQUEyQixPQUFPO0FBQUEsWUFBRUssT0FBTztBQUFBLFVBQWEsR0FBRyxTQUFTLE1BQU12QyxTQUFTLFVBQVUsR0FBRyxNQUFLLFVBQVMsa0NBQWhJO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWtKO0FBQUEsVUFDbEosdUJBQUMsWUFBTyxXQUFVLDRCQUEyQixPQUFPO0FBQUEsWUFBRXVDLE9BQU87QUFBQSxVQUFhLEdBQUcsU0FBUyxNQUFNdkMsU0FBUyxjQUFjLEdBQUcsTUFBSyxVQUFTLDhCQUFwSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrSjtBQUFBLFVBQ2xKLHVCQUFDLFlBQU8sV0FBVSw0QkFBMkIsU0FBUyxNQUFNQSxTQUFTLGVBQWUsR0FBRyxNQUFLLFVBQVMsa0NBQXJHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVIO0FBQUEsVUFDdkgsdUJBQUMsWUFBTyxXQUFVLDRCQUEyQixTQUFTLE1BQU1BLFNBQVMsVUFBVSxHQUFHLE1BQUssVUFBUyxtQ0FBaEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUg7QUFBQSxhQUpySDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTUE7QUFBQSxXQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLFNBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpQkE7QUFBQSxPQTlFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBK0VBO0FBRUo7QUFBRUQsR0ExRklELFdBQVM7QUFBQSxVQUNJRixhQUNBQyxPQUFPO0FBQUE7QUFBQStDLEtBRnBCOUM7QUE0Rk4sZUFBZUE7QUFBVSxJQUFBOEM7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwidXNlTmF2aWdhdGUiLCJ1c2VBdXRoIiwiRGFzaGJvYXJkIiwiX3MiLCJuYXZpZ2F0ZSIsInVzZXIiLCJmaXJzdE5hbWUiLCJmdWxsTmFtZSIsInNwbGl0IiwiZ2V0SW5pdGlhbHMiLCJuYW1lIiwibWFwIiwibiIsImpvaW4iLCJzdWJzdHJpbmciLCJ0b1VwcGVyQ2FzZSIsImluaXRpYWxzIiwiZGlzcGxheSIsIm92ZXJmbG93IiwicHJvZmlsZVBpY3R1cmUiLCJ3aWR0aCIsImhlaWdodCIsIm9iamVjdEZpdCIsImRlcGFydG1lbnQiLCJhY2FkZW1pY0luZm8iLCJ5ZWFyIiwic3BlY2lhbGl6YXRpb24iLCJhdmFpbGFiaWxpdHkiLCJ3ZWVrbHlIb3VycyIsInByZWZlcnJlZERheXMiLCJsZW5ndGgiLCJza2lsbHMiLCJsYW5ndWFnZXMiLCJmcmFtZXdvcmtzIiwidG9vbHMiLCJkYXRhYmFzZXMiLCJsaWJyYXJpZXMiLCJmbGV4RGlyZWN0aW9uIiwiZ2FwIiwiZm9udEZhbWlseSIsImZvbnRTaXplIiwiZm9udFdlaWdodCIsIm1hcmdpbkJvdHRvbSIsImNvbG9yIiwicGFkZGluZyIsInRleHRBbGlnbiIsImJhY2tncm91bmQiLCJib3JkZXJSYWRpdXMiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkRhc2hib2FyZC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgdXNlTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcclxuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4uLy4uL2NvbnRleHQvQXV0aENvbnRleHQnO1xyXG5cclxuY29uc3QgRGFzaGJvYXJkID0gKCkgPT4ge1xyXG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcclxuICBjb25zdCB7IHVzZXIgfSA9IHVzZUF1dGgoKTtcclxuICBcclxuICBjb25zdCBmaXJzdE5hbWUgPSB1c2VyPy5mdWxsTmFtZSA/IHVzZXIuZnVsbE5hbWUuc3BsaXQoJyAnKVswXSA6ICdVc2VyJztcclxuICBjb25zdCBnZXRJbml0aWFscyA9IChuYW1lKSA9PiBuYW1lID8gbmFtZS5zcGxpdCgnICcpLm1hcChuID0+IG5bMF0pLmpvaW4oJycpLnN1YnN0cmluZygwLCAyKS50b1VwcGVyQ2FzZSgpIDogJ1UnO1xyXG4gIGNvbnN0IGluaXRpYWxzID0gZ2V0SW5pdGlhbHModXNlcj8uZnVsbE5hbWUpO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBpZD1cInBhZ2UtZGFzaGJvYXJkXCIgY2xhc3NOYW1lPVwicGFnZSBhY3RpdmVcIiBzdHlsZT17eyBkaXNwbGF5OiAnYmxvY2snIH19PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInBhZ2UtaGRyXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwYWdlLWhkci1sZWZ0XCI+XHJcbiAgICAgICAgICA8aDE+V2VsY29tZSBiYWNrLCB7Zmlyc3ROYW1lfSDwn5GLPC9oMT5cclxuICAgICAgICAgIDxwPkhlcmUncyB5b3VyIHByb2plY3QgcGFydG5lciBhY3Rpdml0eTwvcD5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBhZ2UtaGRyLXJpZ2h0XCI+XHJcbiAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImJ0biBidG4tb3V0bGluZSBidG4tc21cIiBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZSgnL3Byb2ZpbGUnKX0+VmlldyBQcm9maWxlPC9idXR0b24+XHJcbiAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImJ0biBidG4tcHJpbWFyeSBidG4tc21cIiBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZSgnL2VkaXQtcHJvZmlsZScpfT7inI/vuI8gRWRpdCBQcm9maWxlPC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICBcclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm9maWxlLWhlcm9cIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBoLWF2YXRhclwiIHN0eWxlPXt7IG92ZXJmbG93OiAnaGlkZGVuJyB9fT5cclxuICAgICAgICAgIHt1c2VyPy5wcm9maWxlUGljdHVyZSA/IChcclxuICAgICAgICAgICAgPGltZyBzcmM9e3VzZXIucHJvZmlsZVBpY3R1cmV9IGFsdD1cIlByb2ZpbGVcIiBzdHlsZT17eyB3aWR0aDogJzEwMCUnLCBoZWlnaHQ6ICcxMDAlJywgb2JqZWN0Rml0OiAnY292ZXInIH19IC8+XHJcbiAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICBpbml0aWFsc1xyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBoLWluZm9cIj5cclxuICAgICAgICAgIDxoMj57dXNlcj8uZnVsbE5hbWUgfHwgJ1N0dWRlbnQnfTwvaDI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBoLWRlcHRcIj7wn5ONIHt1c2VyPy5kZXBhcnRtZW50IHx8ICdEZXB0LiBVbmFzc2lnbmVkJ30gwrcge3VzZXI/LmFjYWRlbWljSW5mbz8ueWVhciA/IGBZZWFyICR7dXNlci5hY2FkZW1pY0luZm8ueWVhcn1gIDogJ1llYXIgTi9BJ308L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGgtY2hpcHNcIj5cclxuICAgICAgICAgICAgeyh1c2VyPy5zcGVjaWFsaXphdGlvbiB8fCB1c2VyPy5hY2FkZW1pY0luZm8/LnNwZWNpYWxpemF0aW9uKSAmJiA8c3BhbiBjbGFzc05hbWU9XCJwaC1jaGlwXCI+8J+OkyB7dXNlci5zcGVjaWFsaXphdGlvbiB8fCB1c2VyLmFjYWRlbWljSW5mby5zcGVjaWFsaXphdGlvbn08L3NwYW4+fVxyXG4gICAgICAgICAgICB7dXNlcj8uYXZhaWxhYmlsaXR5Py53ZWVrbHlIb3VycyAmJiA8c3BhbiBjbGFzc05hbWU9XCJwaC1jaGlwXCI+4o+wIHt1c2VyLmF2YWlsYWJpbGl0eS53ZWVrbHlIb3Vyc30gaHJzL3dlZWs8L3NwYW4+fVxyXG4gICAgICAgICAgICB7dXNlcj8uYXZhaWxhYmlsaXR5Py5wcmVmZXJyZWREYXlzPy5sZW5ndGggPiAwICYmIDxzcGFuIGNsYXNzTmFtZT1cInBoLWNoaXBcIj7wn5+iIEF2YWlsYWJsZTwvc3Bhbj59XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBoLWFjdGlvbnNcIj5cclxuICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYnRuIGJ0bi1naG9zdCBidG4tc21cIiBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZSgnL2VkaXQtcHJvZmlsZScpfT7inI/vuI8gRWRpdDwvYnV0dG9uPlxyXG4gICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJidG4gYnRuLWdob3N0IGJ0bi1zbVwiIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKCcvcHJvZmlsZScpfT7wn5GB77iPIFByZXZpZXc8L2J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIFxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInN0YXRzLXJvd1wiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3RhdC1jYXJkLXNtXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNjLWxhYmVsXCI+U2tpbGxzIExpc3RlZDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzYy12YWx1ZVwiPlxyXG4gICAgICAgICAgICB7KHVzZXI/LnNraWxscz8ubGFuZ3VhZ2VzPy5sZW5ndGggfHwgMCkgKyAodXNlcj8uc2tpbGxzPy5mcmFtZXdvcmtzPy5sZW5ndGggfHwgMCkgKyAodXNlcj8uc2tpbGxzPy50b29scz8ubGVuZ3RoIHx8IDApICsgKHVzZXI/LnNraWxscz8uZGF0YWJhc2VzPy5sZW5ndGggfHwgMCkgKyAodXNlcj8uc2tpbGxzPy5saWJyYXJpZXM/Lmxlbmd0aCB8fCAwKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzYy1zdWJcIj5BZGQgbW9yZSB0byBtYXRjaCBiZXR0ZXI8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN0YXQtY2FyZC1zbVwiPjxkaXYgY2xhc3NOYW1lPVwic2MtbGFiZWxcIj5Qcm9qZWN0cyBBcHBsaWVkPC9kaXY+PGRpdiBjbGFzc05hbWU9XCJzYy12YWx1ZVwiPjA8L2Rpdj48ZGl2IGNsYXNzTmFtZT1cInNjLXN1YlwiPjAgYWNjZXB0ZWQgwrcgMCBwZW5kaW5nPC9kaXY+PC9kaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdGF0LWNhcmQtc21cIj48ZGl2IGNsYXNzTmFtZT1cInNjLWxhYmVsXCI+TWF0Y2ggU2NvcmUgQXZnPC9kaXY+PGRpdiBjbGFzc05hbWU9XCJzYy12YWx1ZVwiPk4vQTwvZGl2PjxkaXYgY2xhc3NOYW1lPVwic2Mtc3ViXCI+TmV3IFByb2ZpbGU8L2Rpdj48L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIFxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImFpLWJhbm5lclwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWktYmFubmVyLWljb25cIj7wn6SWPC9kaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhaS1iYW5uZXItYm9keVwiPlxyXG4gICAgICAgICAgPGg0PkFJIFNraWxsIFN1Z2dlc3Rpb25zIMK3IFdlYiBEZXZlbG9wbWVudCBEb21haW48L2g0PlxyXG4gICAgICAgICAgPHA+QmFzZWQgb24geW91ciBza2lsbHMsIHlvdSBtYXkgYWxzbyBrbm93IHRoZXNlLiBDbGljayB0byBhZGQ6PC9wPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhaS10YWdzXCI+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImFpLXRhZ1wiPisgVHlwZVNjcmlwdDwvc3Bhbj5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYWktdGFnXCI+KyBSRVNUIEFQSXM8L3NwYW4+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImFpLXRhZ1wiPisgR2l0ICYgR2l0SHViPC9zcGFuPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhaS10YWdcIj4rIFRhaWx3aW5kIENTUzwvc3Bhbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZC0yXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkIGNhcmQtc21cIiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGZsZXhEaXJlY3Rpb246ICdjb2x1bW4nLCBnYXA6ICcuNnJlbScgfX0+XHJcbiAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnRGYW1pbHk6IFwiJ1NvcmEnLCBzYW5zLXNlcmlmXCIsIGZvbnRTaXplOiAnLjk1cmVtJywgZm9udFdlaWdodDogNzAwLCBtYXJnaW5Cb3R0b206ICcuMjVyZW0nIH19PvCflJQgUmVjZW50IFJlcXVlc3RzPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnRTaXplOiAnLjg1cmVtJywgY29sb3I6ICd2YXIoLS1taWQpJywgcGFkZGluZzogJzFyZW0nLCB0ZXh0QWxpZ246ICdjZW50ZXInLCBiYWNrZ3JvdW5kOiAndmFyKC0tYmcpJywgYm9yZGVyUmFkaXVzOiAnMTBweCcgfX0+XHJcbiAgICAgICAgICAgIE5vIHJlY2VudCByZXF1ZXN0cyBjdXJyZW50bHkuXHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQgY2FyZC1zbVwiPlxyXG4gICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250RmFtaWx5OiBcIidTb3JhJywgc2Fucy1zZXJpZlwiLCBmb250U2l6ZTogJy45NXJlbScsIGZvbnRXZWlnaHQ6IDcwMCwgbWFyZ2luQm90dG9tOiAnLjc1cmVtJyB9fT7imqEgUXVpY2sgQWN0aW9uczwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGZsZXhEaXJlY3Rpb246ICdjb2x1bW4nLCBnYXA6ICcuNXJlbScgfX0+XHJcbiAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYnRuIGJ0bi1vdXRsaW5lIGJ0bi1mdWxsXCIgc3R5bGU9e3sgY29sb3I6ICd2YXIoLS1taWQpJyB9fSBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZSgnL3Byb2ZpbGUnKX0gdHlwZT1cImJ1dHRvblwiPvCfk4sgQnJvd3NlIFByb2plY3RzPC9idXR0b24+XHJcbiAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYnRuIGJ0bi1vdXRsaW5lIGJ0bi1mdWxsXCIgc3R5bGU9e3sgY29sb3I6ICd2YXIoLS1taWQpJyB9fSBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZSgnL3JlY3Byb2plY3RzJyl9IHR5cGU9XCJidXR0b25cIj7irZAgVmlldyBNYXRjaGVzPC9idXR0b24+XHJcbiAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYnRuIGJ0bi1wcmltYXJ5IGJ0bi1mdWxsXCIgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoJy9lZGl0LXByb2ZpbGUnKX0gdHlwZT1cImJ1dHRvblwiPuKcj++4jyBFZGl0IE15IFByb2ZpbGU8L2J1dHRvbj5cclxuICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJidG4gYnRuLW91dGxpbmUgYnRuLWZ1bGxcIiBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZSgnL3Byb2ZpbGUnKX0gdHlwZT1cImJ1dHRvblwiPvCfkYHvuI8gUHJldmlldyBQcm9maWxlPC9idXR0b24+XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IERhc2hib2FyZDtcclxuIl0sImZpbGUiOiJGOi9ZM1MyL0lUUE0gcHJvamVjdC9Qcm9NYXRlLS1Qcm9qZWN0LVBhcnRuZXItRmluZGVyL2Zyb250ZW5kL3NyYy9wYWdlcy9Vc2Vycy9EYXNoYm9hcmQuanN4In0=