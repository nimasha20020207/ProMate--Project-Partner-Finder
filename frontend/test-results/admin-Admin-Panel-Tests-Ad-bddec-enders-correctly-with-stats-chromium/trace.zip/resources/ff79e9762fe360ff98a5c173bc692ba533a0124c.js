import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Admin/Admindashboard.jsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Admindashboard.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=383bea9f"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import axios from "/node_modules/.vite/deps/axios.js?v=383bea9f";
import AdminNavbar from "/src/components/AdminNavbar.jsx";
import { Users, Folder, Bell, Clock } from "/node_modules/.vite/deps/lucide-react.js?v=383bea9f";
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from "/node_modules/.vite/deps/recharts.js?v=383bea9f";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=383bea9f";
import { useAuth } from "/src/context/AuthContext.jsx";
const Admindashboard = () => {
  _s();
  const {
    token
  } = useAuth();
  const [report, setReport] = useState({});
  useEffect(() => {
    axios.get("http://localhost:3000/api/admin/reports", {
      headers: {
        "x-auth-token": token
      }
    }).then((res) => setReport(res.data)).catch((err) => console.log(err));
  }, [token]);
  const userStats = [{
    name: "Active Users",
    value: 70
  }, {
    name: "Inactive Users",
    value: 30
  }];
  const COLORS = ["#3B82F6", "#F472B6"];
  const feedbacks = [{
    id: 1,
    name: "John Doe",
    message: "Great platform!",
    date: "2h ago"
  }, {
    id: 2,
    name: "Sarah",
    message: "Easy to find teammates.",
    date: "5h ago"
  }, {
    id: 3,
    name: "Michael",
    message: "UI looks clean 👍",
    date: "1d ago"
  }];
  return /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-screen bg-gradient-to-br from-slate-50 to-slate-100", children: /* @__PURE__ */ jsxDEV("div", { className: "flex-1 p-8", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "mb-6", children: /* @__PURE__ */ jsxDEV("h2", { className: "text-3xl font-bold text-textSecondary", children: "Welcome back! Here's what's happening today." }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Admindashboard.jsx",
      lineNumber: 60,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Admindashboard.jsx",
      lineNumber: 59,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "relative p-6 rounded-2xl bg-gradient-to-br from-primary to-blue-200 text-white shadow-lg hover:scale-[1.02] transition", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "absolute top-4 right-4 opacity-20", children: /* @__PURE__ */ jsxDEV(Users, { size: 60 }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Admindashboard.jsx",
          lineNumber: 71,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Admindashboard.jsx",
          lineNumber: 70,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("h2", { className: "text-sm uppercase tracking-wide font-bold", children: "New Users" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Admindashboard.jsx",
          lineNumber: 73,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-4xl font-bold mt-2", children: report.totalStudents || 0 }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Admindashboard.jsx",
          lineNumber: 74,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Admindashboard.jsx",
        lineNumber: 69,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "relative p-6 rounded-2xl bg-gradient-to-br from-secondary to-pink-200 text-white shadow-lg hover:scale-[1.02] transition", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "absolute top-4 right-4 opacity-20", children: /* @__PURE__ */ jsxDEV(Folder, { size: 60 }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Admindashboard.jsx",
          lineNumber: 82,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Admindashboard.jsx",
          lineNumber: 81,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("h2", { className: "text-sm uppercase tracking-wide font-bold text-textPrimary", children: "New Projects" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Admindashboard.jsx",
          lineNumber: 84,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-4xl font-bold mt-2 text-textPrimary", children: report.totalProjects || 0 }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Admindashboard.jsx",
          lineNumber: 85,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Admindashboard.jsx",
        lineNumber: 80,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "relative p-6 rounded-2xl bg-gradient-to-br from-accent to-yellow-200 text-black shadow-lg hover:scale-[1.02] transition", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "absolute top-4 right-4 opacity-20", children: /* @__PURE__ */ jsxDEV(Bell, { size: 60 }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Admindashboard.jsx",
          lineNumber: 93,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Admindashboard.jsx",
          lineNumber: 92,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("h2", { className: "text-sm uppercase tracking-wide font-bold", children: "All Requests" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Admindashboard.jsx",
          lineNumber: 95,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-4xl font-bold mt-2", children: report.totalRequests || 0 }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Admindashboard.jsx",
          lineNumber: 96,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Admindashboard.jsx",
        lineNumber: 91,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "relative p-6 rounded-2xl bg-gradient-to-br from-indigo-500 to-indigo-200 text-white shadow-lg hover:scale-[1.02] transition", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "absolute top-4 right-4 opacity-20", children: /* @__PURE__ */ jsxDEV(Clock, { size: 60 }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Admindashboard.jsx",
          lineNumber: 104,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Admindashboard.jsx",
          lineNumber: 103,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("h2", { className: "text-sm uppercase tracking-wide font-bold", children: "Pending Requests" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Admindashboard.jsx",
          lineNumber: 106,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-4xl font-bold mt-2", children: report.pendingRequests || 0 }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Admindashboard.jsx",
          lineNumber: 107,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Admindashboard.jsx",
        lineNumber: 102,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Admindashboard.jsx",
      lineNumber: 66,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 lg:grid-cols-2 gap-6 mt-8", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "p-6 rounded-2xl bg-white/70 backdrop-blur-xl shadow-xl border border-white/40", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-semibold mb-4 text-textPrimary", children: "User Activity" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Admindashboard.jsx",
          lineNumber: 119,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(ResponsiveContainer, { width: "100%", height: 260, children: /* @__PURE__ */ jsxDEV(PieChart, { children: [
          /* @__PURE__ */ jsxDEV(Pie, { data: userStats, cx: "50%", cy: "50%", outerRadius: 90, dataKey: "value", label: ({
            percent
          }) => `${(percent * 100).toFixed(0)}%`, children: userStats.map((entry, index) => /* @__PURE__ */ jsxDEV(Cell, { fill: COLORS[index] }, index, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Admindashboard.jsx",
            lineNumber: 128,
            columnNumber: 50
          }, this)) }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Admindashboard.jsx",
            lineNumber: 125,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Tooltip, {}, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Admindashboard.jsx",
            lineNumber: 130,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Admindashboard.jsx",
          lineNumber: 124,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Admindashboard.jsx",
          lineNumber: 123,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-6 mt-4 text-sm", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "w-3 h-3 bg-primary rounded-full" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Admindashboard.jsx",
              lineNumber: 137,
              columnNumber: 15
            }, this),
            "Active"
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Admindashboard.jsx",
            lineNumber: 136,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "w-3 h-3 bg-secondary rounded-full" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Admindashboard.jsx",
              lineNumber: 141,
              columnNumber: 15
            }, this),
            "Inactive"
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Admindashboard.jsx",
            lineNumber: 140,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Admindashboard.jsx",
          lineNumber: 135,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Admindashboard.jsx",
        lineNumber: 118,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-6 rounded-2xl bg-white/70 backdrop-blur-xl shadow-xl border border-white/40", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-4", children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-semibold text-textPrimary", children: "Latest Feedbacks" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Admindashboard.jsx",
            lineNumber: 151,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Link, { to: "/adminfeedbacks", className: "text-sm text-primary font-medium hover:underline", children: "View All →" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Admindashboard.jsx",
            lineNumber: 155,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Admindashboard.jsx",
          lineNumber: 150,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "space-y-4 max-h-72 overflow-y-auto", children: feedbacks.map((fb) => /* @__PURE__ */ jsxDEV("div", { className: "p-4 rounded-xl bg-gradient-to-r from-accent/10 to-secondary/10 hover:shadow-lg transition", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-1", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-textPrimary", children: fb.name }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Admindashboard.jsx",
              lineNumber: 164,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-textSecondary", children: fb.date }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Admindashboard.jsx",
              lineNumber: 167,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Admindashboard.jsx",
            lineNumber: 163,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-textSecondary", children: fb.message }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Admindashboard.jsx",
            lineNumber: 172,
            columnNumber: 17
          }, this)
        ] }, fb.id, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Admindashboard.jsx",
          lineNumber: 162,
          columnNumber: 34
        }, this)) }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Admindashboard.jsx",
          lineNumber: 160,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Admindashboard.jsx",
        lineNumber: 148,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Admindashboard.jsx",
      lineNumber: 115,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Admindashboard.jsx",
    lineNumber: 56,
    columnNumber: 5
  }, this) }, void 0, false, {
    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Admindashboard.jsx",
    lineNumber: 50,
    columnNumber: 10
  }, this);
};
_s(Admindashboard, "IvPDSgLcgeGzSVWMAnhYWTrtftI=", false, function() {
  return [useAuth];
});
_c = Admindashboard;
export default Admindashboard;
var _c;
$RefreshReg$(_c, "Admindashboard");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Admindashboard.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcURROzs7Ozs7Ozs7Ozs7Ozs7O0FBckRSLE9BQU9BLFNBQVNDLFVBQVVDLGlCQUFpQjtBQUMzQyxPQUFPQyxXQUFXO0FBQ2xCLE9BQU9DLGlCQUFpQjtBQUN4QixTQUFTQyxPQUFPQyxRQUFRQyxNQUFNQyxhQUFhO0FBQzNDLFNBQ0VDLFVBQ0FDLEtBQ0FDLE1BQ0FDLFNBQ0FDLDJCQUNLO0FBQ1AsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyxlQUFlO0FBRXhCLE1BQU1DLGlCQUFpQkEsTUFBTTtBQUFBQyxLQUFBO0FBQzNCLFFBQU07QUFBQSxJQUFFQztBQUFBQSxFQUFNLElBQUlILFFBQVE7QUFDMUIsUUFBTSxDQUFDSSxRQUFRQyxTQUFTLElBQUluQixTQUFTLENBQUMsQ0FBQztBQUV2Q0MsWUFBVSxNQUFNO0FBQ2RDLFVBQ0drQixJQUFJLDJDQUEyQztBQUFBLE1BQzlDQyxTQUFTO0FBQUEsUUFBRSxnQkFBZ0JKO0FBQUFBLE1BQU07QUFBQSxJQUNuQyxDQUFDLEVBQ0FLLEtBQU1DLFNBQVFKLFVBQVVJLElBQUlDLElBQUksQ0FBQyxFQUNqQ0MsTUFBT0MsU0FBUUMsUUFBUUMsSUFBSUYsR0FBRyxDQUFDO0FBQUEsRUFDcEMsR0FBRyxDQUFDVCxLQUFLLENBQUM7QUFHVixRQUFNWSxZQUFZLENBQ2hCO0FBQUEsSUFBRUMsTUFBTTtBQUFBLElBQWdCQyxPQUFPO0FBQUEsRUFBRyxHQUNsQztBQUFBLElBQUVELE1BQU07QUFBQSxJQUFrQkMsT0FBTztBQUFBLEVBQUcsQ0FBQztBQUd2QyxRQUFNQyxTQUFTLENBQUMsV0FBVyxTQUFTO0FBR3BDLFFBQU1DLFlBQVksQ0FDaEI7QUFBQSxJQUFFQyxJQUFJO0FBQUEsSUFBR0osTUFBTTtBQUFBLElBQVlLLFNBQVM7QUFBQSxJQUFtQkMsTUFBTTtBQUFBLEVBQVMsR0FDdEU7QUFBQSxJQUFFRixJQUFJO0FBQUEsSUFBR0osTUFBTTtBQUFBLElBQVNLLFNBQVM7QUFBQSxJQUEyQkMsTUFBTTtBQUFBLEVBQVMsR0FDM0U7QUFBQSxJQUFFRixJQUFJO0FBQUEsSUFBR0osTUFBTTtBQUFBLElBQVdLLFNBQVM7QUFBQSxJQUFxQkMsTUFBTTtBQUFBLEVBQVMsQ0FBQztBQUcxRSxTQUNFLHVCQUFDLFNBQUksV0FBVSxrRUFNZixpQ0FBQyxTQUFJLFdBQVUsY0FHYjtBQUFBLDJCQUFDLFNBQUksV0FBVSxRQUNiLGlDQUFDLFFBQUcsV0FBVSx5Q0FBd0MsNERBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLHlDQUdiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLDBIQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHFDQUNiLGlDQUFDLFNBQU0sTUFBTSxNQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0IsS0FEbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxRQUFHLFdBQVUsNkNBQTRDLHlCQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1FO0FBQUEsUUFDbkUsdUJBQUMsT0FBRSxXQUFVLDJCQUNWbEIsaUJBQU9tQixpQkFBaUIsS0FEM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUE7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSw0SEFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxxQ0FDYixpQ0FBQyxVQUFPLE1BQU0sTUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlCLEtBRG5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsUUFBRyxXQUFVLDhEQUE2RCw0QkFBM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1RjtBQUFBLFFBQ3ZGLHVCQUFDLE9BQUUsV0FBVSw0Q0FDVm5CLGlCQUFPb0IsaUJBQWlCLEtBRDNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsMkhBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUscUNBQ2IsaUNBQUMsUUFBSyxNQUFNLE1BQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFlLEtBRGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsUUFBRyxXQUFVLDZDQUE0Qyw0QkFBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzRTtBQUFBLFFBQ3RFLHVCQUFDLE9BQUUsV0FBVSwyQkFDVnBCLGlCQUFPcUIsaUJBQWlCLEtBRDNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsK0hBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUscUNBQ2IsaUNBQUMsU0FBTSxNQUFNLE1BQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnQixLQURsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFFBQUcsV0FBVSw2Q0FBNEMsZ0NBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEU7QUFBQSxRQUMxRSx1QkFBQyxPQUFFLFdBQVUsMkJBQ1ZyQixpQkFBT3NCLG1CQUFtQixLQUQ3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQTtBQUFBLFNBNUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E4Q0E7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSw4Q0FHYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxpRkFDYjtBQUFBLCtCQUFDLFFBQUcsV0FBVSwrQ0FBOEMsNkJBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBRUEsdUJBQUMsdUJBQW9CLE9BQU0sUUFBTyxRQUFRLEtBQ3hDLGlDQUFDLFlBQ0M7QUFBQSxpQ0FBQyxPQUNDLE1BQU1YLFdBQ04sSUFBRyxPQUNILElBQUcsT0FDSCxhQUFhLElBQ2IsU0FBUSxTQUNSLE9BQU8sQ0FBQztBQUFBLFlBQUVZO0FBQUFBLFVBQVEsTUFDaEIsSUFBSUEsVUFBVSxLQUFLQyxRQUFRLENBQUMsQ0FBQyxLQUc5QmIsb0JBQVVjLElBQUksQ0FBQ0MsT0FBT0MsVUFDckIsdUJBQUMsUUFBaUIsTUFBTWIsT0FBT2EsS0FBSyxLQUF6QkEsT0FBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzQyxDQUN2QyxLQVpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBYUE7QUFBQSxVQUNBLHVCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBUTtBQUFBLGFBZlY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWdCQSxLQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBa0JBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxpQ0FBQyxVQUFLLFdBQVUsMkJBQ2Q7QUFBQSxtQ0FBQyxTQUFJLFdBQVUscUNBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUQ7QUFBQSxZQUFNO0FBQUEsZUFEekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsVUFBSyxXQUFVLDJCQUNkO0FBQUEsbUNBQUMsU0FBSSxXQUFVLHVDQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1EO0FBQUEsWUFBTTtBQUFBLGVBRDNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFTQTtBQUFBLFdBbkNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFvQ0E7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSxpRkFFYjtBQUFBLCtCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLGlDQUFDLFFBQUcsV0FBVSwwQ0FBeUMsZ0NBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUVBLHVCQUFDLFFBQ0MsSUFBRyxtQkFDSCxXQUFVLG9EQUNYLDBCQUhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxhQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFXQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLHNDQUVaWixvQkFBVVUsSUFBS0csUUFDZCx1QkFBQyxTQUVDLFdBQVUsNkZBRVY7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxtQ0FBQyxPQUFFLFdBQVUsa0NBQ1ZBLGFBQUdoQixRQUROO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFVBQUssV0FBVSw4QkFDYmdCLGFBQUdWLFFBRE47QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLFVBRUEsdUJBQUMsT0FBRSxXQUFVLDhCQUNWVSxhQUFHWCxXQUROO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQWRLVyxHQUFHWixJQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFnQkEsQ0FDRCxLQXBCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBc0JBO0FBQUEsV0FyQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXNDQTtBQUFBLFNBaEZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FrRkE7QUFBQSxPQTdJRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBK0lBLEtBckpBO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FzSkY7QUFFRjtBQUFFbEIsR0FyTElELGdCQUFjO0FBQUEsVUFDQUQsT0FBTztBQUFBO0FBQUFpQyxLQURyQmhDO0FBdUxOLGVBQWVBO0FBQWUsSUFBQWdDO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsInVzZVN0YXRlIiwidXNlRWZmZWN0IiwiYXhpb3MiLCJBZG1pbk5hdmJhciIsIlVzZXJzIiwiRm9sZGVyIiwiQmVsbCIsIkNsb2NrIiwiUGllQ2hhcnQiLCJQaWUiLCJDZWxsIiwiVG9vbHRpcCIsIlJlc3BvbnNpdmVDb250YWluZXIiLCJMaW5rIiwidXNlQXV0aCIsIkFkbWluZGFzaGJvYXJkIiwiX3MiLCJ0b2tlbiIsInJlcG9ydCIsInNldFJlcG9ydCIsImdldCIsImhlYWRlcnMiLCJ0aGVuIiwicmVzIiwiZGF0YSIsImNhdGNoIiwiZXJyIiwiY29uc29sZSIsImxvZyIsInVzZXJTdGF0cyIsIm5hbWUiLCJ2YWx1ZSIsIkNPTE9SUyIsImZlZWRiYWNrcyIsImlkIiwibWVzc2FnZSIsImRhdGUiLCJ0b3RhbFN0dWRlbnRzIiwidG90YWxQcm9qZWN0cyIsInRvdGFsUmVxdWVzdHMiLCJwZW5kaW5nUmVxdWVzdHMiLCJwZXJjZW50IiwidG9GaXhlZCIsIm1hcCIsImVudHJ5IiwiaW5kZXgiLCJmYiIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQWRtaW5kYXNoYm9hcmQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBheGlvcyBmcm9tIFwiYXhpb3NcIjtcclxuaW1wb3J0IEFkbWluTmF2YmFyIGZyb20gXCIuLi8uLi9jb21wb25lbnRzL0FkbWluTmF2YmFyXCI7XHJcbmltcG9ydCB7IFVzZXJzLCBGb2xkZXIsIEJlbGwsIENsb2NrIH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xyXG5pbXBvcnQge1xyXG4gIFBpZUNoYXJ0LFxyXG4gIFBpZSxcclxuICBDZWxsLFxyXG4gIFRvb2x0aXAsXHJcbiAgUmVzcG9uc2l2ZUNvbnRhaW5lcixcclxufSBmcm9tIFwicmVjaGFydHNcIjtcclxuaW1wb3J0IHsgTGluayB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tIFwiLi4vLi4vY29udGV4dC9BdXRoQ29udGV4dFwiO1xyXG5cclxuY29uc3QgQWRtaW5kYXNoYm9hcmQgPSAoKSA9PiB7XHJcbiAgY29uc3QgeyB0b2tlbiB9ID0gdXNlQXV0aCgpO1xyXG4gIGNvbnN0IFtyZXBvcnQsIHNldFJlcG9ydF0gPSB1c2VTdGF0ZSh7fSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBheGlvc1xyXG4gICAgICAuZ2V0KFwiaHR0cDovL2xvY2FsaG9zdDozMDAwL2FwaS9hZG1pbi9yZXBvcnRzXCIsIHtcclxuICAgICAgICBoZWFkZXJzOiB7IFwieC1hdXRoLXRva2VuXCI6IHRva2VuIH0sXHJcbiAgICAgIH0pXHJcbiAgICAgIC50aGVuKChyZXMpID0+IHNldFJlcG9ydChyZXMuZGF0YSkpXHJcbiAgICAgIC5jYXRjaCgoZXJyKSA9PiBjb25zb2xlLmxvZyhlcnIpKTtcclxuICB9LCBbdG9rZW5dKTtcclxuXHJcbiAgLy8g8J+UtSBEdW1teSBQaWUgRGF0YVxyXG4gIGNvbnN0IHVzZXJTdGF0cyA9IFtcclxuICAgIHsgbmFtZTogXCJBY3RpdmUgVXNlcnNcIiwgdmFsdWU6IDcwIH0sXHJcbiAgICB7IG5hbWU6IFwiSW5hY3RpdmUgVXNlcnNcIiwgdmFsdWU6IDMwIH0sXHJcbiAgXTtcclxuXHJcbiAgY29uc3QgQ09MT1JTID0gW1wiIzNCODJGNlwiLCBcIiNGNDcyQjZcIl07XHJcblxyXG4gIC8vIPCfn6EgRHVtbXkgRmVlZGJhY2tzXHJcbiAgY29uc3QgZmVlZGJhY2tzID0gW1xyXG4gICAgeyBpZDogMSwgbmFtZTogXCJKb2huIERvZVwiLCBtZXNzYWdlOiBcIkdyZWF0IHBsYXRmb3JtIVwiLCBkYXRlOiBcIjJoIGFnb1wiIH0sXHJcbiAgICB7IGlkOiAyLCBuYW1lOiBcIlNhcmFoXCIsIG1lc3NhZ2U6IFwiRWFzeSB0byBmaW5kIHRlYW1tYXRlcy5cIiwgZGF0ZTogXCI1aCBhZ29cIiB9LFxyXG4gICAgeyBpZDogMywgbmFtZTogXCJNaWNoYWVsXCIsIG1lc3NhZ2U6IFwiVUkgbG9va3MgY2xlYW4g8J+RjVwiLCBkYXRlOiBcIjFkIGFnb1wiIH0sXHJcbiAgXTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtaW4taC1zY3JlZW4gYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1zbGF0ZS01MCB0by1zbGF0ZS0xMDBcIj5cclxuICAgIFxyXG4gICAgey8qIFNpZGViYXJcclxuICAgIDxBZG1pbk5hdmJhciAvPiAqL31cclxuXHJcbiAgICB7LyogTWFpbiBDb250ZW50ICovfVxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgcC04XCI+XHJcblxyXG4gICAgICB7Lyog8J+UtyBIZWFkZXIgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNlwiPlxyXG4gICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWJvbGQgdGV4dC10ZXh0U2Vjb25kYXJ5XCI+XHJcbiAgICAgICAgICBXZWxjb21lIGJhY2shIEhlcmUncyB3aGF0J3MgaGFwcGVuaW5nIHRvZGF5LlxyXG4gICAgICAgIDwvaDI+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgey8qIPCflLcgU3RhdCBDYXJkcyAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC02XCI+XHJcblxyXG4gICAgICAgIHsvKiBTdHVkZW50cyAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHAtNiByb3VuZGVkLTJ4bCBiZy1ncmFkaWVudC10by1iciBmcm9tLXByaW1hcnkgdG8tYmx1ZS0yMDAgdGV4dC13aGl0ZSBzaGFkb3ctbGcgaG92ZXI6c2NhbGUtWzEuMDJdIHRyYW5zaXRpb25cIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTQgcmlnaHQtNCBvcGFjaXR5LTIwXCI+XHJcbiAgICAgICAgICAgIDxVc2VycyBzaXplPXs2MH0gLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtc20gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgZm9udC1ib2xkXCI+TmV3IFVzZXJzPC9oMj5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtNHhsIGZvbnQtYm9sZCBtdC0yXCI+XHJcbiAgICAgICAgICAgIHtyZXBvcnQudG90YWxTdHVkZW50cyB8fCAwfVxyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogUHJvamVjdHMgKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBwLTYgcm91bmRlZC0yeGwgYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1zZWNvbmRhcnkgdG8tcGluay0yMDAgdGV4dC13aGl0ZSBzaGFkb3ctbGcgaG92ZXI6c2NhbGUtWzEuMDJdIHRyYW5zaXRpb25cIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTQgcmlnaHQtNCBvcGFjaXR5LTIwXCI+XHJcbiAgICAgICAgICAgIDxGb2xkZXIgc2l6ZT17NjB9IC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIGZvbnQtYm9sZCB0ZXh0LXRleHRQcmltYXJ5XCI+TmV3IFByb2plY3RzPC9oMj5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtNHhsIGZvbnQtYm9sZCBtdC0yIHRleHQtdGV4dFByaW1hcnlcIj5cclxuICAgICAgICAgICAge3JlcG9ydC50b3RhbFByb2plY3RzIHx8IDB9XHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHsvKiBSZXF1ZXN0cyAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHAtNiByb3VuZGVkLTJ4bCBiZy1ncmFkaWVudC10by1iciBmcm9tLWFjY2VudCB0by15ZWxsb3ctMjAwIHRleHQtYmxhY2sgc2hhZG93LWxnIGhvdmVyOnNjYWxlLVsxLjAyXSB0cmFuc2l0aW9uXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC00IHJpZ2h0LTQgb3BhY2l0eS0yMFwiPlxyXG4gICAgICAgICAgICA8QmVsbCBzaXplPXs2MH0gLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtc20gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgZm9udC1ib2xkXCI+QWxsIFJlcXVlc3RzPC9oMj5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtNHhsIGZvbnQtYm9sZCBtdC0yXCI+XHJcbiAgICAgICAgICAgIHtyZXBvcnQudG90YWxSZXF1ZXN0cyB8fCAwfVxyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogUGVuZGluZyAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHAtNiByb3VuZGVkLTJ4bCBiZy1ncmFkaWVudC10by1iciBmcm9tLWluZGlnby01MDAgdG8taW5kaWdvLTIwMCB0ZXh0LXdoaXRlIHNoYWRvdy1sZyBob3ZlcjpzY2FsZS1bMS4wMl0gdHJhbnNpdGlvblwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtNCByaWdodC00IG9wYWNpdHktMjBcIj5cclxuICAgICAgICAgICAgPENsb2NrIHNpemU9ezYwfSAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1zbSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSBmb250LWJvbGRcIj5QZW5kaW5nIFJlcXVlc3RzPC9oMj5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtNHhsIGZvbnQtYm9sZCBtdC0yXCI+XHJcbiAgICAgICAgICAgIHtyZXBvcnQucGVuZGluZ1JlcXVlc3RzIHx8IDB9XHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiDwn5S7IEJvdHRvbSBTZWN0aW9uICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbGc6Z3JpZC1jb2xzLTIgZ2FwLTYgbXQtOFwiPlxyXG5cclxuICAgICAgICB7Lyog8J+UtSBDaGFydCBDYXJkICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02IHJvdW5kZWQtMnhsIGJnLXdoaXRlLzcwIGJhY2tkcm9wLWJsdXIteGwgc2hhZG93LXhsIGJvcmRlciBib3JkZXItd2hpdGUvNDBcIj5cclxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgbWItNCB0ZXh0LXRleHRQcmltYXJ5XCI+XHJcbiAgICAgICAgICAgIFVzZXIgQWN0aXZpdHlcclxuICAgICAgICAgIDwvaDI+XHJcblxyXG4gICAgICAgICAgPFJlc3BvbnNpdmVDb250YWluZXIgd2lkdGg9XCIxMDAlXCIgaGVpZ2h0PXsyNjB9PlxyXG4gICAgICAgICAgICA8UGllQ2hhcnQ+XHJcbiAgICAgICAgICAgICAgPFBpZVxyXG4gICAgICAgICAgICAgICAgZGF0YT17dXNlclN0YXRzfVxyXG4gICAgICAgICAgICAgICAgY3g9XCI1MCVcIlxyXG4gICAgICAgICAgICAgICAgY3k9XCI1MCVcIlxyXG4gICAgICAgICAgICAgICAgb3V0ZXJSYWRpdXM9ezkwfVxyXG4gICAgICAgICAgICAgICAgZGF0YUtleT1cInZhbHVlXCJcclxuICAgICAgICAgICAgICAgIGxhYmVsPXsoeyBwZXJjZW50IH0pID0+XHJcbiAgICAgICAgICAgICAgICAgIGAkeyhwZXJjZW50ICogMTAwKS50b0ZpeGVkKDApfSVgXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAge3VzZXJTdGF0cy5tYXAoKGVudHJ5LCBpbmRleCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8Q2VsbCBrZXk9e2luZGV4fSBmaWxsPXtDT0xPUlNbaW5kZXhdfSAvPlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgPC9QaWU+XHJcbiAgICAgICAgICAgICAgPFRvb2x0aXAgLz5cclxuICAgICAgICAgICAgPC9QaWVDaGFydD5cclxuICAgICAgICAgIDwvUmVzcG9uc2l2ZUNvbnRhaW5lcj5cclxuXHJcbiAgICAgICAgICB7LyogTGVnZW5kICovfVxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIGdhcC02IG10LTQgdGV4dC1zbVwiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0zIGgtMyBiZy1wcmltYXJ5IHJvdW5kZWQtZnVsbFwiPjwvZGl2PlxyXG4gICAgICAgICAgICAgIEFjdGl2ZVxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTMgaC0zIGJnLXNlY29uZGFyeSByb3VuZGVkLWZ1bGxcIj48L2Rpdj5cclxuICAgICAgICAgICAgICBJbmFjdGl2ZVxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgey8qIPCfn6EgRmVlZGJhY2sgUGFuZWwgKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTYgcm91bmRlZC0yeGwgYmctd2hpdGUvNzAgYmFja2Ryb3AtYmx1ci14bCBzaGFkb3cteGwgYm9yZGVyIGJvcmRlci13aGl0ZS80MFwiPlxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBtYi00XCI+XHJcbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC10ZXh0UHJpbWFyeVwiPlxyXG4gICAgICAgICAgICAgIExhdGVzdCBGZWVkYmFja3NcclxuICAgICAgICAgICAgPC9oMj5cclxuXHJcbiAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgdG89XCIvYWRtaW5mZWVkYmFja3NcIlxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1wcmltYXJ5IGZvbnQtbWVkaXVtIGhvdmVyOnVuZGVybGluZVwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICBWaWV3IEFsbCDihpJcclxuICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTQgbWF4LWgtNzIgb3ZlcmZsb3cteS1hdXRvXCI+XHJcblxyXG4gICAgICAgICAgICB7ZmVlZGJhY2tzLm1hcCgoZmIpID0+IChcclxuICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICBrZXk9e2ZiLmlkfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC00IHJvdW5kZWQteGwgYmctZ3JhZGllbnQtdG8tciBmcm9tLWFjY2VudC8xMCB0by1zZWNvbmRhcnkvMTAgaG92ZXI6c2hhZG93LWxnIHRyYW5zaXRpb25cIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXRleHRQcmltYXJ5XCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2ZiLm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXRleHRTZWNvbmRhcnlcIj5cclxuICAgICAgICAgICAgICAgICAgICB7ZmIuZGF0ZX1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXRleHRTZWNvbmRhcnlcIj5cclxuICAgICAgICAgICAgICAgICAge2ZiLm1lc3NhZ2V9XHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICkpfVxyXG5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgPC9kaXY+XHJcbiAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IEFkbWluZGFzaGJvYXJkOyJdLCJmaWxlIjoiRjovWTNTMi9JVFBNIHByb2plY3QvUHJvTWF0ZS0tUHJvamVjdC1QYXJ0bmVyLUZpbmRlci9mcm9udGVuZC9zcmMvcGFnZXMvQWRtaW4vQWRtaW5kYXNoYm9hcmQuanN4In0=