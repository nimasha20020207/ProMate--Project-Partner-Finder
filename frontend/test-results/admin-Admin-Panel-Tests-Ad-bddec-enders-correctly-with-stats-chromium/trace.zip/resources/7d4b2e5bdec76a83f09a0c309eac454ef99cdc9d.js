import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/RecEngine/RecProjects.jsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/RecProjects.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=383bea9f"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Navbar from "/src/components/Navbar.jsx";
const ProjectRecommendations = () => {
  _s();
  const [projects, setProjects] = useState([]);
  useEffect(() => {
    fetch("http://localhost:3000/api/recommendations/projects/S1").then((res) => res.json()).then((data) => setProjects(data));
  }, []);
  return /* @__PURE__ */ jsxDEV("div", { className: "flex h-screen overflow-hidden bg-surface", children: /* @__PURE__ */ jsxDEV("div", { className: "flex-1 p-6 overflow-y-auto", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-6 flex-wrap gap-2", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-bold text-textPrimary", children: "🔹 Recommended Projects" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/RecProjects.jsx",
        lineNumber: 18,
        columnNumber: 3
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2 flex-wrap", children: [
        /* @__PURE__ */ jsxDEV("button", { onClick: () => window.location.href = "/recs", className: "px-5 py-2 rounded-lg text-white text-sm font-medium bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 shadow-md hover:scale-105 hover:shadow-xl active:scale-95 transition duration-300", children: "Find your best match project💡" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/RecProjects.jsx",
          lineNumber: 23,
          columnNumber: 5
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => window.location.href = "/sturecs",
            className: "px-5 py-2 rounded-lg text-white text-sm font-medium bg-gradient-to-r from-secondary  to-primary shadow-md hover:scale-105 hover:shadow-xl active:scale-95 transition duration-300",
            children: "Top match candidates for you 🏆"
          },
          void 0,
          false,
          {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/RecProjects.jsx",
            lineNumber: 27,
            columnNumber: 5
          },
          this
        )
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/RecProjects.jsx",
        lineNumber: 22,
        columnNumber: 3
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/RecProjects.jsx",
      lineNumber: 17,
      columnNumber: 1
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "mb-6", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl shadow-md p-5 border-l-4 border-primary", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-textPrimary", children: "🔰Recommendation Summary" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/RecProjects.jsx",
        lineNumber: 37,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-textSecondary mt-2", children: [
        "You have",
        " ",
        /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-primary", children: projects.length }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/RecProjects.jsx",
          lineNumber: 42,
          columnNumber: 15
        }, this),
        " ",
        "project recommendations."
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/RecProjects.jsx",
        lineNumber: 40,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/RecProjects.jsx",
      lineNumber: 36,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/RecProjects.jsx",
      lineNumber: 35,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6", children: projects.map((item, i) => {
      const project = item.project;
      return /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl p-5 shadow-md hover:shadow-lg transition duration-300", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-textPrimary mb-3", children: project.title }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/RecProjects.jsx",
          lineNumber: 56,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mb-3", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-textSecondary font-medium mb-1", children: "Essential Skills:" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/RecProjects.jsx",
            lineNumber: 62,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2", children: Object.entries(project.essentialSkills).map(([key, skills], idx) => skills.map((skill, sidx) => /* @__PURE__ */ jsxDEV("span", { className: "text-xs px-2 py-1 rounded-full bg-primary/20 text-primary font-medium", children: skill }, `${idx}-${sidx}`, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/RecProjects.jsx",
            lineNumber: 66,
            columnNumber: 118
          }, this))) }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/RecProjects.jsx",
            lineNumber: 65,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/RecProjects.jsx",
          lineNumber: 61,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mb-3 text-sm text-textSecondary", children: [
          /* @__PURE__ */ jsxDEV("p", { children: [
            /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-textPrimary", children: "Specialization:" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/RecProjects.jsx",
              lineNumber: 75,
              columnNumber: 21
            }, this),
            " ",
            project.academicConstraints.specialization.join(", ")
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/RecProjects.jsx",
            lineNumber: 74,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("p", { children: [
            /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-textPrimary", children: "Year:" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/RecProjects.jsx",
              lineNumber: 81,
              columnNumber: 21
            }, this),
            " ",
            project.academicConstraints.year
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/RecProjects.jsx",
            lineNumber: 80,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("p", { children: [
            /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-textPrimary", children: "Semester:" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/RecProjects.jsx",
              lineNumber: 87,
              columnNumber: 21
            }, this),
            " ",
            project.academicConstraints.semester
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/RecProjects.jsx",
            lineNumber: 86,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/RecProjects.jsx",
          lineNumber: 73,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mb-3", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-textSecondary font-medium mb-1", children: "Domain:" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/RecProjects.jsx",
            lineNumber: 96,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2", children: project.domain.map((d, idx) => /* @__PURE__ */ jsxDEV("span", { className: "text-xs px-2 py-1 rounded-full bg-accent/10 text-accent font-medium", children: d }, idx, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/RecProjects.jsx",
            lineNumber: 100,
            columnNumber: 53
          }, this)) }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/RecProjects.jsx",
            lineNumber: 99,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/RecProjects.jsx",
          lineNumber: 95,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex gap-3 mt-4", children: [
          /* @__PURE__ */ jsxDEV("button", { onClick: () => window.location.href = "/projectview", className: "flex-1 py-2 rounded-lg font-medium text-white bg-primary hover:bg-secondary transition duration-300 text-sm", children: "View Project" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/RecProjects.jsx",
            lineNumber: 108,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("button", { className: "flex-1 py-2 rounded-lg font-medium text-white bg-secondary hover:bg-primary transition duration-300 text-sm", children: "Request to Join" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/RecProjects.jsx",
            lineNumber: 111,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/RecProjects.jsx",
          lineNumber: 107,
          columnNumber: 17
        }, this)
      ] }, i, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/RecProjects.jsx",
        lineNumber: 54,
        columnNumber: 18
      }, this);
    }) }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/RecProjects.jsx",
      lineNumber: 51,
      columnNumber: 9
    }, this),
    projects.length === 0 && /* @__PURE__ */ jsxDEV("p", { className: "text-center text-textSecondary mt-10", children: "No recommendations available yet." }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/RecProjects.jsx",
      lineNumber: 120,
      columnNumber: 35
    }, this)
  ] }, void 0, true, {
    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/RecProjects.jsx",
    lineNumber: 14,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/RecProjects.jsx",
    lineNumber: 10,
    columnNumber: 10
  }, this);
};
_s(ProjectRecommendations, "TSrpuQX6QU8EgjQSxaAzj2u9i4o=");
_c = ProjectRecommendations;
export default ProjectRecommendations;
var _c;
$RefreshReg$(_c, "ProjectRecommendations");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/RecProjects.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUJFOzs7Ozs7Ozs7Ozs7Ozs7O0FBckJGLE9BQU9BLFNBQVNDLFdBQVdDLGdCQUFnQjtBQUMzQyxPQUFPQyxZQUFZO0FBRW5CLE1BQU1DLHlCQUF5QkEsTUFBTTtBQUFBQyxLQUFBO0FBQ25DLFFBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJTCxTQUFTLEVBQUU7QUFFM0NELFlBQVUsTUFBTTtBQUNkTyxVQUFNLHVEQUF1RCxFQUMxREMsS0FBTUMsU0FBUUEsSUFBSUMsS0FBSyxDQUFDLEVBQ3hCRixLQUFNRyxVQUFTTCxZQUFZSyxJQUFJLENBQUM7QUFBQSxFQUNyQyxHQUFHLEVBQUU7QUFFTCxTQUNFLHVCQUFDLFNBQUksV0FBVSw0Q0FJYixpQ0FBQyxTQUFJLFdBQVUsOEJBR3JCO0FBQUEsMkJBQUMsU0FBSSxXQUFVLDBEQUNiO0FBQUEsNkJBQUMsUUFBRyxXQUFVLHVDQUFzQyx1Q0FBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSwrQkFBQyxZQUNDLFNBQVMsTUFBTUMsT0FBT0MsU0FBU0MsT0FBTyxTQUN0QyxXQUFVLG1NQUNYLDhDQUhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFFBRUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVMsTUFBTUYsT0FBT0MsU0FBU0MsT0FBTztBQUFBLFlBQ3RDLFdBQVU7QUFBQSxZQUNYO0FBQUE7QUFBQSxVQUhEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtBO0FBQUEsV0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBY0E7QUFBQSxTQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBb0JBO0FBQUEsSUFHUSx1QkFBQyxTQUFJLFdBQVUsUUFDYixpQ0FBQyxTQUFJLFdBQVUsK0RBQ2I7QUFBQSw2QkFBQyxRQUFHLFdBQVUsMENBQXlDLHdDQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLE9BQUUsV0FBVSwyQkFBMEI7QUFBQTtBQUFBLFFBQzVCO0FBQUEsUUFDVCx1QkFBQyxVQUFLLFdBQVUsMEJBQ2JULG1CQUFTVSxVQURaO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQVE7QUFBQSxRQUFJO0FBQUEsV0FKZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTUE7QUFBQSxTQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FXQSxLQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FhQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLDJEQUNaVixtQkFBU1csSUFBSSxDQUFDQyxNQUFNQyxNQUFNO0FBQ3pCLFlBQU1DLFVBQVVGLEtBQUtFO0FBRXJCLGFBQ0UsdUJBQUMsU0FFQyxXQUFVLDZFQUdWO0FBQUEsK0JBQUMsUUFBRyxXQUFVLCtDQUNYQSxrQkFBUUMsU0FEWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUdBLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsaUNBQUMsT0FBRSxXQUFVLCtDQUE4QyxpQ0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLHdCQUNaQyxpQkFBT0MsUUFBUUgsUUFBUUksZUFBZSxFQUFFUCxJQUN2QyxDQUFDLENBQUNRLEtBQUtDLE1BQU0sR0FBR0MsUUFDZEQsT0FBT1QsSUFBSSxDQUFDVyxPQUFPQyxTQUNqQix1QkFBQyxVQUVDLFdBQVUseUVBRVRELG1CQUhJLEdBQUdELEdBQUcsSUFBSUUsSUFBSSxJQURyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBLENBQ0QsQ0FDTCxLQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBWUE7QUFBQSxhQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaUJBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUsbUNBQ2I7QUFBQSxpQ0FBQyxPQUNDO0FBQUEsbUNBQUMsVUFBSyxXQUFVLGdDQUErQiwrQkFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQVE7QUFBQSxZQUNQVCxRQUFRVSxvQkFBb0JDLGVBQWVDLEtBQUssSUFBSTtBQUFBLGVBSnZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxVQUNBLHVCQUFDLE9BQ0M7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsZ0NBQStCLHFCQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFBUTtBQUFBLFlBQ1BaLFFBQVFVLG9CQUFvQkc7QUFBQUEsZUFKL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLFVBQ0EsdUJBQUMsT0FDQztBQUFBLG1DQUFDLFVBQUssV0FBVSxnQ0FBK0IseUJBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUFRO0FBQUEsWUFDUGIsUUFBUVUsb0JBQW9CSTtBQUFBQSxlQUovQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsYUFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW1CQTtBQUFBLFFBR0EsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSxpQ0FBQyxPQUFFLFdBQVUsK0NBQThDLHVCQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsd0JBQ1pkLGtCQUFRZSxPQUFPbEIsSUFBSSxDQUFDbUIsR0FBR1QsUUFDdEIsdUJBQUMsVUFFQyxXQUFVLHVFQUVUUyxlQUhJVCxLQURQO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0EsQ0FDRCxLQVJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBU0E7QUFBQSxhQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFjQTtBQUFBLFFBR0EsdUJBQUMsU0FBSSxXQUFVLG1CQUNiO0FBQUEsaUNBQUMsWUFDRCxTQUFTLE1BQU1kLE9BQU9DLFNBQVNDLE9BQU8sZ0JBQ3RDLFdBQVUsK0dBQThHLDRCQUZ4SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUlBO0FBQUEsVUFDQSx1QkFBQyxZQUFPLFdBQVUsK0dBQThHLCtCQUFoSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0E7QUFBQSxXQTdFS0ksR0FEUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBK0VBO0FBQUEsSUFFSixDQUFDLEtBdEZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1RkE7QUFBQSxJQUdDYixTQUFTVSxXQUFXLEtBQ25CLHVCQUFDLE9BQUUsV0FBVSx3Q0FBdUMsaURBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLE9BdklKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F5SUEsS0E3SUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQThJQTtBQUVKO0FBQUVYLEdBMUpJRCx3QkFBc0I7QUFBQWlDLEtBQXRCakM7QUE0Sk4sZUFBZUE7QUFBdUIsSUFBQWlDO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiTmF2YmFyIiwiUHJvamVjdFJlY29tbWVuZGF0aW9ucyIsIl9zIiwicHJvamVjdHMiLCJzZXRQcm9qZWN0cyIsImZldGNoIiwidGhlbiIsInJlcyIsImpzb24iLCJkYXRhIiwid2luZG93IiwibG9jYXRpb24iLCJocmVmIiwibGVuZ3RoIiwibWFwIiwiaXRlbSIsImkiLCJwcm9qZWN0IiwidGl0bGUiLCJPYmplY3QiLCJlbnRyaWVzIiwiZXNzZW50aWFsU2tpbGxzIiwia2V5Iiwic2tpbGxzIiwiaWR4Iiwic2tpbGwiLCJzaWR4IiwiYWNhZGVtaWNDb25zdHJhaW50cyIsInNwZWNpYWxpemF0aW9uIiwiam9pbiIsInllYXIiLCJzZW1lc3RlciIsImRvbWFpbiIsImQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlJlY1Byb2plY3RzLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi8uLi9jb21wb25lbnRzL05hdmJhclwiO1xyXG5cclxuY29uc3QgUHJvamVjdFJlY29tbWVuZGF0aW9ucyA9ICgpID0+IHtcclxuICBjb25zdCBbcHJvamVjdHMsIHNldFByb2plY3RzXSA9IHVzZVN0YXRlKFtdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGZldGNoKFwiaHR0cDovL2xvY2FsaG9zdDozMDAwL2FwaS9yZWNvbW1lbmRhdGlvbnMvcHJvamVjdHMvUzFcIilcclxuICAgICAgLnRoZW4oKHJlcykgPT4gcmVzLmpzb24oKSlcclxuICAgICAgLnRoZW4oKGRhdGEpID0+IHNldFByb2plY3RzKGRhdGEpKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaC1zY3JlZW4gb3ZlcmZsb3ctaGlkZGVuIGJnLXN1cmZhY2VcIj5cclxuICAgICAgXHJcblxyXG4gICAgICB7LyogTWFpbiBjb250ZW50IChzY3JvbGxhYmxlIG9ubHkpICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBwLTYgb3ZlcmZsb3cteS1hdXRvXCI+XHJcbiAgICAgICAgXHJcbiAgICAgICAgey8qIEhlYWRlciArIEJ1dHRvbnMgKi99XHJcbjxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIG1iLTYgZmxleC13cmFwIGdhcC0yXCI+XHJcbiAgPGgyIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LXRleHRQcmltYXJ5XCI+XHJcbiAgICDwn5S5IFJlY29tbWVuZGVkIFByb2plY3RzXHJcbiAgPC9oMj5cclxuXHJcbiAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0yIGZsZXgtd3JhcFwiPlxyXG4gICAgPGJ1dHRvblxyXG4gICAgICBvbkNsaWNrPXsoKSA9PiB3aW5kb3cubG9jYXRpb24uaHJlZiA9IFwiL3JlY3NcIn1cclxuICAgICAgY2xhc3NOYW1lPVwicHgtNSBweS0yIHJvdW5kZWQtbGcgdGV4dC13aGl0ZSB0ZXh0LXNtIGZvbnQtbWVkaXVtIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1ibHVlLTUwMCB2aWEtcHVycGxlLTUwMCB0by1waW5rLTUwMCBzaGFkb3ctbWQgaG92ZXI6c2NhbGUtMTA1IGhvdmVyOnNoYWRvdy14bCBhY3RpdmU6c2NhbGUtOTUgdHJhbnNpdGlvbiBkdXJhdGlvbi0zMDBcIlxyXG4gICAgPlxyXG4gICAgICBGaW5kIHlvdXIgYmVzdCBtYXRjaCBwcm9qZWN08J+SoVxyXG4gICAgPC9idXR0b24+XHJcblxyXG4gICAgPGJ1dHRvblxyXG4gICAgICBvbkNsaWNrPXsoKSA9PiB3aW5kb3cubG9jYXRpb24uaHJlZiA9IFwiL3N0dXJlY3NcIn0gLy8gY2hhbmdlIFVSTCBhcyBuZWVkZWRcclxuICAgICAgY2xhc3NOYW1lPVwicHgtNSBweS0yIHJvdW5kZWQtbGcgdGV4dC13aGl0ZSB0ZXh0LXNtIGZvbnQtbWVkaXVtIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1zZWNvbmRhcnkgIHRvLXByaW1hcnkgc2hhZG93LW1kIGhvdmVyOnNjYWxlLTEwNSBob3ZlcjpzaGFkb3cteGwgYWN0aXZlOnNjYWxlLTk1IHRyYW5zaXRpb24gZHVyYXRpb24tMzAwXCJcclxuICAgID5cclxuICAgICAgVG9wIG1hdGNoIGNhbmRpZGF0ZXMgZm9yIHlvdSDwn4+GXHJcbiAgICA8L2J1dHRvbj5cclxuICA8L2Rpdj5cclxuPC9kaXY+XHJcblxyXG4gICAgICAgIHsvKiBTdW1tYXJ5IENhcmQgKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi02XCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQteGwgc2hhZG93LW1kIHAtNSBib3JkZXItbC00IGJvcmRlci1wcmltYXJ5XCI+XHJcbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC10ZXh0UHJpbWFyeVwiPlxyXG4gICAgICAgICAgICAgIPCflLBSZWNvbW1lbmRhdGlvbiBTdW1tYXJ5XHJcbiAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtdGV4dFNlY29uZGFyeSBtdC0yXCI+XHJcbiAgICAgICAgICAgICAgWW91IGhhdmV7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtcHJpbWFyeVwiPlxyXG4gICAgICAgICAgICAgICAge3Byb2plY3RzLmxlbmd0aH1cclxuICAgICAgICAgICAgICA8L3NwYW4+e1wiIFwifVxyXG4gICAgICAgICAgICAgIHByb2plY3QgcmVjb21tZW5kYXRpb25zLlxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgey8qIFByb2plY3QgQ2FyZHMgKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIHNtOmdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy0zIGdhcC02XCI+XHJcbiAgICAgICAgICB7cHJvamVjdHMubWFwKChpdGVtLCBpKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnN0IHByb2plY3QgPSBpdGVtLnByb2plY3Q7XHJcblxyXG4gICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgIGtleT17aX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQteGwgcC01IHNoYWRvdy1tZCBob3ZlcjpzaGFkb3ctbGcgdHJhbnNpdGlvbiBkdXJhdGlvbi0zMDBcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHsvKiBUaXRsZSAqL31cclxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC10ZXh0UHJpbWFyeSBtYi0zXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtwcm9qZWN0LnRpdGxlfVxyXG4gICAgICAgICAgICAgICAgPC9oMz5cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogRXNzZW50aWFsIFNraWxscyAqL31cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItM1wiPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtdGV4dFNlY29uZGFyeSBmb250LW1lZGl1bSBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgRXNzZW50aWFsIFNraWxsczpcclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge09iamVjdC5lbnRyaWVzKHByb2plY3QuZXNzZW50aWFsU2tpbGxzKS5tYXAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAoW2tleSwgc2tpbGxzXSwgaWR4KSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBza2lsbHMubWFwKChza2lsbCwgc2lkeCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2Ake2lkeH0tJHtzaWR4fWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXhzIHB4LTIgcHktMSByb3VuZGVkLWZ1bGwgYmctcHJpbWFyeS8yMCB0ZXh0LXByaW1hcnkgZm9udC1tZWRpdW1cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtza2lsbH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkpXHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogQWNhZGVtaWMgSW5mbyAqL31cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMyB0ZXh0LXNtIHRleHQtdGV4dFNlY29uZGFyeVwiPlxyXG4gICAgICAgICAgICAgICAgICA8cD5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LXRleHRQcmltYXJ5XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBTcGVjaWFsaXphdGlvbjpcclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgIHtwcm9qZWN0LmFjYWRlbWljQ29uc3RyYWludHMuc3BlY2lhbGl6YXRpb24uam9pbihcIiwgXCIpfVxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgIDxwPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtdGV4dFByaW1hcnlcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIFllYXI6XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICB7cHJvamVjdC5hY2FkZW1pY0NvbnN0cmFpbnRzLnllYXJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgPHA+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC10ZXh0UHJpbWFyeVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgU2VtZXN0ZXI6XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICB7cHJvamVjdC5hY2FkZW1pY0NvbnN0cmFpbnRzLnNlbWVzdGVyfVxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogRG9tYWluICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0zXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC10ZXh0U2Vjb25kYXJ5IGZvbnQtbWVkaXVtIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICBEb21haW46XHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtwcm9qZWN0LmRvbWFpbi5tYXAoKGQsIGlkeCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW5cclxuICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtpZHh9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQteHMgcHgtMiBweS0xIHJvdW5kZWQtZnVsbCBiZy1hY2NlbnQvMTAgdGV4dC1hY2NlbnQgZm9udC1tZWRpdW1cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZH1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogQnV0dG9ucyAqL31cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMyBtdC00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b24gXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHdpbmRvdy5sb2NhdGlvbi5ocmVmID0gXCIvcHJvamVjdHZpZXdcIn1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIHB5LTIgcm91bmRlZC1sZyBmb250LW1lZGl1bSB0ZXh0LXdoaXRlIGJnLXByaW1hcnkgaG92ZXI6Ymctc2Vjb25kYXJ5IHRyYW5zaXRpb24gZHVyYXRpb24tMzAwIHRleHQtc21cIj5cclxuICAgICAgICAgICAgICAgICAgICBWaWV3IFByb2plY3RcclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiZmxleC0xIHB5LTIgcm91bmRlZC1sZyBmb250LW1lZGl1bSB0ZXh0LXdoaXRlIGJnLXNlY29uZGFyeSBob3ZlcjpiZy1wcmltYXJ5IHRyYW5zaXRpb24gZHVyYXRpb24tMzAwIHRleHQtc21cIj5cclxuICAgICAgICAgICAgICAgICAgICBSZXF1ZXN0IHRvIEpvaW5cclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKTtcclxuICAgICAgICAgIH0pfVxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogRW1wdHkgU3RhdGUgKi99XHJcbiAgICAgICAge3Byb2plY3RzLmxlbmd0aCA9PT0gMCAmJiAoXHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciB0ZXh0LXRleHRTZWNvbmRhcnkgbXQtMTBcIj5cclxuICAgICAgICAgICAgTm8gcmVjb21tZW5kYXRpb25zIGF2YWlsYWJsZSB5ZXQuXHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgUHJvamVjdFJlY29tbWVuZGF0aW9uczsiXSwiZmlsZSI6IkY6L1kzUzIvSVRQTSBwcm9qZWN0L1Byb01hdGUtLVByb2plY3QtUGFydG5lci1GaW5kZXIvZnJvbnRlbmQvc3JjL3BhZ2VzL1JlY0VuZ2luZS9SZWNQcm9qZWN0cy5qc3gifQ==