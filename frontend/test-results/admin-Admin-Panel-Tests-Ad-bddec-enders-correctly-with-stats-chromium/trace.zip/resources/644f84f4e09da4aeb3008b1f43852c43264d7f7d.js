import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Admin/Projectmanagement.jsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=383bea9f"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"];
import axios from "/node_modules/.vite/deps/axios.js?v=383bea9f";
import AdminNavbar from "/src/components/AdminNavbar.jsx";
import { useAuth } from "/src/context/AuthContext.jsx";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=383bea9f";
import { Eye, Check, X } from "/node_modules/.vite/deps/lucide-react.js?v=383bea9f";
const Projectmanagement = () => {
  _s();
  const {
    token
  } = useAuth();
  const navigate = useNavigate();
  const [projects, setProjects] = useState([]);
  const tableRef = useRef(null);
  const [showRejectModal, setShowRejectModal] = useState(false);
  const [selectedProject, setSelectedProject] = useState(null);
  const [reason, setReason] = useState("");
  const [comments, setComments] = useState("");
  const [error, setError] = useState("");
  const fetchProjects = () => {
    axios.get("http://localhost:3000/api/admin/projects", {
      headers: {
        "x-auth-token": token
      }
    }).then((res) => setProjects(res.data)).catch((err) => console.log(err));
  };
  useEffect(() => {
    fetchProjects();
  }, [token]);
  const deleteProject = (id) => {
    if (window.confirm("Delete this project?")) {
      axios.delete(`http://localhost:3000/api/admin/projects/${id}`, {
        headers: {
          "x-auth-token": token
        }
      }).then(fetchProjects).catch((err) => console.log(err));
    }
  };
  const scrollToTable = () => {
    tableRef.current?.scrollIntoView({
      behavior: "smooth"
    });
  };
  const openRejectModal = (project) => {
    setSelectedProject(project);
    setReason("");
    setComments("");
    setError("");
    setShowRejectModal(true);
  };
  const handleReject = () => {
    if (!reason) {
      setError("Please select a reason");
      return;
    }
    if (comments.trim().length < 5) {
      setError("Comments must be at least 5 characters");
      return;
    }
    console.log("Rejected project:", selectedProject._id, {
      reason,
      comments
    });
    setShowRejectModal(false);
    alert("Project rejected successfully!");
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "flex h-screen overflow-hidden", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex-1 p-6 bg-surface", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-6", children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold text-gray-800", children: "New Projects 📝" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
          lineNumber: 77,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("button", { onClick: scrollToTable, className: "bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg text-sm shadow transition-all duration-200 hover:scale-105", children: "View All Projects" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
          lineNumber: 81,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
        lineNumber: 76,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 auto-rows-fr", children: projects.map((p) => /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-2xl shadow-md p-5 border flex flex-col h-full \r\n              transition-all duration-300 hover:shadow-2xl hover:-translate-y-2", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex-grow", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "mb-3", children: [
            /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-bold text-gray-800", children: p.title }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
              lineNumber: 95,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 line-clamp-2", children: p.description }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
              lineNumber: 98,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
            lineNumber: 94,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2 mb-3 text-xs", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "bg-blue-100 text-blue-600 px-2 py-1 rounded", children: p.projectType }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
              lineNumber: 105,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "bg-green-100 text-green-600 px-2 py-1 rounded", children: [
              "Team: ",
              p.teamSize
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
              lineNumber: 108,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "bg-purple-100 text-purple-600 px-2 py-1 rounded", children: p.domain?.[0] }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
              lineNumber: 111,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
            lineNumber: 104,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-gray-700 space-y-1 mb-3", children: [
            /* @__PURE__ */ jsxDEV("p", { children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Year:" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
                lineNumber: 119,
                columnNumber: 21
              }, this),
              " ",
              p.academicConstraints?.year,
              " |",
              /* @__PURE__ */ jsxDEV("strong", { children: " Sem:" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
                lineNumber: 120,
                columnNumber: 21
              }, this),
              " ",
              p.academicConstraints?.semester
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
              lineNumber: 118,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "CGPA:" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
                lineNumber: 124,
                columnNumber: 21
              }, this),
              " ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-yellow-500 font-semibold", children: p.academicConstraints?.minimumCGPA }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
                lineNumber: 125,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
              lineNumber: 123,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Skills:" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
                lineNumber: 131,
                columnNumber: 21
              }, this),
              " ",
              p.essentialSkills?.languages?.slice(0, 2).join(", ")
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
              lineNumber: 130,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Roles:" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
                lineNumber: 136,
                columnNumber: 21
              }, this),
              " ",
              p.requiredRoles?.slice(0, 2).join(", ")
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
              lineNumber: 135,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
            lineNumber: 117,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
          lineNumber: 91,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-auto flex justify-between items-center", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-gray-500 whitespace-nowrap", children: [
            p.availabilityRequirement?.weeklyHours,
            "h/week"
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
            lineNumber: 144,
            columnNumber: 3
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex gap-1 flex-nowrap", children: [
            /* @__PURE__ */ jsxDEV("button", { onClick: () => navigate(`/project/${p._id}`), className: "px-2 py-0.5 text-xs rounded-md border border-blue-500 text-blue-500 hover:bg-blue-50 transition whitespace-nowrap", children: "View" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
              lineNumber: 151,
              columnNumber: 5
            }, this),
            /* @__PURE__ */ jsxDEV("button", { className: "px-2 py-0.5 text-xs rounded-md bg-secondary text-white hover:bg-green-600 transition whitespace-nowrap", children: "Approve" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
              lineNumber: 156,
              columnNumber: 5
            }, this),
            /* @__PURE__ */ jsxDEV("button", { onClick: () => openRejectModal(p), className: "px-2 py-0.5 text-xs rounded-md bg-red-500 text-white hover:bg-red-600 transition whitespace-nowrap", children: "Reject" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
              lineNumber: 161,
              columnNumber: 5
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
            lineNumber: 148,
            columnNumber: 3
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
          lineNumber: 143,
          columnNumber: 1
        }, this)
      ] }, p._id, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
        lineNumber: 88,
        columnNumber: 30
      }, this)) }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
        lineNumber: 87,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { ref: tableRef, className: "mt-16", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-bold text-gray-800 mb-4", children: "All Projects Table" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
          lineNumber: 172,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto bg-white rounded-xl shadow", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full text-sm text-left", children: [
          /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-100 text-gray-700", children: /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("th", { className: "p-3", children: "Title" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
              lineNumber: 181,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { children: "Team" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
              lineNumber: 182,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { children: "Type" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
              lineNumber: 183,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { children: "Academic" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
              lineNumber: 184,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { children: "Skills" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
              lineNumber: 185,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { children: "Roles" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
              lineNumber: 186,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { children: "Availability" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
              lineNumber: 187,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { children: "Actions" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
              lineNumber: 188,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
            lineNumber: 180,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
            lineNumber: 179,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("tbody", { children: projects.map((p) => /* @__PURE__ */ jsxDEV("tr", { className: "border-b hover:bg-gray-50", children: [
            /* @__PURE__ */ jsxDEV("td", { className: "p-3 font-medium", children: [
              p.title,
              /* @__PURE__ */ jsxDEV("p", { className: "text-gray-400", children: p.domain?.join(", ") }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
                lineNumber: 197,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
              lineNumber: 195,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("td", { children: p.teamSize }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
              lineNumber: 200,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("td", { children: p.projectType }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
              lineNumber: 201,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("td", { children: [
              "Y",
              p.academicConstraints?.year,
              " / S",
              p.academicConstraints?.semester,
              /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
                lineNumber: 205,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "text-yellow-500 font-semibold", children: [
                "CGPA ",
                p.academicConstraints?.minimumCGPA
              ] }, void 0, true, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
                lineNumber: 206,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
              lineNumber: 203,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("td", { children: [
              p.essentialSkills?.languages?.slice(0, 2).join(", "),
              /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
                lineNumber: 213,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "text-gray-400", children: p.essentialSkills?.frameworks?.slice(0, 1) }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
                lineNumber: 214,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
              lineNumber: 211,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("td", { children: p.requiredRoles?.join(", ") }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
              lineNumber: 219,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("td", { children: [
              p.availabilityRequirement?.weeklyHours,
              "h/week",
              /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
                lineNumber: 223,
                columnNumber: 23
              }, this),
              p.availabilityRequirement?.durationWeeks,
              "w"
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
              lineNumber: 221,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "space-x-2", children: [
              /* @__PURE__ */ jsxDEV("button", { onClick: () => navigate(`/project/${p._id}`), className: "text-blue-500 border border-blue-500 px-2 py-1 rounded text-xs", children: "View" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
                lineNumber: 228,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("button", { onClick: () => deleteProject(p._id), className: "bg-pink-400 text-white px-2 py-1 rounded text-xs", children: "Remove" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
                lineNumber: 232,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
              lineNumber: 227,
              columnNumber: 21
            }, this)
          ] }, p._id, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
            lineNumber: 193,
            columnNumber: 36
          }, this)) }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
            lineNumber: 192,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
          lineNumber: 177,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
          lineNumber: 176,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
        lineNumber: 171,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
      lineNumber: 73,
      columnNumber: 7
    }, this),
    showRejectModal && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 flex items-center justify-center bg-black bg-opacity-40 z-50", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-6 rounded-xl shadow-lg w-96", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-bold mb-4 text-red-500", children: "Reject Project" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
        lineNumber: 249,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "mb-2", children: [
        "Project: ",
        /* @__PURE__ */ jsxDEV("strong", { children: selectedProject?.title }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
          lineNumber: 254,
          columnNumber: 24
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
        lineNumber: 253,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium mb-1", children: "Reason" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
        lineNumber: 257,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("select", { className: "w-full border rounded p-2 mb-2", value: reason, onChange: (e) => setReason(e.target.value), children: [
        /* @__PURE__ */ jsxDEV("option", { value: "", children: "-- Select Reason --" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
          lineNumber: 259,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("option", { value: "Incomplete details", children: "Incomplete details" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
          lineNumber: 260,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("option", { value: "Not relevant", children: "Not relevant" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
          lineNumber: 261,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("option", { value: "Low quality idea", children: "Low quality idea" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
          lineNumber: 262,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("option", { value: "Duplicate project", children: "Duplicate project" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
          lineNumber: 263,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("option", { value: "Other", children: "Other" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
          lineNumber: 264,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
        lineNumber: 258,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium mb-1", children: "Comments" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
        lineNumber: 267,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("textarea", { className: "w-full border rounded p-2 mb-2", rows: 3, value: comments, onChange: (e) => setComments(e.target.value), placeholder: "Minimum 5 characters" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
        lineNumber: 268,
        columnNumber: 13
      }, this),
      error && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mb-2", children: error }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
        lineNumber: 270,
        columnNumber: 23
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end gap-2 mt-2", children: [
        /* @__PURE__ */ jsxDEV("button", { onClick: () => setShowRejectModal(false), className: "px-3 py-1 rounded bg-gray-300 hover:bg-gray-400", children: "Cancel" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
          lineNumber: 273,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("button", { onClick: handleReject, className: "px-3 py-1 rounded bg-red-500 text-white hover:bg-red-600", children: "Reject" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
          lineNumber: 277,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
        lineNumber: 272,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
      lineNumber: 248,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
      lineNumber: 247,
      columnNumber: 27
    }, this)
  ] }, void 0, true, {
    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx",
    lineNumber: 71,
    columnNumber: 10
  }, this);
};
_s(Projectmanagement, "N2CUYt2seZWJ54s2ubNm48kQMLM=", false, function() {
  return [useAuth, useNavigate];
});
_c = Projectmanagement;
export default Projectmanagement;
var _c;
$RefreshReg$(_c, "Projectmanagement");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Projectmanagement.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUZVOzs7Ozs7Ozs7Ozs7Ozs7O0FBakZWLE9BQU9BLFNBQVNDLFVBQVVDLFdBQVdDLGNBQWM7QUFDbkQsT0FBT0MsV0FBVztBQUNsQixPQUFPQyxpQkFBaUI7QUFDeEIsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsS0FBS0MsT0FBT0MsU0FBUztBQUU5QixNQUFNQyxvQkFBb0JBLE1BQU07QUFBQUMsS0FBQTtBQUM5QixRQUFNO0FBQUEsSUFBRUM7QUFBQUEsRUFBTSxJQUFJUCxRQUFRO0FBQzFCLFFBQU1RLFdBQVdQLFlBQVk7QUFDN0IsUUFBTSxDQUFDUSxVQUFVQyxXQUFXLElBQUlmLFNBQVMsRUFBRTtBQUMzQyxRQUFNZ0IsV0FBV2QsT0FBTyxJQUFJO0FBRzVCLFFBQU0sQ0FBQ2UsaUJBQWlCQyxrQkFBa0IsSUFBSWxCLFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUNtQixpQkFBaUJDLGtCQUFrQixJQUFJcEIsU0FBUyxJQUFJO0FBQzNELFFBQU0sQ0FBQ3FCLFFBQVFDLFNBQVMsSUFBSXRCLFNBQVMsRUFBRTtBQUN2QyxRQUFNLENBQUN1QixVQUFVQyxXQUFXLElBQUl4QixTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDeUIsT0FBT0MsUUFBUSxJQUFJMUIsU0FBUyxFQUFFO0FBRXJDLFFBQU0yQixnQkFBZ0JBLE1BQU07QUFDMUJ4QixVQUFNeUIsSUFBSSw0Q0FBNEM7QUFBQSxNQUNwREMsU0FBUztBQUFBLFFBQUUsZ0JBQWdCakI7QUFBQUEsTUFBTTtBQUFBLElBQ25DLENBQUMsRUFDRWtCLEtBQUtDLFNBQU9oQixZQUFZZ0IsSUFBSUMsSUFBSSxDQUFDLEVBQ2pDQyxNQUFNQyxTQUFPQyxRQUFRQyxJQUFJRixHQUFHLENBQUM7QUFBQSxFQUNsQztBQUVBakMsWUFBVSxNQUFNO0FBQ2QwQixrQkFBYztBQUFBLEVBQ2hCLEdBQUcsQ0FBQ2YsS0FBSyxDQUFDO0FBRVYsUUFBTXlCLGdCQUFpQkMsUUFBTztBQUM1QixRQUFJQyxPQUFPQyxRQUFRLHNCQUFzQixHQUFHO0FBQzFDckMsWUFBTXNDLE9BQU8sNENBQTRDSCxFQUFFLElBQUk7QUFBQSxRQUM3RFQsU0FBUztBQUFBLFVBQUUsZ0JBQWdCakI7QUFBQUEsUUFBTTtBQUFBLE1BQ25DLENBQUMsRUFDRWtCLEtBQUtILGFBQWEsRUFDbEJNLE1BQU1DLFNBQU9DLFFBQVFDLElBQUlGLEdBQUcsQ0FBQztBQUFBLElBQ2xDO0FBQUEsRUFDRjtBQUVBLFFBQU1RLGdCQUFnQkEsTUFBTTtBQUMxQjFCLGFBQVMyQixTQUFTQyxlQUFlO0FBQUEsTUFBRUMsVUFBVTtBQUFBLElBQVMsQ0FBQztBQUFBLEVBQ3pEO0FBRUEsUUFBTUMsa0JBQW1CQyxhQUFZO0FBQ25DM0IsdUJBQW1CMkIsT0FBTztBQUMxQnpCLGNBQVUsRUFBRTtBQUNaRSxnQkFBWSxFQUFFO0FBQ2RFLGFBQVMsRUFBRTtBQUNYUix1QkFBbUIsSUFBSTtBQUFBLEVBQ3pCO0FBRUEsUUFBTThCLGVBQWVBLE1BQU07QUFDekIsUUFBSSxDQUFDM0IsUUFBUTtBQUNYSyxlQUFTLHdCQUF3QjtBQUNqQztBQUFBLElBQ0Y7QUFFQSxRQUFJSCxTQUFTMEIsS0FBSyxFQUFFQyxTQUFTLEdBQUc7QUFDOUJ4QixlQUFTLHdDQUF3QztBQUNqRDtBQUFBLElBQ0Y7QUFFQVMsWUFBUUMsSUFBSSxxQkFBcUJqQixnQkFBZ0JnQyxLQUFLO0FBQUEsTUFDcEQ5QjtBQUFBQSxNQUNBRTtBQUFBQSxJQUNGLENBQUM7QUFFREwsdUJBQW1CLEtBQUs7QUFDeEJrQyxVQUFNLGdDQUFnQztBQUFBLEVBQ3hDO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsaUNBRWI7QUFBQSwyQkFBQyxTQUFJLFdBQVUseUJBR2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSwrQkFBQyxRQUFHLFdBQVUsb0NBQW1DLCtCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUVBLHVCQUFDLFlBQ0MsU0FBU1YsZUFDVCxXQUFVLDRIQUNYLGlDQUhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFdBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVdBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsb0ZBQ1o1QixtQkFBU3VDLElBQUtDLE9BQ2IsdUJBQUMsU0FFQyxXQUFVLHNKQUlWO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGFBR2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLG1DQUFDLFFBQUcsV0FBVSxtQ0FDWEEsWUFBRUMsU0FETDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxPQUFFLFdBQVUsc0NBQ1ZELFlBQUVFLGVBREw7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLFVBR0EsdUJBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsbUNBQUMsVUFBSyxXQUFVLCtDQUNiRixZQUFFRyxlQURMO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFVBQUssV0FBVSxpREFBZ0Q7QUFBQTtBQUFBLGNBQ3ZESCxFQUFFSTtBQUFBQSxpQkFEWDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxVQUFLLFdBQVUsbURBQ2JKLFlBQUVLLFNBQVMsQ0FBQyxLQURmO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVUE7QUFBQSxVQUdBLHVCQUFDLFNBQUksV0FBVSx3Q0FDYjtBQUFBLG1DQUFDLE9BQ0M7QUFBQSxxQ0FBQyxZQUFPLHFCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWE7QUFBQSxjQUFTO0FBQUEsY0FBRUwsRUFBRU0scUJBQXFCQztBQUFBQSxjQUFLO0FBQUEsY0FDcEQsdUJBQUMsWUFBTyxxQkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFhO0FBQUEsY0FBUztBQUFBLGNBQUVQLEVBQUVNLHFCQUFxQkU7QUFBQUEsaUJBRmpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUVBLHVCQUFDLE9BQ0M7QUFBQSxxQ0FBQyxZQUFPLHFCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWE7QUFBQSxjQUFVO0FBQUEsY0FDdkIsdUJBQUMsVUFBSyxXQUFVLGlDQUNiUixZQUFFTSxxQkFBcUJHLGVBRDFCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsWUFFQSx1QkFBQyxPQUNDO0FBQUEscUNBQUMsWUFBTyx1QkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFlO0FBQUEsY0FBVTtBQUFBLGNBQ3hCVCxFQUFFVSxpQkFBaUJDLFdBQVdDLE1BQU0sR0FBRyxDQUFDLEVBQUVDLEtBQUssSUFBSTtBQUFBLGlCQUZ0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFFQSx1QkFBQyxPQUNDO0FBQUEscUNBQUMsWUFBTyxzQkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFjO0FBQUEsY0FBVTtBQUFBLGNBQ3ZCYixFQUFFYyxlQUFlRixNQUFNLEdBQUcsQ0FBQyxFQUFFQyxLQUFLLElBQUk7QUFBQSxpQkFGekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLGVBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBc0JBO0FBQUEsYUFoREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWlEQTtBQUFBLFFBR2QsdUJBQUMsU0FBSSxXQUFVLDZDQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDJDQUNaYjtBQUFBQSxjQUFFZSx5QkFBeUJDO0FBQUFBLFlBQVk7QUFBQSxlQUQxQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsMEJBR2I7QUFBQSxtQ0FBQyxZQUNDLFNBQVMsTUFBTXpELFNBQVMsWUFBWXlDLEVBQUVILEdBQUcsRUFBRSxHQUMzQyxXQUFVLHFIQUNYLG9CQUhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxZQUdBLHVCQUFDLFlBQ0MsV0FBVSwwR0FDWCx1QkFGRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUlBO0FBQUEsWUFHQSx1QkFBQyxZQUNDLFNBQVMsTUFBTUwsZ0JBQWdCUSxDQUFDLEdBQ2hDLFdBQVUsc0dBQ1gsc0JBSEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLGVBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBeUJBO0FBQUEsYUE5QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQStCQTtBQUFBLFdBeEZtQkEsRUFBRUgsS0FEVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMEZBLENBQ0QsS0E3Rkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQThGQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxLQUFLbkMsVUFBVSxXQUFVLFNBQzVCO0FBQUEsK0JBQUMsUUFBRyxXQUFVLHdDQUF1QyxrQ0FBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsOENBQ2IsaUNBQUMsV0FBTSxXQUFVLGdDQUVmO0FBQUEsaUNBQUMsV0FBTSxXQUFVLDZCQUNmLGlDQUFDLFFBQ0M7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsT0FBTSxxQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUI7QUFBQSxZQUN6Qix1QkFBQyxRQUFHLG9CQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQVE7QUFBQSxZQUNSLHVCQUFDLFFBQUcsb0JBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBUTtBQUFBLFlBQ1IsdUJBQUMsUUFBRyx3QkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFZO0FBQUEsWUFDWix1QkFBQyxRQUFHLHNCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQVU7QUFBQSxZQUNWLHVCQUFDLFFBQUcscUJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBUztBQUFBLFlBQ1QsdUJBQUMsUUFBRyw0QkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnQjtBQUFBLFlBQ2hCLHVCQUFDLFFBQUcsdUJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBVztBQUFBLGVBUmI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFTQSxLQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBV0E7QUFBQSxVQUVBLHVCQUFDLFdBQ0VGLG1CQUFTdUMsSUFBS0MsT0FDYix1QkFBQyxRQUFlLFdBQVUsNkJBRXhCO0FBQUEsbUNBQUMsUUFBRyxXQUFVLG1CQUNYQTtBQUFBQSxnQkFBRUM7QUFBQUEsY0FDSCx1QkFBQyxPQUFFLFdBQVUsaUJBQWlCRCxZQUFFSyxRQUFRUSxLQUFLLElBQUksS0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbUQ7QUFBQSxpQkFGckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBRUEsdUJBQUMsUUFBSWIsWUFBRUksWUFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnQjtBQUFBLFlBQ2hCLHVCQUFDLFFBQUlKLFlBQUVHLGVBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUI7QUFBQSxZQUVuQix1QkFBQyxRQUFHO0FBQUE7QUFBQSxjQUNBSCxFQUFFTSxxQkFBcUJDO0FBQUFBLGNBQUs7QUFBQSxjQUFLUCxFQUFFTSxxQkFBcUJFO0FBQUFBLGNBQzFELHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBRztBQUFBLGNBQ0gsdUJBQUMsVUFBSyxXQUFVLGlDQUFnQztBQUFBO0FBQUEsZ0JBQ3hDUixFQUFFTSxxQkFBcUJHO0FBQUFBLG1CQUQvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFNQTtBQUFBLFlBRUEsdUJBQUMsUUFDRVQ7QUFBQUEsZ0JBQUVVLGlCQUFpQkMsV0FBV0MsTUFBTSxHQUFFLENBQUMsRUFBRUMsS0FBSyxJQUFJO0FBQUEsY0FDbkQsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFHO0FBQUEsY0FDSCx1QkFBQyxVQUFLLFdBQVUsaUJBQ2JiLFlBQUVVLGlCQUFpQk8sWUFBWUwsTUFBTSxHQUFFLENBQUMsS0FEM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBTUE7QUFBQSxZQUVBLHVCQUFDLFFBQUlaLFlBQUVjLGVBQWVELEtBQUssSUFBSSxLQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpQztBQUFBLFlBRWpDLHVCQUFDLFFBQ0ViO0FBQUFBLGdCQUFFZSx5QkFBeUJDO0FBQUFBLGNBQVk7QUFBQSxjQUN4Qyx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQUc7QUFBQSxjQUNGaEIsRUFBRWUseUJBQXlCRztBQUFBQSxjQUFjO0FBQUEsaUJBSDVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSUE7QUFBQSxZQUVBLHVCQUFDLFFBQUcsV0FBVSxhQUNaO0FBQUEscUNBQUMsWUFDQyxTQUFTLE1BQU0zRCxTQUFTLFlBQVl5QyxFQUFFSCxHQUFHLEVBQUUsR0FDM0MsV0FBVSxrRUFDWCxvQkFIRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBO0FBQUEsY0FFQSx1QkFBQyxZQUNDLFNBQVMsTUFBTWQsY0FBY2lCLEVBQUVILEdBQUcsR0FDbEMsV0FBVSxvREFDWCxzQkFIRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBO0FBQUEsaUJBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFjQTtBQUFBLGVBaERPRyxFQUFFSCxLQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBa0RBLENBQ0QsS0FyREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFzREE7QUFBQSxhQXJFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBdUVBLEtBeEVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF5RUE7QUFBQSxXQTlFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBK0VBO0FBQUEsU0FqTUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1NQTtBQUFBLElBR0NsQyxtQkFDQyx1QkFBQyxTQUFJLFdBQVUsOEVBQ2IsaUNBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsNkJBQUMsUUFBRyxXQUFVLHVDQUFzQyw4QkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFFQSx1QkFBQyxPQUFFLFdBQVUsUUFBTztBQUFBO0FBQUEsUUFDVCx1QkFBQyxZQUFRRSwyQkFBaUJvQyxTQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdDO0FBQUEsV0FEM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFFQSx1QkFBQyxXQUFNLFdBQVUsa0NBQWlDLHNCQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdEO0FBQUEsTUFDeEQsdUJBQUMsWUFDQyxXQUFVLGtDQUNWLE9BQU9sQyxRQUNQLFVBQVdvRCxPQUFNbkQsVUFBVW1ELEVBQUVDLE9BQU9DLEtBQUssR0FFekM7QUFBQSwrQkFBQyxZQUFPLE9BQU0sSUFBRyxtQ0FBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvQztBQUFBLFFBQ3BDLHVCQUFDLFlBQU8sT0FBTSxzQkFBcUIsa0NBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUQ7QUFBQSxRQUNyRCx1QkFBQyxZQUFPLE9BQU0sZ0JBQWUsNEJBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUM7QUFBQSxRQUN6Qyx1QkFBQyxZQUFPLE9BQU0sb0JBQW1CLGdDQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlEO0FBQUEsUUFDakQsdUJBQUMsWUFBTyxPQUFNLHFCQUFvQixpQ0FBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtRDtBQUFBLFFBQ25ELHVCQUFDLFlBQU8sT0FBTSxTQUFRLHFCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJCO0FBQUEsV0FWN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVdBO0FBQUEsTUFFQSx1QkFBQyxXQUFNLFdBQVUsa0NBQWlDLHdCQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBEO0FBQUEsTUFDMUQsdUJBQUMsY0FDQyxXQUFVLGtDQUNWLE1BQU0sR0FDTixPQUFPcEQsVUFDUCxVQUFXa0QsT0FBTWpELFlBQVlpRCxFQUFFQyxPQUFPQyxLQUFLLEdBQzNDLGFBQVksMEJBTGQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtvQztBQUFBLE1BR25DbEQsU0FBUyx1QkFBQyxPQUFFLFdBQVUsNkJBQTZCQSxtQkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnRDtBQUFBLE1BRTFELHVCQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLCtCQUFDLFlBQ0MsU0FBUyxNQUFNUCxtQkFBbUIsS0FBSyxHQUN2QyxXQUFVLG1EQUNYLHNCQUhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFFBRUEsdUJBQUMsWUFDQyxTQUFTOEIsY0FDVCxXQUFVLDREQUNYLHNCQUhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFdBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWNBO0FBQUEsU0FoREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlEQSxLQWxERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBbURBO0FBQUEsT0E1UEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQStQQTtBQUVKO0FBQUNyQyxHQXJVS0QsbUJBQWlCO0FBQUEsVUFDSEwsU0FDREMsV0FBVztBQUFBO0FBQUFzRSxLQUZ4QmxFO0FBdVVOLGVBQWVBO0FBQWtCLElBQUFrRTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsInVzZVJlZiIsImF4aW9zIiwiQWRtaW5OYXZiYXIiLCJ1c2VBdXRoIiwidXNlTmF2aWdhdGUiLCJFeWUiLCJDaGVjayIsIlgiLCJQcm9qZWN0bWFuYWdlbWVudCIsIl9zIiwidG9rZW4iLCJuYXZpZ2F0ZSIsInByb2plY3RzIiwic2V0UHJvamVjdHMiLCJ0YWJsZVJlZiIsInNob3dSZWplY3RNb2RhbCIsInNldFNob3dSZWplY3RNb2RhbCIsInNlbGVjdGVkUHJvamVjdCIsInNldFNlbGVjdGVkUHJvamVjdCIsInJlYXNvbiIsInNldFJlYXNvbiIsImNvbW1lbnRzIiwic2V0Q29tbWVudHMiLCJlcnJvciIsInNldEVycm9yIiwiZmV0Y2hQcm9qZWN0cyIsImdldCIsImhlYWRlcnMiLCJ0aGVuIiwicmVzIiwiZGF0YSIsImNhdGNoIiwiZXJyIiwiY29uc29sZSIsImxvZyIsImRlbGV0ZVByb2plY3QiLCJpZCIsIndpbmRvdyIsImNvbmZpcm0iLCJkZWxldGUiLCJzY3JvbGxUb1RhYmxlIiwiY3VycmVudCIsInNjcm9sbEludG9WaWV3IiwiYmVoYXZpb3IiLCJvcGVuUmVqZWN0TW9kYWwiLCJwcm9qZWN0IiwiaGFuZGxlUmVqZWN0IiwidHJpbSIsImxlbmd0aCIsIl9pZCIsImFsZXJ0IiwibWFwIiwicCIsInRpdGxlIiwiZGVzY3JpcHRpb24iLCJwcm9qZWN0VHlwZSIsInRlYW1TaXplIiwiZG9tYWluIiwiYWNhZGVtaWNDb25zdHJhaW50cyIsInllYXIiLCJzZW1lc3RlciIsIm1pbmltdW1DR1BBIiwiZXNzZW50aWFsU2tpbGxzIiwibGFuZ3VhZ2VzIiwic2xpY2UiLCJqb2luIiwicmVxdWlyZWRSb2xlcyIsImF2YWlsYWJpbGl0eVJlcXVpcmVtZW50Iiwid2Vla2x5SG91cnMiLCJmcmFtZXdvcmtzIiwiZHVyYXRpb25XZWVrcyIsImUiLCJ0YXJnZXQiLCJ2YWx1ZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUHJvamVjdG1hbmFnZW1lbnQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0LCB1c2VSZWYgfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IGF4aW9zIGZyb20gXCJheGlvc1wiXHJcbmltcG9ydCBBZG1pbk5hdmJhciBmcm9tICcuLi8uLi9jb21wb25lbnRzL0FkbWluTmF2YmFyJ1xyXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSBcIi4uLy4uL2NvbnRleHQvQXV0aENvbnRleHRcIlxyXG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCJcclxuaW1wb3J0IHsgRXllLCBDaGVjaywgWCB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIiAvLyDinIUgaWNvbnNcclxuXHJcbmNvbnN0IFByb2plY3RtYW5hZ2VtZW50ID0gKCkgPT4ge1xyXG4gIGNvbnN0IHsgdG9rZW4gfSA9IHVzZUF1dGgoKTtcclxuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XHJcbiAgY29uc3QgW3Byb2plY3RzLCBzZXRQcm9qZWN0c10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgdGFibGVSZWYgPSB1c2VSZWYobnVsbCk7XHJcblxyXG4gIC8vIOKchSBSZWplY3QgTW9kYWwgU3RhdGVcclxuICBjb25zdCBbc2hvd1JlamVjdE1vZGFsLCBzZXRTaG93UmVqZWN0TW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZFByb2plY3QsIHNldFNlbGVjdGVkUHJvamVjdF0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbcmVhc29uLCBzZXRSZWFzb25dID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2NvbW1lbnRzLCBzZXRDb21tZW50c10gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG5cclxuICBjb25zdCBmZXRjaFByb2plY3RzID0gKCkgPT4ge1xyXG4gICAgYXhpb3MuZ2V0KFwiaHR0cDovL2xvY2FsaG9zdDozMDAwL2FwaS9hZG1pbi9wcm9qZWN0c1wiLCB7XHJcbiAgICAgIGhlYWRlcnM6IHsgXCJ4LWF1dGgtdG9rZW5cIjogdG9rZW4gfSxcclxuICAgIH0pXHJcbiAgICAgIC50aGVuKHJlcyA9PiBzZXRQcm9qZWN0cyhyZXMuZGF0YSkpXHJcbiAgICAgIC5jYXRjaChlcnIgPT4gY29uc29sZS5sb2coZXJyKSk7XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGZldGNoUHJvamVjdHMoKTtcclxuICB9LCBbdG9rZW5dKTtcclxuXHJcbiAgY29uc3QgZGVsZXRlUHJvamVjdCA9IChpZCkgPT4ge1xyXG4gICAgaWYgKHdpbmRvdy5jb25maXJtKFwiRGVsZXRlIHRoaXMgcHJvamVjdD9cIikpIHtcclxuICAgICAgYXhpb3MuZGVsZXRlKGBodHRwOi8vbG9jYWxob3N0OjMwMDAvYXBpL2FkbWluL3Byb2plY3RzLyR7aWR9YCwge1xyXG4gICAgICAgIGhlYWRlcnM6IHsgXCJ4LWF1dGgtdG9rZW5cIjogdG9rZW4gfSxcclxuICAgICAgfSlcclxuICAgICAgICAudGhlbihmZXRjaFByb2plY3RzKVxyXG4gICAgICAgIC5jYXRjaChlcnIgPT4gY29uc29sZS5sb2coZXJyKSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3Qgc2Nyb2xsVG9UYWJsZSA9ICgpID0+IHtcclxuICAgIHRhYmxlUmVmLmN1cnJlbnQ/LnNjcm9sbEludG9WaWV3KHsgYmVoYXZpb3I6IFwic21vb3RoXCIgfSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3Qgb3BlblJlamVjdE1vZGFsID0gKHByb2plY3QpID0+IHtcclxuICAgIHNldFNlbGVjdGVkUHJvamVjdChwcm9qZWN0KTtcclxuICAgIHNldFJlYXNvbihcIlwiKTtcclxuICAgIHNldENvbW1lbnRzKFwiXCIpO1xyXG4gICAgc2V0RXJyb3IoXCJcIik7XHJcbiAgICBzZXRTaG93UmVqZWN0TW9kYWwodHJ1ZSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlUmVqZWN0ID0gKCkgPT4ge1xyXG4gICAgaWYgKCFyZWFzb24pIHtcclxuICAgICAgc2V0RXJyb3IoXCJQbGVhc2Ugc2VsZWN0IGEgcmVhc29uXCIpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKGNvbW1lbnRzLnRyaW0oKS5sZW5ndGggPCA1KSB7XHJcbiAgICAgIHNldEVycm9yKFwiQ29tbWVudHMgbXVzdCBiZSBhdCBsZWFzdCA1IGNoYXJhY3RlcnNcIik7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBjb25zb2xlLmxvZyhcIlJlamVjdGVkIHByb2plY3Q6XCIsIHNlbGVjdGVkUHJvamVjdC5faWQsIHtcclxuICAgICAgcmVhc29uLFxyXG4gICAgICBjb21tZW50cyxcclxuICAgIH0pO1xyXG5cclxuICAgIHNldFNob3dSZWplY3RNb2RhbChmYWxzZSk7XHJcbiAgICBhbGVydChcIlByb2plY3QgcmVqZWN0ZWQgc3VjY2Vzc2Z1bGx5IVwiKTtcclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGgtc2NyZWVuIG92ZXJmbG93LWhpZGRlblwiPlxyXG5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgcC02IGJnLXN1cmZhY2VcIj5cclxuXHJcbiAgICAgICAgey8qIEhlYWRlciAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBtYi02XCI+XHJcbiAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgTmV3IFByb2plY3RzIPCfk51cclxuICAgICAgICAgIDwvaDE+XHJcblxyXG4gICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICBvbkNsaWNrPXtzY3JvbGxUb1RhYmxlfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ibHVlLTUwMCBob3ZlcjpiZy1ibHVlLTYwMCB0ZXh0LXdoaXRlIHB4LTQgcHktMiByb3VuZGVkLWxnIHRleHQtc20gc2hhZG93IHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMCBob3ZlcjpzY2FsZS0xMDVcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICBWaWV3IEFsbCBQcm9qZWN0c1xyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHsvKiA9PT09PT09PT09PT09PT09PSBDQVJEUyA9PT09PT09PT09PT09PT09PSAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTMgeGw6Z3JpZC1jb2xzLTQgZ2FwLTYgYXV0by1yb3dzLWZyXCI+XHJcbiAgICAgICAgICB7cHJvamVjdHMubWFwKChwKSA9PiAoXHJcbiAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICBrZXk9e3AuX2lkfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtMnhsIHNoYWRvdy1tZCBwLTUgYm9yZGVyIGZsZXggZmxleC1jb2wgaC1mdWxsIFxyXG4gICAgICAgICAgICAgIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBob3ZlcjpzaGFkb3ctMnhsIGhvdmVyOi10cmFuc2xhdGUteS0yXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIHsvKiBDb250ZW50ICovfVxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93XCI+XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIEhlYWRlciAqL31cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItM1wiPlxyXG4gICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtwLnRpdGxlfVxyXG4gICAgICAgICAgICAgICAgICA8L2gyPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDAgbGluZS1jbGFtcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge3AuZGVzY3JpcHRpb259XHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBUYWdzICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBnYXAtMiBtYi0zIHRleHQteHNcIj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmctYmx1ZS0xMDAgdGV4dC1ibHVlLTYwMCBweC0yIHB5LTEgcm91bmRlZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtwLnByb2plY3RUeXBlfVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJnLWdyZWVuLTEwMCB0ZXh0LWdyZWVuLTYwMCBweC0yIHB5LTEgcm91bmRlZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFRlYW06IHtwLnRlYW1TaXplfVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJnLXB1cnBsZS0xMDAgdGV4dC1wdXJwbGUtNjAwIHB4LTIgcHktMSByb3VuZGVkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge3AuZG9tYWluPy5bMF19XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBJbmZvICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS03MDAgc3BhY2UteS0xIG1iLTNcIj5cclxuICAgICAgICAgICAgICAgICAgPHA+XHJcbiAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz5ZZWFyOjwvc3Ryb25nPiB7cC5hY2FkZW1pY0NvbnN0cmFpbnRzPy55ZWFyfSB8XHJcbiAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz4gU2VtOjwvc3Ryb25nPiB7cC5hY2FkZW1pY0NvbnN0cmFpbnRzPy5zZW1lc3Rlcn1cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG5cclxuICAgICAgICAgICAgICAgICAgPHA+XHJcbiAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz5DR1BBOjwvc3Ryb25nPntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXllbGxvdy01MDAgZm9udC1zZW1pYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge3AuYWNhZGVtaWNDb25zdHJhaW50cz8ubWluaW11bUNHUEF9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8cD5cclxuICAgICAgICAgICAgICAgICAgICA8c3Ryb25nPlNraWxsczo8L3N0cm9uZz57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAge3AuZXNzZW50aWFsU2tpbGxzPy5sYW5ndWFnZXM/LnNsaWNlKDAsIDIpLmpvaW4oXCIsIFwiKX1cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG5cclxuICAgICAgICAgICAgICAgICAgPHA+XHJcbiAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz5Sb2xlczo8L3N0cm9uZz57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAge3AucmVxdWlyZWRSb2xlcz8uc2xpY2UoMCwgMikuam9pbihcIiwgXCIpfVxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgey8qIEZvb3RlciAqL31cclxuPGRpdiBjbGFzc05hbWU9XCJtdC1hdXRvIGZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiPlxyXG4gIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIHdoaXRlc3BhY2Utbm93cmFwXCI+XHJcbiAgICB7cC5hdmFpbGFiaWxpdHlSZXF1aXJlbWVudD8ud2Vla2x5SG91cnN9aC93ZWVrXHJcbiAgPC9kaXY+XHJcblxyXG4gIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMSBmbGV4LW5vd3JhcFwiPlxyXG5cclxuICAgIHsvKiBWaWV3ICovfVxyXG4gICAgPGJ1dHRvblxyXG4gICAgICBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZShgL3Byb2plY3QvJHtwLl9pZH1gKX1cclxuICAgICAgY2xhc3NOYW1lPVwicHgtMiBweS0wLjUgdGV4dC14cyByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItYmx1ZS01MDAgdGV4dC1ibHVlLTUwMCBob3ZlcjpiZy1ibHVlLTUwIHRyYW5zaXRpb24gd2hpdGVzcGFjZS1ub3dyYXBcIlxyXG4gICAgPlxyXG4gICAgICBWaWV3XHJcbiAgICA8L2J1dHRvbj5cclxuXHJcbiAgICB7LyogQXBwcm92ZSAqL31cclxuICAgIDxidXR0b25cclxuICAgICAgY2xhc3NOYW1lPVwicHgtMiBweS0wLjUgdGV4dC14cyByb3VuZGVkLW1kIGJnLXNlY29uZGFyeSB0ZXh0LXdoaXRlIGhvdmVyOmJnLWdyZWVuLTYwMCB0cmFuc2l0aW9uIHdoaXRlc3BhY2Utbm93cmFwXCJcclxuICAgID5cclxuICAgICAgQXBwcm92ZVxyXG4gICAgPC9idXR0b24+XHJcblxyXG4gICAgey8qIFJlamVjdCAqL31cclxuICAgIDxidXR0b25cclxuICAgICAgb25DbGljaz17KCkgPT4gb3BlblJlamVjdE1vZGFsKHApfVxyXG4gICAgICBjbGFzc05hbWU9XCJweC0yIHB5LTAuNSB0ZXh0LXhzIHJvdW5kZWQtbWQgYmctcmVkLTUwMCB0ZXh0LXdoaXRlIGhvdmVyOmJnLXJlZC02MDAgdHJhbnNpdGlvbiB3aGl0ZXNwYWNlLW5vd3JhcFwiXHJcbiAgICA+XHJcbiAgICAgIFJlamVjdFxyXG4gICAgPC9idXR0b24+XHJcblxyXG4gIDwvZGl2PlxyXG48L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApKX1cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgey8qID09PT09PT09PT09PT09PT09IFRBQkxFID09PT09PT09PT09PT09PT09ICovfVxyXG4gICAgICAgIDxkaXYgcmVmPXt0YWJsZVJlZn0gY2xhc3NOYW1lPVwibXQtMTZcIj5cclxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktODAwIG1iLTRcIj5cclxuICAgICAgICAgICAgQWxsIFByb2plY3RzIFRhYmxlXHJcbiAgICAgICAgICA8L2gyPlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3cteC1hdXRvIGJnLXdoaXRlIHJvdW5kZWQteGwgc2hhZG93XCI+XHJcbiAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJtaW4tdy1mdWxsIHRleHQtc20gdGV4dC1sZWZ0XCI+XHJcblxyXG4gICAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJiZy1ncmF5LTEwMCB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTNcIj5UaXRsZTwvdGg+XHJcbiAgICAgICAgICAgICAgICAgIDx0aD5UZWFtPC90aD5cclxuICAgICAgICAgICAgICAgICAgPHRoPlR5cGU8L3RoPlxyXG4gICAgICAgICAgICAgICAgICA8dGg+QWNhZGVtaWM8L3RoPlxyXG4gICAgICAgICAgICAgICAgICA8dGg+U2tpbGxzPC90aD5cclxuICAgICAgICAgICAgICAgICAgPHRoPlJvbGVzPC90aD5cclxuICAgICAgICAgICAgICAgICAgPHRoPkF2YWlsYWJpbGl0eTwvdGg+XHJcbiAgICAgICAgICAgICAgICAgIDx0aD5BY3Rpb25zPC90aD5cclxuICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgPC90aGVhZD5cclxuXHJcbiAgICAgICAgICAgICAgPHRib2R5PlxyXG4gICAgICAgICAgICAgICAge3Byb2plY3RzLm1hcCgocCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8dHIga2V5PXtwLl9pZH0gY2xhc3NOYW1lPVwiYm9yZGVyLWIgaG92ZXI6YmctZ3JheS01MFwiPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0zIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7cC50aXRsZX1cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDBcIj57cC5kb21haW4/LmpvaW4oXCIsIFwiKX08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPHRkPntwLnRlYW1TaXplfTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPHRkPntwLnByb2plY3RUeXBlfTwvdGQ+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDx0ZD5cclxuICAgICAgICAgICAgICAgICAgICAgIFl7cC5hY2FkZW1pY0NvbnN0cmFpbnRzPy55ZWFyfSAvIFN7cC5hY2FkZW1pY0NvbnN0cmFpbnRzPy5zZW1lc3Rlcn1cclxuICAgICAgICAgICAgICAgICAgICAgIDxiciAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC15ZWxsb3ctNTAwIGZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQ0dQQSB7cC5hY2FkZW1pY0NvbnN0cmFpbnRzPy5taW5pbXVtQ0dQQX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8dGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7cC5lc3NlbnRpYWxTa2lsbHM/Lmxhbmd1YWdlcz8uc2xpY2UoMCwyKS5qb2luKFwiLCBcIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8YnIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3AuZXNzZW50aWFsU2tpbGxzPy5mcmFtZXdvcmtzPy5zbGljZSgwLDEpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDx0ZD57cC5yZXF1aXJlZFJvbGVzPy5qb2luKFwiLCBcIil9PC90ZD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPHRkPlxyXG4gICAgICAgICAgICAgICAgICAgICAge3AuYXZhaWxhYmlsaXR5UmVxdWlyZW1lbnQ/LndlZWtseUhvdXJzfWgvd2Vla1xyXG4gICAgICAgICAgICAgICAgICAgICAgPGJyIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7cC5hdmFpbGFiaWxpdHlSZXF1aXJlbWVudD8uZHVyYXRpb25XZWVrc313XHJcbiAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInNwYWNlLXgtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZShgL3Byb2plY3QvJHtwLl9pZH1gKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTUwMCBib3JkZXIgYm9yZGVyLWJsdWUtNTAwIHB4LTIgcHktMSByb3VuZGVkIHRleHQteHNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBWaWV3XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGRlbGV0ZVByb2plY3QocC5faWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1waW5rLTQwMCB0ZXh0LXdoaXRlIHB4LTIgcHktMSByb3VuZGVkIHRleHQteHNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBSZW1vdmVcclxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgPC90Ym9keT5cclxuXHJcbiAgICAgICAgICAgIDwvdGFibGU+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgey8qID09PT09PT09PT09PT09PT09IFJFSkVDVCBNT0RBTCA9PT09PT09PT09PT09PT09PSAqL31cclxuICAgICAge3Nob3dSZWplY3RNb2RhbCAmJiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJnLWJsYWNrIGJnLW9wYWNpdHktNDAgei01MFwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBwLTYgcm91bmRlZC14bCBzaGFkb3ctbGcgdy05NlwiPlxyXG4gICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgbWItNCB0ZXh0LXJlZC01MDBcIj5cclxuICAgICAgICAgICAgICBSZWplY3QgUHJvamVjdFxyXG4gICAgICAgICAgICA8L2gyPlxyXG5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibWItMlwiPlxyXG4gICAgICAgICAgICAgIFByb2plY3Q6IDxzdHJvbmc+e3NlbGVjdGVkUHJvamVjdD8udGl0bGV9PC9zdHJvbmc+XHJcbiAgICAgICAgICAgIDwvcD5cclxuXHJcbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIG1iLTFcIj5SZWFzb248L2xhYmVsPlxyXG4gICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciByb3VuZGVkIHAtMiBtYi0yXCJcclxuICAgICAgICAgICAgICB2YWx1ZT17cmVhc29ufVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0UmVhc29uKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj4tLSBTZWxlY3QgUmVhc29uIC0tPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkluY29tcGxldGUgZGV0YWlsc1wiPkluY29tcGxldGUgZGV0YWlsczwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJOb3QgcmVsZXZhbnRcIj5Ob3QgcmVsZXZhbnQ8L29wdGlvbj5cclxuICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiTG93IHF1YWxpdHkgaWRlYVwiPkxvdyBxdWFsaXR5IGlkZWE8L29wdGlvbj5cclxuICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiRHVwbGljYXRlIHByb2plY3RcIj5EdXBsaWNhdGUgcHJvamVjdDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJPdGhlclwiPk90aGVyPC9vcHRpb24+XHJcbiAgICAgICAgICAgIDwvc2VsZWN0PlxyXG5cclxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gbWItMVwiPkNvbW1lbnRzPC9sYWJlbD5cclxuICAgICAgICAgICAgPHRleHRhcmVhXHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciByb3VuZGVkIHAtMiBtYi0yXCJcclxuICAgICAgICAgICAgICByb3dzPXszfVxyXG4gICAgICAgICAgICAgIHZhbHVlPXtjb21tZW50c31cclxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldENvbW1lbnRzKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIk1pbmltdW0gNSBjaGFyYWN0ZXJzXCJcclxuICAgICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICAgIHtlcnJvciAmJiA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC1zbSBtYi0yXCI+e2Vycm9yfTwvcD59XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgZ2FwLTIgbXQtMlwiPlxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dSZWplY3RNb2RhbChmYWxzZSl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zIHB5LTEgcm91bmRlZCBiZy1ncmF5LTMwMCBob3ZlcjpiZy1ncmF5LTQwMFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgQ2FuY2VsXHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVJlamVjdH1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMgcHktMSByb3VuZGVkIGJnLXJlZC01MDAgdGV4dC13aGl0ZSBob3ZlcjpiZy1yZWQtNjAwXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBSZWplY3RcclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuXHJcbiAgICA8L2Rpdj5cclxuICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IFByb2plY3RtYW5hZ2VtZW50OyJdLCJmaWxlIjoiRjovWTNTMi9JVFBNIHByb2plY3QvUHJvTWF0ZS0tUHJvamVjdC1QYXJ0bmVyLUZpbmRlci9mcm9udGVuZC9zcmMvcGFnZXMvQWRtaW4vUHJvamVjdG1hbmFnZW1lbnQuanN4In0=