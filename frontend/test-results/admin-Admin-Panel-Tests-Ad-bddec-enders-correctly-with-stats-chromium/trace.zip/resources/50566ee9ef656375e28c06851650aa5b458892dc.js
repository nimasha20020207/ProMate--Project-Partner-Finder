import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Admin/History.jsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/History.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=383bea9f"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import axios from "/node_modules/.vite/deps/axios.js?v=383bea9f";
import { useAuth } from "/src/context/AuthContext.jsx";
const SuspensionHistory = () => {
  _s();
  const {
    token
  } = useAuth();
  const [data, setData] = useState([]);
  useEffect(() => {
    axios.get("http://localhost:3000/api/admin/suspensions", {
      headers: {
        "x-auth-token": token
      }
    }).then((res) => setData(res.data)).catch((err) => console.log(err));
  }, [token]);
  return /* @__PURE__ */ jsxDEV("div", { className: "p-6 bg-surface min-h-screen", children: [
    /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold mb-6 text-textPrimary", children: "Suspension History 🚫" }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/History.jsx",
      lineNumber: 19,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto bg-white rounded-xl shadow", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full text-left text-sm", children: [
      /* @__PURE__ */ jsxDEV("thead", { className: "bg-primary text-white", children: /* @__PURE__ */ jsxDEV("tr", { children: [
        /* @__PURE__ */ jsxDEV("th", { className: "p-3 border-r", children: "Name" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/History.jsx",
          lineNumber: 27,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("th", { className: "p-3 border-r", children: "Student ID" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/History.jsx",
          lineNumber: 28,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("th", { className: "p-3 border-r", children: "Reason" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/History.jsx",
          lineNumber: 29,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("th", { className: "p-3 border-r", children: "Comments" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/History.jsx",
          lineNumber: 30,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("th", { className: "p-3", children: "Suspend Date" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/History.jsx",
          lineNumber: 31,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/History.jsx",
        lineNumber: 26,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/History.jsx",
        lineNumber: 25,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("tbody", { children: [
        data.map((s) => /* @__PURE__ */ jsxDEV("tr", { className: "border-b hover:bg-surface transition-colors", children: [
          /* @__PURE__ */ jsxDEV("td", { className: "p-3 text-textPrimary font-medium", children: s.studentId?.fullName || "N/A" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/History.jsx",
            lineNumber: 37,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("td", { className: "p-3 text-textSecondary", children: s.studentId?.studentId || "N/A" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/History.jsx",
            lineNumber: 40,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("td", { className: "p-3 text-textSecondary", children: s.reason }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/History.jsx",
            lineNumber: 41,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("td", { className: "p-3 text-textSecondary", children: s.additionalComments }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/History.jsx",
            lineNumber: 42,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("td", { className: "p-3 text-textSecondary", children: new Date(s.suspendDate).toLocaleDateString() }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/History.jsx",
            lineNumber: 43,
            columnNumber: 17
          }, this)
        ] }, s._id, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/History.jsx",
          lineNumber: 36,
          columnNumber: 28
        }, this)),
        data.length === 0 && /* @__PURE__ */ jsxDEV("tr", { children: /* @__PURE__ */ jsxDEV("td", { colSpan: 5, className: "p-4 text-center text-textSecondary", children: "No suspension records found." }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/History.jsx",
          lineNumber: 48,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/History.jsx",
          lineNumber: 47,
          columnNumber: 35
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/History.jsx",
        lineNumber: 35,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/History.jsx",
      lineNumber: 24,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/History.jsx",
      lineNumber: 23,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/History.jsx",
    lineNumber: 18,
    columnNumber: 10
  }, this);
};
_s(SuspensionHistory, "e/DmxReD5vDec4f7GHStMoLVfrw=", false, function() {
  return [useAuth];
});
_c = SuspensionHistory;
export default SuspensionHistory;
var _c;
$RefreshReg$(_c, "SuspensionHistory");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/History.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUJNOzs7Ozs7Ozs7Ozs7Ozs7O0FBbkJOLE9BQU9BLFNBQVNDLFdBQVdDLGdCQUFnQjtBQUMzQyxPQUFPQyxXQUFXO0FBQ2xCLFNBQVNDLGVBQWU7QUFFeEIsTUFBTUMsb0JBQW9CQSxNQUFNO0FBQUFDLEtBQUE7QUFDOUIsUUFBTTtBQUFBLElBQUVDO0FBQUFBLEVBQU0sSUFBSUgsUUFBUTtBQUMxQixRQUFNLENBQUNJLE1BQU1DLE9BQU8sSUFBSVAsU0FBUyxFQUFFO0FBRW5DRCxZQUFVLE1BQU07QUFDZEUsVUFDR08sSUFBSSwrQ0FBK0M7QUFBQSxNQUNsREMsU0FBUztBQUFBLFFBQUUsZ0JBQWdCSjtBQUFBQSxNQUFNO0FBQUEsSUFDbkMsQ0FBQyxFQUNBSyxLQUFNQyxTQUFRSixRQUFRSSxJQUFJTCxJQUFJLENBQUMsRUFDL0JNLE1BQU9DLFNBQVFDLFFBQVFDLElBQUlGLEdBQUcsQ0FBQztBQUFBLEVBQ3BDLEdBQUcsQ0FBQ1IsS0FBSyxDQUFDO0FBRVYsU0FDRSx1QkFBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSwyQkFBQyxRQUFHLFdBQVUsNENBQTJDLHFDQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSw4Q0FDYixpQ0FBQyxXQUFNLFdBQVUsZ0NBQ2Y7QUFBQSw2QkFBQyxXQUFNLFdBQVUseUJBQ2YsaUNBQUMsUUFDQztBQUFBLCtCQUFDLFFBQUcsV0FBVSxnQkFBZSxvQkFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpQztBQUFBLFFBQ2pDLHVCQUFDLFFBQUcsV0FBVSxnQkFBZSwwQkFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1QztBQUFBLFFBQ3ZDLHVCQUFDLFFBQUcsV0FBVSxnQkFBZSxzQkFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtQztBQUFBLFFBQ25DLHVCQUFDLFFBQUcsV0FBVSxnQkFBZSx3QkFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxQztBQUFBLFFBQ3JDLHVCQUFDLFFBQUcsV0FBVSxPQUFNLDRCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdDO0FBQUEsV0FMbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1BLEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsTUFFQSx1QkFBQyxXQUNFQztBQUFBQSxhQUFLVSxJQUFLQyxPQUNULHVCQUFDLFFBQWUsV0FBVSwrQ0FDeEI7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsb0NBQ1hBLFlBQUVDLFdBQVdDLFlBQVksU0FENUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsUUFBRyxXQUFVLDBCQUEwQkYsWUFBRUMsV0FBV0EsYUFBYSxTQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3RTtBQUFBLFVBQ3hFLHVCQUFDLFFBQUcsV0FBVSwwQkFBMEJELFlBQUVHLFVBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlEO0FBQUEsVUFDakQsdUJBQUMsUUFBRyxXQUFVLDBCQUEwQkgsWUFBRUksc0JBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZEO0FBQUEsVUFDN0QsdUJBQUMsUUFBRyxXQUFVLDBCQUNYLGNBQUlDLEtBQUtMLEVBQUVNLFdBQVcsRUFBRUMsbUJBQW1CLEtBRDlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQVRPUCxFQUFFUSxLQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQSxDQUNEO0FBQUEsUUFDQW5CLEtBQUtvQixXQUFXLEtBQ2YsdUJBQUMsUUFDQyxpQ0FBQyxRQUFHLFNBQVMsR0FBRyxXQUFVLHNDQUFxQyw0Q0FBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlBO0FBQUEsV0FuQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXFCQTtBQUFBLFNBaENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpQ0EsS0FsQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1DQTtBQUFBLE9BeENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F5Q0E7QUFFSjtBQUFFdEIsR0F6RElELG1CQUFpQjtBQUFBLFVBQ0hELE9BQU87QUFBQTtBQUFBeUIsS0FEckJ4QjtBQTJETixlQUFlQTtBQUFrQixJQUFBd0I7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJheGlvcyIsInVzZUF1dGgiLCJTdXNwZW5zaW9uSGlzdG9yeSIsIl9zIiwidG9rZW4iLCJkYXRhIiwic2V0RGF0YSIsImdldCIsImhlYWRlcnMiLCJ0aGVuIiwicmVzIiwiY2F0Y2giLCJlcnIiLCJjb25zb2xlIiwibG9nIiwibWFwIiwicyIsInN0dWRlbnRJZCIsImZ1bGxOYW1lIiwicmVhc29uIiwiYWRkaXRpb25hbENvbW1lbnRzIiwiRGF0ZSIsInN1c3BlbmREYXRlIiwidG9Mb2NhbGVEYXRlU3RyaW5nIiwiX2lkIiwibGVuZ3RoIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJIaXN0b3J5LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgYXhpb3MgZnJvbSBcImF4aW9zXCI7XHJcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tIFwiLi4vLi4vY29udGV4dC9BdXRoQ29udGV4dFwiO1xyXG5cclxuY29uc3QgU3VzcGVuc2lvbkhpc3RvcnkgPSAoKSA9PiB7XHJcbiAgY29uc3QgeyB0b2tlbiB9ID0gdXNlQXV0aCgpO1xyXG4gIGNvbnN0IFtkYXRhLCBzZXREYXRhXSA9IHVzZVN0YXRlKFtdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGF4aW9zXHJcbiAgICAgIC5nZXQoXCJodHRwOi8vbG9jYWxob3N0OjMwMDAvYXBpL2FkbWluL3N1c3BlbnNpb25zXCIsIHtcclxuICAgICAgICBoZWFkZXJzOiB7IFwieC1hdXRoLXRva2VuXCI6IHRva2VuIH0sXHJcbiAgICAgIH0pXHJcbiAgICAgIC50aGVuKChyZXMpID0+IHNldERhdGEocmVzLmRhdGEpKVxyXG4gICAgICAuY2F0Y2goKGVycikgPT4gY29uc29sZS5sb2coZXJyKSk7XHJcbiAgfSwgW3Rva2VuXSk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNiBiZy1zdXJmYWNlIG1pbi1oLXNjcmVlblwiPlxyXG4gICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIG1iLTYgdGV4dC10ZXh0UHJpbWFyeVwiPlxyXG4gICAgICAgIFN1c3BlbnNpb24gSGlzdG9yeSDwn5qrXHJcbiAgICAgIDwvaDE+XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LXgtYXV0byBiZy13aGl0ZSByb3VuZGVkLXhsIHNoYWRvd1wiPlxyXG4gICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJtaW4tdy1mdWxsIHRleHQtbGVmdCB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICA8dGhlYWQgY2xhc3NOYW1lPVwiYmctcHJpbWFyeSB0ZXh0LXdoaXRlXCI+XHJcbiAgICAgICAgICAgIDx0cj5cclxuICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0zIGJvcmRlci1yXCI+TmFtZTwvdGg+XHJcbiAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMyBib3JkZXItclwiPlN0dWRlbnQgSUQ8L3RoPlxyXG4gICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTMgYm9yZGVyLXJcIj5SZWFzb248L3RoPlxyXG4gICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTMgYm9yZGVyLXJcIj5Db21tZW50czwvdGg+XHJcbiAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtM1wiPlN1c3BlbmQgRGF0ZTwvdGg+XHJcbiAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICA8L3RoZWFkPlxyXG5cclxuICAgICAgICAgIDx0Ym9keT5cclxuICAgICAgICAgICAge2RhdGEubWFwKChzKSA9PiAoXHJcbiAgICAgICAgICAgICAgPHRyIGtleT17cy5faWR9IGNsYXNzTmFtZT1cImJvcmRlci1iIGhvdmVyOmJnLXN1cmZhY2UgdHJhbnNpdGlvbi1jb2xvcnNcIj5cclxuICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTMgdGV4dC10ZXh0UHJpbWFyeSBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICB7cy5zdHVkZW50SWQ/LmZ1bGxOYW1lIHx8IFwiTi9BXCJ9XHJcbiAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMyB0ZXh0LXRleHRTZWNvbmRhcnlcIj57cy5zdHVkZW50SWQ/LnN0dWRlbnRJZCB8fCBcIk4vQVwifTwvdGQ+XHJcbiAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0zIHRleHQtdGV4dFNlY29uZGFyeVwiPntzLnJlYXNvbn08L3RkPlxyXG4gICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMyB0ZXh0LXRleHRTZWNvbmRhcnlcIj57cy5hZGRpdGlvbmFsQ29tbWVudHN9PC90ZD5cclxuICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTMgdGV4dC10ZXh0U2Vjb25kYXJ5XCI+XHJcbiAgICAgICAgICAgICAgICAgIHtuZXcgRGF0ZShzLnN1c3BlbmREYXRlKS50b0xvY2FsZURhdGVTdHJpbmcoKX1cclxuICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIHtkYXRhLmxlbmd0aCA9PT0gMCAmJiAoXHJcbiAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgPHRkIGNvbFNwYW49ezV9IGNsYXNzTmFtZT1cInAtNCB0ZXh0LWNlbnRlciB0ZXh0LXRleHRTZWNvbmRhcnlcIj5cclxuICAgICAgICAgICAgICAgICAgTm8gc3VzcGVuc2lvbiByZWNvcmRzIGZvdW5kLlxyXG4gICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC90Ym9keT5cclxuICAgICAgICA8L3RhYmxlPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBTdXNwZW5zaW9uSGlzdG9yeTsiXSwiZmlsZSI6IkY6L1kzUzIvSVRQTSBwcm9qZWN0L1Byb01hdGUtLVByb2plY3QtUGFydG5lci1GaW5kZXIvZnJvbnRlbmQvc3JjL3BhZ2VzL0FkbWluL0hpc3RvcnkuanN4In0=