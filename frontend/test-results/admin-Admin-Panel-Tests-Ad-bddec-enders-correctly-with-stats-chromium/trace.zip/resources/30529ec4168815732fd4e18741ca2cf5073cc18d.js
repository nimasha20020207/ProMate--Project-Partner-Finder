import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Users/Login.jsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Login.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=383bea9f"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"];
import { Link, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=383bea9f";
import { useAuth } from "/src/context/AuthContext.jsx";
import logo from "/src/assets/images/logo.jpeg?import";
const Login = () => {
  _s();
  const {
    login
  } = useAuth();
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    identifier: "",
    password: ""
  });
  const [error, setError] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const handleChange = (e) => setFormData({
    ...formData,
    [e.target.name]: e.target.value
  });
  const handleSubmit = async (e) => {
    e.preventDefault();
    const res = await login(formData.identifier, formData.password);
    if (res.success) {
      if (res.user && res.user.role === "admin") {
        navigate("/admindashboard");
      } else {
        navigate("/dashboard");
      }
    } else {
      setError(res.message);
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { id: "page-login", className: "page active", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "auth-blob-1" }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Login.jsx",
      lineNumber: 36,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "auth-blob-2" }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Login.jsx",
      lineNumber: 37,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "auth-container", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "auth-logo", onClick: () => navigate("/"), style: {
        cursor: "pointer",
        display: "flex",
        alignItems: "center",
        gap: "8px"
      }, children: [
        /* @__PURE__ */ jsxDEV("img", { src: logo, alt: "ProMate Logo", style: {
          width: "40px",
          height: "40px",
          borderRadius: "50%"
        } }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Login.jsx",
          lineNumber: 46,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { style: {
          fontSize: "1.5rem",
          fontWeight: "bold",
          color: "var(--p)"
        }, children: "ProMate" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Login.jsx",
          lineNumber: 51,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Login.jsx",
        lineNumber: 40,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "auth-card", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "auth-header", children: [
          /* @__PURE__ */ jsxDEV("h2", { children: "Welcome back 👋" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Login.jsx",
            lineNumber: 60,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { children: "Sign in to your ProjectMate account" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Login.jsx",
            lineNumber: 61,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Login.jsx",
          lineNumber: 59,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, children: [
          error && /* @__PURE__ */ jsxDEV("div", { className: "form-error show", style: {
            marginBottom: "1rem",
            textAlign: "center"
          }, children: error }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Login.jsx",
            lineNumber: 65,
            columnNumber: 23
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "form-label", children: "Student ID or Email Address" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Login.jsx",
              lineNumber: 71,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("input", { type: "text", className: "form-input", name: "identifier", placeholder: "Enter your Student ID or Email", value: formData.identifier, onChange: handleChange, required: true }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Login.jsx",
              lineNumber: 72,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Login.jsx",
            lineNumber: 70,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "form-label", children: "Password" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Login.jsx",
              lineNumber: 76,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "pw-wrap", children: [
              /* @__PURE__ */ jsxDEV("input", { type: showPassword ? "text" : "password", className: "form-input", name: "password", placeholder: "Enter your password", value: formData.password, onChange: handleChange, required: true }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Login.jsx",
                lineNumber: 78,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("button", { className: "pw-toggle", type: "button", onClick: () => setShowPassword(!showPassword), children: showPassword ? "🙈" : "👁️" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Login.jsx",
                lineNumber: 79,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Login.jsx",
              lineNumber: 77,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Login.jsx",
            lineNumber: 75,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "remember-row", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "remember-check", children: [
              /* @__PURE__ */ jsxDEV("input", { type: "checkbox" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Login.jsx",
                lineNumber: 87,
                columnNumber: 17
              }, this),
              " Remember me"
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Login.jsx",
              lineNumber: 86,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(Link, { to: "/forgot-password", style: {
              textDecoration: "none"
            }, children: /* @__PURE__ */ jsxDEV("span", { className: "forgot-link", style: {
              cursor: "pointer"
            }, children: "Forgot password?" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Login.jsx",
              lineNumber: 92,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Login.jsx",
              lineNumber: 89,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Login.jsx",
            lineNumber: 85,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("button", { type: "submit", className: "btn btn-primary btn-full", style: {
            padding: ".8rem"
          }, children: "Sign In →" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Login.jsx",
            lineNumber: 98,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Login.jsx",
          lineNumber: 64,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "auth-divider", children: "or continue with" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Login.jsx",
          lineNumber: 105,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "social-btns", children: [
          /* @__PURE__ */ jsxDEV("button", { className: "btn btn-outline", type: "button", children: "🔵 Google" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Login.jsx",
            lineNumber: 107,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("button", { className: "btn btn-outline", type: "button", children: "⚫ GitHub" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Login.jsx",
            lineNumber: 108,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Login.jsx",
          lineNumber: 106,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "auth-footer-text", children: [
          "Don't have an account? ",
          /* @__PURE__ */ jsxDEV(Link, { to: "/register", style: {
            cursor: "pointer"
          }, children: "Create one →" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Login.jsx",
            lineNumber: 112,
            columnNumber: 36
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Login.jsx",
          lineNumber: 111,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Login.jsx",
        lineNumber: 58,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Login.jsx",
      lineNumber: 39,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Login.jsx",
    lineNumber: 35,
    columnNumber: 10
  }, this);
};
_s(Login, "MW+0SfOy0F+qzXbT1bd8x6hgaEw=", false, function() {
  return [useAuth, useNavigate];
});
_c = Login;
export default Login;
var _c;
$RefreshReg$(_c, "Login");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Login.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOEJNOzs7Ozs7Ozs7Ozs7Ozs7O0FBOUJOLE9BQU9BLFNBQVNDLGdCQUFnQjtBQUNoQyxTQUFTQyxNQUFNQyxtQkFBbUI7QUFDbEMsU0FBU0MsZUFBZTtBQUN4QixPQUFPQyxVQUFVO0FBRWpCLE1BQU1DLFFBQVFBLE1BQU07QUFBQUMsS0FBQTtBQUNsQixRQUFNO0FBQUEsSUFBRUM7QUFBQUEsRUFBTSxJQUFJSixRQUFRO0FBQzFCLFFBQU1LLFdBQVdOLFlBQVk7QUFDN0IsUUFBTSxDQUFDTyxVQUFVQyxXQUFXLElBQUlWLFNBQVM7QUFBQSxJQUFFVyxZQUFZO0FBQUEsSUFBSUMsVUFBVTtBQUFBLEVBQUcsQ0FBQztBQUN6RSxRQUFNLENBQUNDLE9BQU9DLFFBQVEsSUFBSWQsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQ2UsY0FBY0MsZUFBZSxJQUFJaEIsU0FBUyxLQUFLO0FBRXRELFFBQU1pQixlQUFnQkMsT0FBTVIsWUFBWTtBQUFBLElBQUUsR0FBR0Q7QUFBQUEsSUFBVSxDQUFDUyxFQUFFQyxPQUFPQyxJQUFJLEdBQUdGLEVBQUVDLE9BQU9FO0FBQUFBLEVBQU0sQ0FBQztBQUV4RixRQUFNQyxlQUFlLE9BQU9KLE1BQU07QUFDaENBLE1BQUVLLGVBQWU7QUFDakIsVUFBTUMsTUFBTSxNQUFNakIsTUFBTUUsU0FBU0UsWUFBWUYsU0FBU0csUUFBUTtBQUM5RCxRQUFJWSxJQUFJQyxTQUFTO0FBQ2YsVUFBSUQsSUFBSUUsUUFBUUYsSUFBSUUsS0FBS0MsU0FBUyxTQUFTO0FBQ3pDbkIsaUJBQVMsaUJBQWlCO0FBQUEsTUFDNUIsT0FBTztBQUNMQSxpQkFBUyxZQUFZO0FBQUEsTUFDdkI7QUFBQSxJQUNGLE9BQU87QUFDTE0sZUFBU1UsSUFBSUksT0FBTztBQUFBLElBQ3RCO0FBQUEsRUFDRjtBQUVBLFNBQ0UsdUJBQUMsU0FBSSxJQUFHLGNBQWEsV0FBVSxlQUM3QjtBQUFBLDJCQUFDLFNBQUksV0FBVSxpQkFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTZCO0FBQUEsSUFDN0IsdUJBQUMsU0FBSSxXQUFVLGlCQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNkI7QUFBQSxJQUU3Qix1QkFBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsYUFBWSxTQUFTLE1BQU1wQixTQUFTLEdBQUcsR0FBRyxPQUFPO0FBQUEsUUFBRXFCLFFBQVE7QUFBQSxRQUFXQyxTQUFTO0FBQUEsUUFBUUMsWUFBWTtBQUFBLFFBQVVDLEtBQUs7QUFBQSxNQUFNLEdBQ3JJO0FBQUEsK0JBQUMsU0FBSSxLQUFLNUIsTUFBTSxLQUFJLGdCQUFlLE9BQU87QUFBQSxVQUFFNkIsT0FBTztBQUFBLFVBQVFDLFFBQVE7QUFBQSxVQUFRQyxjQUFjO0FBQUEsUUFBTSxLQUEvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlHO0FBQUEsUUFDakcsdUJBQUMsVUFBSyxPQUFPO0FBQUEsVUFBRUMsVUFBVTtBQUFBLFVBQVVDLFlBQVk7QUFBQSxVQUFRQyxPQUFPO0FBQUEsUUFBVyxHQUFHLHVCQUE1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1GO0FBQUEsV0FGckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsaUNBQUMsUUFBRywrQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtQjtBQUFBLFVBQ25CLHVCQUFDLE9BQUUsbURBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0M7QUFBQSxhQUZ4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUVBLHVCQUFDLFVBQUssVUFBVWhCLGNBQ2JUO0FBQUFBLG1CQUFTLHVCQUFDLFNBQUksV0FBVSxtQkFBa0IsT0FBTztBQUFBLFlBQUUwQixjQUFjO0FBQUEsWUFBUUMsV0FBVztBQUFBLFVBQVMsR0FBSTNCLG1CQUF4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4RjtBQUFBLFVBRXhHLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGNBQWEsMkNBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlEO0FBQUEsWUFDekQsdUJBQUMsV0FDQyxNQUFLLFFBQ0wsV0FBVSxjQUNWLE1BQUssY0FDTCxhQUFZLGtDQUNaLE9BQU9KLFNBQVNFLFlBQ2hCLFVBQVVNLGNBQ1YsVUFBUSxRQVBWO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBT1U7QUFBQSxlQVRaO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBV0E7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGNBQWEsd0JBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNDO0FBQUEsWUFDdEMsdUJBQUMsU0FBSSxXQUFVLFdBQ2I7QUFBQSxxQ0FBQyxXQUNDLE1BQU1GLGVBQWUsU0FBUyxZQUM5QixXQUFVLGNBQ1YsTUFBSyxZQUNMLGFBQVksdUJBQ1osT0FBT04sU0FBU0csVUFDaEIsVUFBVUssY0FDVixVQUFRLFFBUFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFPVTtBQUFBLGNBRVYsdUJBQUMsWUFDQyxXQUFVLGFBQ1YsTUFBSyxVQUNMLFNBQVMsTUFBTUQsZ0JBQWdCLENBQUNELFlBQVksR0FFM0NBLHlCQUFlLE9BQU8sU0FMekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFNQTtBQUFBLGlCQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWlCQTtBQUFBLGVBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBb0JBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsZ0JBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsa0JBQ2Y7QUFBQSxxQ0FBQyxXQUFNLE1BQUssY0FBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFzQjtBQUFBLGNBQUc7QUFBQSxpQkFEM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsUUFBSyxJQUFHLG9CQUFtQixPQUFPO0FBQUEsY0FBRTBCLGdCQUFnQjtBQUFBLFlBQU8sR0FDMUQsaUNBQUMsVUFBSyxXQUFVLGVBQWMsT0FBTztBQUFBLGNBQUVaLFFBQVE7QUFBQSxZQUFVLEdBQUcsZ0NBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRFLEtBRDlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0E7QUFBQSxVQUVBLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFdBQVUsNEJBQTJCLE9BQU87QUFBQSxZQUFFYSxTQUFTO0FBQUEsVUFBUSxHQUFHLHlCQUF4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFqREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWtEQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLGdCQUFlLGdDQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThDO0FBQUEsUUFDOUMsdUJBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSxpQ0FBQyxZQUFPLFdBQVUsbUJBQWtCLE1BQUssVUFBUyx5QkFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMkQ7QUFBQSxVQUMzRCx1QkFBQyxZQUFPLFdBQVUsbUJBQWtCLE1BQUssVUFBUyx3QkFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEQ7QUFBQSxhQUY1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSxvQkFBbUI7QUFBQTtBQUFBLFVBQ1QsdUJBQUMsUUFBSyxJQUFHLGFBQVksT0FBTztBQUFBLFlBQUViLFFBQVE7QUFBQSxVQUFVLEdBQUcsNEJBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStEO0FBQUEsYUFEeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FsRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW1FQTtBQUFBLFNBekVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EwRUE7QUFBQSxPQTlFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBK0VBO0FBRUo7QUFBRXZCLEdBekdJRCxPQUFLO0FBQUEsVUFDU0YsU0FDREQsV0FBVztBQUFBO0FBQUF5QyxLQUZ4QnRDO0FBMkdOLGVBQWVBO0FBQU0sSUFBQXNDO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsInVzZVN0YXRlIiwiTGluayIsInVzZU5hdmlnYXRlIiwidXNlQXV0aCIsImxvZ28iLCJMb2dpbiIsIl9zIiwibG9naW4iLCJuYXZpZ2F0ZSIsImZvcm1EYXRhIiwic2V0Rm9ybURhdGEiLCJpZGVudGlmaWVyIiwicGFzc3dvcmQiLCJlcnJvciIsInNldEVycm9yIiwic2hvd1Bhc3N3b3JkIiwic2V0U2hvd1Bhc3N3b3JkIiwiaGFuZGxlQ2hhbmdlIiwiZSIsInRhcmdldCIsIm5hbWUiLCJ2YWx1ZSIsImhhbmRsZVN1Ym1pdCIsInByZXZlbnREZWZhdWx0IiwicmVzIiwic3VjY2VzcyIsInVzZXIiLCJyb2xlIiwibWVzc2FnZSIsImN1cnNvciIsImRpc3BsYXkiLCJhbGlnbkl0ZW1zIiwiZ2FwIiwid2lkdGgiLCJoZWlnaHQiLCJib3JkZXJSYWRpdXMiLCJmb250U2l6ZSIsImZvbnRXZWlnaHQiLCJjb2xvciIsIm1hcmdpbkJvdHRvbSIsInRleHRBbGlnbiIsInRleHREZWNvcmF0aW9uIiwicGFkZGluZyIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiTG9naW4uanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgTGluaywgdXNlTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcclxuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4uLy4uL2NvbnRleHQvQXV0aENvbnRleHQnO1xyXG5pbXBvcnQgbG9nbyBmcm9tICcuLi8uLi9hc3NldHMvaW1hZ2VzL2xvZ28uanBlZyc7XHJcblxyXG5jb25zdCBMb2dpbiA9ICgpID0+IHtcclxuICBjb25zdCB7IGxvZ2luIH0gPSB1c2VBdXRoKCk7XHJcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xyXG4gIGNvbnN0IFtmb3JtRGF0YSwgc2V0Rm9ybURhdGFdID0gdXNlU3RhdGUoeyBpZGVudGlmaWVyOiAnJywgcGFzc3dvcmQ6ICcnIH0pO1xyXG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUoJycpO1xyXG4gIGNvbnN0IFtzaG93UGFzc3dvcmQsIHNldFNob3dQYXNzd29yZF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIGNvbnN0IGhhbmRsZUNoYW5nZSA9IChlKSA9PiBzZXRGb3JtRGF0YSh7IC4uLmZvcm1EYXRhLCBbZS50YXJnZXQubmFtZV06IGUudGFyZ2V0LnZhbHVlIH0pO1xyXG5cclxuICBjb25zdCBoYW5kbGVTdWJtaXQgPSBhc3luYyAoZSkgPT4ge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgY29uc3QgcmVzID0gYXdhaXQgbG9naW4oZm9ybURhdGEuaWRlbnRpZmllciwgZm9ybURhdGEucGFzc3dvcmQpO1xyXG4gICAgaWYgKHJlcy5zdWNjZXNzKSB7XHJcbiAgICAgIGlmIChyZXMudXNlciAmJiByZXMudXNlci5yb2xlID09PSAnYWRtaW4nKSB7XHJcbiAgICAgICAgbmF2aWdhdGUoJy9hZG1pbmRhc2hib2FyZCcpO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIG5hdmlnYXRlKCcvZGFzaGJvYXJkJyk7XHJcbiAgICAgIH1cclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHNldEVycm9yKHJlcy5tZXNzYWdlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBpZD1cInBhZ2UtbG9naW5cIiBjbGFzc05hbWU9XCJwYWdlIGFjdGl2ZVwiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImF1dGgtYmxvYi0xXCI+PC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYXV0aC1ibG9iLTJcIj48L2Rpdj5cclxuICAgICAgXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYXV0aC1jb250YWluZXJcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImF1dGgtbG9nb1wiIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKCcvJyl9IHN0eWxlPXt7IGN1cnNvcjogJ3BvaW50ZXInLCBkaXNwbGF5OiAnZmxleCcsIGFsaWduSXRlbXM6ICdjZW50ZXInLCBnYXA6ICc4cHgnIH19PlxyXG4gICAgICAgICAgPGltZyBzcmM9e2xvZ299IGFsdD1cIlByb01hdGUgTG9nb1wiIHN0eWxlPXt7IHdpZHRoOiAnNDBweCcsIGhlaWdodDogJzQwcHgnLCBib3JkZXJSYWRpdXM6ICc1MCUnIH19IC8+XHJcbiAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250U2l6ZTogJzEuNXJlbScsIGZvbnRXZWlnaHQ6ICdib2xkJywgY29sb3I6ICd2YXIoLS1wKScgfX0+UHJvTWF0ZTwvc3Bhbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICBcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImF1dGgtY2FyZFwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhdXRoLWhlYWRlclwiPlxyXG4gICAgICAgICAgICA8aDI+V2VsY29tZSBiYWNrIPCfkYs8L2gyPlxyXG4gICAgICAgICAgICA8cD5TaWduIGluIHRvIHlvdXIgUHJvamVjdE1hdGUgYWNjb3VudDwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU3VibWl0fT5cclxuICAgICAgICAgICAge2Vycm9yICYmIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1lcnJvciBzaG93XCIgc3R5bGU9e3sgbWFyZ2luQm90dG9tOiAnMXJlbScsIHRleHRBbGlnbjogJ2NlbnRlcicgfX0+e2Vycm9yfTwvZGl2Pn1cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncm91cFwiPlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmb3JtLWxhYmVsXCI+U3R1ZGVudCBJRCBvciBFbWFpbCBBZGRyZXNzPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZvcm0taW5wdXRcIlxyXG4gICAgICAgICAgICAgICAgbmFtZT1cImlkZW50aWZpZXJcIlxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB5b3VyIFN0dWRlbnQgSUQgb3IgRW1haWxcIlxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmlkZW50aWZpZXJ9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncm91cFwiPlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmb3JtLWxhYmVsXCI+UGFzc3dvcmQ8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHctd3JhcFwiPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9e3Nob3dQYXNzd29yZCA/ICd0ZXh0JyA6ICdwYXNzd29yZCd9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZvcm0taW5wdXRcIlxyXG4gICAgICAgICAgICAgICAgICBuYW1lPVwicGFzc3dvcmRcIlxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHlvdXIgcGFzc3dvcmRcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEucGFzc3dvcmR9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwdy10b2dnbGVcIlxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd1Bhc3N3b3JkKCFzaG93UGFzc3dvcmQpfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7c2hvd1Bhc3N3b3JkID8gXCLwn5mIXCIgOiBcIvCfkYHvuI9cIn1cclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVtZW1iZXItcm93XCI+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInJlbWVtYmVyLWNoZWNrXCI+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cImNoZWNrYm94XCIgLz4gUmVtZW1iZXIgbWVcclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxMaW5rIHRvPVwiL2ZvcmdvdC1wYXNzd29yZFwiIHN0eWxlPXt7IHRleHREZWNvcmF0aW9uOiAnbm9uZScgfX0+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb3Jnb3QtbGlua1wiIHN0eWxlPXt7IGN1cnNvcjogJ3BvaW50ZXInIH19PkZvcmdvdCBwYXNzd29yZD88L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiIGNsYXNzTmFtZT1cImJ0biBidG4tcHJpbWFyeSBidG4tZnVsbFwiIHN0eWxlPXt7IHBhZGRpbmc6ICcuOHJlbScgfX0+XHJcbiAgICAgICAgICAgICAgU2lnbiBJbiDihpJcclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICA8L2Zvcm0+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhdXRoLWRpdmlkZXJcIj5vciBjb250aW51ZSB3aXRoPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNvY2lhbC1idG5zXCI+XHJcbiAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYnRuIGJ0bi1vdXRsaW5lXCIgdHlwZT1cImJ1dHRvblwiPvCflLUgR29vZ2xlPC9idXR0b24+XHJcbiAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYnRuIGJ0bi1vdXRsaW5lXCIgdHlwZT1cImJ1dHRvblwiPuKaqyBHaXRIdWI8L2J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImF1dGgtZm9vdGVyLXRleHRcIj5cclxuICAgICAgICAgICAgRG9uJ3QgaGF2ZSBhbiBhY2NvdW50PyA8TGluayB0bz1cIi9yZWdpc3RlclwiIHN0eWxlPXt7IGN1cnNvcjogJ3BvaW50ZXInIH19PkNyZWF0ZSBvbmUg4oaSPC9MaW5rPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IExvZ2luO1xyXG4iXSwiZmlsZSI6IkY6L1kzUzIvSVRQTSBwcm9qZWN0L1Byb01hdGUtLVByb2plY3QtUGFydG5lci1GaW5kZXIvZnJvbnRlbmQvc3JjL3BhZ2VzL1VzZXJzL0xvZ2luLmpzeCJ9