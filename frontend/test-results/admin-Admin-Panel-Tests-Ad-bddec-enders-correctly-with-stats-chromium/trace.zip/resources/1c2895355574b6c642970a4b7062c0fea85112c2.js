import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Users/ForgotPassword.jsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ForgotPassword.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=383bea9f"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"];
import { Link, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=383bea9f";
import logo from "/src/assets/images/logo.jpeg?import";
const ForgotPassword = () => {
  _s();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    const emailRegex = /^\S+@\S+\.\S+$/i;
    if (!email || !emailRegex.test(email)) {
      setError("Please enter a valid email address.");
      return;
    }
    setLoading(true);
    try {
      const res = await fetch("http://localhost:3000/api/auth/forgot-password", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          email
        })
      });
      const data = await res.json();
      if (res.ok) {
        navigate("/verify-otp", {
          state: {
            email
          }
        });
      } else {
        setError(data.message || "Failed to send OTP.");
      }
    } catch (err) {
      setError("Server error.");
    } finally {
      setLoading(false);
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { id: "page-login", className: "page active", style: {
    display: "flex"
  }, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "auth-blob-1" }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ForgotPassword.jsx",
      lineNumber: 50,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "auth-blob-2" }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ForgotPassword.jsx",
      lineNumber: 51,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "auth-card", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "auth-logo", onClick: () => navigate("/"), style: {
        cursor: "pointer",
        display: "flex",
        alignItems: "center",
        gap: "8px"
      }, children: [
        /* @__PURE__ */ jsxDEV("img", { src: logo, alt: "ProMate Logo", style: {
          width: "40px",
          height: "40px",
          borderRadius: "50%"
        } }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ForgotPassword.jsx",
          lineNumber: 59,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { style: {
          fontSize: "1.5rem",
          fontWeight: "bold",
          color: "var(--p)"
        }, children: "ProMate" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ForgotPassword.jsx",
          lineNumber: 64,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ForgotPassword.jsx",
        lineNumber: 53,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "auth-header", style: {
        marginBottom: "1.5rem"
      }, children: [
        /* @__PURE__ */ jsxDEV("h2", { children: "Reset your Password" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ForgotPassword.jsx",
          lineNumber: 73,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: "Enter your email address to receive a 6-digit verification code" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ForgotPassword.jsx",
          lineNumber: 74,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ForgotPassword.jsx",
        lineNumber: 70,
        columnNumber: 9
      }, this),
      error && /* @__PURE__ */ jsxDEV("div", { className: "form-error show", style: {
        marginBottom: "1rem",
        textAlign: "center"
      }, children: error }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ForgotPassword.jsx",
        lineNumber: 77,
        columnNumber: 19
      }, this),
      /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, children: [
        /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "form-label", children: "Email Address" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ForgotPassword.jsx",
            lineNumber: 84,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("input", { type: "email", className: "form-input", value: email, onChange: (e) => setEmail(e.target.value), placeholder: "student@example.com" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ForgotPassword.jsx",
            lineNumber: 85,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ForgotPassword.jsx",
          lineNumber: 83,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("button", { type: "submit", className: "btn btn-primary btn-full flex justify-center items-center", style: {
          padding: ".8rem"
        }, disabled: loading, children: loading ? "Sending Code..." : "Send OTP verification" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ForgotPassword.jsx",
          lineNumber: 87,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ForgotPassword.jsx",
        lineNumber: 82,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "auth-footer-text", children: [
        "Remember your password? ",
        /* @__PURE__ */ jsxDEV(Link, { to: "/login", style: {
          cursor: "pointer"
        }, children: "Log In" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ForgotPassword.jsx",
          lineNumber: 94,
          columnNumber: 35
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ForgotPassword.jsx",
        lineNumber: 93,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ForgotPassword.jsx",
      lineNumber: 52,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ForgotPassword.jsx",
    lineNumber: 47,
    columnNumber: 10
  }, this);
};
_s(ForgotPassword, "PcFoNCQ1y+s26Ia9POPrSoxhnwE=", false, function() {
  return [useNavigate];
});
_c = ForgotPassword;
export default ForgotPassword;
var _c;
$RefreshReg$(_c, "ForgotPassword");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ForgotPassword.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNENNOzs7Ozs7Ozs7Ozs7Ozs7O0FBNUNOLE9BQU9BLFNBQVNDLGdCQUFnQjtBQUNoQyxTQUFTQyxNQUFNQyxtQkFBbUI7QUFDbEMsT0FBT0MsVUFBVTtBQUVqQixNQUFNQyxpQkFBaUJBLE1BQU07QUFBQUMsS0FBQTtBQUMzQixRQUFNQyxXQUFXSixZQUFZO0FBQzdCLFFBQU0sQ0FBQ0ssT0FBT0MsUUFBUSxJQUFJUixTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDUyxPQUFPQyxRQUFRLElBQUlWLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUNXLFNBQVNDLFVBQVUsSUFBSVosU0FBUyxLQUFLO0FBRTVDLFFBQU1hLGVBQWUsT0FBT0MsTUFBTTtBQUNoQ0EsTUFBRUMsZUFBZTtBQUNqQkwsYUFBUyxFQUFFO0FBRVgsVUFBTU0sYUFBYTtBQUNuQixRQUFJLENBQUNULFNBQVMsQ0FBQ1MsV0FBV0MsS0FBS1YsS0FBSyxHQUFHO0FBQ3JDRyxlQUFTLHFDQUFxQztBQUM5QztBQUFBLElBQ0Y7QUFFQUUsZUFBVyxJQUFJO0FBQ2YsUUFBSTtBQUNGLFlBQU1NLE1BQU0sTUFBTUMsTUFBTSxrREFBa0Q7QUFBQSxRQUN4RUMsUUFBUTtBQUFBLFFBQ1JDLFNBQVM7QUFBQSxVQUFFLGdCQUFnQjtBQUFBLFFBQW1CO0FBQUEsUUFDOUNDLE1BQU1DLEtBQUtDLFVBQVU7QUFBQSxVQUFFakI7QUFBQUEsUUFBTSxDQUFDO0FBQUEsTUFDaEMsQ0FBQztBQUNELFlBQU1rQixPQUFPLE1BQU1QLElBQUlRLEtBQUs7QUFFNUIsVUFBSVIsSUFBSVMsSUFBSTtBQUVWckIsaUJBQVMsZUFBZTtBQUFBLFVBQUVzQixPQUFPO0FBQUEsWUFBRXJCO0FBQUFBLFVBQU07QUFBQSxRQUFFLENBQUM7QUFBQSxNQUM5QyxPQUFPO0FBQ0xHLGlCQUFTZSxLQUFLSSxXQUFXLHFCQUFxQjtBQUFBLE1BQ2hEO0FBQUEsSUFDRixTQUFTQyxLQUFLO0FBQ1pwQixlQUFTLGVBQWU7QUFBQSxJQUMxQixVQUFDO0FBQ0NFLGlCQUFXLEtBQUs7QUFBQSxJQUNsQjtBQUFBLEVBQ0Y7QUFFQSxTQUNFLHVCQUFDLFNBQUksSUFBRyxjQUFhLFdBQVUsZUFBYyxPQUFPO0FBQUEsSUFBRW1CLFNBQVM7QUFBQSxFQUFPLEdBQ3BFO0FBQUEsMkJBQUMsU0FBSSxXQUFVLGlCQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNkI7QUFBQSxJQUM3Qix1QkFBQyxTQUFJLFdBQVUsaUJBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE2QjtBQUFBLElBQzdCLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGFBQVksU0FBUyxNQUFNekIsU0FBUyxHQUFHLEdBQUcsT0FBTztBQUFBLFFBQUUwQixRQUFRO0FBQUEsUUFBV0QsU0FBUztBQUFBLFFBQVFFLFlBQVk7QUFBQSxRQUFVQyxLQUFLO0FBQUEsTUFBTSxHQUNySTtBQUFBLCtCQUFDLFNBQUksS0FBSy9CLE1BQU0sS0FBSSxnQkFBZSxPQUFPO0FBQUEsVUFBRWdDLE9BQU87QUFBQSxVQUFRQyxRQUFRO0FBQUEsVUFBUUMsY0FBYztBQUFBLFFBQU0sS0FBL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRztBQUFBLFFBQ2pHLHVCQUFDLFVBQUssT0FBTztBQUFBLFVBQUVDLFVBQVU7QUFBQSxVQUFVQyxZQUFZO0FBQUEsVUFBUUMsT0FBTztBQUFBLFFBQVcsR0FBRyx1QkFBNUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtRjtBQUFBLFdBRnJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGVBQWMsT0FBTztBQUFBLFFBQUVDLGNBQWM7QUFBQSxNQUFTLEdBQzNEO0FBQUEsK0JBQUMsUUFBRyxtQ0FBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVCO0FBQUEsUUFDdkIsdUJBQUMsT0FBRSwrRUFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtFO0FBQUEsV0FGcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFFQ2hDLFNBQVMsdUJBQUMsU0FBSSxXQUFVLG1CQUFrQixPQUFPO0FBQUEsUUFBRWdDLGNBQWM7QUFBQSxRQUFRQyxXQUFXO0FBQUEsTUFBUyxHQUFJakMsbUJBQXhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBOEY7QUFBQSxNQUV4Ryx1QkFBQyxVQUFLLFVBQVVJLGNBQ2Q7QUFBQSwrQkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLGlDQUFDLFdBQU0sV0FBVSxjQUFhLDZCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyQztBQUFBLFVBQzNDLHVCQUFDLFdBQ0MsTUFBSyxTQUNMLFdBQVUsY0FDVixPQUFPTixPQUNQLFVBQVdPLE9BQU1OLFNBQVNNLEVBQUU2QixPQUFPQyxLQUFLLEdBQ3hDLGFBQVkseUJBTGQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLbUM7QUFBQSxhQVByQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0E7QUFBQSxRQUNBLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFdBQVUsNkRBQTRELE9BQU87QUFBQSxVQUFFQyxTQUFTO0FBQUEsUUFBUSxHQUFHLFVBQVVsQyxTQUNoSUEsb0JBQVUsb0JBQW9CLDJCQURqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFjQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLG9CQUFtQjtBQUFBO0FBQUEsUUFDUix1QkFBQyxRQUFLLElBQUcsVUFBUyxPQUFPO0FBQUEsVUFBRXFCLFFBQVE7QUFBQSxRQUFVLEdBQUcsc0JBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0Q7QUFBQSxXQURoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBOEJBO0FBQUEsT0FqQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWtDQTtBQUVKO0FBQUUzQixHQTNFSUQsZ0JBQWM7QUFBQSxVQUNERixXQUFXO0FBQUE7QUFBQTRDLEtBRHhCMUM7QUE2RU4sZUFBZUE7QUFBZSxJQUFBMEM7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwidXNlU3RhdGUiLCJMaW5rIiwidXNlTmF2aWdhdGUiLCJsb2dvIiwiRm9yZ290UGFzc3dvcmQiLCJfcyIsIm5hdmlnYXRlIiwiZW1haWwiLCJzZXRFbWFpbCIsImVycm9yIiwic2V0RXJyb3IiLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsImhhbmRsZVN1Ym1pdCIsImUiLCJwcmV2ZW50RGVmYXVsdCIsImVtYWlsUmVnZXgiLCJ0ZXN0IiwicmVzIiwiZmV0Y2giLCJtZXRob2QiLCJoZWFkZXJzIiwiYm9keSIsIkpTT04iLCJzdHJpbmdpZnkiLCJkYXRhIiwianNvbiIsIm9rIiwic3RhdGUiLCJtZXNzYWdlIiwiZXJyIiwiZGlzcGxheSIsImN1cnNvciIsImFsaWduSXRlbXMiLCJnYXAiLCJ3aWR0aCIsImhlaWdodCIsImJvcmRlclJhZGl1cyIsImZvbnRTaXplIiwiZm9udFdlaWdodCIsImNvbG9yIiwibWFyZ2luQm90dG9tIiwidGV4dEFsaWduIiwidGFyZ2V0IiwidmFsdWUiLCJwYWRkaW5nIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJGb3Jnb3RQYXNzd29yZC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyBMaW5rLCB1c2VOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xyXG5pbXBvcnQgbG9nbyBmcm9tICcuLi8uLi9hc3NldHMvaW1hZ2VzL2xvZ28uanBlZyc7XHJcblxyXG5jb25zdCBGb3Jnb3RQYXNzd29yZCA9ICgpID0+IHtcclxuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XHJcbiAgY29uc3QgW2VtYWlsLCBzZXRFbWFpbF0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICBjb25zdCBoYW5kbGVTdWJtaXQgPSBhc3luYyAoZSkgPT4ge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgc2V0RXJyb3IoJycpO1xyXG4gICAgXHJcbiAgICBjb25zdCBlbWFpbFJlZ2V4ID0gL15cXFMrQFxcUytcXC5cXFMrJC9pO1xyXG4gICAgaWYgKCFlbWFpbCB8fCAhZW1haWxSZWdleC50ZXN0KGVtYWlsKSkge1xyXG4gICAgICBzZXRFcnJvcignUGxlYXNlIGVudGVyIGEgdmFsaWQgZW1haWwgYWRkcmVzcy4nKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIHNldExvYWRpbmcodHJ1ZSk7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaCgnaHR0cDovL2xvY2FsaG9zdDozMDAwL2FwaS9hdXRoL2ZvcmdvdC1wYXNzd29yZCcsIHtcclxuICAgICAgICBtZXRob2Q6ICdQT1NUJyxcclxuICAgICAgICBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSxcclxuICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7IGVtYWlsIH0pXHJcbiAgICAgIH0pO1xyXG4gICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzLmpzb24oKTtcclxuICAgICAgXHJcbiAgICAgIGlmIChyZXMub2spIHtcclxuICAgICAgICAvLyBQYXNzIHRoZSBlbWFpbCB2aWEgc3RhdGUgc28gdGhlIG5leHQgc2NyZWVuIGtub3dzIHdobyB3ZSBhcmUgdmVyaWZ5aW5nXHJcbiAgICAgICAgbmF2aWdhdGUoJy92ZXJpZnktb3RwJywgeyBzdGF0ZTogeyBlbWFpbCB9IH0pO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHNldEVycm9yKGRhdGEubWVzc2FnZSB8fCAnRmFpbGVkIHRvIHNlbmQgT1RQLicpO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgc2V0RXJyb3IoJ1NlcnZlciBlcnJvci4nKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGlkPVwicGFnZS1sb2dpblwiIGNsYXNzTmFtZT1cInBhZ2UgYWN0aXZlXCIgc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnIH19PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImF1dGgtYmxvYi0xXCI+PC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYXV0aC1ibG9iLTJcIj48L2Rpdj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJhdXRoLWNhcmRcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImF1dGgtbG9nb1wiIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKCcvJyl9IHN0eWxlPXt7IGN1cnNvcjogJ3BvaW50ZXInLCBkaXNwbGF5OiAnZmxleCcsIGFsaWduSXRlbXM6ICdjZW50ZXInLCBnYXA6ICc4cHgnIH19PlxyXG4gICAgICAgICAgPGltZyBzcmM9e2xvZ299IGFsdD1cIlByb01hdGUgTG9nb1wiIHN0eWxlPXt7IHdpZHRoOiAnNDBweCcsIGhlaWdodDogJzQwcHgnLCBib3JkZXJSYWRpdXM6ICc1MCUnIH19IC8+XHJcbiAgICAgICAgICA8c3BhbiBzdHlsZT17eyBmb250U2l6ZTogJzEuNXJlbScsIGZvbnRXZWlnaHQ6ICdib2xkJywgY29sb3I6ICd2YXIoLS1wKScgfX0+UHJvTWF0ZTwvc3Bhbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImF1dGgtaGVhZGVyXCIgc3R5bGU9e3sgbWFyZ2luQm90dG9tOiAnMS41cmVtJyB9fT5cclxuICAgICAgICAgIDxoMj5SZXNldCB5b3VyIFBhc3N3b3JkPC9oMj5cclxuICAgICAgICAgIDxwPkVudGVyIHlvdXIgZW1haWwgYWRkcmVzcyB0byByZWNlaXZlIGEgNi1kaWdpdCB2ZXJpZmljYXRpb24gY29kZTwvcD5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICBcclxuICAgICAgICB7ZXJyb3IgJiYgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWVycm9yIHNob3dcIiBzdHlsZT17eyBtYXJnaW5Cb3R0b206ICcxcmVtJywgdGV4dEFsaWduOiAnY2VudGVyJyB9fT57ZXJyb3J9PC9kaXY+fVxyXG4gICAgICAgIFxyXG4gICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwXCI+XHJcbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmb3JtLWxhYmVsXCI+RW1haWwgQWRkcmVzczwvbGFiZWw+XHJcbiAgICAgICAgICAgIDxpbnB1dCBcclxuICAgICAgICAgICAgICB0eXBlPVwiZW1haWxcIiBcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmb3JtLWlucHV0XCIgXHJcbiAgICAgICAgICAgICAgdmFsdWU9e2VtYWlsfSBcclxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEVtYWlsKGUudGFyZ2V0LnZhbHVlKX0gXHJcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJzdHVkZW50QGV4YW1wbGUuY29tXCIgXHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiIGNsYXNzTmFtZT1cImJ0biBidG4tcHJpbWFyeSBidG4tZnVsbCBmbGV4IGp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlclwiIHN0eWxlPXt7IHBhZGRpbmc6ICcuOHJlbScgfX0gZGlzYWJsZWQ9e2xvYWRpbmd9PlxyXG4gICAgICAgICAgICB7bG9hZGluZyA/ICdTZW5kaW5nIENvZGUuLi4nIDogJ1NlbmQgT1RQIHZlcmlmaWNhdGlvbid9XHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhdXRoLWZvb3Rlci10ZXh0XCI+XHJcbiAgICAgICAgICBSZW1lbWJlciB5b3VyIHBhc3N3b3JkPyA8TGluayB0bz1cIi9sb2dpblwiIHN0eWxlPXt7IGN1cnNvcjogJ3BvaW50ZXInIH19PkxvZyBJbjwvTGluaz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgRm9yZ290UGFzc3dvcmQ7XHJcbiJdLCJmaWxlIjoiRjovWTNTMi9JVFBNIHByb2plY3QvUHJvTWF0ZS0tUHJvamVjdC1QYXJ0bmVyLUZpbmRlci9mcm9udGVuZC9zcmMvcGFnZXMvVXNlcnMvRm9yZ290UGFzc3dvcmQuanN4In0=