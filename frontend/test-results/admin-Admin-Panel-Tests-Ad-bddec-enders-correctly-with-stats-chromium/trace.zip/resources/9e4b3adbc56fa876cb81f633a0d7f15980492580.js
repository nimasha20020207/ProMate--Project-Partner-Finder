import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Landing.jsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=383bea9f"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=383bea9f";
import logo from "/src/assets/images/logo.jpeg?import";
const Landing = () => {
  _s();
  const navigate = useNavigate();
  const scrollToSection = (id) => {
    const el = document.getElementById(id);
    if (el)
      el.scrollIntoView({
        behavior: "smooth"
      });
  };
  return /* @__PURE__ */ jsxDEV("div", { id: "page-landing", className: "page active", style: {
    display: "block"
  }, children: [
    /* @__PURE__ */ jsxDEV("nav", { className: "landing-nav", id: "landingNav", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "landing-brand", onClick: () => navigate("/"), style: {
        cursor: "pointer",
        display: "flex",
        alignItems: "center",
        gap: "8px"
      }, children: [
        /* @__PURE__ */ jsxDEV("img", { src: logo, alt: "ProMate Logo", style: {
          width: "40px",
          height: "40px",
          borderRadius: "50%"
        } }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
          lineNumber: 24,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { style: {
          fontSize: "1.5rem",
          fontWeight: "bold",
          color: "var(--p)"
        }, children: "ProMate" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
          lineNumber: 29,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
        lineNumber: 18,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "landing-nav-links", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "landing-nav-link", onClick: () => scrollToSection("features"), children: "Features" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
          lineNumber: 36,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "landing-nav-link", onClick: () => scrollToSection("how"), children: "How It Works" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
          lineNumber: 37,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "landing-nav-link", onClick: () => scrollToSection("stats"), children: "Stats" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
          lineNumber: 38,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
        lineNumber: 35,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "landing-nav-actions", children: [
        /* @__PURE__ */ jsxDEV("button", { className: "btn btn-outline btn-sm", onClick: () => navigate("/login"), children: "Log In" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
          lineNumber: 41,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("button", { className: "btn btn-primary btn-sm", onClick: () => navigate("/register"), children: "Get Started →" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
          lineNumber: 42,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
        lineNumber: 40,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
      lineNumber: 17,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "hero", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "hero-bg" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
        lineNumber: 47,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "hero-grid-bg" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
        lineNumber: 48,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "hero-blob-1" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
        lineNumber: 49,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "hero-blob-2" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
        lineNumber: 50,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "hero-content", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "hero-badge", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "hero-badge-dot" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
            lineNumber: 52,
            columnNumber: 39
          }, this),
          " AI-Powered Partner Matching"
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
          lineNumber: 52,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("h1", { children: [
          "Find Your Perfect ",
          /* @__PURE__ */ jsxDEV("span", { className: "gradient-text", children: "Project Partner" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
            lineNumber: 53,
            columnNumber: 33
          }, this),
          " at University"
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
          lineNumber: 53,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "hero-desc", children: "ProjectMate uses intelligent compatibility scoring to match you with the right teammates based on skills, availability, and interests. No more awkward groupings." }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
          lineNumber: 54,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "hero-actions", children: [
          /* @__PURE__ */ jsxDEV("button", { className: "btn btn-primary btn-lg", onClick: () => navigate("/register"), children: "🚀 Create Free Account" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
            lineNumber: 56,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("button", { className: "btn btn-outline btn-lg", onClick: () => navigate("/login"), children: "Sign In →" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
            lineNumber: 57,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
          lineNumber: 55,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "hero-social-proof", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "avatar-stack", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "avatar-sm", style: {
              background: "linear-gradient(135deg,#38BDF8,#2563EB)"
            }, children: "AK" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
              lineNumber: 61,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "avatar-sm", style: {
              background: "linear-gradient(135deg,#1E3A8A,#0369A1)"
            }, children: "SP" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
              lineNumber: 64,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "avatar-sm", style: {
              background: "linear-gradient(135deg,#0369A1,#38BDF8)"
            }, children: "NF" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
              lineNumber: 67,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "avatar-sm", style: {
              background: "linear-gradient(135deg,#2563EB,#1E3A8A)"
            }, children: "RM" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
              lineNumber: 70,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "avatar-sm", style: {
              background: "linear-gradient(135deg,#7C3AED,#2563EB)"
            }, children: "+" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
              lineNumber: 73,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
            lineNumber: 60,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "social-text", children: [
            /* @__PURE__ */ jsxDEV("strong", { children: "1,200+ students" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
              lineNumber: 77,
              columnNumber: 42
            }, this),
            " already found their team"
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
            lineNumber: 77,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
          lineNumber: 59,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
        lineNumber: 51,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "hero-visual", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "hero-card-float", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "match-row", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "match-avatar", style: {
              background: "linear-gradient(135deg,#38BDF8,#2563EB)"
            }, children: "NK" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
              lineNumber: 83,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "match-info", children: [
              /* @__PURE__ */ jsxDEV("h4", { children: "Nimal Karunaratne" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
                lineNumber: 86,
                columnNumber: 43
              }, this),
              /* @__PURE__ */ jsxDEV("p", { children: "Frontend Dev · 10 hrs/week" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
                lineNumber: 86,
                columnNumber: 69
              }, this)
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
              lineNumber: 86,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "match-score", children: "92%" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
              lineNumber: 87,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
            lineNumber: 82,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "match-bar-bg", children: /* @__PURE__ */ jsxDEV("div", { className: "match-bar", style: {
            width: "92%"
          } }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
            lineNumber: 89,
            columnNumber: 43
          }, this) }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
            lineNumber: 89,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "skill-pips", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "skill-pip", children: "React" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
              lineNumber: 92,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "skill-pip", children: "Node.js" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
              lineNumber: 92,
              columnNumber: 81
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "skill-pip", children: "MongoDB" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
              lineNumber: 92,
              columnNumber: 123
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
            lineNumber: 92,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
          lineNumber: 81,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "hero-card-float", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "match-row", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "match-avatar", style: {
              background: "linear-gradient(135deg,#1E3A8A,#0369A1)"
            }, children: "SR" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
              lineNumber: 96,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "match-info", children: [
              /* @__PURE__ */ jsxDEV("h4", { children: "Sithumi Rathnayake" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
                lineNumber: 99,
                columnNumber: 43
              }, this),
              /* @__PURE__ */ jsxDEV("p", { children: "AI Engineer · 8 hrs/week" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
                lineNumber: 99,
                columnNumber: 70
              }, this)
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
              lineNumber: 99,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "match-score", children: "85%" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
              lineNumber: 100,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
            lineNumber: 95,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "match-bar-bg", children: /* @__PURE__ */ jsxDEV("div", { className: "match-bar", style: {
            width: "85%"
          } }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
            lineNumber: 102,
            columnNumber: 43
          }, this) }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
            lineNumber: 102,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "skill-pips", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "skill-pip", children: "Python" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
              lineNumber: 105,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "skill-pip", children: "FastAPI" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
              lineNumber: 105,
              columnNumber: 82
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "skill-pip", children: "TF-IDF" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
              lineNumber: 105,
              columnNumber: 124
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
            lineNumber: 105,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
          lineNumber: 94,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
        lineNumber: 80,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
      lineNumber: 46,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "features", id: "features", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "section-label", children: "Why ProjectMate" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
        lineNumber: 111,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "section-title", children: [
        "Everything you need to",
        /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
          lineNumber: 112,
          columnNumber: 62
        }, this),
        "build the perfect team"
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
        lineNumber: 112,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "section-sub", children: "From smart AI matching to seamless request workflows — we've built the tools university students actually need." }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
        lineNumber: 113,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "features-grid", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "feature-card", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "feature-icon", children: "🧠" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
            lineNumber: 115,
            columnNumber: 41
          }, this),
          /* @__PURE__ */ jsxDEV("h3", { children: "AI Compatibility Matching" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
            lineNumber: 115,
            columnNumber: 79
          }, this),
          /* @__PURE__ */ jsxDEV("p", { children: "Our weighted scoring algorithm analyzes skill overlap, availability, and interest alignment to rank the most compatible partners for you." }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
            lineNumber: 115,
            columnNumber: 113
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
          lineNumber: 115,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "feature-card", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "feature-icon", children: "🎯" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
            lineNumber: 116,
            columnNumber: 41
          }, this),
          /* @__PURE__ */ jsxDEV("h3", { children: "Skill-Based Discovery" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
            lineNumber: 116,
            columnNumber: 79
          }, this),
          /* @__PURE__ */ jsxDEV("p", { children: "Browse projects that specifically need your skills. No more scrolling through irrelevant listings — your matches are curated just for you." }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
            lineNumber: 116,
            columnNumber: 109
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
          lineNumber: 116,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "feature-card", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "feature-icon", children: "⚡" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
            lineNumber: 117,
            columnNumber: 41
          }, this),
          /* @__PURE__ */ jsxDEV("h3", { children: "Instant Request Workflow" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
            lineNumber: 117,
            columnNumber: 78
          }, this),
          /* @__PURE__ */ jsxDEV("p", { children: "Send partner requests, accept or reject with one click, and watch your team lock automatically when all positions are filled." }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
            lineNumber: 117,
            columnNumber: 111
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
          lineNumber: 117,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "feature-card", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "feature-icon", children: "💡" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
            lineNumber: 118,
            columnNumber: 41
          }, this),
          /* @__PURE__ */ jsxDEV("h3", { children: "Smart Profile Suggestions" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
            lineNumber: 118,
            columnNumber: 79
          }, this),
          /* @__PURE__ */ jsxDEV("p", { children: "AI suggests skills you might be missing based on your selected domain, helping you build a complete profile that attracts the right projects." }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
            lineNumber: 118,
            columnNumber: 113
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
          lineNumber: 118,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "feature-card", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "feature-icon", children: "📊" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
            lineNumber: 119,
            columnNumber: 41
          }, this),
          /* @__PURE__ */ jsxDEV("h3", { children: "Transparent Explanations" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
            lineNumber: 119,
            columnNumber: 79
          }, this),
          /* @__PURE__ */ jsxDEV("p", { children: "Every match comes with a clear explanation. No black boxes — just honest, readable compatibility breakdowns." }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
            lineNumber: 119,
            columnNumber: 112
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
          lineNumber: 119,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "feature-card", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "feature-icon", children: "🔒" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
            lineNumber: 120,
            columnNumber: 41
          }, this),
          /* @__PURE__ */ jsxDEV("h3", { children: "University-Safe & Private" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
            lineNumber: 120,
            columnNumber: 79
          }, this),
          /* @__PURE__ */ jsxDEV("p", { children: "Your data stays within your university ecosystem. No external integrations, no ads, no data selling. Just clean, focused collaboration." }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
            lineNumber: 120,
            columnNumber: 113
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
          lineNumber: 120,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
        lineNumber: 114,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
      lineNumber: 110,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "steps", id: "how", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "section-label", children: "Getting Started" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
        lineNumber: 125,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "section-title", children: "Up and running in minutes" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
        lineNumber: 126,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "steps-grid", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "step-card", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "step-num", children: "1" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
            lineNumber: 128,
            columnNumber: 38
          }, this),
          /* @__PURE__ */ jsxDEV("h4", { children: "Create Profile" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
            lineNumber: 128,
            columnNumber: 71
          }, this),
          /* @__PURE__ */ jsxDEV("p", { children: "Sign up with your university email and set your basic info." }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
            lineNumber: 128,
            columnNumber: 94
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
          lineNumber: 128,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "step-card", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "step-num", children: "2" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
            lineNumber: 129,
            columnNumber: 38
          }, this),
          /* @__PURE__ */ jsxDEV("h4", { children: "Add Your Skills" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
            lineNumber: 129,
            columnNumber: 71
          }, this),
          /* @__PURE__ */ jsxDEV("p", { children: "Fill in your skills, interests, and weekly availability in your profile." }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
            lineNumber: 129,
            columnNumber: 95
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
          lineNumber: 129,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "step-card", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "step-num", children: "3" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
            lineNumber: 130,
            columnNumber: 38
          }, this),
          /* @__PURE__ */ jsxDEV("h4", { children: "Get Matched" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
            lineNumber: 130,
            columnNumber: 71
          }, this),
          /* @__PURE__ */ jsxDEV("p", { children: "AI recommends the most compatible partners with clear explanations." }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
            lineNumber: 130,
            columnNumber: 91
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
          lineNumber: 130,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "step-card", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "step-num", children: "4" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
            lineNumber: 131,
            columnNumber: 38
          }, this),
          /* @__PURE__ */ jsxDEV("h4", { children: "Build Your Team" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
            lineNumber: 131,
            columnNumber: 71
          }, this),
          /* @__PURE__ */ jsxDEV("p", { children: "Send requests, get accepted, and your project team locks automatically." }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
            lineNumber: 131,
            columnNumber: 95
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
          lineNumber: 131,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
        lineNumber: 127,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
      lineNumber: 124,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "stats-bar", id: "stats", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "stat-item", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "stat-num", children: "1,200+" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
          lineNumber: 136,
          columnNumber: 36
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "stat-label", children: "Active Students" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
          lineNumber: 136,
          columnNumber: 76
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
        lineNumber: 136,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "stat-item", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "stat-num", children: "340+" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
          lineNumber: 137,
          columnNumber: 36
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "stat-label", children: "Projects Posted" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
          lineNumber: 137,
          columnNumber: 74
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
        lineNumber: 137,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "stat-item", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "stat-num", children: "87%" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
          lineNumber: 138,
          columnNumber: 36
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "stat-label", children: "Match Satisfaction" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
          lineNumber: 138,
          columnNumber: 73
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
        lineNumber: 138,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "stat-item", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "stat-num", children: "50+" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
          lineNumber: 139,
          columnNumber: 36
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "stat-label", children: "Skills Tracked" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
          lineNumber: 139,
          columnNumber: 73
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
        lineNumber: 139,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
      lineNumber: 135,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("section", { className: "cta-section", children: /* @__PURE__ */ jsxDEV("div", { className: "cta-box", children: [
      /* @__PURE__ */ jsxDEV("h2", { children: "Ready to find your team?" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
        lineNumber: 144,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: "Join 1,200+ students who've already stopped struggling with group formation. Create your free profile in under 2 minutes." }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
        lineNumber: 145,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "btn-actions", style: {
        justifyContent: "center"
      }, children: [
        /* @__PURE__ */ jsxDEV("button", { className: "btn btn-ghost btn-lg", onClick: () => navigate("/login"), children: "Log In" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
          lineNumber: 149,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("button", { className: "btn btn-lg", style: {
          background: "#fff",
          color: "var(--p)"
        }, onClick: () => navigate("/register"), children: "🚀 Get Started Free" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
          lineNumber: 150,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
        lineNumber: 146,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
      lineNumber: 143,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
      lineNumber: 142,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("footer", { className: "landing-footer", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "footer-brand", style: {
        display: "flex",
        alignItems: "center",
        gap: "8px"
      }, children: [
        /* @__PURE__ */ jsxDEV("img", { src: logo, alt: "ProMate Logo", style: {
          width: "30px",
          height: "30px",
          borderRadius: "50%"
        } }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
          lineNumber: 164,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { children: "ProMate" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
          lineNumber: 169,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
        lineNumber: 159,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "footer-text", children: "© 2026 ProjectMate · IT3040 Project · Sri Lanka Institute of Information Technology" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
        lineNumber: 171,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "footer-text", children: "Built with 💙 by Team" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
        lineNumber: 172,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
      lineNumber: 158,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx",
    lineNumber: 14,
    columnNumber: 10
  }, this);
};
_s(Landing, "CzcTeTziyjMsSrAVmHuCCb6+Bfg=", false, function() {
  return [useNavigate];
});
_c = Landing;
export default Landing;
var _c;
$RefreshReg$(_c, "Landing");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Landing.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0JVOzs7Ozs7Ozs7Ozs7Ozs7O0FBaEJWLE9BQU9BLFdBQVc7QUFDbEIsU0FBU0MsbUJBQW1CO0FBQzVCLE9BQU9DLFVBQVU7QUFFakIsTUFBTUMsVUFBVUEsTUFBTTtBQUFBQyxLQUFBO0FBQ3BCLFFBQU1DLFdBQVdKLFlBQVk7QUFFN0IsUUFBTUssa0JBQW1CQyxRQUFPO0FBQzlCLFVBQU1DLEtBQUtDLFNBQVNDLGVBQWVILEVBQUU7QUFDckMsUUFBSUM7QUFBSUEsU0FBR0csZUFBZTtBQUFBLFFBQUVDLFVBQVU7QUFBQSxNQUFTLENBQUM7QUFBQSxFQUNsRDtBQUVBLFNBQ0UsdUJBQUMsU0FBSSxJQUFHLGdCQUFlLFdBQVUsZUFBYyxPQUFPO0FBQUEsSUFBRUMsU0FBUztBQUFBLEVBQVEsR0FDdkU7QUFBQSwyQkFBQyxTQUFJLFdBQVUsZUFBYyxJQUFHLGNBQzlCO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGlCQUFnQixTQUFTLE1BQU1SLFNBQVMsR0FBRyxHQUFHLE9BQU87QUFBQSxRQUFFUyxRQUFRO0FBQUEsUUFBV0QsU0FBUztBQUFBLFFBQVFFLFlBQVk7QUFBQSxRQUFVQyxLQUFLO0FBQUEsTUFBTSxHQUN6STtBQUFBLCtCQUFDLFNBQUksS0FBS2QsTUFBTSxLQUFJLGdCQUFlLE9BQU87QUFBQSxVQUFFZSxPQUFPO0FBQUEsVUFBUUMsUUFBUTtBQUFBLFVBQVFDLGNBQWM7QUFBQSxRQUFNLEtBQS9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUc7QUFBQSxRQUNqRyx1QkFBQyxVQUFLLE9BQU87QUFBQSxVQUFFQyxVQUFVO0FBQUEsVUFBVUMsWUFBWTtBQUFBLFVBQVFDLE9BQU87QUFBQSxRQUFXLEdBQUcsdUJBQTVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUY7QUFBQSxXQUZyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLCtCQUFDLFVBQUssV0FBVSxvQkFBbUIsU0FBUyxNQUFNaEIsZ0JBQWdCLFVBQVUsR0FBRyx3QkFBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1RjtBQUFBLFFBQ3ZGLHVCQUFDLFVBQUssV0FBVSxvQkFBbUIsU0FBUyxNQUFNQSxnQkFBZ0IsS0FBSyxHQUFHLDRCQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNGO0FBQUEsUUFDdEYsdUJBQUMsVUFBSyxXQUFVLG9CQUFtQixTQUFTLE1BQU1BLGdCQUFnQixPQUFPLEdBQUcscUJBQTVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUY7QUFBQSxXQUhuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUE7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSx1QkFDYjtBQUFBLCtCQUFDLFlBQU8sV0FBVSwwQkFBeUIsU0FBUyxNQUFNRCxTQUFTLFFBQVEsR0FBRyxzQkFBOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvRjtBQUFBLFFBQ3BGLHVCQUFDLFlBQU8sV0FBVSwwQkFBeUIsU0FBUyxNQUFNQSxTQUFTLFdBQVcsR0FBRyw2QkFBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4RjtBQUFBLFdBRmhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLFNBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWNBO0FBQUEsSUFFQSx1QkFBQyxhQUFRLFdBQVUsUUFDakI7QUFBQSw2QkFBQyxTQUFJLFdBQVUsYUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlCO0FBQUEsTUFDekIsdUJBQUMsU0FBSSxXQUFVLGtCQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBOEI7QUFBQSxNQUM5Qix1QkFBQyxTQUFJLFdBQVUsaUJBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2QjtBQUFBLE1BQzdCLHVCQUFDLFNBQUksV0FBVSxpQkFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZCO0FBQUEsTUFDN0IsdUJBQUMsU0FBSSxXQUFVLGdCQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGNBQWE7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsb0JBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0M7QUFBQSxVQUFNO0FBQUEsYUFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4RjtBQUFBLFFBQzlGLHVCQUFDLFFBQUc7QUFBQTtBQUFBLFVBQWtCLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsK0JBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStDO0FBQUEsVUFBTztBQUFBLGFBQTVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEY7QUFBQSxRQUMxRix1QkFBQyxPQUFFLFdBQVUsYUFBWSxpTEFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwTDtBQUFBLFFBQzFMLHVCQUFDLFNBQUksV0FBVSxnQkFDYjtBQUFBLGlDQUFDLFlBQU8sV0FBVSwwQkFBeUIsU0FBUyxNQUFNQSxTQUFTLFdBQVcsR0FBRyxzQ0FBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUc7QUFBQSxVQUN2Ryx1QkFBQyxZQUFPLFdBQVUsMEJBQXlCLFNBQVMsTUFBTUEsU0FBUyxRQUFRLEdBQUcseUJBQTlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVGO0FBQUEsYUFGekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsZ0JBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsYUFBWSxPQUFPO0FBQUEsY0FBRWtCLFlBQVk7QUFBQSxZQUF5QyxHQUFHLGtCQUE1RjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4RjtBQUFBLFlBQzlGLHVCQUFDLFNBQUksV0FBVSxhQUFZLE9BQU87QUFBQSxjQUFFQSxZQUFZO0FBQUEsWUFBeUMsR0FBRyxrQkFBNUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEY7QUFBQSxZQUM5Rix1QkFBQyxTQUFJLFdBQVUsYUFBWSxPQUFPO0FBQUEsY0FBRUEsWUFBWTtBQUFBLFlBQXlDLEdBQUcsa0JBQTVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThGO0FBQUEsWUFDOUYsdUJBQUMsU0FBSSxXQUFVLGFBQVksT0FBTztBQUFBLGNBQUVBLFlBQVk7QUFBQSxZQUF5QyxHQUFHLGtCQUE1RjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4RjtBQUFBLFlBQzlGLHVCQUFDLFNBQUksV0FBVSxhQUFZLE9BQU87QUFBQSxjQUFFQSxZQUFZO0FBQUEsWUFBeUMsR0FBRyxpQkFBNUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkY7QUFBQSxlQUwvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU1BO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsZUFBYztBQUFBLG1DQUFDLFlBQU8sK0JBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUI7QUFBQSxZQUFTO0FBQUEsZUFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0Y7QUFBQSxhQVJ4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0E7QUFBQSxXQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBa0JBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxtQkFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLGdCQUFlLE9BQU87QUFBQSxjQUFFQSxZQUFZO0FBQUEsWUFBeUMsR0FBRyxrQkFBL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUc7QUFBQSxZQUNqRyx1QkFBQyxTQUFJLFdBQVUsY0FBYTtBQUFBLHFDQUFDLFFBQUcsaUNBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUI7QUFBQSxjQUFLLHVCQUFDLE9BQUUsMENBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNkI7QUFBQSxpQkFBbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUY7QUFBQSxZQUN2Rix1QkFBQyxTQUFJLFdBQVUsZUFBYyxtQkFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0M7QUFBQSxlQUhsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUlBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsZ0JBQWUsaUNBQUMsU0FBSSxXQUFVLGFBQVksT0FBTztBQUFBLFlBQUVOLE9BQU87QUFBQSxVQUFNLEtBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9ELEtBQWxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdGO0FBQUEsVUFDeEYsdUJBQUMsU0FBSSxXQUFVLGNBQWE7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsYUFBWSxxQkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUM7QUFBQSxZQUFPLHVCQUFDLFVBQUssV0FBVSxhQUFZLHVCQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtQztBQUFBLFlBQU8sdUJBQUMsVUFBSyxXQUFVLGFBQVksdUJBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1DO0FBQUEsZUFBako7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0o7QUFBQSxhQVAxSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSxtQkFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLGdCQUFlLE9BQU87QUFBQSxjQUFFTSxZQUFZO0FBQUEsWUFBeUMsR0FBRyxrQkFBL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUc7QUFBQSxZQUNqRyx1QkFBQyxTQUFJLFdBQVUsY0FBYTtBQUFBLHFDQUFDLFFBQUcsa0NBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBc0I7QUFBQSxjQUFLLHVCQUFDLE9BQUUsd0NBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMkI7QUFBQSxpQkFBbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0Y7QUFBQSxZQUN0Rix1QkFBQyxTQUFJLFdBQVUsZUFBYyxtQkFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0M7QUFBQSxlQUhsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUlBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsZ0JBQWUsaUNBQUMsU0FBSSxXQUFVLGFBQVksT0FBTztBQUFBLFlBQUVOLE9BQU87QUFBQSxVQUFNLEtBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9ELEtBQWxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdGO0FBQUEsVUFDeEYsdUJBQUMsU0FBSSxXQUFVLGNBQWE7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsYUFBWSxzQkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0M7QUFBQSxZQUFPLHVCQUFDLFVBQUssV0FBVSxhQUFZLHVCQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtQztBQUFBLFlBQU8sdUJBQUMsVUFBSyxXQUFVLGFBQVksc0JBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtDO0FBQUEsZUFBako7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0o7QUFBQSxhQVAxSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQSxXQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBbUJBO0FBQUEsU0EzQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTRDQTtBQUFBLElBRUEsdUJBQUMsYUFBUSxXQUFVLFlBQVcsSUFBRyxZQUMvQjtBQUFBLDZCQUFDLFNBQUksV0FBVSxpQkFBZ0IsK0JBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBOEM7QUFBQSxNQUM5Qyx1QkFBQyxTQUFJLFdBQVUsaUJBQWdCO0FBQUE7QUFBQSxRQUFzQix1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBRztBQUFBLFFBQUU7QUFBQSxXQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdGO0FBQUEsTUFDaEYsdUJBQUMsU0FBSSxXQUFVLGVBQWMsK0hBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEk7QUFBQSxNQUM1SSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsZ0JBQWU7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsZ0JBQWUsa0JBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdDO0FBQUEsVUFBTSx1QkFBQyxRQUFHLHlDQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZCO0FBQUEsVUFBSyx1QkFBQyxPQUFFLHlKQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRJO0FBQUEsYUFBbFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzUDtBQUFBLFFBQ3RQLHVCQUFDLFNBQUksV0FBVSxnQkFBZTtBQUFBLGlDQUFDLFNBQUksV0FBVSxnQkFBZSxrQkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0M7QUFBQSxVQUFNLHVCQUFDLFFBQUcscUNBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUI7QUFBQSxVQUFLLHVCQUFDLE9BQUUsMEpBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkk7QUFBQSxhQUEvTztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1QO0FBQUEsUUFDblAsdUJBQUMsU0FBSSxXQUFVLGdCQUFlO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGdCQUFlLGlCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUErQjtBQUFBLFVBQU0sdUJBQUMsUUFBRyx3Q0FBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0QjtBQUFBLFVBQUssdUJBQUMsT0FBRSw2SUFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnSTtBQUFBLGFBQXBPO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd087QUFBQSxRQUN4Tyx1QkFBQyxTQUFJLFdBQVUsZ0JBQWU7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsZ0JBQWUsa0JBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdDO0FBQUEsVUFBTSx1QkFBQyxRQUFHLHlDQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZCO0FBQUEsVUFBSyx1QkFBQyxPQUFFLDZKQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdKO0FBQUEsYUFBdFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwUDtBQUFBLFFBQzFQLHVCQUFDLFNBQUksV0FBVSxnQkFBZTtBQUFBLGlDQUFDLFNBQUksV0FBVSxnQkFBZSxrQkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0M7QUFBQSxVQUFNLHVCQUFDLFFBQUcsd0NBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEI7QUFBQSxVQUFLLHVCQUFDLE9BQUUsNEhBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0c7QUFBQSxhQUFwTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdOO0FBQUEsUUFDeE4sdUJBQUMsU0FBSSxXQUFVLGdCQUFlO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGdCQUFlLGtCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnQztBQUFBLFVBQU0sdUJBQUMsUUFBRyx5Q0FBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2QjtBQUFBLFVBQUssdUJBQUMsT0FBRSx1SkFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwSTtBQUFBLGFBQWhQO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb1A7QUFBQSxXQU50UDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0E7QUFBQSxTQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FZQTtBQUFBLElBRUEsdUJBQUMsYUFBUSxXQUFVLFNBQVEsSUFBRyxPQUM1QjtBQUFBLDZCQUFDLFNBQUksV0FBVSxpQkFBZ0IsK0JBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBOEM7QUFBQSxNQUM5Qyx1QkFBQyxTQUFJLFdBQVUsaUJBQWdCLHlDQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdEO0FBQUEsTUFDeEQsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsYUFBWTtBQUFBLGlDQUFDLFNBQUksV0FBVSxZQUFXLGlCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyQjtBQUFBLFVBQU0sdUJBQUMsUUFBRyw4QkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrQjtBQUFBLFVBQUssdUJBQUMsT0FBRSwyRUFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4RDtBQUFBLGFBQWpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUo7QUFBQSxRQUNySix1QkFBQyxTQUFJLFdBQVUsYUFBWTtBQUFBLGlDQUFDLFNBQUksV0FBVSxZQUFXLGlCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyQjtBQUFBLFVBQU0sdUJBQUMsUUFBRywrQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtQjtBQUFBLFVBQUssdUJBQUMsT0FBRSx3RkFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyRTtBQUFBLGFBQS9KO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUs7QUFBQSxRQUNuSyx1QkFBQyxTQUFJLFdBQVUsYUFBWTtBQUFBLGlDQUFDLFNBQUksV0FBVSxZQUFXLGlCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyQjtBQUFBLFVBQU0sdUJBQUMsUUFBRywyQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFlO0FBQUEsVUFBSyx1QkFBQyxPQUFFLG1GQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNFO0FBQUEsYUFBdEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwSjtBQUFBLFFBQzFKLHVCQUFDLFNBQUksV0FBVSxhQUFZO0FBQUEsaUNBQUMsU0FBSSxXQUFVLFlBQVcsaUJBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTJCO0FBQUEsVUFBTSx1QkFBQyxRQUFHLCtCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1CO0FBQUEsVUFBSyx1QkFBQyxPQUFFLHVGQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBFO0FBQUEsYUFBOUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrSztBQUFBLFdBSnBLO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLFNBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsYUFBWSxJQUFHLFNBQzVCO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGFBQVk7QUFBQSwrQkFBQyxVQUFLLFdBQVUsWUFBVyxzQkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpQztBQUFBLFFBQU8sdUJBQUMsVUFBSyxXQUFVLGNBQWEsK0JBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEM7QUFBQSxXQUEvRztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXNIO0FBQUEsTUFDdEgsdUJBQUMsU0FBSSxXQUFVLGFBQVk7QUFBQSwrQkFBQyxVQUFLLFdBQVUsWUFBVyxvQkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErQjtBQUFBLFFBQU8sdUJBQUMsVUFBSyxXQUFVLGNBQWEsK0JBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEM7QUFBQSxXQUE3RztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9IO0FBQUEsTUFDcEgsdUJBQUMsU0FBSSxXQUFVLGFBQVk7QUFBQSwrQkFBQyxVQUFLLFdBQVUsWUFBVyxtQkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4QjtBQUFBLFFBQU8sdUJBQUMsVUFBSyxXQUFVLGNBQWEsa0NBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0M7QUFBQSxXQUEvRztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXNIO0FBQUEsTUFDdEgsdUJBQUMsU0FBSSxXQUFVLGFBQVk7QUFBQSwrQkFBQyxVQUFLLFdBQVUsWUFBVyxtQkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4QjtBQUFBLFFBQU8sdUJBQUMsVUFBSyxXQUFVLGNBQWEsOEJBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkM7QUFBQSxXQUEzRztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtIO0FBQUEsU0FKcEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtBO0FBQUEsSUFFQSx1QkFBQyxhQUFRLFdBQVUsZUFDakIsaUNBQUMsU0FBSSxXQUFVLFdBQ2I7QUFBQSw2QkFBQyxRQUFHLHdDQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEI7QUFBQSxNQUM1Qix1QkFBQyxPQUFFLHlJQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEg7QUFBQSxNQUM1SCx1QkFBQyxTQUFJLFdBQVUsZUFBYyxPQUFPO0FBQUEsUUFBRU8sZ0JBQWdCO0FBQUEsTUFBUyxHQUM3RDtBQUFBLCtCQUFDLFlBQU8sV0FBVSx3QkFBdUIsU0FBUyxNQUFNbkIsU0FBUyxRQUFRLEdBQUcsc0JBQTVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0Y7QUFBQSxRQUNsRix1QkFBQyxZQUFPLFdBQVUsY0FBYSxPQUFPO0FBQUEsVUFBRWtCLFlBQVk7QUFBQSxVQUFRRCxPQUFPO0FBQUEsUUFBVyxHQUFHLFNBQVMsTUFBTWpCLFNBQVMsV0FBVyxHQUFHLG1DQUF2SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBJO0FBQUEsV0FGNUk7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsU0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0EsS0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBU0E7QUFBQSxJQUVBLHVCQUFDLFlBQU8sV0FBVSxrQkFDaEI7QUFBQSw2QkFBQyxTQUFJLFdBQVUsZ0JBQWUsT0FBTztBQUFBLFFBQUVRLFNBQVM7QUFBQSxRQUFRRSxZQUFZO0FBQUEsUUFBVUMsS0FBSztBQUFBLE1BQU0sR0FDdkY7QUFBQSwrQkFBQyxTQUFJLEtBQUtkLE1BQU0sS0FBSSxnQkFBZSxPQUFPO0FBQUEsVUFBRWUsT0FBTztBQUFBLFVBQVFDLFFBQVE7QUFBQSxVQUFRQyxjQUFjO0FBQUEsUUFBTSxLQUEvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlHO0FBQUEsUUFDakcsdUJBQUMsVUFBSyx1QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWE7QUFBQSxXQUZmO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGVBQWMsbUdBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0g7QUFBQSxNQUNoSCx1QkFBQyxTQUFJLFdBQVUsZUFBYyxxQ0FBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrRDtBQUFBLFNBTnBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPQTtBQUFBLE9BakhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FrSEE7QUFFSjtBQUFFZixHQTdISUQsU0FBTztBQUFBLFVBQ01GLFdBQVc7QUFBQTtBQUFBd0IsS0FEeEJ0QjtBQStITixlQUFlQTtBQUFRLElBQUFzQjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJ1c2VOYXZpZ2F0ZSIsImxvZ28iLCJMYW5kaW5nIiwiX3MiLCJuYXZpZ2F0ZSIsInNjcm9sbFRvU2VjdGlvbiIsImlkIiwiZWwiLCJkb2N1bWVudCIsImdldEVsZW1lbnRCeUlkIiwic2Nyb2xsSW50b1ZpZXciLCJiZWhhdmlvciIsImRpc3BsYXkiLCJjdXJzb3IiLCJhbGlnbkl0ZW1zIiwiZ2FwIiwid2lkdGgiLCJoZWlnaHQiLCJib3JkZXJSYWRpdXMiLCJmb250U2l6ZSIsImZvbnRXZWlnaHQiLCJjb2xvciIsImJhY2tncm91bmQiLCJqdXN0aWZ5Q29udGVudCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiTGFuZGluZy5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgdXNlTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcclxuaW1wb3J0IGxvZ28gZnJvbSAnLi4vYXNzZXRzL2ltYWdlcy9sb2dvLmpwZWcnO1xyXG5cclxuY29uc3QgTGFuZGluZyA9ICgpID0+IHtcclxuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XHJcblxyXG4gIGNvbnN0IHNjcm9sbFRvU2VjdGlvbiA9IChpZCkgPT4ge1xyXG4gICAgY29uc3QgZWwgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChpZCk7XHJcbiAgICBpZiAoZWwpIGVsLnNjcm9sbEludG9WaWV3KHsgYmVoYXZpb3I6ICdzbW9vdGgnIH0pO1xyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGlkPVwicGFnZS1sYW5kaW5nXCIgY2xhc3NOYW1lPVwicGFnZSBhY3RpdmVcIiBzdHlsZT17eyBkaXNwbGF5OiAnYmxvY2snIH19PlxyXG4gICAgICA8bmF2IGNsYXNzTmFtZT1cImxhbmRpbmctbmF2XCIgaWQ9XCJsYW5kaW5nTmF2XCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsYW5kaW5nLWJyYW5kXCIgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoJy8nKX0gc3R5bGU9e3sgY3Vyc29yOiAncG9pbnRlcicsIGRpc3BsYXk6ICdmbGV4JywgYWxpZ25JdGVtczogJ2NlbnRlcicsIGdhcDogJzhweCcgfX0+XHJcbiAgICAgICAgICA8aW1nIHNyYz17bG9nb30gYWx0PVwiUHJvTWF0ZSBMb2dvXCIgc3R5bGU9e3sgd2lkdGg6ICc0MHB4JywgaGVpZ2h0OiAnNDBweCcsIGJvcmRlclJhZGl1czogJzUwJScgfX0gLz5cclxuICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGZvbnRTaXplOiAnMS41cmVtJywgZm9udFdlaWdodDogJ2JvbGQnLCBjb2xvcjogJ3ZhcigtLXApJyB9fT5Qcm9NYXRlPC9zcGFuPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGFuZGluZy1uYXYtbGlua3NcIj5cclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImxhbmRpbmctbmF2LWxpbmtcIiBvbkNsaWNrPXsoKSA9PiBzY3JvbGxUb1NlY3Rpb24oJ2ZlYXR1cmVzJyl9PkZlYXR1cmVzPC9zcGFuPlxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibGFuZGluZy1uYXYtbGlua1wiIG9uQ2xpY2s9eygpID0+IHNjcm9sbFRvU2VjdGlvbignaG93Jyl9PkhvdyBJdCBXb3Jrczwvc3Bhbj5cclxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImxhbmRpbmctbmF2LWxpbmtcIiBvbkNsaWNrPXsoKSA9PiBzY3JvbGxUb1NlY3Rpb24oJ3N0YXRzJyl9PlN0YXRzPC9zcGFuPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGFuZGluZy1uYXYtYWN0aW9uc1wiPlxyXG4gICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJidG4gYnRuLW91dGxpbmUgYnRuLXNtXCIgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoJy9sb2dpbicpfT5Mb2cgSW48L2J1dHRvbj5cclxuICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYnRuIGJ0bi1wcmltYXJ5IGJ0bi1zbVwiIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKCcvcmVnaXN0ZXInKX0+R2V0IFN0YXJ0ZWQg4oaSPC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvbmF2PlxyXG5cclxuICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwiaGVyb1wiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGVyby1iZ1wiPjwvZGl2PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGVyby1ncmlkLWJnXCI+PC9kaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoZXJvLWJsb2ItMVwiPjwvZGl2PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGVyby1ibG9iLTJcIj48L2Rpdj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhlcm8tY29udGVudFwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoZXJvLWJhZGdlXCI+PGRpdiBjbGFzc05hbWU9XCJoZXJvLWJhZGdlLWRvdFwiPjwvZGl2PiBBSS1Qb3dlcmVkIFBhcnRuZXIgTWF0Y2hpbmc8L2Rpdj5cclxuICAgICAgICAgIDxoMT5GaW5kIFlvdXIgUGVyZmVjdCA8c3BhbiBjbGFzc05hbWU9XCJncmFkaWVudC10ZXh0XCI+UHJvamVjdCBQYXJ0bmVyPC9zcGFuPiBhdCBVbml2ZXJzaXR5PC9oMT5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImhlcm8tZGVzY1wiPlByb2plY3RNYXRlIHVzZXMgaW50ZWxsaWdlbnQgY29tcGF0aWJpbGl0eSBzY29yaW5nIHRvIG1hdGNoIHlvdSB3aXRoIHRoZSByaWdodCB0ZWFtbWF0ZXMgYmFzZWQgb24gc2tpbGxzLCBhdmFpbGFiaWxpdHksIGFuZCBpbnRlcmVzdHMuIE5vIG1vcmUgYXdrd2FyZCBncm91cGluZ3MuPC9wPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoZXJvLWFjdGlvbnNcIj5cclxuICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJidG4gYnRuLXByaW1hcnkgYnRuLWxnXCIgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoJy9yZWdpc3RlcicpfT7wn5qAIENyZWF0ZSBGcmVlIEFjY291bnQ8L2J1dHRvbj5cclxuICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJidG4gYnRuLW91dGxpbmUgYnRuLWxnXCIgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoJy9sb2dpbicpfT5TaWduIEluIOKGkjwvYnV0dG9uPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhlcm8tc29jaWFsLXByb29mXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYXZhdGFyLXN0YWNrXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhdmF0YXItc21cIiBzdHlsZT17eyBiYWNrZ3JvdW5kOiAnbGluZWFyLWdyYWRpZW50KDEzNWRlZywjMzhCREY4LCMyNTYzRUIpJ319PkFLPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhdmF0YXItc21cIiBzdHlsZT17eyBiYWNrZ3JvdW5kOiAnbGluZWFyLWdyYWRpZW50KDEzNWRlZywjMUUzQThBLCMwMzY5QTEpJ319PlNQPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhdmF0YXItc21cIiBzdHlsZT17eyBiYWNrZ3JvdW5kOiAnbGluZWFyLWdyYWRpZW50KDEzNWRlZywjMDM2OUExLCMzOEJERjgpJ319Pk5GPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhdmF0YXItc21cIiBzdHlsZT17eyBiYWNrZ3JvdW5kOiAnbGluZWFyLWdyYWRpZW50KDEzNWRlZywjMjU2M0VCLCMxRTNBOEEpJ319PlJNPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhdmF0YXItc21cIiBzdHlsZT17eyBiYWNrZ3JvdW5kOiAnbGluZWFyLWdyYWRpZW50KDEzNWRlZywjN0MzQUVELCMyNTYzRUIpJ319Pis8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic29jaWFsLXRleHRcIj48c3Ryb25nPjEsMjAwKyBzdHVkZW50czwvc3Ryb25nPiBhbHJlYWR5IGZvdW5kIHRoZWlyIHRlYW08L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGVyby12aXN1YWxcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGVyby1jYXJkLWZsb2F0XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF0Y2gtcm93XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXRjaC1hdmF0YXJcIiBzdHlsZT17eyBiYWNrZ3JvdW5kOiAnbGluZWFyLWdyYWRpZW50KDEzNWRlZywjMzhCREY4LCMyNTYzRUIpJ319Pk5LPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXRjaC1pbmZvXCI+PGg0Pk5pbWFsIEthcnVuYXJhdG5lPC9oND48cD5Gcm9udGVuZCBEZXYgwrcgMTAgaHJzL3dlZWs8L3A+PC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXRjaC1zY29yZVwiPjkyJTwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXRjaC1iYXItYmdcIj48ZGl2IGNsYXNzTmFtZT1cIm1hdGNoLWJhclwiIHN0eWxlPXt7IHdpZHRoOiAnOTIlJyB9fT48L2Rpdj48L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJza2lsbC1waXBzXCI+PHNwYW4gY2xhc3NOYW1lPVwic2tpbGwtcGlwXCI+UmVhY3Q8L3NwYW4+PHNwYW4gY2xhc3NOYW1lPVwic2tpbGwtcGlwXCI+Tm9kZS5qczwvc3Bhbj48c3BhbiBjbGFzc05hbWU9XCJza2lsbC1waXBcIj5Nb25nb0RCPC9zcGFuPjwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhlcm8tY2FyZC1mbG9hdFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1hdGNoLXJvd1wiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF0Y2gtYXZhdGFyXCIgc3R5bGU9e3sgYmFja2dyb3VuZDogJ2xpbmVhci1ncmFkaWVudCgxMzVkZWcsIzFFM0E4QSwjMDM2OUExKSd9fT5TUjwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF0Y2gtaW5mb1wiPjxoND5TaXRodW1pIFJhdGhuYXlha2U8L2g0PjxwPkFJIEVuZ2luZWVyIMK3IDggaHJzL3dlZWs8L3A+PC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXRjaC1zY29yZVwiPjg1JTwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXRjaC1iYXItYmdcIj48ZGl2IGNsYXNzTmFtZT1cIm1hdGNoLWJhclwiIHN0eWxlPXt7IHdpZHRoOiAnODUlJyB9fT48L2Rpdj48L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJza2lsbC1waXBzXCI+PHNwYW4gY2xhc3NOYW1lPVwic2tpbGwtcGlwXCI+UHl0aG9uPC9zcGFuPjxzcGFuIGNsYXNzTmFtZT1cInNraWxsLXBpcFwiPkZhc3RBUEk8L3NwYW4+PHNwYW4gY2xhc3NOYW1lPVwic2tpbGwtcGlwXCI+VEYtSURGPC9zcGFuPjwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvc2VjdGlvbj5cclxuXHJcbiAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImZlYXR1cmVzXCIgaWQ9XCJmZWF0dXJlc1wiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2VjdGlvbi1sYWJlbFwiPldoeSBQcm9qZWN0TWF0ZTwvZGl2PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2VjdGlvbi10aXRsZVwiPkV2ZXJ5dGhpbmcgeW91IG5lZWQgdG88YnIvPmJ1aWxkIHRoZSBwZXJmZWN0IHRlYW08L2Rpdj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNlY3Rpb24tc3ViXCI+RnJvbSBzbWFydCBBSSBtYXRjaGluZyB0byBzZWFtbGVzcyByZXF1ZXN0IHdvcmtmbG93cyDigJQgd2UndmUgYnVpbHQgdGhlIHRvb2xzIHVuaXZlcnNpdHkgc3R1ZGVudHMgYWN0dWFsbHkgbmVlZC48L2Rpdj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZlYXR1cmVzLWdyaWRcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmVhdHVyZS1jYXJkXCI+PGRpdiBjbGFzc05hbWU9XCJmZWF0dXJlLWljb25cIj7wn6egPC9kaXY+PGgzPkFJIENvbXBhdGliaWxpdHkgTWF0Y2hpbmc8L2gzPjxwPk91ciB3ZWlnaHRlZCBzY29yaW5nIGFsZ29yaXRobSBhbmFseXplcyBza2lsbCBvdmVybGFwLCBhdmFpbGFiaWxpdHksIGFuZCBpbnRlcmVzdCBhbGlnbm1lbnQgdG8gcmFuayB0aGUgbW9zdCBjb21wYXRpYmxlIHBhcnRuZXJzIGZvciB5b3UuPC9wPjwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmZWF0dXJlLWNhcmRcIj48ZGl2IGNsYXNzTmFtZT1cImZlYXR1cmUtaWNvblwiPvCfjq88L2Rpdj48aDM+U2tpbGwtQmFzZWQgRGlzY292ZXJ5PC9oMz48cD5Ccm93c2UgcHJvamVjdHMgdGhhdCBzcGVjaWZpY2FsbHkgbmVlZCB5b3VyIHNraWxscy4gTm8gbW9yZSBzY3JvbGxpbmcgdGhyb3VnaCBpcnJlbGV2YW50IGxpc3RpbmdzIOKAlCB5b3VyIG1hdGNoZXMgYXJlIGN1cmF0ZWQganVzdCBmb3IgeW91LjwvcD48L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmVhdHVyZS1jYXJkXCI+PGRpdiBjbGFzc05hbWU9XCJmZWF0dXJlLWljb25cIj7imqE8L2Rpdj48aDM+SW5zdGFudCBSZXF1ZXN0IFdvcmtmbG93PC9oMz48cD5TZW5kIHBhcnRuZXIgcmVxdWVzdHMsIGFjY2VwdCBvciByZWplY3Qgd2l0aCBvbmUgY2xpY2ssIGFuZCB3YXRjaCB5b3VyIHRlYW0gbG9jayBhdXRvbWF0aWNhbGx5IHdoZW4gYWxsIHBvc2l0aW9ucyBhcmUgZmlsbGVkLjwvcD48L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmVhdHVyZS1jYXJkXCI+PGRpdiBjbGFzc05hbWU9XCJmZWF0dXJlLWljb25cIj7wn5KhPC9kaXY+PGgzPlNtYXJ0IFByb2ZpbGUgU3VnZ2VzdGlvbnM8L2gzPjxwPkFJIHN1Z2dlc3RzIHNraWxscyB5b3UgbWlnaHQgYmUgbWlzc2luZyBiYXNlZCBvbiB5b3VyIHNlbGVjdGVkIGRvbWFpbiwgaGVscGluZyB5b3UgYnVpbGQgYSBjb21wbGV0ZSBwcm9maWxlIHRoYXQgYXR0cmFjdHMgdGhlIHJpZ2h0IHByb2plY3RzLjwvcD48L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmVhdHVyZS1jYXJkXCI+PGRpdiBjbGFzc05hbWU9XCJmZWF0dXJlLWljb25cIj7wn5OKPC9kaXY+PGgzPlRyYW5zcGFyZW50IEV4cGxhbmF0aW9uczwvaDM+PHA+RXZlcnkgbWF0Y2ggY29tZXMgd2l0aCBhIGNsZWFyIGV4cGxhbmF0aW9uLiBObyBibGFjayBib3hlcyDigJQganVzdCBob25lc3QsIHJlYWRhYmxlIGNvbXBhdGliaWxpdHkgYnJlYWtkb3ducy48L3A+PC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZlYXR1cmUtY2FyZFwiPjxkaXYgY2xhc3NOYW1lPVwiZmVhdHVyZS1pY29uXCI+8J+UkjwvZGl2PjxoMz5Vbml2ZXJzaXR5LVNhZmUgJiBQcml2YXRlPC9oMz48cD5Zb3VyIGRhdGEgc3RheXMgd2l0aGluIHlvdXIgdW5pdmVyc2l0eSBlY29zeXN0ZW0uIE5vIGV4dGVybmFsIGludGVncmF0aW9ucywgbm8gYWRzLCBubyBkYXRhIHNlbGxpbmcuIEp1c3QgY2xlYW4sIGZvY3VzZWQgY29sbGFib3JhdGlvbi48L3A+PC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvc2VjdGlvbj5cclxuXHJcbiAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInN0ZXBzXCIgaWQ9XCJob3dcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNlY3Rpb24tbGFiZWxcIj5HZXR0aW5nIFN0YXJ0ZWQ8L2Rpdj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNlY3Rpb24tdGl0bGVcIj5VcCBhbmQgcnVubmluZyBpbiBtaW51dGVzPC9kaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdGVwcy1ncmlkXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN0ZXAtY2FyZFwiPjxkaXYgY2xhc3NOYW1lPVwic3RlcC1udW1cIj4xPC9kaXY+PGg0PkNyZWF0ZSBQcm9maWxlPC9oND48cD5TaWduIHVwIHdpdGggeW91ciB1bml2ZXJzaXR5IGVtYWlsIGFuZCBzZXQgeW91ciBiYXNpYyBpbmZvLjwvcD48L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3RlcC1jYXJkXCI+PGRpdiBjbGFzc05hbWU9XCJzdGVwLW51bVwiPjI8L2Rpdj48aDQ+QWRkIFlvdXIgU2tpbGxzPC9oND48cD5GaWxsIGluIHlvdXIgc2tpbGxzLCBpbnRlcmVzdHMsIGFuZCB3ZWVrbHkgYXZhaWxhYmlsaXR5IGluIHlvdXIgcHJvZmlsZS48L3A+PC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN0ZXAtY2FyZFwiPjxkaXYgY2xhc3NOYW1lPVwic3RlcC1udW1cIj4zPC9kaXY+PGg0PkdldCBNYXRjaGVkPC9oND48cD5BSSByZWNvbW1lbmRzIHRoZSBtb3N0IGNvbXBhdGlibGUgcGFydG5lcnMgd2l0aCBjbGVhciBleHBsYW5hdGlvbnMuPC9wPjwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdGVwLWNhcmRcIj48ZGl2IGNsYXNzTmFtZT1cInN0ZXAtbnVtXCI+NDwvZGl2PjxoND5CdWlsZCBZb3VyIFRlYW08L2g0PjxwPlNlbmQgcmVxdWVzdHMsIGdldCBhY2NlcHRlZCwgYW5kIHlvdXIgcHJvamVjdCB0ZWFtIGxvY2tzIGF1dG9tYXRpY2FsbHkuPC9wPjwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L3NlY3Rpb24+XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInN0YXRzLWJhclwiIGlkPVwic3RhdHNcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN0YXQtaXRlbVwiPjxzcGFuIGNsYXNzTmFtZT1cInN0YXQtbnVtXCI+MSwyMDArPC9zcGFuPjxzcGFuIGNsYXNzTmFtZT1cInN0YXQtbGFiZWxcIj5BY3RpdmUgU3R1ZGVudHM8L3NwYW4+PC9kaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdGF0LWl0ZW1cIj48c3BhbiBjbGFzc05hbWU9XCJzdGF0LW51bVwiPjM0MCs8L3NwYW4+PHNwYW4gY2xhc3NOYW1lPVwic3RhdC1sYWJlbFwiPlByb2plY3RzIFBvc3RlZDwvc3Bhbj48L2Rpdj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN0YXQtaXRlbVwiPjxzcGFuIGNsYXNzTmFtZT1cInN0YXQtbnVtXCI+ODclPC9zcGFuPjxzcGFuIGNsYXNzTmFtZT1cInN0YXQtbGFiZWxcIj5NYXRjaCBTYXRpc2ZhY3Rpb248L3NwYW4+PC9kaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdGF0LWl0ZW1cIj48c3BhbiBjbGFzc05hbWU9XCJzdGF0LW51bVwiPjUwKzwvc3Bhbj48c3BhbiBjbGFzc05hbWU9XCJzdGF0LWxhYmVsXCI+U2tpbGxzIFRyYWNrZWQ8L3NwYW4+PC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwiY3RhLXNlY3Rpb25cIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImN0YS1ib3hcIj5cclxuICAgICAgICAgIDxoMj5SZWFkeSB0byBmaW5kIHlvdXIgdGVhbT88L2gyPlxyXG4gICAgICAgICAgPHA+Sm9pbiAxLDIwMCsgc3R1ZGVudHMgd2hvJ3ZlIGFscmVhZHkgc3RvcHBlZCBzdHJ1Z2dsaW5nIHdpdGggZ3JvdXAgZm9ybWF0aW9uLiBDcmVhdGUgeW91ciBmcmVlIHByb2ZpbGUgaW4gdW5kZXIgMiBtaW51dGVzLjwvcD5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYnRuLWFjdGlvbnNcIiBzdHlsZT17eyBqdXN0aWZ5Q29udGVudDogJ2NlbnRlcicgfX0+XHJcbiAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYnRuIGJ0bi1naG9zdCBidG4tbGdcIiBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZSgnL2xvZ2luJyl9PkxvZyBJbjwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImJ0biBidG4tbGdcIiBzdHlsZT17eyBiYWNrZ3JvdW5kOiAnI2ZmZicsIGNvbG9yOiAndmFyKC0tcCknIH19IG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKCcvcmVnaXN0ZXInKX0+8J+agCBHZXQgU3RhcnRlZCBGcmVlPC9idXR0b24+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9zZWN0aW9uPlxyXG5cclxuICAgICAgPGZvb3RlciBjbGFzc05hbWU9XCJsYW5kaW5nLWZvb3RlclwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9vdGVyLWJyYW5kXCIgc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCBhbGlnbkl0ZW1zOiAnY2VudGVyJywgZ2FwOiAnOHB4JyB9fT5cclxuICAgICAgICAgIDxpbWcgc3JjPXtsb2dvfSBhbHQ9XCJQcm9NYXRlIExvZ29cIiBzdHlsZT17eyB3aWR0aDogJzMwcHgnLCBoZWlnaHQ6ICczMHB4JywgYm9yZGVyUmFkaXVzOiAnNTAlJyB9fSAvPlxyXG4gICAgICAgICAgPHNwYW4+UHJvTWF0ZTwvc3Bhbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvb3Rlci10ZXh0XCI+wqkgMjAyNiBQcm9qZWN0TWF0ZSDCtyBJVDMwNDAgUHJvamVjdCDCtyBTcmkgTGFua2EgSW5zdGl0dXRlIG9mIEluZm9ybWF0aW9uIFRlY2hub2xvZ3k8L2Rpdj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvb3Rlci10ZXh0XCI+QnVpbHQgd2l0aCDwn5KZIGJ5IFRlYW08L2Rpdj5cclxuICAgICAgPC9mb290ZXI+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgTGFuZGluZztcclxuIl0sImZpbGUiOiJGOi9ZM1MyL0lUUE0gcHJvamVjdC9Qcm9NYXRlLS1Qcm9qZWN0LVBhcnRuZXItRmluZGVyL2Zyb250ZW5kL3NyYy9wYWdlcy9MYW5kaW5nLmpzeCJ9