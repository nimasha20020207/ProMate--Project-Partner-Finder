import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Users/EditProfile.jsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=383bea9f"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"];
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=383bea9f";
import { useAuth } from "/src/context/AuthContext.jsx";
import { calculateProfileCompleteness } from "/src/utils/profileUtils.js";
import { User, Mail, BookOpen, Briefcase, Code, Globe, Calendar, Clock, Link as LinkIcon, LogOut, Save, X, Phone, Github, Linkedin, CheckCircle2, AlertCircle, Info, Hash, ChevronRight, Award, Brain, Plus } from "/node_modules/.vite/deps/lucide-react.js?v=383bea9f";
import Modal from "/src/components/Modal.jsx";
import "/src/pages/Users/EditProfile.css";
const EditProfile = () => {
  _s();
  const navigate = useNavigate();
  const {
    user,
    token,
    fetchProfile
  } = useAuth();
  const [activeSegment, setActiveSegment] = useState("personal");
  const [showSuccess, setShowSuccess] = useState(false);
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    studentId: "",
    department: "",
    bio: "",
    contactNumber: "",
    profilePicture: "",
    socialLinks: {
      github: "",
      linkedin: "",
      portfolio: ""
    },
    academicInfo: {
      specialization: "",
      year: "",
      semester: "",
      cgpa: ""
    },
    skills: {
      languages: [],
      frameworks: [],
      libraries: [],
      databases: [],
      tools: []
    },
    availability: {
      weeklyHours: 10,
      preferredDays: [],
      preferredTime: []
    },
    interests: [],
    preferredRoles: []
  });
  useEffect(() => {
    if (user) {
      setFormData((prev) => ({
        ...prev,
        ...user,
        academicInfo: {
          specialization: user.academicInfo?.specialization || "",
          year: user.academicInfo?.year?.toString() || "",
          semester: user.academicInfo?.semester?.toString() || "",
          cgpa: user.academicInfo?.cgpa || ""
        },
        skills: {
          languages: user.skills?.languages || [],
          frameworks: user.skills?.frameworks || [],
          libraries: user.skills?.libraries || [],
          databases: user.skills?.databases || [],
          tools: user.skills?.tools || []
        },
        availability: {
          weeklyHours: user.availability?.weeklyHours || 10,
          preferredDays: user.availability?.preferredDays || [],
          preferredTime: user.availability?.preferredTime || []
        },
        socialLinks: {
          github: user.socialLinks?.github || "",
          linkedin: user.socialLinks?.linkedin || "",
          portfolio: user.socialLinks?.portfolio || ""
        },
        contactNumber: user.contactNumber || "",
        preferredRoles: user.preferredRoles || []
      }));
    }
  }, [user]);
  const skillData = {
    languages: ["JavaScript", "TypeScript", "Python", "Java", "C", "C++", "C#", "Go", "Rust", "Kotlin", "Swift", "PHP", "Ruby", "Dart", "R", "MATLAB"],
    frameworks: ["React", "Angular", "Vue.js", "Next.js", "Nuxt.js", "Node.js", "Express.js", "Django", "Flask", "Spring Boot", "ASP.NET", "Laravel", "Ruby on Rails", "Flutter", "React Native"],
    libraries: ["Redux", "Axios", "jQuery", "Loash", "TensorFlow", "Keras", "PyTorch", "Scikit-learn", "Pandas", "NumPy", "Chart.js", "D3.js", "Three.js", "Socket.io", "Bootstrap"],
    databases: ["MongoDB", "MySQL", "PostgreSQL", "SQLite", "Oracle", "Microsoft SQL Server", "Firebase", "Redis", "Cassandra", "DynamoDB", "Neo4j"],
    tools: ["Git", "GitHub", "GitLab", "Docker", "Kubernetes", "Postman", "Jira", "Trello", "Figma", "Adobe XD", "VS Code", "IntelliJ IDEA", "Eclipse", "Webpack", "Babel"]
  };
  const skillCategories = ["languages", "frameworks", "libraries", "databases", "tools"];
  const interests = ["AI / ML", "Web Development", "Mobile Development", "UI/UX", "DevOps", "Data Science", "Cloud Computing", "IoT", "Blockchain", "Game Development", "Cybersecurity"];
  const rolesOptions = ["Frontend Developer", "Backend Developer", "Fullstack Developer", "Mobile App Developer", "ML Engineer", "Data Scientist", "UI/UX Designer", "DevOps Engineer", "QA Engineer", "Project Manager"];
  const days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
  const times = ["Morning", "Afternoon", "Evening", "Night"];
  const [activeDropdown, setActiveDropdown] = useState(null);
  const [skillInput, setSkillInput] = useState({
    category: "languages",
    text: ""
  });
  const handleInputChange = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value
    }));
  };
  const handleNestedChange = (parent, field, value) => {
    setFormData((prev) => ({
      ...prev,
      [parent]: {
        ...prev[parent],
        [field]: value
      }
    }));
  };
  const handleMultiSelect = (field, value) => {
    setFormData((prev) => {
      const current = prev[field] || [];
      const updated = current.includes(value) ? current.filter((i) => i !== value) : [...current, value];
      return {
        ...prev,
        [field]: updated
      };
    });
  };
  const handleAvailabilitySelect = (field, value) => {
    setFormData((prev) => {
      const current = prev.availability[field] || [];
      const updated = current.includes(value) ? current.filter((i) => i !== value) : [...current, value];
      return {
        ...prev,
        availability: {
          ...prev.availability,
          [field]: updated
        }
      };
    });
  };
  const handleRemoveSkill = (cat, skill) => {
    setFormData((prev) => ({
      ...prev,
      skills: {
        ...prev.skills,
        [cat]: prev.skills[cat].filter((s) => s !== skill)
      }
    }));
  };
  const handleSubmit = async () => {
    try {
      const res = await fetch("http://localhost:3000/api/profile/", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          "x-auth-token": token
        },
        body: JSON.stringify(formData)
      });
      if (res.ok) {
        await fetchProfile();
        setShowSuccess(true);
      } else {
        const errorData = await res.json();
        alert(errorData.msg || "Error updating profile");
      }
    } catch (err) {
      alert("Error updating profile");
    }
  };
  const toggleDropdown = (id) => setActiveDropdown(activeDropdown === id ? null : id);
  const {
    percentage: completeness
  } = calculateProfileCompleteness(formData);
  return /* @__PURE__ */ jsxDEV("div", { id: "page-edit-profile", className: "page active", style: {
    display: "block",
    paddingBottom: "3rem",
    background: "#f8fafc"
  }, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "page-hdr", style: {
      maxWidth: "1200px",
      margin: "0 auto 2rem auto",
      paddingTop: "1.5rem"
    }, children: [
      /* @__PURE__ */ jsxDEV("div", { className: "page-hdr-left", children: [
        /* @__PURE__ */ jsxDEV("h1", { style: {
          display: "flex",
          alignItems: "center",
          gap: "10px"
        }, children: [
          /* @__PURE__ */ jsxDEV(User, { size: 28, color: "var(--p)" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
            lineNumber: 194,
            columnNumber: 13
          }, this),
          " Edit Profile"
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
          lineNumber: 189,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: "Craft your professional presence on ProMate" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
          lineNumber: 196,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
        lineNumber: 188,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "page-hdr-right", style: {
        display: "flex",
        alignItems: "center",
        gap: "1rem"
      }, children: [
        /* @__PURE__ */ jsxDEV("button", { className: "btn btn-outline btn-sm", onClick: () => navigate("/profile"), children: "Discard" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
          lineNumber: 203,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("button", { className: "btn btn-primary btn-sm", onClick: handleSubmit, children: [
          /* @__PURE__ */ jsxDEV(Save, { size: 16 }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
            lineNumber: 205,
            columnNumber: 13
          }, this),
          " Save Changes"
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
          lineNumber: 204,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
        lineNumber: 198,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
      lineNumber: 183,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "ep-outer-container", children: /* @__PURE__ */ jsxDEV("div", { className: "ep-main-card", children: [
      /* @__PURE__ */ jsxDEV("aside", { className: "ep-sidebar", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "ep-sb-item", style: {
          pointerEvents: "none",
          marginBottom: "1rem",
          borderBottom: "1px solid var(--border)",
          paddingBottom: "0.5rem"
        }, children: [
          /* @__PURE__ */ jsxDEV("div", { className: "cc-pct", style: {
            fontSize: "1.2rem"
          }, children: [
            completeness,
            "%"
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
            lineNumber: 220,
            columnNumber: 16
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: {
            fontSize: "0.7rem",
            color: "var(--mid)"
          }, children: "Completeness" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
            lineNumber: 223,
            columnNumber: 16
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
          lineNumber: 214,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: `ep-sb-item ${activeSegment === "personal" ? "active" : ""}`, onClick: () => setActiveSegment("personal"), children: [
          /* @__PURE__ */ jsxDEV(User, { className: "ep-sb-icon" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
            lineNumber: 230,
            columnNumber: 15
          }, this),
          " Personal Details"
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
          lineNumber: 229,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: `ep-sb-item ${activeSegment === "academic" ? "active" : ""}`, onClick: () => setActiveSegment("academic"), children: [
          /* @__PURE__ */ jsxDEV(BookOpen, { className: "ep-sb-icon" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
            lineNumber: 233,
            columnNumber: 15
          }, this),
          " Academic Info"
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
          lineNumber: 232,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: `ep-sb-item ${activeSegment === "social" ? "active" : ""}`, onClick: () => setActiveSegment("social"), children: [
          /* @__PURE__ */ jsxDEV(Globe, { className: "ep-sb-icon" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
            lineNumber: 236,
            columnNumber: 15
          }, this),
          " Social Links"
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
          lineNumber: 235,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: `ep-sb-item ${activeSegment === "skills" ? "active" : ""}`, onClick: () => setActiveSegment("skills"), children: [
          /* @__PURE__ */ jsxDEV(Code, { className: "ep-sb-icon" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
            lineNumber: 239,
            columnNumber: 15
          }, this),
          " Skills & Tech"
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
          lineNumber: 238,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: `ep-sb-item ${activeSegment === "availability" ? "active" : ""}`, onClick: () => setActiveSegment("availability"), children: [
          /* @__PURE__ */ jsxDEV(Calendar, { className: "ep-sb-icon" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
            lineNumber: 242,
            columnNumber: 15
          }, this),
          " Availability"
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
          lineNumber: 241,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: `ep-sb-item ${activeSegment === "interests" ? "active" : ""}`, onClick: () => setActiveSegment("interests"), children: [
          /* @__PURE__ */ jsxDEV(Brain, { className: "ep-sb-icon" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
            lineNumber: 245,
            columnNumber: 15
          }, this),
          " Project Interests"
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
          lineNumber: 244,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: `ep-sb-item ${activeSegment === "roles" ? "active" : ""}`, onClick: () => setActiveSegment("roles"), children: [
          /* @__PURE__ */ jsxDEV(Briefcase, { className: "ep-sb-icon" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
            lineNumber: 248,
            columnNumber: 15
          }, this),
          " Preferred Roles"
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
          lineNumber: 247,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "ep-sb-promo", children: [
          /* @__PURE__ */ jsxDEV(Award, { size: 20, style: {
            color: "var(--p)",
            marginBottom: "0.5rem"
          } }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
            lineNumber: 252,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: {
            fontSize: "0.75rem",
            fontWeight: 600,
            color: "var(--p)"
          }, children: "Pro Tip" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
            lineNumber: 256,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { style: {
            fontSize: "0.65rem",
            color: "var(--mid)",
            marginTop: "2px"
          }, children: "Complete your profile to get better project matches!" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
            lineNumber: 261,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
          lineNumber: 251,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
        lineNumber: 213,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("main", { className: "ep-content", children: [
        activeSegment === "personal" && /* @__PURE__ */ jsxDEV("div", { className: "ep-section-card", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "ep-section-header", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "ep-section-icon-bg", children: /* @__PURE__ */ jsxDEV(User, { size: 20 }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 274,
              columnNumber: 55
            }, this) }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 274,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("h2", { children: "Personal Information" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 275,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
            lineNumber: 273,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "pf-upload-card", children: [
            /* @__PURE__ */ jsxDEV("div", { style: {
              position: "relative",
              display: "inline-block"
            }, children: [
              /* @__PURE__ */ jsxDEV("img", { src: formData.profilePicture || "https://ui-avatars.com/api/?name=" + (formData.fullName || "User"), alt: "Avatar", className: "ep-avatar-lg" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
                lineNumber: 283,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("label", { htmlFor: "pf-upload", className: "pf-upload-btn", children: /* @__PURE__ */ jsxDEV(Plus, { size: 16 }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
                lineNumber: 285,
                columnNumber: 23
              }, this) }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
                lineNumber: 284,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("input", { id: "pf-upload", type: "file", hidden: true, accept: "image/*", onChange: async (e) => {
                const file = e.target.files[0];
                if (!file)
                  return;
                const fd = new FormData();
                fd.append("profilePicture", file);
                try {
                  const res = await fetch("http://localhost:3000/api/profile/upload", {
                    method: "POST",
                    headers: {
                      "x-auth-token": token
                    },
                    body: fd
                  });
                  const data = await res.json();
                  if (res.ok) {
                    handleInputChange("profilePicture", data.url);
                    await fetchProfile();
                  } else {
                    alert("Upload failed: " + data.message);
                  }
                } catch (err) {
                  alert("Error uploading image");
                }
              } }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
                lineNumber: 287,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 279,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "pf-upload-info", children: [
              /* @__PURE__ */ jsxDEV("h3", { children: formData.fullName || "Your Student Profile" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
                lineNumber: 313,
                columnNumber: 22
              }, this),
              /* @__PURE__ */ jsxDEV("p", { children: formData.email }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
                lineNumber: 314,
                columnNumber: 22
              }, this)
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 312,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
            lineNumber: 278,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "form-row", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "form-label", children: "Full Name" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
                lineNumber: 320,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("input", { type: "text", className: "ep-form-input", value: formData.fullName, onChange: (e) => handleInputChange("fullName", e.target.value) }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
                lineNumber: 321,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 319,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "form-label", children: "Student ID" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
                lineNumber: 324,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "ep-form-input readonly", children: [
                /* @__PURE__ */ jsxDEV(Hash, { size: 14 }, void 0, false, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
                  lineNumber: 325,
                  columnNumber: 61
                }, this),
                " ",
                formData.studentId
              ] }, void 0, true, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
                lineNumber: 325,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 323,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
            lineNumber: 318,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "form-label", children: "Professional Bio" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 330,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("textarea", { className: "ep-form-input", rows: "4", placeholder: "Tell potential teammates about your passion, goals...", value: formData.bio || "", onChange: (e) => handleInputChange("bio", e.target.value) }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 331,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
            lineNumber: 329,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "form-label", children: [
              /* @__PURE__ */ jsxDEV(Phone, { size: 14 }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
                lineNumber: 335,
                columnNumber: 49
              }, this),
              " Contact Number"
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 335,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("input", { type: "text", className: "ep-form-input", placeholder: "+94 77 123 4567", value: formData.contactNumber, onChange: (e) => handleInputChange("contactNumber", e.target.value) }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 336,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
            lineNumber: 334,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
          lineNumber: 272,
          columnNumber: 46
        }, this),
        activeSegment === "academic" && /* @__PURE__ */ jsxDEV("div", { className: "ep-section-card", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "ep-section-header", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "ep-section-icon-bg", children: /* @__PURE__ */ jsxDEV(BookOpen, { size: 20 }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 342,
              columnNumber: 55
            }, this) }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 342,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("h2", { children: "Academic Background" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 343,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
            lineNumber: 341,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "form-label", children: [
              "Department ",
              /* @__PURE__ */ jsxDEV("span", { style: {
                color: "var(--mid)",
                fontWeight: 400,
                fontSize: "0.75rem"
              }, children: "(Contact Admin to change)" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
                lineNumber: 347,
                columnNumber: 60
              }, this)
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 347,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "ep-form-input readonly", children: [
              /* @__PURE__ */ jsxDEV(BookOpen, { size: 14 }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
                lineNumber: 353,
                columnNumber: 21
              }, this),
              " ",
              formData.department || "Not Set"
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 352,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
            lineNumber: 346,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "form-row", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "form-label", children: "Year of Study" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
                lineNumber: 359,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("select", { className: "ep-form-input", value: formData.academicInfo.year, onChange: (e) => handleNestedChange("academicInfo", "year", e.target.value), children: [
                /* @__PURE__ */ jsxDEV("option", { value: "", children: "Select Year" }, void 0, false, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
                  lineNumber: 361,
                  columnNumber: 23
                }, this),
                ["1", "2", "3", "4"].map((y) => /* @__PURE__ */ jsxDEV("option", { value: y, children: [
                  "Year ",
                  y
                ] }, y, true, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
                  lineNumber: 362,
                  columnNumber: 54
                }, this))
              ] }, void 0, true, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
                lineNumber: 360,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 358,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "form-label", children: "Semester" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
                lineNumber: 366,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("select", { className: "ep-form-input", value: formData.academicInfo.semester, onChange: (e) => handleNestedChange("academicInfo", "semester", e.target.value), children: [
                /* @__PURE__ */ jsxDEV("option", { value: "", children: "Select Semester" }, void 0, false, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
                  lineNumber: 368,
                  columnNumber: 23
                }, this),
                ["1", "2"].map((s) => /* @__PURE__ */ jsxDEV("option", { value: s, children: [
                  "Semester ",
                  s
                ] }, s, true, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
                  lineNumber: 369,
                  columnNumber: 44
                }, this))
              ] }, void 0, true, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
                lineNumber: 367,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 365,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
            lineNumber: 357,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "form-row", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "form-label", children: [
                "Specialization ",
                /* @__PURE__ */ jsxDEV("span", { style: {
                  color: "var(--mid)",
                  fontWeight: 400,
                  fontSize: "0.75rem"
                }, children: "(Contact Admin to change)" }, void 0, false, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
                  lineNumber: 376,
                  columnNumber: 66
                }, this)
              ] }, void 0, true, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
                lineNumber: 376,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "ep-form-input readonly", children: [
                /* @__PURE__ */ jsxDEV(Award, { size: 14 }, void 0, false, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
                  lineNumber: 382,
                  columnNumber: 24
                }, this),
                " ",
                formData.academicInfo.specialization || "Not Set"
              ] }, void 0, true, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
                lineNumber: 381,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 375,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "form-label", children: "Current CGPA" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
                lineNumber: 386,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("input", { type: "number", className: "ep-form-input", value: formData.academicInfo.cgpa, onChange: (e) => handleNestedChange("academicInfo", "cgpa", e.target.value), min: "0", max: "4", step: "0.01" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
                lineNumber: 387,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 385,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
            lineNumber: 374,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
          lineNumber: 340,
          columnNumber: 46
        }, this),
        activeSegment === "social" && /* @__PURE__ */ jsxDEV("div", { className: "ep-section-card", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "ep-section-header", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "ep-section-icon-bg", children: /* @__PURE__ */ jsxDEV(Globe, { size: 20 }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 394,
              columnNumber: 55
            }, this) }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 394,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("h2", { children: "Professional Links" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 395,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
            lineNumber: 393,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "form-label", children: [
              /* @__PURE__ */ jsxDEV(Github, { size: 14 }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
                lineNumber: 399,
                columnNumber: 49
              }, this),
              " GitHub Profile"
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 399,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("input", { type: "url", className: "ep-form-input", placeholder: "https://github.com/username", value: formData.socialLinks?.github || "", onChange: (e) => handleNestedChange("socialLinks", "github", e.target.value) }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 400,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
            lineNumber: 398,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "form-label", children: [
              /* @__PURE__ */ jsxDEV(Linkedin, { size: 14 }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
                lineNumber: 404,
                columnNumber: 49
              }, this),
              " LinkedIn Profile"
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 404,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("input", { type: "url", className: "ep-form-input", placeholder: "https://linkedin.com/in/username", value: formData.socialLinks?.linkedin || "", onChange: (e) => handleNestedChange("socialLinks", "linkedin", e.target.value) }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 405,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
            lineNumber: 403,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "form-label", children: [
              /* @__PURE__ */ jsxDEV(LinkIcon, { size: 14 }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
                lineNumber: 409,
                columnNumber: 49
              }, this),
              " Personal Portfolio"
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 409,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("input", { type: "url", className: "ep-form-input", placeholder: "https://yourwebsite.com", value: formData.socialLinks?.portfolio || "", onChange: (e) => handleNestedChange("socialLinks", "portfolio", e.target.value) }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 410,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
            lineNumber: 408,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
          lineNumber: 392,
          columnNumber: 44
        }, this),
        activeSegment === "skills" && /* @__PURE__ */ jsxDEV("div", { className: "ep-section-card", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "ep-section-header", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "ep-section-icon-bg", children: /* @__PURE__ */ jsxDEV(Code, { size: 20 }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 416,
              columnNumber: 55
            }, this) }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 416,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("h2", { children: "Skills & Tech" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 417,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
            lineNumber: 415,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "skill-section-main", children: skillCategories.map((cat) => /* @__PURE__ */ jsxDEV("div", { className: "skill-cat-row", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "skill-cat-label", children: cat }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 422,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "skill-grid", children: skillData[cat].map((skill) => {
              const isSelected = formData.skills[cat]?.includes(skill);
              return /* @__PURE__ */ jsxDEV("div", { className: `skill-chip-toggle ${isSelected ? "active" : ""}`, onClick: () => isSelected ? handleRemoveSkill(cat, skill) : setFormData((prev) => ({
                ...prev,
                skills: {
                  ...prev.skills,
                  [cat]: [...prev.skills[cat], skill]
                }
              })), children: [
                skill,
                " ",
                isSelected ? /* @__PURE__ */ jsxDEV(CheckCircle2, { size: 12 }, void 0, false, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
                  lineNumber: 433,
                  columnNumber: 53
                }, this) : /* @__PURE__ */ jsxDEV(Plus, { size: 12 }, void 0, false, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
                  lineNumber: 433,
                  columnNumber: 82
                }, this)
              ] }, skill, true, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
                lineNumber: 426,
                columnNumber: 28
              }, this);
            }) }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 423,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "custom-skill-list", children: formData.skills[cat]?.filter((s) => !skillData[cat].includes(s)).map((s) => /* @__PURE__ */ jsxDEV("span", { className: "skill-tag-removable", onClick: () => handleRemoveSkill(cat, s), children: [
              s,
              " ",
              /* @__PURE__ */ jsxDEV(X, { size: 12 }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
                lineNumber: 441,
                columnNumber: 34
              }, this)
            ] }, s, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 440,
              columnNumber: 99
            }, this)) }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 439,
              columnNumber: 23
            }, this)
          ] }, cat, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
            lineNumber: 421,
            columnNumber: 47
          }, this)) }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
            lineNumber: 420,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "custom-skill-adder", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "form-label", children: "Add Custom Technology" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 448,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "adder-flex", children: [
              /* @__PURE__ */ jsxDEV("select", { value: skillInput.category, onChange: (e) => setSkillInput({
                ...skillInput,
                category: e.target.value
              }), children: skillCategories.map((cat) => /* @__PURE__ */ jsxDEV("option", { value: cat, children: cat }, cat, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
                lineNumber: 454,
                columnNumber: 51
              }, this)) }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
                lineNumber: 450,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("input", { type: "text", placeholder: "Enter skill name...", value: skillInput.text, onChange: (e) => setSkillInput({
                ...skillInput,
                text: e.target.value
              }), onKeyDown: (e) => {
                if (e.key === "Enter") {
                  e.preventDefault();
                  const val = skillInput.text.trim();
                  if (val) {
                    const cat = skillInput.category;
                    if (!formData.skills[cat].includes(val)) {
                      setFormData((prev) => ({
                        ...prev,
                        skills: {
                          ...prev.skills,
                          [cat]: [...prev.skills[cat] || [], val]
                        }
                      }));
                    }
                    setSkillInput({
                      ...skillInput,
                      text: ""
                    });
                  }
                }
              } }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
                lineNumber: 456,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("button", { className: "btn btn-primary", onClick: () => {
                const val = skillInput.text.trim();
                if (val) {
                  const cat = skillInput.category;
                  if (!formData.skills[cat].includes(val)) {
                    setFormData((prev) => ({
                      ...prev,
                      skills: {
                        ...prev.skills,
                        [cat]: [...prev.skills[cat] || [], val]
                      }
                    }));
                  }
                  setSkillInput({
                    ...skillInput,
                    text: ""
                  });
                }
              }, children: /* @__PURE__ */ jsxDEV(Plus, { size: 20 }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
                lineNumber: 499,
                columnNumber: 20
              }, this) }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
                lineNumber: 481,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 449,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
            lineNumber: 447,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
          lineNumber: 414,
          columnNumber: 44
        }, this),
        activeSegment === "interests" && /* @__PURE__ */ jsxDEV("div", { className: "ep-section-card", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "ep-section-header", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "ep-section-icon-bg", children: /* @__PURE__ */ jsxDEV(Brain, { size: 20 }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 506,
              columnNumber: 55
            }, this) }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 506,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("h2", { children: "Project Interests" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 507,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
            lineNumber: 505,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "ai-suggestion-banner", children: [
            /* @__PURE__ */ jsxDEV(Brain, { size: 20, color: "var(--p)" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 511,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h4", { children: "Project Domain Selection" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
                lineNumber: 513,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("p", { children: "Select domains that excite you. We use these to recommend projects!" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
                lineNumber: 514,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 512,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
            lineNumber: 510,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "interest-selection-grid", children: interests.map((domain) => {
            const isSelected = formData.interests.includes(domain);
            return /* @__PURE__ */ jsxDEV("div", { className: `interest-pill ${isSelected ? "active" : ""}`, onClick: () => handleMultiSelect("interests", domain), children: [
              isSelected ? /* @__PURE__ */ jsxDEV(CheckCircle2, { size: 16 }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
                lineNumber: 522,
                columnNumber: 39
              }, this) : /* @__PURE__ */ jsxDEV(Plus, { size: 16 }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
                lineNumber: 522,
                columnNumber: 68
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: domain }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
                lineNumber: 523,
                columnNumber: 25
              }, this)
            ] }, domain, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 521,
              columnNumber: 24
            }, this);
          }) }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
            lineNumber: 518,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
          lineNumber: 504,
          columnNumber: 47
        }, this),
        activeSegment === "availability" && /* @__PURE__ */ jsxDEV("div", { className: "ep-section-card", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "ep-section-header", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "ep-section-icon-bg", children: /* @__PURE__ */ jsxDEV(Calendar, { size: 20 }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 531,
              columnNumber: 55
            }, this) }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 531,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("h2", { children: "Weekly Availability" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 532,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
            lineNumber: 530,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "avail-info-box", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "form-label", children: [
              "Dedicated Hours Per Week: ",
              /* @__PURE__ */ jsxDEV("strong", { children: [
                formData.availability.weeklyHours,
                "h"
              ] }, void 0, true, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
                lineNumber: 536,
                columnNumber: 75
              }, this)
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 536,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("input", { type: "range", min: "1", max: "40", value: formData.availability.weeklyHours || 10, onChange: (e) => handleNestedChange("availability", "weeklyHours", e.target.value) }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 537,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
            lineNumber: 535,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "form-label", children: "Working Days" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 541,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "day-grid", children: days.map((d) => /* @__PURE__ */ jsxDEV("div", { className: `day-btn ${formData.availability.preferredDays.includes(d) ? "active" : ""}`, onClick: () => handleAvailabilitySelect("preferredDays", d), children: d.substring(0, 3) }, d, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 543,
              columnNumber: 36
            }, this)) }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 542,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
            lineNumber: 540,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "form-label", children: "Preferred Time Window" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 550,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "chip-grid", children: times.map((t) => /* @__PURE__ */ jsxDEV("div", { className: `chip-btn ${formData.availability.preferredTime.includes(t) ? "active" : ""}`, onClick: () => handleAvailabilitySelect("preferredTime", t), children: t }, t, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 552,
              columnNumber: 37
            }, this)) }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 551,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
            lineNumber: 549,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
          lineNumber: 529,
          columnNumber: 50
        }, this),
        activeSegment === "roles" && /* @__PURE__ */ jsxDEV("div", { className: "ep-section-card", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "ep-section-header", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "ep-section-icon-bg", children: /* @__PURE__ */ jsxDEV(Briefcase, { size: 20 }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 561,
              columnNumber: 55
            }, this) }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 561,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("h2", { children: "Preferred Project Roles" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 562,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
            lineNumber: 560,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "role-selection-grid", children: rolesOptions.map((role) => {
            const isSelected = formData.preferredRoles.includes(role);
            return /* @__PURE__ */ jsxDEV("div", { className: `role-card-select ${isSelected ? "active" : ""}`, onClick: () => handleMultiSelect("preferredRoles", role), children: [
              /* @__PURE__ */ jsxDEV("div", { className: "role-check", children: isSelected ? /* @__PURE__ */ jsxDEV(CheckCircle2, { size: 16 }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
                lineNumber: 569,
                columnNumber: 67
              }, this) : /* @__PURE__ */ jsxDEV("div", { className: "dot" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
                lineNumber: 569,
                columnNumber: 96
              }, this) }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
                lineNumber: 569,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: role }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
                lineNumber: 570,
                columnNumber: 25
              }, this)
            ] }, role, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
              lineNumber: 568,
              columnNumber: 24
            }, this);
          }) }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
            lineNumber: 565,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
          lineNumber: 559,
          columnNumber: 43
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
        lineNumber: 270,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
      lineNumber: 211,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
      lineNumber: 210,
      columnNumber: 7
    }, this),
    showSuccess && /* @__PURE__ */ jsxDEV("div", { className: "success-modal-overlay", children: /* @__PURE__ */ jsxDEV("div", { className: "success-modal-card", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "success-bounce-icon", children: /* @__PURE__ */ jsxDEV(CheckCircle2, { size: 60, color: "#10b981" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
        lineNumber: 583,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
        lineNumber: 582,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("h2", { children: "Profile Updated!" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
        lineNumber: 585,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: "Your changes have been saved successfully. Your profile is looking great!" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
        lineNumber: 586,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("button", { className: "btn btn-primary btn-full success-btn", onClick: () => navigate("/profile"), children: "View My Profile" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
        lineNumber: 587,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
      lineNumber: 581,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
      lineNumber: 580,
      columnNumber: 23
    }, this)
  ] }, void 0, true, {
    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx",
    lineNumber: 177,
    columnNumber: 10
  }, this);
};
_s(EditProfile, "E+BNGFb1yd6RC5fhDyqk8saKmbg=", false, function() {
  return [useNavigate, useAuth];
});
_c = EditProfile;
export default EditProfile;
var _c;
$RefreshReg$(_c, "EditProfile");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/EditProfile.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOEpZOzs7Ozs7Ozs7Ozs7Ozs7O0FBOUpaLE9BQU9BLFNBQVNDLFVBQVVDLFdBQVdDLGVBQWU7QUFDcEQsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLGVBQWU7QUFDeEIsU0FBU0Msb0NBQW9DO0FBQzdDLFNBQ0VDLE1BQU1DLE1BQU1DLFVBQVVDLFdBQVdDLE1BQU1DLE9BQ3ZDQyxVQUFVQyxPQUFPQyxRQUFRQyxVQUFVQyxRQUFRQyxNQUFNQyxHQUFHQyxPQUNwREMsUUFBUUMsVUFBVUMsY0FBY0MsYUFBYUMsTUFBTUMsTUFDbkRDLGNBQWNDLE9BQU9DLE9BQU9DLFlBQ3ZCO0FBQ1AsT0FBT0MsV0FBVztBQUNsQixPQUFPO0FBRVAsTUFBTUMsY0FBY0EsTUFBTTtBQUFBQyxLQUFBO0FBQ3hCLFFBQU1DLFdBQVc5QixZQUFZO0FBQzdCLFFBQU07QUFBQSxJQUFFK0I7QUFBQUEsSUFBTUM7QUFBQUEsSUFBT0M7QUFBQUEsRUFBYSxJQUFJaEMsUUFBUTtBQUM5QyxRQUFNLENBQUNpQyxlQUFlQyxnQkFBZ0IsSUFBSXRDLFNBQVMsVUFBVTtBQUM3RCxRQUFNLENBQUN1QyxhQUFhQyxjQUFjLElBQUl4QyxTQUFTLEtBQUs7QUFFcEQsUUFBTSxDQUFDeUMsVUFBVUMsV0FBVyxJQUFJMUMsU0FBUztBQUFBLElBQ3ZDMkMsVUFBVTtBQUFBLElBQ1ZDLE9BQU87QUFBQSxJQUNQQyxXQUFXO0FBQUEsSUFDWEMsWUFBWTtBQUFBLElBQ1pDLEtBQUs7QUFBQSxJQUNMQyxlQUFlO0FBQUEsSUFDZkMsZ0JBQWdCO0FBQUEsSUFDaEJDLGFBQWE7QUFBQSxNQUFFQyxRQUFRO0FBQUEsTUFBSUMsVUFBVTtBQUFBLE1BQUlDLFdBQVc7QUFBQSxJQUFHO0FBQUEsSUFDdkRDLGNBQWM7QUFBQSxNQUFFQyxnQkFBZ0I7QUFBQSxNQUFJQyxNQUFNO0FBQUEsTUFBSUMsVUFBVTtBQUFBLE1BQUlDLE1BQU07QUFBQSxJQUFHO0FBQUEsSUFDckVDLFFBQVE7QUFBQSxNQUFFQyxXQUFXO0FBQUEsTUFBSUMsWUFBWTtBQUFBLE1BQUlDLFdBQVc7QUFBQSxNQUFJQyxXQUFXO0FBQUEsTUFBSUMsT0FBTztBQUFBLElBQUc7QUFBQSxJQUNqRkMsY0FBYztBQUFBLE1BQUVDLGFBQWE7QUFBQSxNQUFJQyxlQUFlO0FBQUEsTUFBSUMsZUFBZTtBQUFBLElBQUc7QUFBQSxJQUN0RUMsV0FBVztBQUFBLElBQ1hDLGdCQUFnQjtBQUFBLEVBQ2xCLENBQUM7QUFFRHJFLFlBQVUsTUFBTTtBQUNkLFFBQUlpQyxNQUFNO0FBQ1JRLGtCQUFZNkIsV0FBUztBQUFBLFFBQ25CLEdBQUdBO0FBQUFBLFFBQ0gsR0FBR3JDO0FBQUFBLFFBQ0hvQixjQUFjO0FBQUEsVUFDWkMsZ0JBQWdCckIsS0FBS29CLGNBQWNDLGtCQUFrQjtBQUFBLFVBQ3JEQyxNQUFNdEIsS0FBS29CLGNBQWNFLE1BQU1nQixTQUFTLEtBQUs7QUFBQSxVQUM3Q2YsVUFBVXZCLEtBQUtvQixjQUFjRyxVQUFVZSxTQUFTLEtBQUs7QUFBQSxVQUNyRGQsTUFBTXhCLEtBQUtvQixjQUFjSSxRQUFRO0FBQUEsUUFDbkM7QUFBQSxRQUNBQyxRQUFRO0FBQUEsVUFDTkMsV0FBVzFCLEtBQUt5QixRQUFRQyxhQUFhO0FBQUEsVUFDckNDLFlBQVkzQixLQUFLeUIsUUFBUUUsY0FBYztBQUFBLFVBQ3ZDQyxXQUFXNUIsS0FBS3lCLFFBQVFHLGFBQWE7QUFBQSxVQUNyQ0MsV0FBVzdCLEtBQUt5QixRQUFRSSxhQUFhO0FBQUEsVUFDckNDLE9BQU85QixLQUFLeUIsUUFBUUssU0FBUztBQUFBLFFBQy9CO0FBQUEsUUFDQUMsY0FBYztBQUFBLFVBQ1pDLGFBQWFoQyxLQUFLK0IsY0FBY0MsZUFBZTtBQUFBLFVBQy9DQyxlQUFlakMsS0FBSytCLGNBQWNFLGlCQUFpQjtBQUFBLFVBQ25EQyxlQUFlbEMsS0FBSytCLGNBQWNHLGlCQUFpQjtBQUFBLFFBQ3JEO0FBQUEsUUFDQWxCLGFBQWE7QUFBQSxVQUNYQyxRQUFRakIsS0FBS2dCLGFBQWFDLFVBQVU7QUFBQSxVQUNwQ0MsVUFBVWxCLEtBQUtnQixhQUFhRSxZQUFZO0FBQUEsVUFDeENDLFdBQVduQixLQUFLZ0IsYUFBYUcsYUFBYTtBQUFBLFFBQzVDO0FBQUEsUUFDQUwsZUFBZWQsS0FBS2MsaUJBQWlCO0FBQUEsUUFDckNzQixnQkFBZ0JwQyxLQUFLb0Msa0JBQWtCO0FBQUEsTUFDekMsRUFBRTtBQUFBLElBQ0o7QUFBQSxFQUNGLEdBQUcsQ0FBQ3BDLElBQUksQ0FBQztBQUdULFFBQU11QyxZQUFZO0FBQUEsSUFDaEJiLFdBQVcsQ0FBQyxjQUFjLGNBQWMsVUFBVSxRQUFRLEtBQUssT0FBTyxNQUFNLE1BQU0sUUFBUSxVQUFVLFNBQVMsT0FBTyxRQUFRLFFBQVEsS0FBSyxRQUFRO0FBQUEsSUFDakpDLFlBQVksQ0FBQyxTQUFTLFdBQVcsVUFBVSxXQUFXLFdBQVcsV0FBVyxjQUFjLFVBQVUsU0FBUyxlQUFlLFdBQVcsV0FBVyxpQkFBaUIsV0FBVyxjQUFjO0FBQUEsSUFDNUxDLFdBQVcsQ0FBQyxTQUFTLFNBQVMsVUFBVSxTQUFTLGNBQWMsU0FBUyxXQUFXLGdCQUFnQixVQUFVLFNBQVMsWUFBWSxTQUFTLFlBQVksYUFBYSxXQUFXO0FBQUEsSUFDL0tDLFdBQVcsQ0FBQyxXQUFXLFNBQVEsY0FBYyxVQUFVLFVBQVUsd0JBQXdCLFlBQVksU0FBUyxhQUFhLFlBQVksT0FBTztBQUFBLElBQzlJQyxPQUFPLENBQUMsT0FBTyxVQUFVLFVBQVUsVUFBVSxjQUFjLFdBQVcsUUFBUSxVQUFVLFNBQVMsWUFBWSxXQUFXLGlCQUFpQixXQUFXLFdBQVcsT0FBTztBQUFBLEVBQ3hLO0FBRUEsUUFBTVUsa0JBQWtCLENBQUMsYUFBYSxjQUFjLGFBQWEsYUFBYSxPQUFPO0FBQ3JGLFFBQU1MLFlBQVksQ0FBQyxXQUFXLG1CQUFtQixzQkFBc0IsU0FBUyxVQUFVLGdCQUFnQixtQkFBbUIsT0FBTyxjQUFjLG9CQUFvQixlQUFlO0FBQ3JMLFFBQU1NLGVBQWUsQ0FBQyxzQkFBc0IscUJBQXFCLHVCQUF1Qix3QkFBd0IsZUFBZSxrQkFBa0Isa0JBQWtCLG1CQUFtQixlQUFlLGlCQUFpQjtBQUN0TixRQUFNQyxPQUFPLENBQUMsVUFBVSxXQUFXLGFBQWEsWUFBWSxVQUFVLFlBQVksUUFBUTtBQUMxRixRQUFNQyxRQUFRLENBQUMsV0FBVyxhQUFhLFdBQVcsT0FBTztBQUV6RCxRQUFNLENBQUNDLGdCQUFnQkMsaUJBQWlCLElBQUkvRSxTQUFTLElBQUk7QUFDekQsUUFBTSxDQUFDZ0YsWUFBWUMsYUFBYSxJQUFJakYsU0FBUztBQUFBLElBQUVrRixVQUFVO0FBQUEsSUFBYUMsTUFBTTtBQUFBLEVBQUcsQ0FBQztBQUVoRixRQUFNQyxvQkFBb0JBLENBQUNDLE9BQU9DLFVBQVU7QUFDMUM1QyxnQkFBWTZCLFdBQVM7QUFBQSxNQUFFLEdBQUdBO0FBQUFBLE1BQU0sQ0FBQ2MsS0FBSyxHQUFHQztBQUFBQSxJQUFNLEVBQUU7QUFBQSxFQUNuRDtBQUVBLFFBQU1DLHFCQUFxQkEsQ0FBQ0MsUUFBUUgsT0FBT0MsVUFBVTtBQUNuRDVDLGdCQUFZNkIsV0FBUztBQUFBLE1BQ25CLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQ2lCLE1BQU0sR0FBRztBQUFBLFFBQUUsR0FBR2pCLEtBQUtpQixNQUFNO0FBQUEsUUFBRyxDQUFDSCxLQUFLLEdBQUdDO0FBQUFBLE1BQU07QUFBQSxJQUM5QyxFQUFFO0FBQUEsRUFDSjtBQUVBLFFBQU1HLG9CQUFvQkEsQ0FBQ0osT0FBT0MsVUFBVTtBQUMxQzVDLGdCQUFZNkIsVUFBUTtBQUNsQixZQUFNbUIsVUFBVW5CLEtBQUtjLEtBQUssS0FBSztBQUMvQixZQUFNTSxVQUFVRCxRQUFRRSxTQUFTTixLQUFLLElBQ2xDSSxRQUFRRyxPQUFPQyxPQUFLQSxNQUFNUixLQUFLLElBQy9CLENBQUMsR0FBR0ksU0FBU0osS0FBSztBQUN0QixhQUFPO0FBQUEsUUFBRSxHQUFHZjtBQUFBQSxRQUFNLENBQUNjLEtBQUssR0FBR007QUFBQUEsTUFBUTtBQUFBLElBQ3JDLENBQUM7QUFBQSxFQUNIO0FBRUEsUUFBTUksMkJBQTJCQSxDQUFDVixPQUFPQyxVQUFVO0FBQ2pENUMsZ0JBQVk2QixVQUFRO0FBQ2xCLFlBQU1tQixVQUFVbkIsS0FBS04sYUFBYW9CLEtBQUssS0FBSztBQUM1QyxZQUFNTSxVQUFVRCxRQUFRRSxTQUFTTixLQUFLLElBQ2xDSSxRQUFRRyxPQUFPQyxPQUFLQSxNQUFNUixLQUFLLElBQy9CLENBQUMsR0FBR0ksU0FBU0osS0FBSztBQUN0QixhQUFPO0FBQUEsUUFBRSxHQUFHZjtBQUFBQSxRQUFNTixjQUFjO0FBQUEsVUFBRSxHQUFHTSxLQUFLTjtBQUFBQSxVQUFjLENBQUNvQixLQUFLLEdBQUdNO0FBQUFBLFFBQVE7QUFBQSxNQUFFO0FBQUEsSUFDN0UsQ0FBQztBQUFBLEVBQ0g7QUFFQSxRQUFNSyxvQkFBb0JBLENBQUNDLEtBQUtDLFVBQVU7QUFDeEN4RCxnQkFBWTZCLFdBQVM7QUFBQSxNQUNuQixHQUFHQTtBQUFBQSxNQUNIWixRQUFRO0FBQUEsUUFBRSxHQUFHWSxLQUFLWjtBQUFBQSxRQUFRLENBQUNzQyxHQUFHLEdBQUcxQixLQUFLWixPQUFPc0MsR0FBRyxFQUFFSixPQUFPTSxPQUFLQSxNQUFNRCxLQUFLO0FBQUEsTUFBRTtBQUFBLElBQzdFLEVBQUU7QUFBQSxFQUNKO0FBRUEsUUFBTUUsZUFBZSxZQUFZO0FBQy9CLFFBQUk7QUFDRixZQUFNQyxNQUFNLE1BQU1DLE1BQU0sc0NBQXNDO0FBQUEsUUFDNURDLFFBQVE7QUFBQSxRQUNSQyxTQUFTO0FBQUEsVUFDUCxnQkFBZ0I7QUFBQSxVQUNoQixnQkFBZ0JyRTtBQUFBQSxRQUNsQjtBQUFBLFFBQ0FzRSxNQUFNQyxLQUFLQyxVQUFVbEUsUUFBUTtBQUFBLE1BQy9CLENBQUM7QUFFRCxVQUFJNEQsSUFBSU8sSUFBSTtBQUNWLGNBQU14RSxhQUFhO0FBQ25CSSx1QkFBZSxJQUFJO0FBQUEsTUFDckIsT0FBTztBQUNMLGNBQU1xRSxZQUFZLE1BQU1SLElBQUlTLEtBQUs7QUFDakNDLGNBQU1GLFVBQVVHLE9BQU8sd0JBQXdCO0FBQUEsTUFDakQ7QUFBQSxJQUNGLFNBQVNDLEtBQUs7QUFDWkYsWUFBTSx3QkFBd0I7QUFBQSxJQUNoQztBQUFBLEVBQ0Y7QUFFQSxRQUFNRyxpQkFBa0JDLFFBQU9wQyxrQkFBa0JELG1CQUFtQnFDLEtBQUssT0FBT0EsRUFBRTtBQUVsRixRQUFNO0FBQUEsSUFBRUMsWUFBWUM7QUFBQUEsRUFBYSxJQUFJaEgsNkJBQTZCb0MsUUFBUTtBQUUxRSxTQUNFLHVCQUFDLFNBQUksSUFBRyxxQkFBb0IsV0FBVSxlQUFjLE9BQU87QUFBQSxJQUFFNkUsU0FBUztBQUFBLElBQVNDLGVBQWU7QUFBQSxJQUFRQyxZQUFZO0FBQUEsRUFBVSxHQUUxSDtBQUFBLDJCQUFDLFNBQUksV0FBVSxZQUFXLE9BQU87QUFBQSxNQUFFQyxVQUFVO0FBQUEsTUFBVUMsUUFBUTtBQUFBLE1BQW9CQyxZQUFZO0FBQUEsSUFBUyxHQUN0RztBQUFBLDZCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLCtCQUFDLFFBQUcsT0FBTztBQUFBLFVBQUVMLFNBQVM7QUFBQSxVQUFRTSxZQUFZO0FBQUEsVUFBVUMsS0FBSztBQUFBLFFBQU8sR0FDOUQ7QUFBQSxpQ0FBQyxRQUFLLE1BQU0sSUFBSSxPQUFNLGNBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdDO0FBQUEsVUFBRztBQUFBLGFBRHJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsT0FBRSwyREFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThDO0FBQUEsV0FKaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsa0JBQWlCLE9BQU87QUFBQSxRQUFFUCxTQUFTO0FBQUEsUUFBUU0sWUFBWTtBQUFBLFFBQVVDLEtBQUs7QUFBQSxNQUFPLEdBQzFGO0FBQUEsK0JBQUMsWUFBTyxXQUFVLDBCQUF5QixTQUFTLE1BQU01RixTQUFTLFVBQVUsR0FBRyx1QkFBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1RjtBQUFBLFFBQ3ZGLHVCQUFDLFlBQU8sV0FBVSwwQkFBeUIsU0FBU21FLGNBQ2xEO0FBQUEsaUNBQUMsUUFBSyxNQUFNLE1BQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZTtBQUFBLFVBQUc7QUFBQSxhQURwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLFNBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWFBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsc0JBQ2IsaUNBQUMsU0FBSSxXQUFVLGdCQUViO0FBQUEsNkJBQUMsV0FBTSxXQUFVLGNBQ2Y7QUFBQSwrQkFBQyxTQUFJLFdBQVUsY0FBYSxPQUFPO0FBQUEsVUFBRTBCLGVBQWU7QUFBQSxVQUFRQyxjQUFjO0FBQUEsVUFBUUMsY0FBYztBQUFBLFVBQTJCVCxlQUFlO0FBQUEsUUFBUyxHQUNoSjtBQUFBLGlDQUFDLFNBQUksV0FBVSxVQUFTLE9BQU87QUFBQSxZQUFFVSxVQUFVO0FBQUEsVUFBUyxHQUFJWjtBQUFBQTtBQUFBQSxZQUFhO0FBQUEsZUFBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0U7QUFBQSxVQUN0RSx1QkFBQyxTQUFJLE9BQU87QUFBQSxZQUFFWSxVQUFVO0FBQUEsWUFBVUMsT0FBTztBQUFBLFVBQWEsR0FBRyw0QkFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUU7QUFBQSxhQUZ4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVyxjQUFjN0Ysa0JBQWtCLGFBQWEsV0FBVyxFQUFFLElBQUksU0FBUyxNQUFNQyxpQkFBaUIsVUFBVSxHQUN0SDtBQUFBLGlDQUFDLFFBQUssV0FBVSxnQkFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEI7QUFBQSxVQUFHO0FBQUEsYUFEakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVcsY0FBY0Qsa0JBQWtCLGFBQWEsV0FBVyxFQUFFLElBQUksU0FBUyxNQUFNQyxpQkFBaUIsVUFBVSxHQUN0SDtBQUFBLGlDQUFDLFlBQVMsV0FBVSxnQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0M7QUFBQSxVQUFHO0FBQUEsYUFEckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVcsY0FBY0Qsa0JBQWtCLFdBQVcsV0FBVyxFQUFFLElBQUksU0FBUyxNQUFNQyxpQkFBaUIsUUFBUSxHQUNsSDtBQUFBLGlDQUFDLFNBQU0sV0FBVSxnQkFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkI7QUFBQSxVQUFHO0FBQUEsYUFEbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVcsY0FBY0Qsa0JBQWtCLFdBQVcsV0FBVyxFQUFFLElBQUksU0FBUyxNQUFNQyxpQkFBaUIsUUFBUSxHQUNsSDtBQUFBLGlDQUFDLFFBQUssV0FBVSxnQkFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEI7QUFBQSxVQUFHO0FBQUEsYUFEakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVcsY0FBY0Qsa0JBQWtCLGlCQUFpQixXQUFXLEVBQUUsSUFBSSxTQUFTLE1BQU1DLGlCQUFpQixjQUFjLEdBQzlIO0FBQUEsaUNBQUMsWUFBUyxXQUFVLGdCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnQztBQUFBLFVBQUc7QUFBQSxhQURyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVyxjQUFjRCxrQkFBa0IsY0FBYyxXQUFXLEVBQUUsSUFBSSxTQUFTLE1BQU1DLGlCQUFpQixXQUFXLEdBQ3hIO0FBQUEsaUNBQUMsU0FBTSxXQUFVLGdCQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2QjtBQUFBLFVBQUc7QUFBQSxhQURsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVyxjQUFjRCxrQkFBa0IsVUFBVSxXQUFXLEVBQUUsSUFBSSxTQUFTLE1BQU1DLGlCQUFpQixPQUFPLEdBQ2hIO0FBQUEsaUNBQUMsYUFBVSxXQUFVLGdCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFpQztBQUFBLFVBQUc7QUFBQSxhQUR0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsaUNBQUMsU0FBTSxNQUFNLElBQUksT0FBTztBQUFBLFlBQUU0RixPQUFPO0FBQUEsWUFBWUgsY0FBYztBQUFBLFVBQVMsS0FBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0U7QUFBQSxVQUN0RSx1QkFBQyxTQUFJLE9BQU87QUFBQSxZQUFFRSxVQUFVO0FBQUEsWUFBV0UsWUFBWTtBQUFBLFlBQUtELE9BQU87QUFBQSxVQUFXLEdBQUcsdUJBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdGO0FBQUEsVUFDaEYsdUJBQUMsU0FBSSxPQUFPO0FBQUEsWUFBRUQsVUFBVTtBQUFBLFlBQVdDLE9BQU87QUFBQSxZQUFjRSxXQUFXO0FBQUEsVUFBTSxHQUFHLG9FQUE1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnSTtBQUFBLGFBSGxJO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQTtBQUFBLFdBaENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFpQ0E7QUFBQSxNQUdBLHVCQUFDLFVBQUssV0FBVSxjQUViL0Y7QUFBQUEsMEJBQWtCLGNBQ2pCLHVCQUFDLFNBQUksV0FBVSxtQkFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSxzQkFBcUIsaUNBQUMsUUFBSyxNQUFNLE1BQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZSxLQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzRDtBQUFBLFlBQ3RELHVCQUFDLFFBQUcsb0NBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0I7QUFBQSxlQUYxQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSxtQ0FBQyxTQUFJLE9BQU87QUFBQSxjQUFFZ0csVUFBVTtBQUFBLGNBQVlmLFNBQVM7QUFBQSxZQUFlLEdBQzFEO0FBQUEscUNBQUMsU0FDQyxLQUFLN0UsU0FBU1Esa0JBQWtCLHVDQUF1Q1IsU0FBU0UsWUFBWSxTQUM1RixLQUFJLFVBQ0osV0FBVSxrQkFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUcwQjtBQUFBLGNBRTFCLHVCQUFDLFdBQU0sU0FBUSxhQUFZLFdBQVUsaUJBQ25DLGlDQUFDLFFBQUssTUFBTSxNQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWUsS0FEakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsV0FBTSxJQUFHLGFBQVksTUFBSyxRQUFPLFFBQU0sTUFBQyxRQUFPLFdBQVUsVUFBVSxPQUFPMkYsTUFBTTtBQUMvRSxzQkFBTUMsT0FBT0QsRUFBRUUsT0FBT0MsTUFBTSxDQUFDO0FBQzdCLG9CQUFJLENBQUNGO0FBQU07QUFDWCxzQkFBTUcsS0FBSyxJQUFJQyxTQUFTO0FBQ3hCRCxtQkFBR0UsT0FBTyxrQkFBa0JMLElBQUk7QUFDaEMsb0JBQUk7QUFDRix3QkFBTWxDLE1BQU0sTUFBTUMsTUFBTSw0Q0FBNEM7QUFBQSxvQkFDbEVDLFFBQVE7QUFBQSxvQkFDUkMsU0FBUztBQUFBLHNCQUFFLGdCQUFnQnJFO0FBQUFBLG9CQUFNO0FBQUEsb0JBQ2pDc0UsTUFBTWlDO0FBQUFBLGtCQUNSLENBQUM7QUFDRCx3QkFBTUcsT0FBTyxNQUFNeEMsSUFBSVMsS0FBSztBQUM1QixzQkFBSVQsSUFBSU8sSUFBSTtBQUNWeEIsc0NBQWtCLGtCQUFrQnlELEtBQUtDLEdBQUc7QUFDNUMsMEJBQU0xRyxhQUFhO0FBQUEsa0JBQ3JCLE9BQU87QUFBRTJFLDBCQUFNLG9CQUFvQjhCLEtBQUtFLE9BQU87QUFBQSxrQkFBRztBQUFBLGdCQUNwRCxTQUFTOUIsS0FBSztBQUFFRix3QkFBTSx1QkFBdUI7QUFBQSxnQkFBRztBQUFBLGNBQ2xELEtBakJBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBaUJFO0FBQUEsaUJBMUJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMkJBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsa0JBQ1o7QUFBQSxxQ0FBQyxRQUFJdEUsbUJBQVNFLFlBQVksMEJBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWlEO0FBQUEsY0FDakQsdUJBQUMsT0FBR0YsbUJBQVNHLFNBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbUI7QUFBQSxpQkFGdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLGVBaENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBaUNBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsWUFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEscUNBQUMsV0FBTSxXQUFVLGNBQWEseUJBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXVDO0FBQUEsY0FDdkMsdUJBQUMsV0FBTSxNQUFLLFFBQU8sV0FBVSxpQkFBZ0IsT0FBT0gsU0FBU0UsVUFBVSxVQUFVMkYsT0FBS2xELGtCQUFrQixZQUFZa0QsRUFBRUUsT0FBT2xELEtBQUssS0FBbEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBb0k7QUFBQSxpQkFGdEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsY0FBYSwwQkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBd0M7QUFBQSxjQUN4Qyx1QkFBQyxTQUFJLFdBQVUsMEJBQXlCO0FBQUEsdUNBQUMsUUFBSyxNQUFNLE1BQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZTtBQUFBLGdCQUFHO0FBQUEsZ0JBQUU3QyxTQUFTSTtBQUFBQSxtQkFBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBK0U7QUFBQSxpQkFGakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLGVBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFTQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsY0FBYSxnQ0FBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEM7QUFBQSxZQUM5Qyx1QkFBQyxjQUNDLFdBQVUsaUJBQ1YsTUFBSyxLQUNMLGFBQVkseURBQ1osT0FBT0osU0FBU00sT0FBTyxJQUN2QixVQUFVdUYsT0FBS2xELGtCQUFrQixPQUFPa0QsRUFBRUUsT0FBT2xELEtBQUssS0FMeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFNQztBQUFBLGVBUkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFTQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsY0FBYTtBQUFBLHFDQUFDLFNBQU0sTUFBTSxNQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdCO0FBQUEsY0FBRztBQUFBLGlCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnRTtBQUFBLFlBQ2hFLHVCQUFDLFdBQU0sTUFBSyxRQUFPLFdBQVUsaUJBQWdCLGFBQVksbUJBQWtCLE9BQU83QyxTQUFTTyxlQUFlLFVBQVVzRixPQUFLbEQsa0JBQWtCLGlCQUFpQmtELEVBQUVFLE9BQU9sRCxLQUFLLEtBQTFLO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRLO0FBQUEsZUFGOUs7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLGFBbEVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFtRUE7QUFBQSxRQUdEakQsa0JBQWtCLGNBQ2pCLHVCQUFDLFNBQUksV0FBVSxtQkFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSxzQkFBcUIsaUNBQUMsWUFBUyxNQUFNLE1BQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1CLEtBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBEO0FBQUEsWUFDMUQsdUJBQUMsUUFBRyxtQ0FBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1QjtBQUFBLGVBRnpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGNBQWE7QUFBQTtBQUFBLGNBQVcsdUJBQUMsVUFBSyxPQUFPO0FBQUEsZ0JBQUU2RixPQUFPO0FBQUEsZ0JBQWNDLFlBQVk7QUFBQSxnQkFBS0YsVUFBVTtBQUFBLGNBQVUsR0FBRyx5Q0FBNUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUc7QUFBQSxpQkFBOUk7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUo7QUFBQSxZQUNySix1QkFBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQSxxQ0FBQyxZQUFTLE1BQU0sTUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbUI7QUFBQSxjQUFHO0FBQUEsY0FBRXhGLFNBQVNLLGNBQWM7QUFBQSxpQkFEakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLFlBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLHFDQUFDLFdBQU0sV0FBVSxjQUFhLDZCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEyQztBQUFBLGNBQzNDLHVCQUFDLFlBQU8sV0FBVSxpQkFBZ0IsT0FBT0wsU0FBU2EsYUFBYUUsTUFBTSxVQUFVOEUsT0FBSy9DLG1CQUFtQixnQkFBZ0IsUUFBUStDLEVBQUVFLE9BQU9sRCxLQUFLLEdBQzNJO0FBQUEsdUNBQUMsWUFBTyxPQUFNLElBQUcsMkJBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTRCO0FBQUEsZ0JBQzNCLENBQUMsS0FBSyxLQUFLLEtBQUssR0FBRyxFQUFFMEQsSUFBSUMsT0FBSyx1QkFBQyxZQUFlLE9BQU9BLEdBQUc7QUFBQTtBQUFBLGtCQUFNQTtBQUFBQSxxQkFBbkJBLEdBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBa0MsQ0FBUztBQUFBLG1CQUY1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsaUJBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFNQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsY0FBYSx3QkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBc0M7QUFBQSxjQUN0Qyx1QkFBQyxZQUFPLFdBQVUsaUJBQWdCLE9BQU94RyxTQUFTYSxhQUFhRyxVQUFVLFVBQVU2RSxPQUFLL0MsbUJBQW1CLGdCQUFnQixZQUFZK0MsRUFBRUUsT0FBT2xELEtBQUssR0FDbko7QUFBQSx1Q0FBQyxZQUFPLE9BQU0sSUFBRywrQkFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0M7QUFBQSxnQkFDL0IsQ0FBQyxLQUFLLEdBQUcsRUFBRTBELElBQUk3QyxPQUFLLHVCQUFDLFlBQWUsT0FBT0EsR0FBRztBQUFBO0FBQUEsa0JBQVVBO0FBQUFBLHFCQUF2QkEsR0FBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFzQyxDQUFTO0FBQUEsbUJBRnRFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxpQkFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU1BO0FBQUEsZUFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWVBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsWUFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEscUNBQUMsV0FBTSxXQUFVLGNBQWE7QUFBQTtBQUFBLGdCQUFlLHVCQUFDLFVBQUssT0FBTztBQUFBLGtCQUFFK0IsT0FBTztBQUFBLGtCQUFjQyxZQUFZO0FBQUEsa0JBQUtGLFVBQVU7QUFBQSxnQkFBVSxHQUFHLHlDQUE1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFxRztBQUFBLG1CQUFsSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5SjtBQUFBLGNBQ3pKLHVCQUFDLFNBQUksV0FBVSwwQkFDWjtBQUFBLHVDQUFDLFNBQU0sTUFBTSxNQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdCO0FBQUEsZ0JBQUc7QUFBQSxnQkFBRXhGLFNBQVNhLGFBQWFDLGtCQUFrQjtBQUFBLG1CQURoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsY0FBYSw0QkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMEM7QUFBQSxjQUMxQyx1QkFBQyxXQUFNLE1BQUssVUFBUyxXQUFVLGlCQUFnQixPQUFPZCxTQUFTYSxhQUFhSSxNQUFNLFVBQVU0RSxPQUFLL0MsbUJBQW1CLGdCQUFnQixRQUFRK0MsRUFBRUUsT0FBT2xELEtBQUssR0FBRyxLQUFJLEtBQUksS0FBSSxLQUFJLE1BQUssVUFBbEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBd0w7QUFBQSxpQkFGMUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLGVBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFXQTtBQUFBLGFBekNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEwQ0E7QUFBQSxRQUdEakQsa0JBQWtCLFlBQ2pCLHVCQUFDLFNBQUksV0FBVSxtQkFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSxzQkFBcUIsaUNBQUMsU0FBTSxNQUFNLE1BQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0IsS0FBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUQ7QUFBQSxZQUN2RCx1QkFBQyxRQUFHLGtDQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNCO0FBQUEsZUFGeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsY0FBYTtBQUFBLHFDQUFDLFVBQU8sTUFBTSxNQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWlCO0FBQUEsY0FBRztBQUFBLGlCQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpRTtBQUFBLFlBQ2pFLHVCQUFDLFdBQU0sTUFBSyxPQUFNLFdBQVUsaUJBQWdCLGFBQVksK0JBQThCLE9BQU9JLFNBQVNTLGFBQWFDLFVBQVUsSUFBSSxVQUFVbUYsT0FBSy9DLG1CQUFtQixlQUFlLFVBQVUrQyxFQUFFRSxPQUFPbEQsS0FBSyxLQUExTTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0TTtBQUFBLGVBRjlNO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGNBQWE7QUFBQSxxQ0FBQyxZQUFTLE1BQU0sTUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbUI7QUFBQSxjQUFHO0FBQUEsaUJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFFO0FBQUEsWUFDckUsdUJBQUMsV0FBTSxNQUFLLE9BQU0sV0FBVSxpQkFBZ0IsYUFBWSxvQ0FBbUMsT0FBTzdDLFNBQVNTLGFBQWFFLFlBQVksSUFBSSxVQUFVa0YsT0FBSy9DLG1CQUFtQixlQUFlLFlBQVkrQyxFQUFFRSxPQUFPbEQsS0FBSyxLQUFuTjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxTjtBQUFBLGVBRnZOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGNBQWE7QUFBQSxxQ0FBQyxZQUFTLE1BQU0sTUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbUI7QUFBQSxjQUFHO0FBQUEsaUJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVFO0FBQUEsWUFDdkUsdUJBQUMsV0FBTSxNQUFLLE9BQU0sV0FBVSxpQkFBZ0IsYUFBWSwyQkFBMEIsT0FBTzdDLFNBQVNTLGFBQWFHLGFBQWEsSUFBSSxVQUFVaUYsT0FBSy9DLG1CQUFtQixlQUFlLGFBQWErQyxFQUFFRSxPQUFPbEQsS0FBSyxLQUE1TTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4TTtBQUFBLGVBRmhOO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBb0JBO0FBQUEsUUFHRGpELGtCQUFrQixZQUNqQix1QkFBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsc0JBQXFCLGlDQUFDLFFBQUssTUFBTSxNQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWUsS0FBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0Q7QUFBQSxZQUN0RCx1QkFBQyxRQUFHLDZCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlCO0FBQUEsZUFGbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLHNCQUNacUMsMEJBQWdCc0UsSUFBSS9DLFNBQ25CLHVCQUFDLFNBQWMsV0FBVSxpQkFDdkI7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsbUJBQW1CQSxpQkFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0M7QUFBQSxZQUN0Qyx1QkFBQyxTQUFJLFdBQVUsY0FDWnhCLG9CQUFVd0IsR0FBRyxFQUFFK0MsSUFBSTlDLFdBQVM7QUFDM0Isb0JBQU1nRCxhQUFhekcsU0FBU2tCLE9BQU9zQyxHQUFHLEdBQUdMLFNBQVNNLEtBQUs7QUFDdkQscUJBQ0UsdUJBQUMsU0FFQyxXQUFXLHFCQUFxQmdELGFBQWEsV0FBVyxFQUFFLElBQzFELFNBQVMsTUFBTUEsYUFBYWxELGtCQUFrQkMsS0FBS0MsS0FBSyxJQUFJeEQsWUFBWTZCLFdBQVM7QUFBQSxnQkFBRSxHQUFHQTtBQUFBQSxnQkFBTVosUUFBUTtBQUFBLGtCQUFFLEdBQUdZLEtBQUtaO0FBQUFBLGtCQUFRLENBQUNzQyxHQUFHLEdBQUcsQ0FBQyxHQUFHMUIsS0FBS1osT0FBT3NDLEdBQUcsR0FBR0MsS0FBSztBQUFBLGdCQUFFO0FBQUEsY0FBRSxFQUFFLEdBRTdKQTtBQUFBQTtBQUFBQSxnQkFBTTtBQUFBLGdCQUFFZ0QsYUFBYSx1QkFBQyxnQkFBYSxNQUFNLE1BQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXVCLElBQU0sdUJBQUMsUUFBSyxNQUFNLE1BQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZTtBQUFBLG1CQUo3RGhELE9BRFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFNQTtBQUFBLFlBRUosQ0FBQyxLQVpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBYUE7QUFBQSxZQUdBLHVCQUFDLFNBQUksV0FBVSxxQkFDWHpELG1CQUFTa0IsT0FBT3NDLEdBQUcsR0FBR0osT0FBT00sT0FBSyxDQUFDMUIsVUFBVXdCLEdBQUcsRUFBRUwsU0FBU08sQ0FBQyxDQUFDLEVBQUU2QyxJQUFJN0MsT0FDbEUsdUJBQUMsVUFBYSxXQUFVLHVCQUFzQixTQUFTLE1BQU1ILGtCQUFrQkMsS0FBS0UsQ0FBQyxHQUNsRkE7QUFBQUE7QUFBQUEsY0FBRTtBQUFBLGNBQUMsdUJBQUMsS0FBRSxNQUFNLE1BQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBWTtBQUFBLGlCQURQQSxHQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUEsQ0FDRCxLQUxKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBTUE7QUFBQSxlQXhCUUYsS0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXlCQSxDQUNELEtBNUJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBNkJBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsc0JBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsY0FBYSxxQ0FBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUQ7QUFBQSxZQUNuRCx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLHFDQUFDLFlBQU8sT0FBT2pCLFdBQVdFLFVBQVUsVUFBVW9ELE9BQUtyRCxjQUFjO0FBQUEsZ0JBQUMsR0FBR0Q7QUFBQUEsZ0JBQVlFLFVBQVVvRCxFQUFFRSxPQUFPbEQ7QUFBQUEsY0FBSyxDQUFDLEdBQ3ZHWiwwQkFBZ0JzRSxJQUFJL0MsU0FBTyx1QkFBQyxZQUFpQixPQUFPQSxLQUFNQSxpQkFBbEJBLEtBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbUMsQ0FBUyxLQUQxRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxXQUNDLE1BQUssUUFDTCxhQUFZLHVCQUNaLE9BQU9qQixXQUFXRyxNQUNsQixVQUFVbUQsT0FBS3JELGNBQWM7QUFBQSxnQkFBQyxHQUFHRDtBQUFBQSxnQkFBWUcsTUFBTW1ELEVBQUVFLE9BQU9sRDtBQUFBQSxjQUFLLENBQUMsR0FDbEUsV0FBV2dELE9BQUs7QUFDZCxvQkFBSUEsRUFBRWEsUUFBUSxTQUFTO0FBQ3JCYixvQkFBRWMsZUFBZTtBQUNqQix3QkFBTUMsTUFBTXJFLFdBQVdHLEtBQUttRSxLQUFLO0FBQ2pDLHNCQUFJRCxLQUFLO0FBQ1AsMEJBQU1wRCxNQUFNakIsV0FBV0U7QUFDdkIsd0JBQUksQ0FBQ3pDLFNBQVNrQixPQUFPc0MsR0FBRyxFQUFFTCxTQUFTeUQsR0FBRyxHQUFHO0FBQ3ZDM0csa0NBQVk2QixXQUFTO0FBQUEsd0JBQUUsR0FBR0E7QUFBQUEsd0JBQU1aLFFBQVE7QUFBQSwwQkFBRSxHQUFHWSxLQUFLWjtBQUFBQSwwQkFBUSxDQUFDc0MsR0FBRyxHQUFHLENBQUMsR0FBSTFCLEtBQUtaLE9BQU9zQyxHQUFHLEtBQUssSUFBS29ELEdBQUc7QUFBQSx3QkFBRTtBQUFBLHNCQUFFLEVBQUU7QUFBQSxvQkFDMUc7QUFDQXBFLGtDQUFjO0FBQUEsc0JBQUMsR0FBR0Q7QUFBQUEsc0JBQVlHLE1BQU07QUFBQSxvQkFBRSxDQUFDO0FBQUEsa0JBQ3pDO0FBQUEsZ0JBQ0Y7QUFBQSxjQUNGLEtBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBaUJJO0FBQUEsY0FFSix1QkFBQyxZQUFPLFdBQVUsbUJBQWtCLFNBQVMsTUFBTTtBQUNqRCxzQkFBTWtFLE1BQU1yRSxXQUFXRyxLQUFLbUUsS0FBSztBQUNqQyxvQkFBSUQsS0FBSztBQUNOLHdCQUFNcEQsTUFBTWpCLFdBQVdFO0FBQ3ZCLHNCQUFJLENBQUN6QyxTQUFTa0IsT0FBT3NDLEdBQUcsRUFBRUwsU0FBU3lELEdBQUcsR0FBRztBQUN2QzNHLGdDQUFZNkIsV0FBUztBQUFBLHNCQUFFLEdBQUdBO0FBQUFBLHNCQUFNWixRQUFRO0FBQUEsd0JBQUUsR0FBR1ksS0FBS1o7QUFBQUEsd0JBQVEsQ0FBQ3NDLEdBQUcsR0FBRyxDQUFDLEdBQUkxQixLQUFLWixPQUFPc0MsR0FBRyxLQUFLLElBQUtvRCxHQUFHO0FBQUEsc0JBQUU7QUFBQSxvQkFBRSxFQUFFO0FBQUEsa0JBQzFHO0FBQ0FwRSxnQ0FBYztBQUFBLG9CQUFDLEdBQUdEO0FBQUFBLG9CQUFZRyxNQUFNO0FBQUEsa0JBQUUsQ0FBQztBQUFBLGdCQUMxQztBQUFBLGNBQ0YsR0FBRyxpQ0FBQyxRQUFLLE1BQU0sTUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFlLEtBVGxCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBU3FCO0FBQUEsaUJBaEN2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWlDQTtBQUFBLGVBbkNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBb0NBO0FBQUEsYUF6RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTBFQTtBQUFBLFFBR0Q5QyxrQkFBa0IsZUFDakIsdUJBQUMsU0FBSSxXQUFVLG1CQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLHNCQUFxQixpQ0FBQyxTQUFNLE1BQU0sTUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnQixLQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1RDtBQUFBLFlBQ3ZELHVCQUFDLFFBQUcsaUNBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUI7QUFBQSxlQUZ2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsd0JBQ2I7QUFBQSxtQ0FBQyxTQUFNLE1BQU0sSUFBSSxPQUFNLGNBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlDO0FBQUEsWUFDakMsdUJBQUMsU0FDQztBQUFBLHFDQUFDLFFBQUcsd0NBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNEI7QUFBQSxjQUM1Qix1QkFBQyxPQUFFLG1GQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXNFO0FBQUEsaUJBRnhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxlQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTUE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSwyQkFDWmdDLG9CQUFVMkUsSUFBSU8sWUFBVTtBQUN2QixrQkFBTUwsYUFBYXpHLFNBQVM0QixVQUFVdUIsU0FBUzJELE1BQU07QUFDckQsbUJBQ0UsdUJBQUMsU0FFQyxXQUFXLGlCQUFpQkwsYUFBYSxXQUFXLEVBQUUsSUFDdEQsU0FBUyxNQUFNekQsa0JBQWtCLGFBQWE4RCxNQUFNLEdBRW5ETDtBQUFBQSwyQkFBYSx1QkFBQyxnQkFBYSxNQUFNLE1BQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXVCLElBQU0sdUJBQUMsUUFBSyxNQUFNLE1BQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZTtBQUFBLGNBQzFELHVCQUFDLFVBQU1LLG9CQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWM7QUFBQSxpQkFMVEEsUUFEUDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU9BO0FBQUEsVUFFSixDQUFDLEtBYkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFjQTtBQUFBLGFBNUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE2QkE7QUFBQSxRQUdEbEgsa0JBQWtCLGtCQUNqQix1QkFBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsc0JBQXFCLGlDQUFDLFlBQVMsTUFBTSxNQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtQixLQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwRDtBQUFBLFlBQzFELHVCQUFDLFFBQUcsbUNBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUI7QUFBQSxlQUZ6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsY0FBYTtBQUFBO0FBQUEsY0FBMEIsdUJBQUMsWUFBUUk7QUFBQUEseUJBQVN3QixhQUFhQztBQUFBQSxnQkFBWTtBQUFBLG1CQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE0QztBQUFBLGlCQUFwRztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2RztBQUFBLFlBQzdHLHVCQUFDLFdBQU0sTUFBSyxTQUFRLEtBQUksS0FBSSxLQUFJLE1BQUssT0FBT3pCLFNBQVN3QixhQUFhQyxlQUFlLElBQUksVUFBVW9FLE9BQUsvQyxtQkFBbUIsZ0JBQWdCLGVBQWUrQyxFQUFFRSxPQUFPbEQsS0FBSyxLQUFwSztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzSztBQUFBLGVBRnhLO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGNBQWEsNEJBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBDO0FBQUEsWUFDMUMsdUJBQUMsU0FBSSxXQUFVLFlBQ1pWLGVBQUtvRSxJQUFJUSxPQUNSLHVCQUFDLFNBQVksV0FBVyxXQUFXL0csU0FBU3dCLGFBQWFFLGNBQWN5QixTQUFTNEQsQ0FBQyxJQUFJLFdBQVcsRUFBRSxJQUFJLFNBQVMsTUFBTXpELHlCQUF5QixpQkFBaUJ5RCxDQUFDLEdBQzdKQSxZQUFFQyxVQUFVLEdBQUUsQ0FBQyxLQURSRCxHQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUEsQ0FDRCxLQUxIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBTUE7QUFBQSxlQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBU0E7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGNBQWEscUNBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW1EO0FBQUEsWUFDbkQsdUJBQUMsU0FBSSxXQUFVLGFBQ1ozRSxnQkFBTW1FLElBQUlVLE9BQ1QsdUJBQUMsU0FBWSxXQUFXLFlBQVlqSCxTQUFTd0IsYUFBYUcsY0FBY3dCLFNBQVM4RCxDQUFDLElBQUksV0FBVyxFQUFFLElBQUksU0FBUyxNQUFNM0QseUJBQXlCLGlCQUFpQjJELENBQUMsR0FDOUpBLGVBRE9BLEdBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQSxDQUNELEtBTEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFNQTtBQUFBLGVBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFTQTtBQUFBLGFBL0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFnQ0E7QUFBQSxRQUdEckgsa0JBQWtCLFdBQ2pCLHVCQUFDLFNBQUksV0FBVSxtQkFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSxzQkFBcUIsaUNBQUMsYUFBVSxNQUFNLE1BQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9CLEtBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJEO0FBQUEsWUFDM0QsdUJBQUMsUUFBRyx1Q0FBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyQjtBQUFBLGVBRjdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSx1QkFDWnNDLHVCQUFhcUUsSUFBSVcsVUFBUTtBQUN4QixrQkFBTVQsYUFBYXpHLFNBQVM2QixlQUFlc0IsU0FBUytELElBQUk7QUFDeEQsbUJBQ0UsdUJBQUMsU0FFQyxXQUFXLG9CQUFvQlQsYUFBYSxXQUFXLEVBQUUsSUFDekQsU0FBUyxNQUFNekQsa0JBQWtCLGtCQUFrQmtFLElBQUksR0FFdkQ7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsY0FBY1QsdUJBQWEsdUJBQUMsZ0JBQWEsTUFBTSxNQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF1QixJQUFNLHVCQUFDLFNBQUksV0FBVSxTQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFCLEtBQTVGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1HO0FBQUEsY0FDbkcsdUJBQUMsVUFBTVMsa0JBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBWTtBQUFBLGlCQUxQQSxNQURQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBT0E7QUFBQSxVQUVKLENBQUMsS0FiSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWNBO0FBQUEsYUFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXFCQTtBQUFBLFdBeFRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEyVEE7QUFBQSxTQWpXRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBa1dBLEtBbldGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvV0E7QUFBQSxJQUVDcEgsZUFDQyx1QkFBQyxTQUFJLFdBQVUseUJBQ2IsaUNBQUMsU0FBSSxXQUFVLHNCQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLHVCQUNiLGlDQUFDLGdCQUFhLE1BQU0sSUFBSSxPQUFNLGFBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUMsS0FEekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxRQUFHLGdDQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0I7QUFBQSxNQUNwQix1QkFBQyxPQUFFLHlGQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEU7QUFBQSxNQUM1RSx1QkFBQyxZQUFPLFdBQVUsd0NBQXVDLFNBQVMsTUFBTU4sU0FBUyxVQUFVLEdBQUcsK0JBQTlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNBLEtBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVdBO0FBQUEsT0FuWUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXFZQTtBQUVKO0FBQUVELEdBbmhCSUQsYUFBVztBQUFBLFVBQ0U1QixhQUNxQkMsT0FBTztBQUFBO0FBQUF3SixLQUZ6QzdIO0FBcWhCTixlQUFlQTtBQUFZLElBQUE2SDtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsInVzZU1lbW8iLCJ1c2VOYXZpZ2F0ZSIsInVzZUF1dGgiLCJjYWxjdWxhdGVQcm9maWxlQ29tcGxldGVuZXNzIiwiVXNlciIsIk1haWwiLCJCb29rT3BlbiIsIkJyaWVmY2FzZSIsIkNvZGUiLCJHbG9iZSIsIkNhbGVuZGFyIiwiQ2xvY2siLCJMaW5rIiwiTGlua0ljb24iLCJMb2dPdXQiLCJTYXZlIiwiWCIsIlBob25lIiwiR2l0aHViIiwiTGlua2VkaW4iLCJDaGVja0NpcmNsZTIiLCJBbGVydENpcmNsZSIsIkluZm8iLCJIYXNoIiwiQ2hldnJvblJpZ2h0IiwiQXdhcmQiLCJCcmFpbiIsIlBsdXMiLCJNb2RhbCIsIkVkaXRQcm9maWxlIiwiX3MiLCJuYXZpZ2F0ZSIsInVzZXIiLCJ0b2tlbiIsImZldGNoUHJvZmlsZSIsImFjdGl2ZVNlZ21lbnQiLCJzZXRBY3RpdmVTZWdtZW50Iiwic2hvd1N1Y2Nlc3MiLCJzZXRTaG93U3VjY2VzcyIsImZvcm1EYXRhIiwic2V0Rm9ybURhdGEiLCJmdWxsTmFtZSIsImVtYWlsIiwic3R1ZGVudElkIiwiZGVwYXJ0bWVudCIsImJpbyIsImNvbnRhY3ROdW1iZXIiLCJwcm9maWxlUGljdHVyZSIsInNvY2lhbExpbmtzIiwiZ2l0aHViIiwibGlua2VkaW4iLCJwb3J0Zm9saW8iLCJhY2FkZW1pY0luZm8iLCJzcGVjaWFsaXphdGlvbiIsInllYXIiLCJzZW1lc3RlciIsImNncGEiLCJza2lsbHMiLCJsYW5ndWFnZXMiLCJmcmFtZXdvcmtzIiwibGlicmFyaWVzIiwiZGF0YWJhc2VzIiwidG9vbHMiLCJhdmFpbGFiaWxpdHkiLCJ3ZWVrbHlIb3VycyIsInByZWZlcnJlZERheXMiLCJwcmVmZXJyZWRUaW1lIiwiaW50ZXJlc3RzIiwicHJlZmVycmVkUm9sZXMiLCJwcmV2IiwidG9TdHJpbmciLCJza2lsbERhdGEiLCJza2lsbENhdGVnb3JpZXMiLCJyb2xlc09wdGlvbnMiLCJkYXlzIiwidGltZXMiLCJhY3RpdmVEcm9wZG93biIsInNldEFjdGl2ZURyb3Bkb3duIiwic2tpbGxJbnB1dCIsInNldFNraWxsSW5wdXQiLCJjYXRlZ29yeSIsInRleHQiLCJoYW5kbGVJbnB1dENoYW5nZSIsImZpZWxkIiwidmFsdWUiLCJoYW5kbGVOZXN0ZWRDaGFuZ2UiLCJwYXJlbnQiLCJoYW5kbGVNdWx0aVNlbGVjdCIsImN1cnJlbnQiLCJ1cGRhdGVkIiwiaW5jbHVkZXMiLCJmaWx0ZXIiLCJpIiwiaGFuZGxlQXZhaWxhYmlsaXR5U2VsZWN0IiwiaGFuZGxlUmVtb3ZlU2tpbGwiLCJjYXQiLCJza2lsbCIsInMiLCJoYW5kbGVTdWJtaXQiLCJyZXMiLCJmZXRjaCIsIm1ldGhvZCIsImhlYWRlcnMiLCJib2R5IiwiSlNPTiIsInN0cmluZ2lmeSIsIm9rIiwiZXJyb3JEYXRhIiwianNvbiIsImFsZXJ0IiwibXNnIiwiZXJyIiwidG9nZ2xlRHJvcGRvd24iLCJpZCIsInBlcmNlbnRhZ2UiLCJjb21wbGV0ZW5lc3MiLCJkaXNwbGF5IiwicGFkZGluZ0JvdHRvbSIsImJhY2tncm91bmQiLCJtYXhXaWR0aCIsIm1hcmdpbiIsInBhZGRpbmdUb3AiLCJhbGlnbkl0ZW1zIiwiZ2FwIiwicG9pbnRlckV2ZW50cyIsIm1hcmdpbkJvdHRvbSIsImJvcmRlckJvdHRvbSIsImZvbnRTaXplIiwiY29sb3IiLCJmb250V2VpZ2h0IiwibWFyZ2luVG9wIiwicG9zaXRpb24iLCJlIiwiZmlsZSIsInRhcmdldCIsImZpbGVzIiwiZmQiLCJGb3JtRGF0YSIsImFwcGVuZCIsImRhdGEiLCJ1cmwiLCJtZXNzYWdlIiwibWFwIiwieSIsImlzU2VsZWN0ZWQiLCJrZXkiLCJwcmV2ZW50RGVmYXVsdCIsInZhbCIsInRyaW0iLCJkb21haW4iLCJkIiwic3Vic3RyaW5nIiwidCIsInJvbGUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkVkaXRQcm9maWxlLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZUVmZmVjdCwgdXNlTWVtbyB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgdXNlTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcclxuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4uLy4uL2NvbnRleHQvQXV0aENvbnRleHQnO1xyXG5pbXBvcnQgeyBjYWxjdWxhdGVQcm9maWxlQ29tcGxldGVuZXNzIH0gZnJvbSAnLi4vLi4vdXRpbHMvcHJvZmlsZVV0aWxzJztcclxuaW1wb3J0IHsgXHJcbiAgVXNlciwgTWFpbCwgQm9va09wZW4sIEJyaWVmY2FzZSwgQ29kZSwgR2xvYmUsIFxyXG4gIENhbGVuZGFyLCBDbG9jaywgTGluayBhcyBMaW5rSWNvbiwgTG9nT3V0LCBTYXZlLCBYLCBQaG9uZSxcclxuICBHaXRodWIsIExpbmtlZGluLCBDaGVja0NpcmNsZTIsIEFsZXJ0Q2lyY2xlLCBJbmZvLCBIYXNoLFxyXG4gIENoZXZyb25SaWdodCwgQXdhcmQsIEJyYWluLCBQbHVzXHJcbn0gZnJvbSAnbHVjaWRlLXJlYWN0JztcclxuaW1wb3J0IE1vZGFsIGZyb20gJy4uLy4uL2NvbXBvbmVudHMvTW9kYWwnO1xyXG5pbXBvcnQgJy4vRWRpdFByb2ZpbGUuY3NzJztcclxuXHJcbmNvbnN0IEVkaXRQcm9maWxlID0gKCkgPT4ge1xyXG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcclxuICBjb25zdCB7IHVzZXIsIHRva2VuLCBmZXRjaFByb2ZpbGUgfSA9IHVzZUF1dGgoKTtcclxuICBjb25zdCBbYWN0aXZlU2VnbWVudCwgc2V0QWN0aXZlU2VnbWVudF0gPSB1c2VTdGF0ZSgncGVyc29uYWwnKTsgXHJcbiAgY29uc3QgW3Nob3dTdWNjZXNzLCBzZXRTaG93U3VjY2Vzc10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIGNvbnN0IFtmb3JtRGF0YSwgc2V0Rm9ybURhdGFdID0gdXNlU3RhdGUoe1xyXG4gICAgZnVsbE5hbWU6IFwiXCIsXHJcbiAgICBlbWFpbDogXCJcIixcclxuICAgIHN0dWRlbnRJZDogXCJcIixcclxuICAgIGRlcGFydG1lbnQ6IFwiXCIsXHJcbiAgICBiaW86IFwiXCIsXHJcbiAgICBjb250YWN0TnVtYmVyOiBcIlwiLFxyXG4gICAgcHJvZmlsZVBpY3R1cmU6IFwiXCIsXHJcbiAgICBzb2NpYWxMaW5rczogeyBnaXRodWI6IFwiXCIsIGxpbmtlZGluOiBcIlwiLCBwb3J0Zm9saW86IFwiXCIgfSxcclxuICAgIGFjYWRlbWljSW5mbzogeyBzcGVjaWFsaXphdGlvbjogXCJcIiwgeWVhcjogXCJcIiwgc2VtZXN0ZXI6IFwiXCIsIGNncGE6IFwiXCIgfSxcclxuICAgIHNraWxsczogeyBsYW5ndWFnZXM6IFtdLCBmcmFtZXdvcmtzOiBbXSwgbGlicmFyaWVzOiBbXSwgZGF0YWJhc2VzOiBbXSwgdG9vbHM6IFtdIH0sXHJcbiAgICBhdmFpbGFiaWxpdHk6IHsgd2Vla2x5SG91cnM6IDEwLCBwcmVmZXJyZWREYXlzOiBbXSwgcHJlZmVycmVkVGltZTogW10gfSxcclxuICAgIGludGVyZXN0czogW10sXHJcbiAgICBwcmVmZXJyZWRSb2xlczogW11cclxuICB9KTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmICh1c2VyKSB7XHJcbiAgICAgIHNldEZvcm1EYXRhKHByZXYgPT4gKHtcclxuICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgIC4uLnVzZXIsXHJcbiAgICAgICAgYWNhZGVtaWNJbmZvOiB7IFxyXG4gICAgICAgICAgc3BlY2lhbGl6YXRpb246IHVzZXIuYWNhZGVtaWNJbmZvPy5zcGVjaWFsaXphdGlvbiB8fCBcIlwiLFxyXG4gICAgICAgICAgeWVhcjogdXNlci5hY2FkZW1pY0luZm8/LnllYXI/LnRvU3RyaW5nKCkgfHwgXCJcIiwgXHJcbiAgICAgICAgICBzZW1lc3RlcjogdXNlci5hY2FkZW1pY0luZm8/LnNlbWVzdGVyPy50b1N0cmluZygpIHx8IFwiXCIsIFxyXG4gICAgICAgICAgY2dwYTogdXNlci5hY2FkZW1pY0luZm8/LmNncGEgfHwgXCJcIiBcclxuICAgICAgICB9LFxyXG4gICAgICAgIHNraWxsczogeyBcclxuICAgICAgICAgIGxhbmd1YWdlczogdXNlci5za2lsbHM/Lmxhbmd1YWdlcyB8fCBbXSxcclxuICAgICAgICAgIGZyYW1ld29ya3M6IHVzZXIuc2tpbGxzPy5mcmFtZXdvcmtzIHx8IFtdLFxyXG4gICAgICAgICAgbGlicmFyaWVzOiB1c2VyLnNraWxscz8ubGlicmFyaWVzIHx8IFtdLFxyXG4gICAgICAgICAgZGF0YWJhc2VzOiB1c2VyLnNraWxscz8uZGF0YWJhc2VzIHx8IFtdLFxyXG4gICAgICAgICAgdG9vbHM6IHVzZXIuc2tpbGxzPy50b29scyB8fCBbXVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgYXZhaWxhYmlsaXR5OiB7IFxyXG4gICAgICAgICAgd2Vla2x5SG91cnM6IHVzZXIuYXZhaWxhYmlsaXR5Py53ZWVrbHlIb3VycyB8fCAxMCxcclxuICAgICAgICAgIHByZWZlcnJlZERheXM6IHVzZXIuYXZhaWxhYmlsaXR5Py5wcmVmZXJyZWREYXlzIHx8IFtdLFxyXG4gICAgICAgICAgcHJlZmVycmVkVGltZTogdXNlci5hdmFpbGFiaWxpdHk/LnByZWZlcnJlZFRpbWUgfHwgW11cclxuICAgICAgICB9LFxyXG4gICAgICAgIHNvY2lhbExpbmtzOiB7IFxyXG4gICAgICAgICAgZ2l0aHViOiB1c2VyLnNvY2lhbExpbmtzPy5naXRodWIgfHwgXCJcIixcclxuICAgICAgICAgIGxpbmtlZGluOiB1c2VyLnNvY2lhbExpbmtzPy5saW5rZWRpbiB8fCBcIlwiLFxyXG4gICAgICAgICAgcG9ydGZvbGlvOiB1c2VyLnNvY2lhbExpbmtzPy5wb3J0Zm9saW8gfHwgXCJcIlxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgY29udGFjdE51bWJlcjogdXNlci5jb250YWN0TnVtYmVyIHx8IFwiXCIsXHJcbiAgICAgICAgcHJlZmVycmVkUm9sZXM6IHVzZXIucHJlZmVycmVkUm9sZXMgfHwgW11cclxuICAgICAgfSkpO1xyXG4gICAgfVxyXG4gIH0sIFt1c2VyXSk7XHJcblxyXG4gIC8vIFByZWRlZmluZWQgU2tpbGwgTGlzdHNcclxuICBjb25zdCBza2lsbERhdGEgPSB7XHJcbiAgICBsYW5ndWFnZXM6IFsnSmF2YVNjcmlwdCcsICdUeXBlU2NyaXB0JywgJ1B5dGhvbicsICdKYXZhJywgJ0MnLCAnQysrJywgJ0MjJywgJ0dvJywgJ1J1c3QnLCAnS290bGluJywgJ1N3aWZ0JywgJ1BIUCcsICdSdWJ5JywgJ0RhcnQnLCAnUicsICdNQVRMQUInXSxcclxuICAgIGZyYW1ld29ya3M6IFsnUmVhY3QnLCAnQW5ndWxhcicsICdWdWUuanMnLCAnTmV4dC5qcycsICdOdXh0LmpzJywgJ05vZGUuanMnLCAnRXhwcmVzcy5qcycsICdEamFuZ28nLCAnRmxhc2snLCAnU3ByaW5nIEJvb3QnLCAnQVNQLk5FVCcsICdMYXJhdmVsJywgJ1J1Ynkgb24gUmFpbHMnLCAnRmx1dHRlcicsICdSZWFjdCBOYXRpdmUnXSxcclxuICAgIGxpYnJhcmllczogWydSZWR1eCcsICdBeGlvcycsICdqUXVlcnknLCAnTG9hc2gnLCAnVGVuc29yRmxvdycsICdLZXJhcycsICdQeVRvcmNoJywgJ1NjaWtpdC1sZWFybicsICdQYW5kYXMnLCAnTnVtUHknLCAnQ2hhcnQuanMnLCAnRDMuanMnLCAnVGhyZWUuanMnLCAnU29ja2V0LmlvJywgJ0Jvb3RzdHJhcCddLFxyXG4gICAgZGF0YWJhc2VzOiBbJ01vbmdvREInLCAnTXlTUUwnLCdQb3N0Z3JlU1FMJywgJ1NRTGl0ZScsICdPcmFjbGUnLCAnTWljcm9zb2Z0IFNRTCBTZXJ2ZXInLCAnRmlyZWJhc2UnLCAnUmVkaXMnLCAnQ2Fzc2FuZHJhJywgJ0R5bmFtb0RCJywgJ05lbzRqJ10sXHJcbiAgICB0b29sczogWydHaXQnLCAnR2l0SHViJywgJ0dpdExhYicsICdEb2NrZXInLCAnS3ViZXJuZXRlcycsICdQb3N0bWFuJywgJ0ppcmEnLCAnVHJlbGxvJywgJ0ZpZ21hJywgJ0Fkb2JlIFhEJywgJ1ZTIENvZGUnLCAnSW50ZWxsaUogSURFQScsICdFY2xpcHNlJywgJ1dlYnBhY2snLCAnQmFiZWwnXVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IHNraWxsQ2F0ZWdvcmllcyA9IFsnbGFuZ3VhZ2VzJywgJ2ZyYW1ld29ya3MnLCAnbGlicmFyaWVzJywgJ2RhdGFiYXNlcycsICd0b29scyddO1xyXG4gIGNvbnN0IGludGVyZXN0cyA9IFtcIkFJIC8gTUxcIiwgXCJXZWIgRGV2ZWxvcG1lbnRcIiwgXCJNb2JpbGUgRGV2ZWxvcG1lbnRcIiwgXCJVSS9VWFwiLCBcIkRldk9wc1wiLCBcIkRhdGEgU2NpZW5jZVwiLCBcIkNsb3VkIENvbXB1dGluZ1wiLCBcIklvVFwiLCBcIkJsb2NrY2hhaW5cIiwgXCJHYW1lIERldmVsb3BtZW50XCIsIFwiQ3liZXJzZWN1cml0eVwiXTtcclxuICBjb25zdCByb2xlc09wdGlvbnMgPSBbXCJGcm9udGVuZCBEZXZlbG9wZXJcIiwgXCJCYWNrZW5kIERldmVsb3BlclwiLCBcIkZ1bGxzdGFjayBEZXZlbG9wZXJcIiwgXCJNb2JpbGUgQXBwIERldmVsb3BlclwiLCBcIk1MIEVuZ2luZWVyXCIsIFwiRGF0YSBTY2llbnRpc3RcIiwgXCJVSS9VWCBEZXNpZ25lclwiLCBcIkRldk9wcyBFbmdpbmVlclwiLCBcIlFBIEVuZ2luZWVyXCIsIFwiUHJvamVjdCBNYW5hZ2VyXCJdO1xyXG4gIGNvbnN0IGRheXMgPSBbXCJNb25kYXlcIiwgXCJUdWVzZGF5XCIsIFwiV2VkbmVzZGF5XCIsIFwiVGh1cnNkYXlcIiwgXCJGcmlkYXlcIiwgXCJTYXR1cmRheVwiLCBcIlN1bmRheVwiXTtcclxuICBjb25zdCB0aW1lcyA9IFtcIk1vcm5pbmdcIiwgXCJBZnRlcm5vb25cIiwgXCJFdmVuaW5nXCIsIFwiTmlnaHRcIl07XHJcblxyXG4gIGNvbnN0IFthY3RpdmVEcm9wZG93biwgc2V0QWN0aXZlRHJvcGRvd25dID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3NraWxsSW5wdXQsIHNldFNraWxsSW5wdXRdID0gdXNlU3RhdGUoeyBjYXRlZ29yeTogJ2xhbmd1YWdlcycsIHRleHQ6ICcnIH0pO1xyXG5cclxuICBjb25zdCBoYW5kbGVJbnB1dENoYW5nZSA9IChmaWVsZCwgdmFsdWUpID0+IHtcclxuICAgIHNldEZvcm1EYXRhKHByZXYgPT4gKHsgLi4ucHJldiwgW2ZpZWxkXTogdmFsdWUgfSkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZU5lc3RlZENoYW5nZSA9IChwYXJlbnQsIGZpZWxkLCB2YWx1ZSkgPT4ge1xyXG4gICAgc2V0Rm9ybURhdGEocHJldiA9PiAoe1xyXG4gICAgICAuLi5wcmV2LFxyXG4gICAgICBbcGFyZW50XTogeyAuLi5wcmV2W3BhcmVudF0sIFtmaWVsZF06IHZhbHVlIH1cclxuICAgIH0pKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVNdWx0aVNlbGVjdCA9IChmaWVsZCwgdmFsdWUpID0+IHtcclxuICAgIHNldEZvcm1EYXRhKHByZXYgPT4ge1xyXG4gICAgICBjb25zdCBjdXJyZW50ID0gcHJldltmaWVsZF0gfHwgW107XHJcbiAgICAgIGNvbnN0IHVwZGF0ZWQgPSBjdXJyZW50LmluY2x1ZGVzKHZhbHVlKSBcclxuICAgICAgICA/IGN1cnJlbnQuZmlsdGVyKGkgPT4gaSAhPT0gdmFsdWUpIFxyXG4gICAgICAgIDogWy4uLmN1cnJlbnQsIHZhbHVlXTtcclxuICAgICAgcmV0dXJuIHsgLi4ucHJldiwgW2ZpZWxkXTogdXBkYXRlZCB9O1xyXG4gICAgfSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQXZhaWxhYmlsaXR5U2VsZWN0ID0gKGZpZWxkLCB2YWx1ZSkgPT4ge1xyXG4gICAgc2V0Rm9ybURhdGEocHJldiA9PiB7XHJcbiAgICAgIGNvbnN0IGN1cnJlbnQgPSBwcmV2LmF2YWlsYWJpbGl0eVtmaWVsZF0gfHwgW107XHJcbiAgICAgIGNvbnN0IHVwZGF0ZWQgPSBjdXJyZW50LmluY2x1ZGVzKHZhbHVlKSBcclxuICAgICAgICA/IGN1cnJlbnQuZmlsdGVyKGkgPT4gaSAhPT0gdmFsdWUpIFxyXG4gICAgICAgIDogWy4uLmN1cnJlbnQsIHZhbHVlXTtcclxuICAgICAgcmV0dXJuIHsgLi4ucHJldiwgYXZhaWxhYmlsaXR5OiB7IC4uLnByZXYuYXZhaWxhYmlsaXR5LCBbZmllbGRdOiB1cGRhdGVkIH0gfTtcclxuICAgIH0pO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVJlbW92ZVNraWxsID0gKGNhdCwgc2tpbGwpID0+IHtcclxuICAgIHNldEZvcm1EYXRhKHByZXYgPT4gKHtcclxuICAgICAgLi4ucHJldixcclxuICAgICAgc2tpbGxzOiB7IC4uLnByZXYuc2tpbGxzLCBbY2F0XTogcHJldi5za2lsbHNbY2F0XS5maWx0ZXIocyA9PiBzICE9PSBza2lsbCkgfVxyXG4gICAgfSkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jICgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKCdodHRwOi8vbG9jYWxob3N0OjMwMDAvYXBpL3Byb2ZpbGUvJywge1xyXG4gICAgICAgIG1ldGhvZDogJ1BVVCcsXHJcbiAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyxcclxuICAgICAgICAgICd4LWF1dGgtdG9rZW4nOiB0b2tlblxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoZm9ybURhdGEpXHJcbiAgICAgIH0pO1xyXG4gICAgICBcclxuICAgICAgaWYgKHJlcy5vaykge1xyXG4gICAgICAgIGF3YWl0IGZldGNoUHJvZmlsZSgpO1xyXG4gICAgICAgIHNldFNob3dTdWNjZXNzKHRydWUpO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGNvbnN0IGVycm9yRGF0YSA9IGF3YWl0IHJlcy5qc29uKCk7XHJcbiAgICAgICAgYWxlcnQoZXJyb3JEYXRhLm1zZyB8fCBcIkVycm9yIHVwZGF0aW5nIHByb2ZpbGVcIik7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBhbGVydChcIkVycm9yIHVwZGF0aW5nIHByb2ZpbGVcIik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgdG9nZ2xlRHJvcGRvd24gPSAoaWQpID0+IHNldEFjdGl2ZURyb3Bkb3duKGFjdGl2ZURyb3Bkb3duID09PSBpZCA/IG51bGwgOiBpZCk7XHJcblxyXG4gIGNvbnN0IHsgcGVyY2VudGFnZTogY29tcGxldGVuZXNzIH0gPSBjYWxjdWxhdGVQcm9maWxlQ29tcGxldGVuZXNzKGZvcm1EYXRhKTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgaWQ9XCJwYWdlLWVkaXQtcHJvZmlsZVwiIGNsYXNzTmFtZT1cInBhZ2UgYWN0aXZlXCIgc3R5bGU9e3sgZGlzcGxheTogJ2Jsb2NrJywgcGFkZGluZ0JvdHRvbTogJzNyZW0nLCBiYWNrZ3JvdW5kOiAnI2Y4ZmFmYycgfX0+XHJcbiAgICAgIFxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInBhZ2UtaGRyXCIgc3R5bGU9e3sgbWF4V2lkdGg6ICcxMjAwcHgnLCBtYXJnaW46ICcwIGF1dG8gMnJlbSBhdXRvJywgcGFkZGluZ1RvcDogJzEuNXJlbScgfX0+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwYWdlLWhkci1sZWZ0XCI+XHJcbiAgICAgICAgICA8aDEgc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCBhbGlnbkl0ZW1zOiAnY2VudGVyJywgZ2FwOiAnMTBweCcgfX0+XHJcbiAgICAgICAgICAgIDxVc2VyIHNpemU9ezI4fSBjb2xvcj1cInZhcigtLXApXCIgLz4gRWRpdCBQcm9maWxlXHJcbiAgICAgICAgICA8L2gxPlxyXG4gICAgICAgICAgPHA+Q3JhZnQgeW91ciBwcm9mZXNzaW9uYWwgcHJlc2VuY2Ugb24gUHJvTWF0ZTwvcD5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBhZ2UtaGRyLXJpZ2h0XCIgc3R5bGU9e3sgZGlzcGxheTogJ2ZsZXgnLCBhbGlnbkl0ZW1zOiAnY2VudGVyJywgZ2FwOiAnMXJlbScgfX0+XHJcbiAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImJ0biBidG4tb3V0bGluZSBidG4tc21cIiBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZSgnL3Byb2ZpbGUnKX0+RGlzY2FyZDwvYnV0dG9uPlxyXG4gICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJidG4gYnRuLXByaW1hcnkgYnRuLXNtXCIgb25DbGljaz17aGFuZGxlU3VibWl0fT5cclxuICAgICAgICAgICAgPFNhdmUgc2l6ZT17MTZ9IC8+IFNhdmUgQ2hhbmdlc1xyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJlcC1vdXRlci1jb250YWluZXJcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImVwLW1haW4tY2FyZFwiPlxyXG4gICAgICAgICAgey8qIPCfk4sgU2lkZWJhciBOYXZpZ2F0aW9uICovfVxyXG4gICAgICAgICAgPGFzaWRlIGNsYXNzTmFtZT1cImVwLXNpZGViYXJcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJlcC1zYi1pdGVtXCIgc3R5bGU9e3sgcG9pbnRlckV2ZW50czogJ25vbmUnLCBtYXJnaW5Cb3R0b206ICcxcmVtJywgYm9yZGVyQm90dG9tOiAnMXB4IHNvbGlkIHZhcigtLWJvcmRlciknLCBwYWRkaW5nQm90dG9tOiAnMC41cmVtJyB9fT5cclxuICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYy1wY3RcIiBzdHlsZT17eyBmb250U2l6ZTogJzEuMnJlbScgfX0+e2NvbXBsZXRlbmVzc30lPC9kaXY+XHJcbiAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZm9udFNpemU6ICcwLjdyZW0nLCBjb2xvcjogJ3ZhcigtLW1pZCknIH19PkNvbXBsZXRlbmVzczwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgZXAtc2ItaXRlbSAke2FjdGl2ZVNlZ21lbnQgPT09ICdwZXJzb25hbCcgPyAnYWN0aXZlJyA6ICcnfWB9IG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVNlZ21lbnQoJ3BlcnNvbmFsJyl9PlxyXG4gICAgICAgICAgICAgIDxVc2VyIGNsYXNzTmFtZT1cImVwLXNiLWljb25cIiAvPiBQZXJzb25hbCBEZXRhaWxzXHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YGVwLXNiLWl0ZW0gJHthY3RpdmVTZWdtZW50ID09PSAnYWNhZGVtaWMnID8gJ2FjdGl2ZScgOiAnJ31gfSBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVTZWdtZW50KCdhY2FkZW1pYycpfT5cclxuICAgICAgICAgICAgICA8Qm9va09wZW4gY2xhc3NOYW1lPVwiZXAtc2ItaWNvblwiIC8+IEFjYWRlbWljIEluZm9cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgZXAtc2ItaXRlbSAke2FjdGl2ZVNlZ21lbnQgPT09ICdzb2NpYWwnID8gJ2FjdGl2ZScgOiAnJ31gfSBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVTZWdtZW50KCdzb2NpYWwnKX0+XHJcbiAgICAgICAgICAgICAgPEdsb2JlIGNsYXNzTmFtZT1cImVwLXNiLWljb25cIiAvPiBTb2NpYWwgTGlua3NcclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgZXAtc2ItaXRlbSAke2FjdGl2ZVNlZ21lbnQgPT09ICdza2lsbHMnID8gJ2FjdGl2ZScgOiAnJ31gfSBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVTZWdtZW50KCdza2lsbHMnKX0+XHJcbiAgICAgICAgICAgICAgPENvZGUgY2xhc3NOYW1lPVwiZXAtc2ItaWNvblwiIC8+IFNraWxscyAmIFRlY2hcclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgZXAtc2ItaXRlbSAke2FjdGl2ZVNlZ21lbnQgPT09ICdhdmFpbGFiaWxpdHknID8gJ2FjdGl2ZScgOiAnJ31gfSBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVTZWdtZW50KCdhdmFpbGFiaWxpdHknKX0+XHJcbiAgICAgICAgICAgICAgPENhbGVuZGFyIGNsYXNzTmFtZT1cImVwLXNiLWljb25cIiAvPiBBdmFpbGFiaWxpdHlcclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgZXAtc2ItaXRlbSAke2FjdGl2ZVNlZ21lbnQgPT09ICdpbnRlcmVzdHMnID8gJ2FjdGl2ZScgOiAnJ31gfSBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVTZWdtZW50KCdpbnRlcmVzdHMnKX0+XHJcbiAgICAgICAgICAgICAgPEJyYWluIGNsYXNzTmFtZT1cImVwLXNiLWljb25cIiAvPiBQcm9qZWN0IEludGVyZXN0c1xyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2BlcC1zYi1pdGVtICR7YWN0aXZlU2VnbWVudCA9PT0gJ3JvbGVzJyA/ICdhY3RpdmUnIDogJyd9YH0gb25DbGljaz17KCkgPT4gc2V0QWN0aXZlU2VnbWVudCgncm9sZXMnKX0+XHJcbiAgICAgICAgICAgICAgPEJyaWVmY2FzZSBjbGFzc05hbWU9XCJlcC1zYi1pY29uXCIgLz4gUHJlZmVycmVkIFJvbGVzXHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJlcC1zYi1wcm9tb1wiPlxyXG4gICAgICAgICAgICAgIDxBd2FyZCBzaXplPXsyMH0gc3R5bGU9e3sgY29sb3I6ICd2YXIoLS1wKScsIG1hcmdpbkJvdHRvbTogJzAuNXJlbScgfX0gLz5cclxuICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZvbnRTaXplOiAnMC43NXJlbScsIGZvbnRXZWlnaHQ6IDYwMCwgY29sb3I6ICd2YXIoLS1wKScgfX0+UHJvIFRpcDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZm9udFNpemU6ICcwLjY1cmVtJywgY29sb3I6ICd2YXIoLS1taWQpJywgbWFyZ2luVG9wOiAnMnB4JyB9fT5Db21wbGV0ZSB5b3VyIHByb2ZpbGUgdG8gZ2V0IGJldHRlciBwcm9qZWN0IG1hdGNoZXMhPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9hc2lkZT5cclxuXHJcbiAgICAgICAgICB7Lyog8J+TnSBNYWluIENvbnRlbnQgQXJlYSAqL31cclxuICAgICAgICAgIDxtYWluIGNsYXNzTmFtZT1cImVwLWNvbnRlbnRcIj5cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIHthY3RpdmVTZWdtZW50ID09PSAncGVyc29uYWwnICYmIChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImVwLXNlY3Rpb24tY2FyZFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJlcC1zZWN0aW9uLWhlYWRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImVwLXNlY3Rpb24taWNvbi1iZ1wiPjxVc2VyIHNpemU9ezIwfSAvPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8aDI+UGVyc29uYWwgSW5mb3JtYXRpb248L2gyPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGYtdXBsb2FkLWNhcmRcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBwb3NpdGlvbjogJ3JlbGF0aXZlJywgZGlzcGxheTogJ2lubGluZS1ibG9jaycgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgPGltZyBcclxuICAgICAgICAgICAgICAgICAgICAgIHNyYz17Zm9ybURhdGEucHJvZmlsZVBpY3R1cmUgfHwgXCJodHRwczovL3VpLWF2YXRhcnMuY29tL2FwaS8/bmFtZT1cIiArIChmb3JtRGF0YS5mdWxsTmFtZSB8fCBcIlVzZXJcIil9IFxyXG4gICAgICAgICAgICAgICAgICAgICAgYWx0PVwiQXZhdGFyXCIgXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJlcC1hdmF0YXItbGdcIlxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJwZi11cGxvYWRcIiBjbGFzc05hbWU9XCJwZi11cGxvYWQtYnRuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8UGx1cyBzaXplPXsxNn0gLz5cclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dCBpZD1cInBmLXVwbG9hZFwiIHR5cGU9XCJmaWxlXCIgaGlkZGVuIGFjY2VwdD1cImltYWdlLypcIiBvbkNoYW5nZT17YXN5bmMgKGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGZpbGUgPSBlLnRhcmdldC5maWxlc1swXTtcclxuICAgICAgICAgICAgICAgICAgICAgIGlmICghZmlsZSkgcmV0dXJuO1xyXG4gICAgICAgICAgICAgICAgICAgICAgY29uc3QgZmQgPSBuZXcgRm9ybURhdGEoKTtcclxuICAgICAgICAgICAgICAgICAgICAgIGZkLmFwcGVuZCgncHJvZmlsZVBpY3R1cmUnLCBmaWxlKTtcclxuICAgICAgICAgICAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKCdodHRwOi8vbG9jYWxob3N0OjMwMDAvYXBpL3Byb2ZpbGUvdXBsb2FkJywge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGhlYWRlcnM6IHsgJ3gtYXV0aC10b2tlbic6IHRva2VuIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYm9keTogZmRcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXMuanNvbigpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAocmVzLm9rKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlSW5wdXRDaGFuZ2UoXCJwcm9maWxlUGljdHVyZVwiLCBkYXRhLnVybCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYXdhaXQgZmV0Y2hQcm9maWxlKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7IGFsZXJ0KFwiVXBsb2FkIGZhaWxlZDogXCIgKyBkYXRhLm1lc3NhZ2UpOyB9XHJcbiAgICAgICAgICAgICAgICAgICAgICB9IGNhdGNoIChlcnIpIHsgYWxlcnQoXCJFcnJvciB1cGxvYWRpbmcgaW1hZ2VcIik7IH1cclxuICAgICAgICAgICAgICAgICAgICB9fSAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwZi11cGxvYWQtaW5mb1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICA8aDM+e2Zvcm1EYXRhLmZ1bGxOYW1lIHx8IFwiWW91ciBTdHVkZW50IFByb2ZpbGVcIn08L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgICA8cD57Zm9ybURhdGEuZW1haWx9PC9wPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1yb3dcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZvcm0tbGFiZWxcIj5GdWxsIE5hbWU8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIGNsYXNzTmFtZT1cImVwLWZvcm0taW5wdXRcIiB2YWx1ZT17Zm9ybURhdGEuZnVsbE5hbWV9IG9uQ2hhbmdlPXtlID0+IGhhbmRsZUlucHV0Q2hhbmdlKFwiZnVsbE5hbWVcIiwgZS50YXJnZXQudmFsdWUpfSAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZvcm0tbGFiZWxcIj5TdHVkZW50IElEPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImVwLWZvcm0taW5wdXQgcmVhZG9ubHlcIj48SGFzaCBzaXplPXsxNH0gLz4ge2Zvcm1EYXRhLnN0dWRlbnRJZH08L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXBcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZvcm0tbGFiZWxcIj5Qcm9mZXNzaW9uYWwgQmlvPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPHRleHRhcmVhIFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImVwLWZvcm0taW5wdXRcIiBcclxuICAgICAgICAgICAgICAgICAgICByb3dzPVwiNFwiIFxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiVGVsbCBwb3RlbnRpYWwgdGVhbW1hdGVzIGFib3V0IHlvdXIgcGFzc2lvbiwgZ29hbHMuLi5cIiBcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuYmlvIHx8IFwiXCJ9IFxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IGhhbmRsZUlucHV0Q2hhbmdlKFwiYmlvXCIsIGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgPjwvdGV4dGFyZWE+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXBcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZvcm0tbGFiZWxcIj48UGhvbmUgc2l6ZT17MTR9IC8+IENvbnRhY3QgTnVtYmVyPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgY2xhc3NOYW1lPVwiZXAtZm9ybS1pbnB1dFwiIHBsYWNlaG9sZGVyPVwiKzk0IDc3IDEyMyA0NTY3XCIgdmFsdWU9e2Zvcm1EYXRhLmNvbnRhY3ROdW1iZXJ9IG9uQ2hhbmdlPXtlID0+IGhhbmRsZUlucHV0Q2hhbmdlKFwiY29udGFjdE51bWJlclwiLCBlLnRhcmdldC52YWx1ZSl9IC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIHthY3RpdmVTZWdtZW50ID09PSAnYWNhZGVtaWMnICYmIChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImVwLXNlY3Rpb24tY2FyZFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJlcC1zZWN0aW9uLWhlYWRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImVwLXNlY3Rpb24taWNvbi1iZ1wiPjxCb29rT3BlbiBzaXplPXsyMH0gLz48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGgyPkFjYWRlbWljIEJhY2tncm91bmQ8L2gyPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncm91cFwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZm9ybS1sYWJlbFwiPkRlcGFydG1lbnQgPHNwYW4gc3R5bGU9e3sgY29sb3I6ICd2YXIoLS1taWQpJywgZm9udFdlaWdodDogNDAwLCBmb250U2l6ZTogJzAuNzVyZW0nIH19PihDb250YWN0IEFkbWluIHRvIGNoYW5nZSk8L3NwYW4+PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJlcC1mb3JtLWlucHV0IHJlYWRvbmx5XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJvb2tPcGVuIHNpemU9ezE0fSAvPiB7Zm9ybURhdGEuZGVwYXJ0bWVudCB8fCBcIk5vdCBTZXRcIn1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tcm93XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncm91cFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmb3JtLWxhYmVsXCI+WWVhciBvZiBTdHVkeTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNlbGVjdCBjbGFzc05hbWU9XCJlcC1mb3JtLWlucHV0XCIgdmFsdWU9e2Zvcm1EYXRhLmFjYWRlbWljSW5mby55ZWFyfSBvbkNoYW5nZT17ZSA9PiBoYW5kbGVOZXN0ZWRDaGFuZ2UoXCJhY2FkZW1pY0luZm9cIiwgXCJ5ZWFyXCIsIGUudGFyZ2V0LnZhbHVlKX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+U2VsZWN0IFllYXI8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtbJzEnLCAnMicsICczJywgJzQnXS5tYXAoeSA9PiA8b3B0aW9uIGtleT17eX0gdmFsdWU9e3l9PlllYXIge3l9PC9vcHRpb24+KX1cclxuICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncm91cFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmb3JtLWxhYmVsXCI+U2VtZXN0ZXI8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzZWxlY3QgY2xhc3NOYW1lPVwiZXAtZm9ybS1pbnB1dFwiIHZhbHVlPXtmb3JtRGF0YS5hY2FkZW1pY0luZm8uc2VtZXN0ZXJ9IG9uQ2hhbmdlPXtlID0+IGhhbmRsZU5lc3RlZENoYW5nZShcImFjYWRlbWljSW5mb1wiLCBcInNlbWVzdGVyXCIsIGUudGFyZ2V0LnZhbHVlKX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+U2VsZWN0IFNlbWVzdGVyPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7WycxJywgJzInXS5tYXAocyA9PiA8b3B0aW9uIGtleT17c30gdmFsdWU9e3N9PlNlbWVzdGVyIHtzfTwvb3B0aW9uPil9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLXJvd1wiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXBcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZm9ybS1sYWJlbFwiPlNwZWNpYWxpemF0aW9uIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiAndmFyKC0tbWlkKScsIGZvbnRXZWlnaHQ6IDQwMCwgZm9udFNpemU6ICcwLjc1cmVtJyB9fT4oQ29udGFjdCBBZG1pbiB0byBjaGFuZ2UpPC9zcGFuPjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJlcC1mb3JtLWlucHV0IHJlYWRvbmx5XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgPEF3YXJkIHNpemU9ezE0fSAvPiB7Zm9ybURhdGEuYWNhZGVtaWNJbmZvLnNwZWNpYWxpemF0aW9uIHx8IFwiTm90IFNldFwifVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZvcm0tbGFiZWxcIj5DdXJyZW50IENHUEE8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwibnVtYmVyXCIgY2xhc3NOYW1lPVwiZXAtZm9ybS1pbnB1dFwiIHZhbHVlPXtmb3JtRGF0YS5hY2FkZW1pY0luZm8uY2dwYX0gb25DaGFuZ2U9e2UgPT4gaGFuZGxlTmVzdGVkQ2hhbmdlKFwiYWNhZGVtaWNJbmZvXCIsIFwiY2dwYVwiLCBlLnRhcmdldC52YWx1ZSl9IG1pbj1cIjBcIiBtYXg9XCI0XCIgc3RlcD1cIjAuMDFcIiAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAge2FjdGl2ZVNlZ21lbnQgPT09ICdzb2NpYWwnICYmIChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImVwLXNlY3Rpb24tY2FyZFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJlcC1zZWN0aW9uLWhlYWRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImVwLXNlY3Rpb24taWNvbi1iZ1wiPjxHbG9iZSBzaXplPXsyMH0gLz48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGgyPlByb2Zlc3Npb25hbCBMaW5rczwvaDI+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmb3JtLWxhYmVsXCI+PEdpdGh1YiBzaXplPXsxNH0gLz4gR2l0SHViIFByb2ZpbGU8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInVybFwiIGNsYXNzTmFtZT1cImVwLWZvcm0taW5wdXRcIiBwbGFjZWhvbGRlcj1cImh0dHBzOi8vZ2l0aHViLmNvbS91c2VybmFtZVwiIHZhbHVlPXtmb3JtRGF0YS5zb2NpYWxMaW5rcz8uZ2l0aHViIHx8IFwiXCJ9IG9uQ2hhbmdlPXtlID0+IGhhbmRsZU5lc3RlZENoYW5nZShcInNvY2lhbExpbmtzXCIsIFwiZ2l0aHViXCIsIGUudGFyZ2V0LnZhbHVlKX0gLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncm91cFwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZm9ybS1sYWJlbFwiPjxMaW5rZWRpbiBzaXplPXsxNH0gLz4gTGlua2VkSW4gUHJvZmlsZTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidXJsXCIgY2xhc3NOYW1lPVwiZXAtZm9ybS1pbnB1dFwiIHBsYWNlaG9sZGVyPVwiaHR0cHM6Ly9saW5rZWRpbi5jb20vaW4vdXNlcm5hbWVcIiB2YWx1ZT17Zm9ybURhdGEuc29jaWFsTGlua3M/LmxpbmtlZGluIHx8IFwiXCJ9IG9uQ2hhbmdlPXtlID0+IGhhbmRsZU5lc3RlZENoYW5nZShcInNvY2lhbExpbmtzXCIsIFwibGlua2VkaW5cIiwgZS50YXJnZXQudmFsdWUpfSAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmb3JtLWxhYmVsXCI+PExpbmtJY29uIHNpemU9ezE0fSAvPiBQZXJzb25hbCBQb3J0Zm9saW88L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInVybFwiIGNsYXNzTmFtZT1cImVwLWZvcm0taW5wdXRcIiBwbGFjZWhvbGRlcj1cImh0dHBzOi8veW91cndlYnNpdGUuY29tXCIgdmFsdWU9e2Zvcm1EYXRhLnNvY2lhbExpbmtzPy5wb3J0Zm9saW8gfHwgXCJcIn0gb25DaGFuZ2U9e2UgPT4gaGFuZGxlTmVzdGVkQ2hhbmdlKFwic29jaWFsTGlua3NcIiwgXCJwb3J0Zm9saW9cIiwgZS50YXJnZXQudmFsdWUpfSAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICB7YWN0aXZlU2VnbWVudCA9PT0gJ3NraWxscycgJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZXAtc2VjdGlvbi1jYXJkXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImVwLXNlY3Rpb24taGVhZGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZXAtc2VjdGlvbi1pY29uLWJnXCI+PENvZGUgc2l6ZT17MjB9IC8+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxoMj5Ta2lsbHMgJiBUZWNoPC9oMj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2tpbGwtc2VjdGlvbi1tYWluXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtza2lsbENhdGVnb3JpZXMubWFwKGNhdCA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2NhdH0gY2xhc3NOYW1lPVwic2tpbGwtY2F0LXJvd1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJza2lsbC1jYXQtbGFiZWxcIj57Y2F0fTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJza2lsbC1ncmlkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtza2lsbERhdGFbY2F0XS5tYXAoc2tpbGwgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGlzU2VsZWN0ZWQgPSBmb3JtRGF0YS5za2lsbHNbY2F0XT8uaW5jbHVkZXMoc2tpbGwpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e3NraWxsfSBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgc2tpbGwtY2hpcC10b2dnbGUgJHtpc1NlbGVjdGVkID8gJ2FjdGl2ZScgOiAnJ31gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBpc1NlbGVjdGVkID8gaGFuZGxlUmVtb3ZlU2tpbGwoY2F0LCBza2lsbCkgOiBzZXRGb3JtRGF0YShwcmV2ID0+ICh7IC4uLnByZXYsIHNraWxsczogeyAuLi5wcmV2LnNraWxscywgW2NhdF06IFsuLi5wcmV2LnNraWxsc1tjYXRdLCBza2lsbF0gfSB9KSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtza2lsbH0ge2lzU2VsZWN0ZWQgPyA8Q2hlY2tDaXJjbGUyIHNpemU9ezEyfSAvPiA6IDxQbHVzIHNpemU9ezEyfSAvPn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBDdXN0b20gU2tpbGxzIGZvciB0aGlzIGNhdGVnb3J5ICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjdXN0b20tc2tpbGwtbGlzdFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1EYXRhLnNraWxsc1tjYXRdPy5maWx0ZXIocyA9PiAhc2tpbGxEYXRhW2NhdF0uaW5jbHVkZXMocykpLm1hcChzID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4ga2V5PXtzfSBjbGFzc05hbWU9XCJza2lsbC10YWctcmVtb3ZhYmxlXCIgb25DbGljaz17KCkgPT4gaGFuZGxlUmVtb3ZlU2tpbGwoY2F0LCBzKX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3N9IDxYIHNpemU9ezEyfSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY3VzdG9tLXNraWxsLWFkZGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmb3JtLWxhYmVsXCI+QWRkIEN1c3RvbSBUZWNobm9sb2d5PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhZGRlci1mbGV4XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNlbGVjdCB2YWx1ZT17c2tpbGxJbnB1dC5jYXRlZ29yeX0gb25DaGFuZ2U9e2UgPT4gc2V0U2tpbGxJbnB1dCh7Li4uc2tpbGxJbnB1dCwgY2F0ZWdvcnk6IGUudGFyZ2V0LnZhbHVlfSl9PlxyXG4gICAgICAgICAgICAgICAgICAgICAge3NraWxsQ2F0ZWdvcmllcy5tYXAoY2F0ID0+IDxvcHRpb24ga2V5PXtjYXR9IHZhbHVlPXtjYXR9PntjYXR9PC9vcHRpb24+KX1cclxuICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXQgXHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiIFxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBza2lsbCBuYW1lLi4uXCIgXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2tpbGxJbnB1dC50ZXh0fSBcclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldFNraWxsSW5wdXQoey4uLnNraWxsSW5wdXQsIHRleHQ6IGUudGFyZ2V0LnZhbHVlfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbktleURvd249e2UgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoZS5rZXkgPT09ICdFbnRlcicpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdmFsID0gc2tpbGxJbnB1dC50ZXh0LnRyaW0oKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodmFsKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBjYXQgPSBza2lsbElucHV0LmNhdGVnb3J5O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFmb3JtRGF0YS5za2lsbHNbY2F0XS5pbmNsdWRlcyh2YWwpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKHByZXYgPT4gKHsgLi4ucHJldiwgc2tpbGxzOiB7IC4uLnByZXYuc2tpbGxzLCBbY2F0XTogWy4uLihwcmV2LnNraWxsc1tjYXRdIHx8IFtdKSwgdmFsXSB9IH0pKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNraWxsSW5wdXQoey4uLnNraWxsSW5wdXQsIHRleHQ6ICcnfSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJidG4gYnRuLXByaW1hcnlcIiBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBjb25zdCB2YWwgPSBza2lsbElucHV0LnRleHQudHJpbSgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgaWYgKHZhbCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgY2F0ID0gc2tpbGxJbnB1dC5jYXRlZ29yeTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgIGlmICghZm9ybURhdGEuc2tpbGxzW2NhdF0uaW5jbHVkZXModmFsKSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YShwcmV2ID0+ICh7IC4uLnByZXYsIHNraWxsczogeyAuLi5wcmV2LnNraWxscywgW2NhdF06IFsuLi4ocHJldi5za2lsbHNbY2F0XSB8fCBbXSksIHZhbF0gfSB9KSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICBzZXRTa2lsbElucHV0KHsuLi5za2lsbElucHV0LCB0ZXh0OiAnJ30pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH19PjxQbHVzIHNpemU9ezIwfSAvPjwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAge2FjdGl2ZVNlZ21lbnQgPT09ICdpbnRlcmVzdHMnICYmIChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImVwLXNlY3Rpb24tY2FyZFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJlcC1zZWN0aW9uLWhlYWRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImVwLXNlY3Rpb24taWNvbi1iZ1wiPjxCcmFpbiBzaXplPXsyMH0gLz48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGgyPlByb2plY3QgSW50ZXJlc3RzPC9oMj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFpLXN1Z2dlc3Rpb24tYmFubmVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxCcmFpbiBzaXplPXsyMH0gY29sb3I9XCJ2YXIoLS1wKVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGg0PlByb2plY3QgRG9tYWluIFNlbGVjdGlvbjwvaDQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPHA+U2VsZWN0IGRvbWFpbnMgdGhhdCBleGNpdGUgeW91LiBXZSB1c2UgdGhlc2UgdG8gcmVjb21tZW5kIHByb2plY3RzITwvcD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImludGVyZXN0LXNlbGVjdGlvbi1ncmlkXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtpbnRlcmVzdHMubWFwKGRvbWFpbiA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNTZWxlY3RlZCA9IGZvcm1EYXRhLmludGVyZXN0cy5pbmNsdWRlcyhkb21haW4pO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2RvbWFpbn0gXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGludGVyZXN0LXBpbGwgJHtpc1NlbGVjdGVkID8gJ2FjdGl2ZScgOiAnJ31gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVNdWx0aVNlbGVjdCgnaW50ZXJlc3RzJywgZG9tYWluKX1cclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2lzU2VsZWN0ZWQgPyA8Q2hlY2tDaXJjbGUyIHNpemU9ezE2fSAvPiA6IDxQbHVzIHNpemU9ezE2fSAvPn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e2RvbWFpbn08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAge2FjdGl2ZVNlZ21lbnQgPT09ICdhdmFpbGFiaWxpdHknICYmIChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImVwLXNlY3Rpb24tY2FyZFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJlcC1zZWN0aW9uLWhlYWRlclwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImVwLXNlY3Rpb24taWNvbi1iZ1wiPjxDYWxlbmRhciBzaXplPXsyMH0gLz48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGgyPldlZWtseSBBdmFpbGFiaWxpdHk8L2gyPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYXZhaWwtaW5mby1ib3hcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZvcm0tbGFiZWxcIj5EZWRpY2F0ZWQgSG91cnMgUGVyIFdlZWs6IDxzdHJvbmc+e2Zvcm1EYXRhLmF2YWlsYWJpbGl0eS53ZWVrbHlIb3Vyc31oPC9zdHJvbmc+PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJyYW5nZVwiIG1pbj1cIjFcIiBtYXg9XCI0MFwiIHZhbHVlPXtmb3JtRGF0YS5hdmFpbGFiaWxpdHkud2Vla2x5SG91cnMgfHwgMTB9IG9uQ2hhbmdlPXtlID0+IGhhbmRsZU5lc3RlZENoYW5nZShcImF2YWlsYWJpbGl0eVwiLCBcIndlZWtseUhvdXJzXCIsIGUudGFyZ2V0LnZhbHVlKX0gLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncm91cFwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZm9ybS1sYWJlbFwiPldvcmtpbmcgRGF5czwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGF5LWdyaWRcIj5cclxuICAgICAgICAgICAgICAgICAgICB7ZGF5cy5tYXAoZCA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17ZH0gY2xhc3NOYW1lPXtgZGF5LWJ0biAke2Zvcm1EYXRhLmF2YWlsYWJpbGl0eS5wcmVmZXJyZWREYXlzLmluY2x1ZGVzKGQpID8gJ2FjdGl2ZScgOiAnJ31gfSBvbkNsaWNrPXsoKSA9PiBoYW5kbGVBdmFpbGFiaWxpdHlTZWxlY3QoXCJwcmVmZXJyZWREYXlzXCIsIGQpfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Quc3Vic3RyaW5nKDAsMyl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXBcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZvcm0tbGFiZWxcIj5QcmVmZXJyZWQgVGltZSBXaW5kb3c8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNoaXAtZ3JpZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHt0aW1lcy5tYXAodCA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17dH0gY2xhc3NOYW1lPXtgY2hpcC1idG4gJHtmb3JtRGF0YS5hdmFpbGFiaWxpdHkucHJlZmVycmVkVGltZS5pbmNsdWRlcyh0KSA/ICdhY3RpdmUnIDogJyd9YH0gb25DbGljaz17KCkgPT4gaGFuZGxlQXZhaWxhYmlsaXR5U2VsZWN0KFwicHJlZmVycmVkVGltZVwiLCB0KX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHt0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICB7YWN0aXZlU2VnbWVudCA9PT0gJ3JvbGVzJyAmJiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJlcC1zZWN0aW9uLWNhcmRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZXAtc2VjdGlvbi1oZWFkZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJlcC1zZWN0aW9uLWljb24tYmdcIj48QnJpZWZjYXNlIHNpemU9ezIwfSAvPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8aDI+UHJlZmVycmVkIFByb2plY3QgUm9sZXM8L2gyPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm9sZS1zZWxlY3Rpb24tZ3JpZFwiPlxyXG4gICAgICAgICAgICAgICAgICB7cm9sZXNPcHRpb25zLm1hcChyb2xlID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zdCBpc1NlbGVjdGVkID0gZm9ybURhdGEucHJlZmVycmVkUm9sZXMuaW5jbHVkZXMocm9sZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleT17cm9sZX0gXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHJvbGUtY2FyZC1zZWxlY3QgJHtpc1NlbGVjdGVkID8gJ2FjdGl2ZScgOiAnJ31gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVNdWx0aVNlbGVjdCgncHJlZmVycmVkUm9sZXMnLCByb2xlKX1cclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb2xlLWNoZWNrXCI+e2lzU2VsZWN0ZWQgPyA8Q2hlY2tDaXJjbGUyIHNpemU9ezE2fSAvPiA6IDxkaXYgY2xhc3NOYW1lPVwiZG90XCI+PC9kaXY+fTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57cm9sZX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgIDwvbWFpbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7c2hvd1N1Y2Nlc3MgJiYgKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3VjY2Vzcy1tb2RhbC1vdmVybGF5XCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN1Y2Nlc3MtbW9kYWwtY2FyZFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN1Y2Nlc3MtYm91bmNlLWljb25cIj5cclxuICAgICAgICAgICAgICA8Q2hlY2tDaXJjbGUyIHNpemU9ezYwfSBjb2xvcj1cIiMxMGI5ODFcIiAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGgyPlByb2ZpbGUgVXBkYXRlZCE8L2gyPlxyXG4gICAgICAgICAgICA8cD5Zb3VyIGNoYW5nZXMgaGF2ZSBiZWVuIHNhdmVkIHN1Y2Nlc3NmdWxseS4gWW91ciBwcm9maWxlIGlzIGxvb2tpbmcgZ3JlYXQhPC9wPlxyXG4gICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImJ0biBidG4tcHJpbWFyeSBidG4tZnVsbCBzdWNjZXNzLWJ0blwiIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKCcvcHJvZmlsZScpfT5cclxuICAgICAgICAgICAgICBWaWV3IE15IFByb2ZpbGVcclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBFZGl0UHJvZmlsZTtcclxuIl0sImZpbGUiOiJGOi9ZM1MyL0lUUE0gcHJvamVjdC9Qcm9NYXRlLS1Qcm9qZWN0LVBhcnRuZXItRmluZGVyL2Zyb250ZW5kL3NyYy9wYWdlcy9Vc2Vycy9FZGl0UHJvZmlsZS5qc3gifQ==