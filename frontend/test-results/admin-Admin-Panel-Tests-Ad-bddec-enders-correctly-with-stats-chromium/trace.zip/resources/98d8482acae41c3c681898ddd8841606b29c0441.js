import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/RecEngine/ProjectRecommendations.jsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectRecommendations.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=383bea9f"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Navbar from "/src/components/Navbar.jsx";
const Recommendations = () => {
  _s();
  const [projects, setProjects] = useState([]);
  useEffect(() => {
    fetch("http://localhost:3000/api/recommendations/projects/S1").then((res) => res.json()).then((data) => setProjects(data));
  }, []);
  return /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-screen", children: /* @__PURE__ */ jsxDEV("div", { className: "flex-1 p-6 bg-surface", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "mb-6 flex justify-end", children: /* @__PURE__ */ jsxDEV("button", { onClick: () => window.location.href = "/feedbacks", className: "relative w-full max-w-xs px-6 py-3 font-semibold text-white rounded-xl \r\n               bg-gradient-to-r from-primary to-secondary\r\n               shadow-md hover:shadow-lg transition-transform duration-300 hover:scale-105\r\n               text-sm text-center", children: "Rate Recommendations⭐⭐" }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectRecommendations.jsx",
      lineNumber: 17,
      columnNumber: 3
    }, this) }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectRecommendations.jsx",
      lineNumber: 16,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6", children: projects.map((item, i) => {
      const percentage = (item.score * 100).toFixed(0);
      const progressColor = percentage > 75 ? "from-accent to-yellow-400" : percentage > 50 ? "from-primary to-blue-400" : "from-secondary to-pink-400";
      return /* @__PURE__ */ jsxDEV("div", { className: "relative rounded-xl p-[1px] bg-gradient-to-r from-primary via-secondary to-accent hover:scale-[1.02] transition duration-300", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl p-4 backdrop-blur-md shadow-md hover:shadow-lg transition", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-textPrimary mb-1", children: item.project.title }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectRecommendations.jsx",
          lineNumber: 33,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-textSecondary text-sm mb-3 line-clamp-3", children: item.project.description }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectRecommendations.jsx",
          lineNumber: 38,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 mb-3", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "relative w-12 h-12", children: [
            /* @__PURE__ */ jsxDEV("svg", { className: "w-12 h-12 transform -rotate-90", children: [
              /* @__PURE__ */ jsxDEV("circle", { cx: "24", cy: "24", r: "20", className: "stroke-gray-200", strokeWidth: "5", fill: "none" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectRecommendations.jsx",
                lineNumber: 47,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("circle", { cx: "24", cy: "24", r: "20", stroke: "url(#grad)", strokeWidth: "5", fill: "none", strokeDasharray: 2 * Math.PI * 20, strokeDashoffset: 2 * Math.PI * 20 * (1 - percentage / 100), strokeLinecap: "round" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectRecommendations.jsx",
                lineNumber: 48,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("defs", { children: /* @__PURE__ */ jsxDEV("linearGradient", { id: "grad", children: [
                /* @__PURE__ */ jsxDEV("stop", { offset: "0%", stopColor: "#3B82F6" }, void 0, false, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectRecommendations.jsx",
                  lineNumber: 51,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("stop", { offset: "50%", stopColor: "#F472B6" }, void 0, false, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectRecommendations.jsx",
                  lineNumber: 52,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("stop", { offset: "100%", stopColor: "#FACC15" }, void 0, false, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectRecommendations.jsx",
                  lineNumber: 53,
                  columnNumber: 29
                }, this)
              ] }, void 0, true, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectRecommendations.jsx",
                lineNumber: 50,
                columnNumber: 27
              }, this) }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectRecommendations.jsx",
                lineNumber: 49,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectRecommendations.jsx",
              lineNumber: 46,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 flex items-center justify-center text-xs font-bold text-textPrimary", children: [
              percentage,
              "%"
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectRecommendations.jsx",
              lineNumber: 58,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectRecommendations.jsx",
            lineNumber: 45,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "text-sm", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-textSecondary", children: "Match Score" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectRecommendations.jsx",
              lineNumber: 65,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent", children: [
              percentage,
              "%"
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectRecommendations.jsx",
              lineNumber: 66,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectRecommendations.jsx",
            lineNumber: 64,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectRecommendations.jsx",
          lineNumber: 43,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-textPrimary mb-3 line-clamp-3", children: item.explanation }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectRecommendations.jsx",
          lineNumber: 73,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2 mt-2", children: item.details?.matchedSkills?.map((skill, idx) => /* @__PURE__ */ jsxDEV("span", { className: "text-xs bg-blue-100 text-blue-600 px-2 py-1 rounded", children: skill }, idx, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectRecommendations.jsx",
          lineNumber: 79,
          columnNumber: 67
        }, this)) }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectRecommendations.jsx",
          lineNumber: 78,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2 mb-3 mt-3", children: item.project.domain?.map((d, index) => /* @__PURE__ */ jsxDEV("span", { className: "text-xs px-2 py-1 rounded-full bg-gradient-to-r from-primary/20 to-secondary/20 text-primary font-medium", children: d }, index, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectRecommendations.jsx",
          lineNumber: 86,
          columnNumber: 61
        }, this)) }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectRecommendations.jsx",
          lineNumber: 85,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV("button", { onClick: () => window.location.href = "/projectview", className: "w-full py-2 rounded-lg font-medium text-white bg-primary hover:from-secondary hover:to-primary transition-all duration-300 shadow-sm hover:shadow-md text-sm", children: "View Project" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectRecommendations.jsx",
          lineNumber: 92,
          columnNumber: 19
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectRecommendations.jsx",
        lineNumber: 31,
        columnNumber: 17
      }, this) }, i, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectRecommendations.jsx",
        lineNumber: 29,
        columnNumber: 18
      }, this);
    }) }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectRecommendations.jsx",
      lineNumber: 25,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectRecommendations.jsx",
    lineNumber: 13,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectRecommendations.jsx",
    lineNumber: 10,
    columnNumber: 10
  }, this);
};
_s(Recommendations, "TSrpuQX6QU8EgjQSxaAzj2u9i4o=");
_c = Recommendations;
export default Recommendations;
var _c;
$RefreshReg$(_c, "Recommendations");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectRecommendations.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0JFOzs7Ozs7Ozs7Ozs7Ozs7O0FBcEJGLE9BQU9BLFNBQVNDLFdBQVdDLGdCQUFnQjtBQUMzQyxPQUFPQyxZQUFZO0FBRW5CLE1BQU1DLGtCQUFrQkEsTUFBTTtBQUFBQyxLQUFBO0FBQzVCLFFBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJTCxTQUFTLEVBQUU7QUFFM0NELFlBQVUsTUFBTTtBQUNkTyxVQUFNLHVEQUF1RCxFQUMxREMsS0FBTUMsU0FBUUEsSUFBSUMsS0FBSyxDQUFDLEVBQ3hCRixLQUFNRyxVQUFTTCxZQUFZSyxJQUFJLENBQUM7QUFBQSxFQUNyQyxHQUFHLEVBQUU7QUFFTCxTQUNFLHVCQUFDLFNBQUksV0FBVSxxQkFHYixpQ0FBQyxTQUFJLFdBQVUseUJBR2I7QUFBQSwyQkFBQyxTQUFJLFdBQVUseUJBQ3JCLGlDQUFDLFlBQ0MsU0FBUyxNQUFNQyxPQUFPQyxTQUFTQyxPQUFPLGNBQ3RDLFdBQVUsNFFBSVgsc0NBTkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVFBLEtBVE07QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVVSO0FBQUEsSUFFUSx1QkFBQyxTQUFJLFdBQVUsMkRBQ1pULG1CQUFTVSxJQUFJLENBQUNDLE1BQU1DLE1BQU07QUFDekIsWUFBTUMsY0FBY0YsS0FBS0csUUFBUSxLQUFLQyxRQUFRLENBQUM7QUFFL0MsWUFBTUMsZ0JBQ0pILGFBQWEsS0FDVCw4QkFDQUEsYUFBYSxLQUNiLDZCQUNBO0FBRU4sYUFDRSx1QkFBQyxTQUVDLFdBQVUsZ0lBR1YsaUNBQUMsU0FBSSxXQUFVLGlGQUViO0FBQUEsK0JBQUMsUUFBRyxXQUFVLCtDQUNYRixlQUFLTSxRQUFRQyxTQURoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUdBLHVCQUFDLE9BQUUsV0FBVSxnREFDVlAsZUFBS00sUUFBUUUsZUFEaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUsZ0NBRWI7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsc0JBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsa0NBQ2I7QUFBQSxxQ0FBQyxZQUNDLElBQUcsTUFDSCxJQUFHLE1BQ0gsR0FBRSxNQUNGLFdBQVUsbUJBQ1YsYUFBWSxLQUNaLE1BQUssVUFOUDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU1hO0FBQUEsY0FFYix1QkFBQyxZQUNDLElBQUcsTUFDSCxJQUFHLE1BQ0gsR0FBRSxNQUNGLFFBQU8sY0FDUCxhQUFZLEtBQ1osTUFBSyxRQUNMLGlCQUFpQixJQUFJQyxLQUFLQyxLQUFLLElBQy9CLGtCQUNFLElBQUlELEtBQUtDLEtBQUssTUFBTSxJQUFJUixhQUFhLE1BRXZDLGVBQWMsV0FYaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFXdUI7QUFBQSxjQUV2Qix1QkFBQyxVQUNDLGlDQUFDLG9CQUFlLElBQUcsUUFDakI7QUFBQSx1Q0FBQyxVQUFLLFFBQU8sTUFBSyxXQUFVLGFBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXFDO0FBQUEsZ0JBQ3JDLHVCQUFDLFVBQUssUUFBTyxPQUFNLFdBQVUsYUFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBc0M7QUFBQSxnQkFDdEMsdUJBQUMsVUFBSyxRQUFPLFFBQU8sV0FBVSxhQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF1QztBQUFBLG1CQUh6QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUlBLEtBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFNQTtBQUFBLGlCQTVCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTZCQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLHdGQUNaQTtBQUFBQTtBQUFBQSxjQUFXO0FBQUEsaUJBRGQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBbENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUNBO0FBQUEsVUFHQSx1QkFBQyxTQUFJLFdBQVUsV0FDYjtBQUFBLG1DQUFDLE9BQUUsV0FBVSxzQkFBcUIsMkJBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZDO0FBQUEsWUFDN0MsdUJBQUMsT0FBRSxXQUFVLHNGQUNWQTtBQUFBQTtBQUFBQSxjQUFXO0FBQUEsaUJBRGQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLGFBN0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE4Q0E7QUFBQSxRQUdBLHVCQUFDLE9BQUUsV0FBVSw4Q0FDVkYsZUFBS1csZUFEUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUdKLHVCQUFDLFNBQUksV0FBVSw2QkFDWlgsZUFBS1ksU0FBU0MsZUFBZWQsSUFBSSxDQUFDZSxPQUFPQyxRQUN4Qyx1QkFBQyxVQUVDLFdBQVUsdURBRVRELG1CQUhJQyxLQURQO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQSxDQUNELEtBUkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsUUFHSSx1QkFBQyxTQUFJLFdBQVUsa0NBQ1pmLGVBQUtNLFFBQVFVLFFBQVFqQixJQUFJLENBQUNrQixHQUFHQyxVQUM1Qix1QkFBQyxVQUVDLFdBQVUsNEdBRVRELGVBSElDLE9BRFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBLENBQ0QsS0FSSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0E7QUFBQSxRQUdBLHVCQUFDLFlBQ0QsU0FBUyxNQUFNdEIsT0FBT0MsU0FBU0MsT0FBTyxnQkFDdEMsV0FBVSxnS0FBK0osNEJBRnpLO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQTtBQUFBLFdBOUZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUErRkEsS0FuR0tHLEdBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXFHQTtBQUFBLElBRUosQ0FBQyxLQW5ISDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBb0hBO0FBQUEsT0FuSUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW9JQSxLQXZJRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBd0lBO0FBRUo7QUFBRWIsR0FwSklELGlCQUFlO0FBQUFnQyxLQUFmaEM7QUFzSk4sZUFBZUE7QUFBZ0IsSUFBQWdDO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiTmF2YmFyIiwiUmVjb21tZW5kYXRpb25zIiwiX3MiLCJwcm9qZWN0cyIsInNldFByb2plY3RzIiwiZmV0Y2giLCJ0aGVuIiwicmVzIiwianNvbiIsImRhdGEiLCJ3aW5kb3ciLCJsb2NhdGlvbiIsImhyZWYiLCJtYXAiLCJpdGVtIiwiaSIsInBlcmNlbnRhZ2UiLCJzY29yZSIsInRvRml4ZWQiLCJwcm9ncmVzc0NvbG9yIiwicHJvamVjdCIsInRpdGxlIiwiZGVzY3JpcHRpb24iLCJNYXRoIiwiUEkiLCJleHBsYW5hdGlvbiIsImRldGFpbHMiLCJtYXRjaGVkU2tpbGxzIiwic2tpbGwiLCJpZHgiLCJkb21haW4iLCJkIiwiaW5kZXgiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlByb2plY3RSZWNvbW1lbmRhdGlvbnMuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBOYXZiYXIgZnJvbSBcIi4uLy4uL2NvbXBvbmVudHMvTmF2YmFyXCI7XHJcblxyXG5jb25zdCBSZWNvbW1lbmRhdGlvbnMgPSAoKSA9PiB7XHJcbiAgY29uc3QgW3Byb2plY3RzLCBzZXRQcm9qZWN0c10gPSB1c2VTdGF0ZShbXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBmZXRjaChcImh0dHA6Ly9sb2NhbGhvc3Q6MzAwMC9hcGkvcmVjb21tZW5kYXRpb25zL3Byb2plY3RzL1MxXCIpXHJcbiAgICAgIC50aGVuKChyZXMpID0+IHJlcy5qc29uKCkpXHJcbiAgICAgIC50aGVuKChkYXRhKSA9PiBzZXRQcm9qZWN0cyhkYXRhKSk7XHJcbiAgfSwgW10pO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG1pbi1oLXNjcmVlblwiPlxyXG5cclxuICAgICAgey8qIE1haW4gY29udGVudCAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgcC02IGJnLXN1cmZhY2VcIj5cclxuXHJcbiAgICAgICAgey8qIEJ1dHRvbiAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTYgZmxleCBqdXN0aWZ5LWVuZFwiPlxyXG4gIDxidXR0b25cclxuICAgIG9uQ2xpY2s9eygpID0+IHdpbmRvdy5sb2NhdGlvbi5ocmVmID0gXCIvZmVlZGJhY2tzXCJ9XHJcbiAgICBjbGFzc05hbWU9XCJyZWxhdGl2ZSB3LWZ1bGwgbWF4LXcteHMgcHgtNiBweS0zIGZvbnQtc2VtaWJvbGQgdGV4dC13aGl0ZSByb3VuZGVkLXhsIFxyXG4gICAgICAgICAgICAgICBiZy1ncmFkaWVudC10by1yIGZyb20tcHJpbWFyeSB0by1zZWNvbmRhcnlcclxuICAgICAgICAgICAgICAgc2hhZG93LW1kIGhvdmVyOnNoYWRvdy1sZyB0cmFuc2l0aW9uLXRyYW5zZm9ybSBkdXJhdGlvbi0zMDAgaG92ZXI6c2NhbGUtMTA1XHJcbiAgICAgICAgICAgICAgIHRleHQtc20gdGV4dC1jZW50ZXJcIlxyXG4gID5cclxuICAgIFJhdGUgUmVjb21tZW5kYXRpb25z4q2Q4q2QXHJcbiAgPC9idXR0b24+XHJcbjwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgc206Z3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTMgZ2FwLTZcIj5cclxuICAgICAgICAgIHtwcm9qZWN0cy5tYXAoKGl0ZW0sIGkpID0+IHtcclxuICAgICAgICAgICAgY29uc3QgcGVyY2VudGFnZSA9IChpdGVtLnNjb3JlICogMTAwKS50b0ZpeGVkKDApO1xyXG5cclxuICAgICAgICAgICAgY29uc3QgcHJvZ3Jlc3NDb2xvciA9XHJcbiAgICAgICAgICAgICAgcGVyY2VudGFnZSA+IDc1XHJcbiAgICAgICAgICAgICAgICA/IFwiZnJvbS1hY2NlbnQgdG8teWVsbG93LTQwMFwiXHJcbiAgICAgICAgICAgICAgICA6IHBlcmNlbnRhZ2UgPiA1MFxyXG4gICAgICAgICAgICAgICAgPyBcImZyb20tcHJpbWFyeSB0by1ibHVlLTQwMFwiXHJcbiAgICAgICAgICAgICAgICA6IFwiZnJvbS1zZWNvbmRhcnkgdG8tcGluay00MDBcIjtcclxuXHJcbiAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAga2V5PXtpfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicmVsYXRpdmUgcm91bmRlZC14bCBwLVsxcHhdIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1wcmltYXJ5IHZpYS1zZWNvbmRhcnkgdG8tYWNjZW50IGhvdmVyOnNjYWxlLVsxLjAyXSB0cmFuc2l0aW9uIGR1cmF0aW9uLTMwMFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgey8qIENhcmQgKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQteGwgcC00IGJhY2tkcm9wLWJsdXItbWQgc2hhZG93LW1kIGhvdmVyOnNoYWRvdy1sZyB0cmFuc2l0aW9uXCI+XHJcbiAgICAgICAgICAgICAgICAgIHsvKiBUaXRsZSAqL31cclxuICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LXRleHRQcmltYXJ5IG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICB7aXRlbS5wcm9qZWN0LnRpdGxlfVxyXG4gICAgICAgICAgICAgICAgICA8L2gzPlxyXG5cclxuICAgICAgICAgICAgICAgICAgey8qIERlc2NyaXB0aW9uICovfVxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXRleHRTZWNvbmRhcnkgdGV4dC1zbSBtYi0zIGxpbmUtY2xhbXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtpdGVtLnByb2plY3QuZGVzY3JpcHRpb259XHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHsvKiBTY29yZSBTZWN0aW9uICovfVxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00IG1iLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICB7LyogR3JhZGllbnQgQ2lyY2xlICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgdy0xMiBoLTEyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3ZnIGNsYXNzTmFtZT1cInctMTIgaC0xMiB0cmFuc2Zvcm0gLXJvdGF0ZS05MFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Y2lyY2xlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY3g9XCIyNFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY3k9XCIyNFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcj1cIjIwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzdHJva2UtZ3JheS0yMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZVdpZHRoPVwiNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZmlsbD1cIm5vbmVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Y2lyY2xlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY3g9XCIyNFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY3k9XCIyNFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcj1cIjIwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzdHJva2U9XCJ1cmwoI2dyYWQpXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzdHJva2VXaWR0aD1cIjVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGZpbGw9XCJub25lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzdHJva2VEYXNoYXJyYXk9ezIgKiBNYXRoLlBJICogMjB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlRGFzaG9mZnNldD17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAyICogTWF0aC5QSSAqIDIwICogKDEgLSBwZXJjZW50YWdlIC8gMTAwKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGVmcz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8bGluZWFyR3JhZGllbnQgaWQ9XCJncmFkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3RvcCBvZmZzZXQ9XCIwJVwiIHN0b3BDb2xvcj1cIiMzQjgyRjZcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHN0b3Agb2Zmc2V0PVwiNTAlXCIgc3RvcENvbG9yPVwiI0Y0NzJCNlwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3RvcCBvZmZzZXQ9XCIxMDAlXCIgc3RvcENvbG9yPVwiI0ZBQ0MxNVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9saW5lYXJHcmFkaWVudD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kZWZzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zdmc+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQteHMgZm9udC1ib2xkIHRleHQtdGV4dFByaW1hcnlcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3BlcmNlbnRhZ2V9JVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBTY29yZSBUZXh0ICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC10ZXh0U2Vjb25kYXJ5XCI+TWF0Y2ggU2NvcmU8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LWJvbGQgYmctZ3JhZGllbnQtdG8tciBmcm9tLXByaW1hcnkgdG8tc2Vjb25kYXJ5IGJnLWNsaXAtdGV4dCB0ZXh0LXRyYW5zcGFyZW50XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtwZXJjZW50YWdlfSVcclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICB7LyogRXhwbGFuYXRpb24gKi99XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC10ZXh0UHJpbWFyeSBtYi0zIGxpbmUtY2xhbXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtpdGVtLmV4cGxhbmF0aW9ufVxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcblxyXG4gICAgICAgICAgICAgICAgICB7LyogTWF0Y2hlZCBTa2lsbHMgKi99XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBnYXAtMiBtdC0yXCI+XHJcbiAgICAgICAgICAgICAgICB7aXRlbS5kZXRhaWxzPy5tYXRjaGVkU2tpbGxzPy5tYXAoKHNraWxsLCBpZHgpID0+IChcclxuICAgICAgICAgICAgICAgICAgPHNwYW5cclxuICAgICAgICAgICAgICAgICAgICBrZXk9e2lkeH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXhzIGJnLWJsdWUtMTAwIHRleHQtYmx1ZS02MDAgcHgtMiBweS0xIHJvdW5kZWRcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge3NraWxsfVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHsvKiBUYWdzICovfVxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGdhcC0yIG1iLTMgbXQtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtpdGVtLnByb2plY3QuZG9tYWluPy5tYXAoKGQsIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2luZGV4fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXhzIHB4LTIgcHktMSByb3VuZGVkLWZ1bGwgYmctZ3JhZGllbnQtdG8tciBmcm9tLXByaW1hcnkvMjAgdG8tc2Vjb25kYXJ5LzIwIHRleHQtcHJpbWFyeSBmb250LW1lZGl1bVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHsvKiBCdXR0b24gKi99XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b24gXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHdpbmRvdy5sb2NhdGlvbi5ocmVmID0gXCIvcHJvamVjdHZpZXdcIn1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB5LTIgcm91bmRlZC1sZyBmb250LW1lZGl1bSB0ZXh0LXdoaXRlIGJnLXByaW1hcnkgaG92ZXI6ZnJvbS1zZWNvbmRhcnkgaG92ZXI6dG8tcHJpbWFyeSB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDAgc2hhZG93LXNtIGhvdmVyOnNoYWRvdy1tZCB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgVmlldyBQcm9qZWN0XHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICk7XHJcbiAgICAgICAgICB9KX1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgUmVjb21tZW5kYXRpb25zOyJdLCJmaWxlIjoiRjovWTNTMi9JVFBNIHByb2plY3QvUHJvTWF0ZS0tUHJvamVjdC1QYXJ0bmVyLUZpbmRlci9mcm9udGVuZC9zcmMvcGFnZXMvUmVjRW5naW5lL1Byb2plY3RSZWNvbW1lbmRhdGlvbnMuanN4In0=