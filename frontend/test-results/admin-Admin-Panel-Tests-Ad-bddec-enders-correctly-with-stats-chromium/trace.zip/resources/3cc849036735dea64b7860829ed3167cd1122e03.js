import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/RecEngine/Feedbacks.jsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/Feedbacks.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=383bea9f"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"];
import Navbar from "/src/components/Navbar.jsx";
import { useForm } from "/node_modules/.vite/deps/react-hook-form.js?v=383bea9f";
import { motion } from "/node_modules/.vite/deps/framer-motion.js?v=383bea9f";
import { Star } from "/node_modules/.vite/deps/lucide-react.js?v=383bea9f";
const Feedbacks = () => {
  _s();
  const {
    register,
    handleSubmit,
    formState: {
      errors
    },
    reset,
    setValue
  } = useForm();
  const [rating, setRating] = useState(0);
  const [hover, setHover] = useState(0);
  const onSubmit = async (data) => {
    try {
      const payload = {
        ...data,
        rating,
        studentId: "S123"
      };
      const res = await fetch("http://localhost:3000/api/feedback", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(payload)
      });
      const result = await res.json();
      if (res.ok) {
        alert("Feedback submitted!");
        reset();
        setRating(0);
      } else {
        alert(result.message);
      }
    } catch (err) {
      alert("Error submitting feedback");
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-screen bg-gradient-to-br from-gray-100 to-gray-200", children: /* @__PURE__ */ jsxDEV("div", { className: "flex-1 p-10 bg-surface", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "mb-8", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "text-3xl font-bold text-textPrimary", children: "Feedback Center" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/Feedbacks.jsx",
        lineNumber: 58,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-textSecondary", children: "Help us improve your project recommendations" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/Feedbacks.jsx",
        lineNumber: 59,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/Feedbacks.jsx",
      lineNumber: 57,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-3 gap-6", children: [
      /* @__PURE__ */ jsxDEV(motion.div, { initial: {
        opacity: 0,
        y: 30
      }, animate: {
        opacity: 1,
        y: 0
      }, className: "bg-white rounded-2xl shadow-lg p-8 col-span-2", children: /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit(onSubmit), className: "space-y-6", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: "Rating" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/Feedbacks.jsx",
            lineNumber: 76,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: [1, 2, 3, 4, 5].map((star) => /* @__PURE__ */ jsxDEV(Star, { size: 32, className: `cursor-pointer transition ${(hover || rating) >= star ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}`, onClick: () => {
            setRating(star);
            setValue("rating", star);
          }, onMouseEnter: () => setHover(star), onMouseLeave: () => setHover(0) }, star, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/Feedbacks.jsx",
            lineNumber: 81,
            columnNumber: 48
          }, this)) }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/Feedbacks.jsx",
            lineNumber: 80,
            columnNumber: 17
          }, this),
          errors.rating && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: "Rating is required" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/Feedbacks.jsx",
            lineNumber: 87,
            columnNumber: 35
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/Feedbacks.jsx",
          lineNumber: 75,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-1", children: "Comments" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/Feedbacks.jsx",
            lineNumber: 92,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("textarea", { rows: "4", ...register("comments", {
            required: "Comments required",
            maxLength: {
              value: 300,
              message: "Max 300 characters"
            }
          }), placeholder: "Share your thoughts about the recommendations...", className: "w-full border border-gray-300 p-3 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/Feedbacks.jsx",
            lineNumber: 95,
            columnNumber: 17
          }, this),
          errors.comments && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.comments.message }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/Feedbacks.jsx",
            lineNumber: 102,
            columnNumber: 37
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/Feedbacks.jsx",
          lineNumber: 91,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: "What can we improve?" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/Feedbacks.jsx",
            lineNumber: 107,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-3", children: ["skills", "availability", "interest", "other"].map((item) => /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-2 bg-gray-50 border p-3 rounded-lg cursor-pointer hover:bg-gray-100", children: [
            /* @__PURE__ */ jsxDEV("input", { type: "checkbox", value: item, ...register("improvementAreas"), className: "accent-blue-600" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/Feedbacks.jsx",
              lineNumber: 113,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "capitalize text-gray-700", children: [
              item === "skills" && "Skills Matching",
              item === "availability" && "Availability",
              item === "interest" && "Interest Alignment",
              item === "other" && "Other"
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/Feedbacks.jsx",
              lineNumber: 114,
              columnNumber: 23
            }, this)
          ] }, item, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/Feedbacks.jsx",
            lineNumber: 112,
            columnNumber: 80
          }, this)) }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/Feedbacks.jsx",
            lineNumber: 111,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/Feedbacks.jsx",
          lineNumber: 106,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(motion.button, { whileHover: {
          scale: 1.03
        }, whileTap: {
          scale: 0.97
        }, type: "submit", className: "w-full bg-blue-600 text-white py-3 rounded-xl font-semibold shadow-md hover:bg-blue-700 transition", children: "Submit Feedback" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/Feedbacks.jsx",
          lineNumber: 125,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/Feedbacks.jsx",
        lineNumber: 72,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/Feedbacks.jsx",
        lineNumber: 65,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-5 rounded-xl shadow", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 text-sm font-semibold", children: "This Week" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/Feedbacks.jsx",
            lineNumber: 140,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-bold text-blue-600", children: "20 Projects" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/Feedbacks.jsx",
            lineNumber: 141,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-gray-600 text-sm", children: "You appeared as a top match" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/Feedbacks.jsx",
            lineNumber: 142,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/Feedbacks.jsx",
          lineNumber: 139,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-5 rounded-xl shadow", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 text-sm font-semibold", children: "Success Rate" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/Feedbacks.jsx",
            lineNumber: 146,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-bold text-accent", children: "85%" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/Feedbacks.jsx",
            lineNumber: 147,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-gray-600 text-sm", children: "Students accepted recommendations" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/Feedbacks.jsx",
            lineNumber: 148,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/Feedbacks.jsx",
          lineNumber: 145,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-5 rounded-xl shadow", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 text-sm font-semibold", children: "Your Strength" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/Feedbacks.jsx",
            lineNumber: 152,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-bold text-secondary", children: "AI & Web Dev" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/Feedbacks.jsx",
            lineNumber: 153,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-gray-600 text-sm", children: "Most matched skill areas" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/Feedbacks.jsx",
            lineNumber: 154,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/Feedbacks.jsx",
          lineNumber: 151,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-primary to-secondary\r\n               shadow-md hover:shadow-lg transition-transform duration-300 hover:scale-105\r\n               text-sm text-center text-white p-5 rounded-xl shadow", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-xl font-semibold", children: "Tip💡" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/Feedbacks.jsx",
            lineNumber: 160,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm mt-1 font-semibold", children: "Updating your skills increases match accuracy" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/Feedbacks.jsx",
            lineNumber: 161,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/Feedbacks.jsx",
          lineNumber: 157,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/Feedbacks.jsx",
        lineNumber: 137,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/Feedbacks.jsx",
      lineNumber: 62,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/Feedbacks.jsx",
    lineNumber: 54,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/Feedbacks.jsx",
    lineNumber: 46,
    columnNumber: 10
  }, this);
};
_s(Feedbacks, "/j0WDpmKj+ZxcwaAfBWTmNAdDxI=", false, function() {
  return [useForm];
});
_c = Feedbacks;
export default Feedbacks;
var _c;
$RefreshReg$(_c, "Feedbacks");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/Feedbacks.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOERVOzs7Ozs7Ozs7Ozs7Ozs7O0FBOURWLE9BQU9BLFNBQVNDLGdCQUFnQjtBQUNoQyxPQUFPQyxZQUFZO0FBQ25CLFNBQVNDLGVBQWU7QUFDeEIsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxZQUFZO0FBRXJCLE1BQU1DLFlBQVlBLE1BQU07QUFBQUMsS0FBQTtBQUN0QixRQUFNO0FBQUEsSUFDSkM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUMsV0FBVztBQUFBLE1BQUVDO0FBQUFBLElBQU87QUFBQSxJQUNwQkM7QUFBQUEsSUFDQUM7QUFBQUEsRUFDRixJQUFJVixRQUFRO0FBRVosUUFBTSxDQUFDVyxRQUFRQyxTQUFTLElBQUlkLFNBQVMsQ0FBQztBQUN0QyxRQUFNLENBQUNlLE9BQU9DLFFBQVEsSUFBSWhCLFNBQVMsQ0FBQztBQUVwQyxRQUFNaUIsV0FBVyxPQUFPQyxTQUFTO0FBQy9CLFFBQUk7QUFDRixZQUFNQyxVQUFVO0FBQUEsUUFDZCxHQUFHRDtBQUFBQSxRQUNITDtBQUFBQSxRQUNBTyxXQUFXO0FBQUEsTUFDYjtBQUVBLFlBQU1DLE1BQU0sTUFBTUMsTUFBTSxzQ0FBc0M7QUFBQSxRQUM1REMsUUFBUTtBQUFBLFFBQ1JDLFNBQVM7QUFBQSxVQUNQLGdCQUFnQjtBQUFBLFFBQ2xCO0FBQUEsUUFDQUMsTUFBTUMsS0FBS0MsVUFBVVIsT0FBTztBQUFBLE1BQzlCLENBQUM7QUFFRCxZQUFNUyxTQUFTLE1BQU1QLElBQUlRLEtBQUs7QUFFOUIsVUFBSVIsSUFBSVMsSUFBSTtBQUNWQyxjQUFNLHFCQUFxQjtBQUMzQnBCLGNBQU07QUFDTkcsa0JBQVUsQ0FBQztBQUFBLE1BQ2IsT0FBTztBQUNMaUIsY0FBTUgsT0FBT0ksT0FBTztBQUFBLE1BQ3RCO0FBQUEsSUFFRixTQUFTQyxLQUFLO0FBQ1pGLFlBQU0sMkJBQTJCO0FBQUEsSUFDbkM7QUFBQSxFQUNGO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsaUVBUWIsaUNBQUMsU0FBSSxXQUFVLDBCQUdiO0FBQUEsMkJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSw2QkFBQyxRQUFHLFdBQVUsdUNBQXNDLCtCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1FO0FBQUEsTUFDbkUsdUJBQUMsT0FBRSxXQUFVLHNCQUFxQiw0REFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4RTtBQUFBLFNBRmhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLDBCQUdiO0FBQUEsNkJBQUMsT0FBTyxLQUFQLEVBQ0MsU0FBUztBQUFBLFFBQUVHLFNBQVM7QUFBQSxRQUFHQyxHQUFHO0FBQUEsTUFBRyxHQUM3QixTQUFTO0FBQUEsUUFBRUQsU0FBUztBQUFBLFFBQUdDLEdBQUc7QUFBQSxNQUFFLEdBQzVCLFdBQVUsaURBRVYsaUNBQUMsVUFBSyxVQUFVM0IsYUFBYVMsUUFBUSxHQUFHLFdBQVUsYUFHaEQ7QUFBQSwrQkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLGtEQUFpRCxzQkFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLGNBQ1osV0FBQyxHQUFHLEdBQUcsR0FBRyxHQUFHLENBQUMsRUFBRW1CLElBQUtDLFVBQ3BCLHVCQUFDLFFBRUMsTUFBTSxJQUNOLFdBQVcsOEJBQ1J0QixTQUFTRixXQUFXd0IsT0FDakIsb0NBQ0EsZUFBZSxJQUVyQixTQUFTLE1BQU07QUFDYnZCLHNCQUFVdUIsSUFBSTtBQUNkekIscUJBQVMsVUFBVXlCLElBQUk7QUFBQSxVQUN6QixHQUNBLGNBQWMsTUFBTXJCLFNBQVNxQixJQUFJLEdBQ2pDLGNBQWMsTUFBTXJCLFNBQVMsQ0FBQyxLQVp6QnFCLE1BRFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFha0MsQ0FFbkMsS0FqQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFrQkE7QUFBQSxVQUVDM0IsT0FBT0csVUFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQTRCLGtDQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyRDtBQUFBLGFBMUIvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBNEJBO0FBQUEsUUFHQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLGtEQUFpRCx3QkFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsY0FDQyxNQUFLLEtBQ0wsR0FBSU4sU0FBUyxZQUFZO0FBQUEsWUFDdkIrQixVQUFVO0FBQUEsWUFDVkMsV0FBVztBQUFBLGNBQ1RDLE9BQU87QUFBQSxjQUNQUixTQUFTO0FBQUEsWUFDWDtBQUFBLFVBQ0YsQ0FBQyxHQUNELGFBQVksb0RBQ1osV0FBVSxnR0FWWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVV3RztBQUFBLFVBRXZHdEIsT0FBTytCLFlBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUE2Qi9CLGlCQUFPK0IsU0FBU1QsV0FBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0U7QUFBQSxhQWpCdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW1CQTtBQUFBLFFBR0EsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFdBQU0sV0FBVSxrREFBaUQsb0NBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSwwQkFDWixXQUFDLFVBQVUsZ0JBQWdCLFlBQVksT0FBTyxFQUFFSSxJQUFLTSxVQUNwRCx1QkFBQyxXQUVDLFdBQVUsNkZBRVY7QUFBQSxtQ0FBQyxXQUNDLE1BQUssWUFDTCxPQUFPQSxNQUNQLEdBQUluQyxTQUFTLGtCQUFrQixHQUMvQixXQUFVLHFCQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSTZCO0FBQUEsWUFFN0IsdUJBQUMsVUFBSyxXQUFVLDRCQUNibUM7QUFBQUEsdUJBQVMsWUFBWTtBQUFBLGNBQ3JCQSxTQUFTLGtCQUFrQjtBQUFBLGNBQzNCQSxTQUFTLGNBQWM7QUFBQSxjQUN2QkEsU0FBUyxXQUFXO0FBQUEsaUJBSnZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxlQWRLQSxNQURQO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZ0JBLENBQ0QsS0FuQkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFvQkE7QUFBQSxhQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMEJBO0FBQUEsUUFHQSx1QkFBQyxPQUFPLFFBQVAsRUFDQyxZQUFZO0FBQUEsVUFBRUMsT0FBTztBQUFBLFFBQUssR0FDMUIsVUFBVTtBQUFBLFVBQUVBLE9BQU87QUFBQSxRQUFLLEdBQ3hCLE1BQUssVUFDTCxXQUFVLHNHQUNYLCtCQUxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFdBNUZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE4RkEsS0FuR0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW9HQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxXQUFVLGFBRWI7QUFBQSwrQkFBQyxTQUFJLFdBQVUsa0NBQ2I7QUFBQSxpQ0FBQyxPQUFFLFdBQVUsdUNBQXNDLHlCQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0RDtBQUFBLFVBQzVELHVCQUFDLFFBQUcsV0FBVSxvQ0FBbUMsMkJBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTREO0FBQUEsVUFDNUQsdUJBQUMsT0FBRSxXQUFVLHlCQUF3QiwyQ0FBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0U7QUFBQSxhQUhsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSUE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSxrQ0FDYjtBQUFBLGlDQUFDLE9BQUUsV0FBVSx1Q0FBc0MsNEJBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStEO0FBQUEsVUFDL0QsdUJBQUMsUUFBRyxXQUFVLGtDQUFpQyxtQkFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0Q7QUFBQSxVQUNsRCx1QkFBQyxPQUFFLFdBQVUseUJBQXdCLGlEQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzRTtBQUFBLGFBSHhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLGtDQUNiO0FBQUEsaUNBQUMsT0FBRSxXQUFVLHVDQUFzQyw2QkFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0U7QUFBQSxVQUNoRSx1QkFBQyxRQUFHLFdBQVUsb0NBQW1DLDRCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE2RDtBQUFBLFVBQzdELHVCQUFDLE9BQUUsV0FBVSx5QkFBd0Isd0NBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZEO0FBQUEsYUFIL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsbU5BR2I7QUFBQSxpQ0FBQyxPQUFFLFdBQVUseUJBQXdCLHFCQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwQztBQUFBLFVBQzFDLHVCQUFDLE9BQUUsV0FBVSw4QkFBNkIsNkRBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVGO0FBQUEsYUFKekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsV0F6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTJCQTtBQUFBLFNBcklGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1SUE7QUFBQSxPQS9JRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBaUpBLEtBekpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EwSkE7QUFFSjtBQUFDckMsR0F4TUtELFdBQVM7QUFBQSxVQU9USCxPQUFPO0FBQUE7QUFBQTBDLEtBUFB2QztBQTBNTixlQUFlQTtBQUFVLElBQUF1QztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJ1c2VTdGF0ZSIsIk5hdmJhciIsInVzZUZvcm0iLCJtb3Rpb24iLCJTdGFyIiwiRmVlZGJhY2tzIiwiX3MiLCJyZWdpc3RlciIsImhhbmRsZVN1Ym1pdCIsImZvcm1TdGF0ZSIsImVycm9ycyIsInJlc2V0Iiwic2V0VmFsdWUiLCJyYXRpbmciLCJzZXRSYXRpbmciLCJob3ZlciIsInNldEhvdmVyIiwib25TdWJtaXQiLCJkYXRhIiwicGF5bG9hZCIsInN0dWRlbnRJZCIsInJlcyIsImZldGNoIiwibWV0aG9kIiwiaGVhZGVycyIsImJvZHkiLCJKU09OIiwic3RyaW5naWZ5IiwicmVzdWx0IiwianNvbiIsIm9rIiwiYWxlcnQiLCJtZXNzYWdlIiwiZXJyIiwib3BhY2l0eSIsInkiLCJtYXAiLCJzdGFyIiwicmVxdWlyZWQiLCJtYXhMZW5ndGgiLCJ2YWx1ZSIsImNvbW1lbnRzIiwiaXRlbSIsInNjYWxlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJGZWVkYmFja3MuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gJy4uLy4uL2NvbXBvbmVudHMvTmF2YmFyJ1xyXG5pbXBvcnQgeyB1c2VGb3JtIH0gZnJvbSBcInJlYWN0LWhvb2stZm9ybVwiO1xyXG5pbXBvcnQgeyBtb3Rpb24gfSBmcm9tIFwiZnJhbWVyLW1vdGlvblwiO1xyXG5pbXBvcnQgeyBTdGFyIH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xyXG5cclxuY29uc3QgRmVlZGJhY2tzID0gKCkgPT4ge1xyXG4gIGNvbnN0IHtcclxuICAgIHJlZ2lzdGVyLFxyXG4gICAgaGFuZGxlU3VibWl0LFxyXG4gICAgZm9ybVN0YXRlOiB7IGVycm9ycyB9LFxyXG4gICAgcmVzZXQsXHJcbiAgICBzZXRWYWx1ZVxyXG4gIH0gPSB1c2VGb3JtKCk7XHJcblxyXG4gIGNvbnN0IFtyYXRpbmcsIHNldFJhdGluZ10gPSB1c2VTdGF0ZSgwKTtcclxuICBjb25zdCBbaG92ZXIsIHNldEhvdmVyXSA9IHVzZVN0YXRlKDApO1xyXG5cclxuICBjb25zdCBvblN1Ym1pdCA9IGFzeW5jIChkYXRhKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCBwYXlsb2FkID0ge1xyXG4gICAgICAgIC4uLmRhdGEsXHJcbiAgICAgICAgcmF0aW5nLFxyXG4gICAgICAgIHN0dWRlbnRJZDogXCJTMTIzXCIsXHJcbiAgICAgIH07XHJcblxyXG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaChcImh0dHA6Ly9sb2NhbGhvc3Q6MzAwMC9hcGkvZmVlZGJhY2tcIiwge1xyXG4gICAgICAgIG1ldGhvZDogXCJQT1NUXCIsXHJcbiAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIsXHJcbiAgICAgICAgfSxcclxuICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeShwYXlsb2FkKSxcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCByZXMuanNvbigpO1xyXG5cclxuICAgICAgaWYgKHJlcy5vaykge1xyXG4gICAgICAgIGFsZXJ0KFwiRmVlZGJhY2sgc3VibWl0dGVkIVwiKTtcclxuICAgICAgICByZXNldCgpO1xyXG4gICAgICAgIHNldFJhdGluZygwKTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBhbGVydChyZXN1bHQubWVzc2FnZSk7XHJcbiAgICAgIH1cclxuXHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgYWxlcnQoXCJFcnJvciBzdWJtaXR0aW5nIGZlZWRiYWNrXCIpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbWluLWgtc2NyZWVuIGJnLWdyYWRpZW50LXRvLWJyIGZyb20tZ3JheS0xMDAgdG8tZ3JheS0yMDBcIj5cclxuXHJcbiAgICAgIHsvKiBTaWRlYmFyXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy02NCBiZy1ncmF5LTkwMCB0ZXh0LXdoaXRlIHNoYWRvdy14bFwiPlxyXG4gICAgICAgIDxOYXZiYXIgLz5cclxuICAgICAgPC9kaXY+ICovfVxyXG5cclxuICAgICAgey8qIE1haW4gQ29udGVudCAqL31cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgcC0xMCBiZy1zdXJmYWNlXCI+XHJcblxyXG4gICAgICAgIHsvKiBIZWFkZXIgKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi04XCI+XHJcbiAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ib2xkIHRleHQtdGV4dFByaW1hcnlcIj5GZWVkYmFjayBDZW50ZXI8L2gxPlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC10ZXh0U2Vjb25kYXJ5XCI+SGVscCB1cyBpbXByb3ZlIHlvdXIgcHJvamVjdCByZWNvbW1lbmRhdGlvbnM8L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMyBnYXAtNlwiPlxyXG5cclxuICAgICAgICAgIHsvKiBMRUZUOiBGT1JNICovfVxyXG4gICAgICAgICAgPG1vdGlvbi5kaXZcclxuICAgICAgICAgICAgaW5pdGlhbD17eyBvcGFjaXR5OiAwLCB5OiAzMCB9fVxyXG4gICAgICAgICAgICBhbmltYXRlPXt7IG9wYWNpdHk6IDEsIHk6IDAgfX1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC0yeGwgc2hhZG93LWxnIHAtOCBjb2wtc3Bhbi0yXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdChvblN1Ym1pdCl9IGNsYXNzTmFtZT1cInNwYWNlLXktNlwiPlxyXG5cclxuICAgICAgICAgICAgICB7Lyog4q2QIFNUQVIgUkFUSU5HICovfVxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICBSYXRpbmdcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtbMSwgMiwgMywgNCwgNV0ubWFwKChzdGFyKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPFN0YXJcclxuICAgICAgICAgICAgICAgICAgICAgIGtleT17c3Rhcn1cclxuICAgICAgICAgICAgICAgICAgICAgIHNpemU9ezMyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgY3Vyc29yLXBvaW50ZXIgdHJhbnNpdGlvbiAke1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAoaG92ZXIgfHwgcmF0aW5nKSA+PSBzdGFyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcInRleHQteWVsbG93LTQwMCBmaWxsLXllbGxvdy00MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJ0ZXh0LWdyYXktMzAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRSYXRpbmcoc3Rhcik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFZhbHVlKFwicmF0aW5nXCIsIHN0YXIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uTW91c2VFbnRlcj17KCkgPT4gc2V0SG92ZXIoc3Rhcil9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbk1vdXNlTGVhdmU9eygpID0+IHNldEhvdmVyKDApfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAge2Vycm9ycy5yYXRpbmcgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC1zbSBtdC0xXCI+UmF0aW5nIGlzIHJlcXVpcmVkPC9wPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgey8qIENvbW1lbnRzICovfVxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICBDb21tZW50c1xyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDx0ZXh0YXJlYVxyXG4gICAgICAgICAgICAgICAgICByb3dzPVwiNFwiXHJcbiAgICAgICAgICAgICAgICAgIHsuLi5yZWdpc3RlcihcImNvbW1lbnRzXCIsIHtcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZDogXCJDb21tZW50cyByZXF1aXJlZFwiLFxyXG4gICAgICAgICAgICAgICAgICAgIG1heExlbmd0aDoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU6IDMwMCxcclxuICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IFwiTWF4IDMwMCBjaGFyYWN0ZXJzXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2hhcmUgeW91ciB0aG91Z2h0cyBhYm91dCB0aGUgcmVjb21tZW5kYXRpb25zLi4uXCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcC0zIHJvdW5kZWQtbGcgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYmx1ZS01MDAgb3V0bGluZS1ub25lXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICB7ZXJyb3JzLmNvbW1lbnRzICYmIChcclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQtc20gbXQtMVwiPntlcnJvcnMuY29tbWVudHMubWVzc2FnZX08L3A+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7LyogSW1wcm92ZW1lbnQgQXJlYXMgKi99XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIFdoYXQgY2FuIHdlIGltcHJvdmU/XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgICB7W1wic2tpbGxzXCIsIFwiYXZhaWxhYmlsaXR5XCIsIFwiaW50ZXJlc3RcIiwgXCJvdGhlclwiXS5tYXAoKGl0ZW0pID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGtleT17aXRlbX1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGJnLWdyYXktNTAgYm9yZGVyIHAtMyByb3VuZGVkLWxnIGN1cnNvci1wb2ludGVyIGhvdmVyOmJnLWdyYXktMTAwXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2l0ZW19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsuLi5yZWdpc3RlcihcImltcHJvdmVtZW50QXJlYXNcIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImFjY2VudC1ibHVlLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY2FwaXRhbGl6ZSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtID09PSBcInNraWxsc1wiICYmIFwiU2tpbGxzIE1hdGNoaW5nXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtID09PSBcImF2YWlsYWJpbGl0eVwiICYmIFwiQXZhaWxhYmlsaXR5XCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtID09PSBcImludGVyZXN0XCIgJiYgXCJJbnRlcmVzdCBBbGlnbm1lbnRcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0gPT09IFwib3RoZXJcIiAmJiBcIk90aGVyXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgey8qIFN1Ym1pdCAqL31cclxuICAgICAgICAgICAgICA8bW90aW9uLmJ1dHRvblxyXG4gICAgICAgICAgICAgICAgd2hpbGVIb3Zlcj17eyBzY2FsZTogMS4wMyB9fVxyXG4gICAgICAgICAgICAgICAgd2hpbGVUYXA9e3sgc2NhbGU6IDAuOTcgfX1cclxuICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLWJsdWUtNjAwIHRleHQtd2hpdGUgcHktMyByb3VuZGVkLXhsIGZvbnQtc2VtaWJvbGQgc2hhZG93LW1kIGhvdmVyOmJnLWJsdWUtNzAwIHRyYW5zaXRpb25cIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIFN1Ym1pdCBGZWVkYmFja1xyXG4gICAgICAgICAgICAgIDwvbW90aW9uLmJ1dHRvbj5cclxuXHJcbiAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgIDwvbW90aW9uLmRpdj5cclxuXHJcbiAgICAgICAgICB7LyogUklHSFQ6IElOU0lHSFRTIFBBTkVMICovfVxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcC01IHJvdW5kZWQteGwgc2hhZG93XCI+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGRcIj5UaGlzIFdlZWs8L3A+XHJcbiAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWJsdWUtNjAwXCI+MjAgUHJvamVjdHM8L2gyPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS02MDAgdGV4dC1zbVwiPllvdSBhcHBlYXJlZCBhcyBhIHRvcCBtYXRjaDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHAtNSByb3VuZGVkLXhsIHNoYWRvd1wiPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDAgdGV4dC1zbSBmb250LXNlbWlib2xkXCI+U3VjY2VzcyBSYXRlPC9wPlxyXG4gICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1hY2NlbnRcIj44NSU8L2gyPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS02MDAgdGV4dC1zbVwiPlN0dWRlbnRzIGFjY2VwdGVkIHJlY29tbWVuZGF0aW9uczwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHAtNSByb3VuZGVkLXhsIHNoYWRvd1wiPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDAgdGV4dC1zbSBmb250LXNlbWlib2xkXCI+WW91ciBTdHJlbmd0aDwvcD5cclxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1zZWNvbmRhcnlcIj5BSSAmIFdlYiBEZXY8L2gyPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS02MDAgdGV4dC1zbVwiPk1vc3QgbWF0Y2hlZCBza2lsbCBhcmVhczwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLXIgZnJvbS1wcmltYXJ5IHRvLXNlY29uZGFyeVxyXG4gICAgICAgICAgICAgICBzaGFkb3ctbWQgaG92ZXI6c2hhZG93LWxnIHRyYW5zaXRpb24tdHJhbnNmb3JtIGR1cmF0aW9uLTMwMCBob3ZlcjpzY2FsZS0xMDVcclxuICAgICAgICAgICAgICAgdGV4dC1zbSB0ZXh0LWNlbnRlciB0ZXh0LXdoaXRlIHAtNSByb3VuZGVkLXhsIHNoYWRvd1wiPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1zZW1pYm9sZFwiPlRpcPCfkqE8L3A+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBtdC0xIGZvbnQtc2VtaWJvbGRcIj5VcGRhdGluZyB5b3VyIHNraWxscyBpbmNyZWFzZXMgbWF0Y2ggYWNjdXJhY3k8L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBGZWVkYmFja3M7XHJcbiJdLCJmaWxlIjoiRjovWTNTMi9JVFBNIHByb2plY3QvUHJvTWF0ZS0tUHJvamVjdC1QYXJ0bmVyLUZpbmRlci9mcm9udGVuZC9zcmMvcGFnZXMvUmVjRW5naW5lL0ZlZWRiYWNrcy5qc3gifQ==