import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Projects/ProjectDetailsView.jsx");import { Fragment, jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=383bea9f"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { useParams, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=383bea9f";
import { useAuth } from "/src/context/AuthContext.jsx";
import "/src/pages/Projects/AllProjects.css";
const ProjectDetailsView = () => {
  _s();
  const {
    id
  } = useParams();
  const navigate = useNavigate();
  const {
    user,
    token
  } = useAuth();
  const [viewingProject, setViewingProject] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const fetchProject = async () => {
    try {
      const res = await fetch(`http://localhost:3000/api/posts/${id}`);
      if (res.ok) {
        const data = await res.json();
        const displayId = data.projectId || "P0000";
        setViewingProject({
          ...data,
          displayId,
          displayTitle: `${displayId} - ${data.title}`
        });
      } else {
        alert("Failed to fetch project details");
        navigate(-1);
      }
    } catch (err) {
      console.error(err);
      alert("Network error");
    } finally {
      setIsLoading(false);
    }
  };
  useEffect(() => {
    fetchProject();
  }, [id, navigate]);
  const handleJoin = async () => {
    const payload = {
      senderIt: user ? `${user.studentId} - ${user.fullName}` : "Unknown",
      targetIt: viewingProject.itNumber || "Unknown",
      message: `Requested to join ${viewingProject.displayTitle} project`,
      type: "join_request"
    };
    try {
      const res = await fetch("http://localhost:3000/api/notifications", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(payload)
      });
      if (res.ok) {
        alert("Join Request Sent to the Notifications Page!");
        navigate(-1);
      } else {
        alert("Failed to send request");
      }
    } catch (err) {
      console.error(err);
      alert("Network error");
    }
  };
  const handleDelete = async () => {
    if (!window.confirm("Delete this project forever?"))
      return;
    try {
      const res = await fetch(`http://localhost:3000/api/posts/${id}`, {
        method: "DELETE",
        headers: {
          "x-auth-token": token
        }
      });
      if (res.ok) {
        alert("Project deleted successfully");
        navigate("/your-projects");
      } else {
        alert("Failed to delete project");
      }
    } catch (err) {
      console.error(err);
    }
  };
  if (isLoading) {
    return /* @__PURE__ */ jsxDEV("div", { className: "all-loading", style: {
      marginTop: "100px"
    }, children: "Loading details..." }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
      lineNumber: 89,
      columnNumber: 12
    }, this);
  }
  if (!viewingProject) {
    return null;
  }
  const isOwner = user?.studentId === viewingProject.itNumber;
  return /* @__PURE__ */ jsxDEV("div", { className: "all-projects-container", style: {
    paddingTop: "40px",
    maxWidth: "900px",
    margin: "0 auto"
  }, children: [
    /* @__PURE__ */ jsxDEV("button", { onClick: () => navigate(-1), style: {
      marginBottom: "20px",
      background: "none",
      border: "none",
      color: "#3B82F6",
      cursor: "pointer",
      fontWeight: "600",
      fontSize: "15px"
    }, children: "← Back" }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
      lineNumber: 103,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: {
      background: "#fff",
      borderRadius: "12px",
      boxShadow: "0 20px 40px rgba(0,0,0,0.1)",
      overflow: "hidden"
    }, children: [
      /* @__PURE__ */ jsxDEV("div", { style: {
        padding: "24px",
        borderBottom: "1px solid #eaeaea"
      }, children: /* @__PURE__ */ jsxDEV("h2", { style: {
        margin: 0,
        fontSize: "24px",
        color: "#1e293b",
        fontWeight: "700"
      }, children: viewingProject.displayTitle }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
        lineNumber: 125,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
        lineNumber: 121,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "all-project-details-view relative", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "all-details-body", style: {
          paddingBottom: "32px"
        }, children: [
          /* @__PURE__ */ jsxDEV("div", { className: "all-details-meta", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "all-details-badge", children: viewingProject.projectType || "Project" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
              lineNumber: 138,
              columnNumber: 15
            }, this),
            viewingProject.teamSize && /* @__PURE__ */ jsxDEV("span", { className: "all-details-badge all-badge-team", children: [
              "Team of ",
              viewingProject.teamSize
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
              lineNumber: 139,
              columnNumber: 43
            }, this),
            viewingProject.itNumber && /* @__PURE__ */ jsxDEV("span", { className: "all-details-badge", style: {
              backgroundColor: "#f8fafc",
              color: "#475569",
              border: "1px solid #e2e8f0"
            }, children: [
              "IT NO: ",
              viewingProject.itNumber
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
              lineNumber: 140,
              columnNumber: 43
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
            lineNumber: 137,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("h3", { className: "all-section-title-mod", children: "Project Description" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
            lineNumber: 149,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "all-details-desc", children: viewingProject.description || "No description provided." }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
            lineNumber: 150,
            columnNumber: 13
          }, this),
          viewingProject.dueDate && /* @__PURE__ */ jsxDEV("div", { style: {
            fontSize: "15px",
            color: "#ef4444",
            marginBottom: "24px",
            fontWeight: "600"
          }, children: [
            "Due Date: ",
            /* @__PURE__ */ jsxDEV("span", { style: {
              color: "#1e293b"
            }, children: new Date(viewingProject.dueDate).toLocaleDateString("en-GB") }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
              lineNumber: 158,
              columnNumber: 27
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
            lineNumber: 152,
            columnNumber: 40
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "all-details-grid", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "all-details-section", children: [
              /* @__PURE__ */ jsxDEV("h4", { children: "Target Domain" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
                lineNumber: 165,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "all-details-tags", children: viewingProject.domain?.length > 0 ? viewingProject.domain.map((d, i) => /* @__PURE__ */ jsxDEV("span", { className: "all-skill-tag all-domain-tag-mod", children: d }, i, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
                lineNumber: 167,
                columnNumber: 92
              }, this)) : /* @__PURE__ */ jsxDEV("span", { className: "all-empty-text", children: "Not specified" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
                lineNumber: 167,
                columnNumber: 165
              }, this) }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
                lineNumber: 166,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
              lineNumber: 164,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "all-details-section", children: [
              /* @__PURE__ */ jsxDEV("h4", { children: "Academic Constraints" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
                lineNumber: 171,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("ul", { className: "all-stats-list", children: [
                /* @__PURE__ */ jsxDEV("li", { children: [
                  /* @__PURE__ */ jsxDEV("span", { children: "Specialization:" }, void 0, false, {
                    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
                    lineNumber: 173,
                    columnNumber: 23
                  }, this),
                  " ",
                  /* @__PURE__ */ jsxDEV("strong", { children: viewingProject.specialization || "Any" }, void 0, false, {
                    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
                    lineNumber: 173,
                    columnNumber: 52
                  }, this)
                ] }, void 0, true, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
                  lineNumber: 173,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("li", { children: [
                  /* @__PURE__ */ jsxDEV("span", { children: "Year/Sem:" }, void 0, false, {
                    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
                    lineNumber: 174,
                    columnNumber: 23
                  }, this),
                  " ",
                  /* @__PURE__ */ jsxDEV("strong", { children: [
                    viewingProject.year || "-",
                    " / ",
                    viewingProject.semester || "-"
                  ] }, void 0, true, {
                    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
                    lineNumber: 174,
                    columnNumber: 46
                  }, this)
                ] }, void 0, true, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
                  lineNumber: 174,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("li", { children: [
                  /* @__PURE__ */ jsxDEV("span", { children: "Min CGPA:" }, void 0, false, {
                    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
                    lineNumber: 175,
                    columnNumber: 23
                  }, this),
                  " ",
                  /* @__PURE__ */ jsxDEV("strong", { children: viewingProject.minimumCGPA || "None" }, void 0, false, {
                    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
                    lineNumber: 175,
                    columnNumber: 46
                  }, this)
                ] }, void 0, true, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
                  lineNumber: 175,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
                lineNumber: 172,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
              lineNumber: 170,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
            lineNumber: 163,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "all-skills-grid", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "all-details-section all-box-essential", children: [
              /* @__PURE__ */ jsxDEV("h4", { children: "Must Have Skills" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
                lineNumber: 182,
                columnNumber: 17
              }, this),
              ["languages", "frameworks", "databases", "libraries", "tools"].map((cat) => viewingProject.essentialSkills?.[cat]?.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "all-skill-category", children: [
                /* @__PURE__ */ jsxDEV("h5", { children: cat }, void 0, false, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
                  lineNumber: 184,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "all-details-tags", children: viewingProject.essentialSkills[cat].map((skill, i) => /* @__PURE__ */ jsxDEV("span", { className: "all-skill-tag all-essential-skill", children: skill }, i, false, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
                  lineNumber: 186,
                  columnNumber: 80
                }, this)) }, void 0, false, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
                  lineNumber: 185,
                  columnNumber: 23
                }, this)
              ] }, cat, true, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
                lineNumber: 183,
                columnNumber: 145
              }, this)),
              !["languages", "frameworks", "databases", "libraries", "tools"].some((cat) => viewingProject.essentialSkills?.[cat]?.length > 0) && /* @__PURE__ */ jsxDEV("span", { className: "all-empty-text", children: "No essential skills specified." }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
                lineNumber: 189,
                columnNumber: 148
              }, this)
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
              lineNumber: 181,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "all-details-section all-box-optional", children: [
              /* @__PURE__ */ jsxDEV("h4", { children: "Nice to Have" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
                lineNumber: 193,
                columnNumber: 17
              }, this),
              ["languages", "frameworks", "databases", "libraries", "tools"].map((cat) => viewingProject.optionalSkills?.[cat]?.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "all-skill-category", children: [
                /* @__PURE__ */ jsxDEV("h5", { children: cat }, void 0, false, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
                  lineNumber: 195,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "all-details-tags", children: viewingProject.optionalSkills[cat].map((skill, i) => /* @__PURE__ */ jsxDEV("span", { className: "all-skill-tag all-optional-skill", children: skill }, i, false, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
                  lineNumber: 197,
                  columnNumber: 79
                }, this)) }, void 0, false, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
                  lineNumber: 196,
                  columnNumber: 23
                }, this)
              ] }, cat, true, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
                lineNumber: 194,
                columnNumber: 144
              }, this)),
              !["languages", "frameworks", "databases", "libraries", "tools"].some((cat) => viewingProject.optionalSkills?.[cat]?.length > 0) && /* @__PURE__ */ jsxDEV("span", { className: "all-empty-text", children: "No optional skills specified." }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
                lineNumber: 200,
                columnNumber: 147
              }, this)
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
              lineNumber: 192,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
            lineNumber: 180,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "all-details-section all-box-roles", children: [
            /* @__PURE__ */ jsxDEV("h4", { children: "Engagement & Expected Roles" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
              lineNumber: 205,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "all-details-grid", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("h5", { children: "Required Roles:" }, void 0, false, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
                  lineNumber: 208,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "all-details-tags", children: viewingProject.requiredRoles?.length > 0 ? viewingProject.requiredRoles.map((role, i) => /* @__PURE__ */ jsxDEV("span", { className: "all-skill-tag all-role-tag", children: role }, i, false, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
                  lineNumber: 210,
                  columnNumber: 111
                }, this)) : /* @__PURE__ */ jsxDEV("span", { className: "all-empty-text", children: "Not specified" }, void 0, false, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
                  lineNumber: 210,
                  columnNumber: 181
                }, this) }, void 0, false, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
                  lineNumber: 209,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
                lineNumber: 207,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("h5", { children: "Commitment:" }, void 0, false, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
                  lineNumber: 214,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("ul", { className: "all-stats-list", children: [
                  /* @__PURE__ */ jsxDEV("li", { children: [
                    /* @__PURE__ */ jsxDEV("span", { children: "Weekly Hours:" }, void 0, false, {
                      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
                      lineNumber: 216,
                      columnNumber: 25
                    }, this),
                    " ",
                    /* @__PURE__ */ jsxDEV("strong", { children: viewingProject.availabilityRequirement?.weeklyHours ? `${viewingProject.availabilityRequirement.weeklyHours} hrs` : "-" }, void 0, false, {
                      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
                      lineNumber: 216,
                      columnNumber: 52
                    }, this)
                  ] }, void 0, true, {
                    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
                    lineNumber: 216,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("li", { children: [
                    /* @__PURE__ */ jsxDEV("span", { children: "Duration:" }, void 0, false, {
                      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
                      lineNumber: 217,
                      columnNumber: 25
                    }, this),
                    " ",
                    /* @__PURE__ */ jsxDEV("strong", { children: viewingProject.availabilityRequirement?.durationWeeks ? `${viewingProject.availabilityRequirement.durationWeeks} weeks` : "-" }, void 0, false, {
                      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
                      lineNumber: 217,
                      columnNumber: 48
                    }, this)
                  ] }, void 0, true, {
                    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
                    lineNumber: 217,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("li", { style: {
                    flexDirection: "column",
                    alignItems: "flex-start"
                  }, children: [
                    /* @__PURE__ */ jsxDEV("span", { style: {
                      marginBottom: 4
                    }, children: "Meeting Days:" }, void 0, false, {
                      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
                      lineNumber: 222,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("strong", { children: viewingProject.availabilityRequirement?.meetingDays?.join(", ") || "Flexible" }, void 0, false, {
                      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
                      lineNumber: 225,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
                    lineNumber: 218,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
                  lineNumber: 215,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
                lineNumber: 213,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
              lineNumber: 206,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
            lineNumber: 204,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
          lineNumber: 134,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "all-details-footer", style: {
          position: "relative",
          borderBottomLeftRadius: 0,
          borderBottomRightRadius: 0,
          marginTop: "20px",
          display: "flex",
          justifyContent: "center",
          gap: "20px"
        }, children: isOwner ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV("button", { className: "btn-delete", style: {
            background: "transparent",
            border: "2px solid #ef4444",
            color: "#ef4444",
            padding: "12px 32px",
            borderRadius: "8px",
            fontWeight: "600",
            cursor: "pointer"
          }, onClick: handleDelete, children: "Delete Post" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
            lineNumber: 243,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("button", { className: "btn-update", style: {
            background: "transparent",
            border: "2px solid #3B82F6",
            color: "#3B82F6",
            padding: "12px 32px",
            borderRadius: "8px",
            fontWeight: "600",
            cursor: "pointer"
          }, onClick: () => navigate("/update-project/" + id), children: "Update Details" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
            lineNumber: 252,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
          lineNumber: 242,
          columnNumber: 24
        }, this) : /* @__PURE__ */ jsxDEV("button", { className: "all-btn-join", onClick: handleJoin, children: "Join Project" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
          lineNumber: 261,
          columnNumber: 21
        }, this) }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
          lineNumber: 233,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
        lineNumber: 133,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
      lineNumber: 115,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx",
    lineNumber: 97,
    columnNumber: 10
  }, this);
};
_s(ProjectDetailsView, "pev3PdGoW3lptqlF1IA67020gCE=", false, function() {
  return [useParams, useNavigate, useAuth];
});
_c = ProjectDetailsView;
export default ProjectDetailsView;
var _c;
$RefreshReg$(_c, "ProjectDetailsView");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/ProjectDetailsView.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0ZXLFNBc0lHLFVBdElIOzs7Ozs7Ozs7Ozs7Ozs7O0FBdEZYLE9BQU9BLFNBQVNDLFVBQVVDLGlCQUFpQjtBQUMzQyxTQUFTQyxXQUFXQyxtQkFBbUI7QUFDdkMsU0FBU0MsZUFBZTtBQUN4QixPQUFPO0FBRVAsTUFBTUMscUJBQXFCQSxNQUFNO0FBQUFDLEtBQUE7QUFDL0IsUUFBTTtBQUFBLElBQUVDO0FBQUFBLEVBQUcsSUFBSUwsVUFBVTtBQUN6QixRQUFNTSxXQUFXTCxZQUFZO0FBQzdCLFFBQU07QUFBQSxJQUFFTTtBQUFBQSxJQUFNQztBQUFBQSxFQUFNLElBQUlOLFFBQVE7QUFDaEMsUUFBTSxDQUFDTyxnQkFBZ0JDLGlCQUFpQixJQUFJWixTQUFTLElBQUk7QUFDekQsUUFBTSxDQUFDYSxXQUFXQyxZQUFZLElBQUlkLFNBQVMsSUFBSTtBQUUvQyxRQUFNZSxlQUFlLFlBQVk7QUFDL0IsUUFBSTtBQUNGLFlBQU1DLE1BQU0sTUFBTUMsTUFBTSxtQ0FBbUNWLEVBQUUsRUFBRTtBQUMvRCxVQUFJUyxJQUFJRSxJQUFJO0FBQ1YsY0FBTUMsT0FBTyxNQUFNSCxJQUFJSSxLQUFLO0FBQzVCLGNBQU1DLFlBQVlGLEtBQUtHLGFBQWE7QUFDcENWLDBCQUFrQjtBQUFBLFVBQ2hCLEdBQUdPO0FBQUFBLFVBQ0hFO0FBQUFBLFVBQ0FFLGNBQWMsR0FBR0YsU0FBUyxNQUFNRixLQUFLSyxLQUFLO0FBQUEsUUFDNUMsQ0FBQztBQUFBLE1BQ0gsT0FBTztBQUNMQyxjQUFNLGlDQUFpQztBQUN2Q2pCLGlCQUFTLEVBQUU7QUFBQSxNQUNiO0FBQUEsSUFDRixTQUFTa0IsS0FBSztBQUNaQyxjQUFRQyxNQUFNRixHQUFHO0FBQ2pCRCxZQUFNLGVBQWU7QUFBQSxJQUN2QixVQUFDO0FBQ0NYLG1CQUFhLEtBQUs7QUFBQSxJQUNwQjtBQUFBLEVBQ0Y7QUFFQWIsWUFBVSxNQUFNO0FBQ2RjLGlCQUFhO0FBQUEsRUFDZixHQUFHLENBQUNSLElBQUlDLFFBQVEsQ0FBQztBQUVqQixRQUFNcUIsYUFBYSxZQUFZO0FBQzdCLFVBQU1DLFVBQVU7QUFBQSxNQUNkQyxVQUFVdEIsT0FBTyxHQUFHQSxLQUFLdUIsU0FBUyxNQUFNdkIsS0FBS3dCLFFBQVEsS0FBSztBQUFBLE1BQzFEQyxVQUFVdkIsZUFBZXdCLFlBQVk7QUFBQSxNQUNyQ0MsU0FBUyxxQkFBcUJ6QixlQUFlWSxZQUFZO0FBQUEsTUFDekRjLE1BQU07QUFBQSxJQUNSO0FBRUEsUUFBSTtBQUNGLFlBQU1yQixNQUFNLE1BQU1DLE1BQU0sMkNBQTJDO0FBQUEsUUFDakVxQixRQUFRO0FBQUEsUUFDUkMsU0FBUztBQUFBLFVBQUUsZ0JBQWdCO0FBQUEsUUFBbUI7QUFBQSxRQUM5Q0MsTUFBTUMsS0FBS0MsVUFBVVosT0FBTztBQUFBLE1BQzlCLENBQUM7QUFDRCxVQUFJZCxJQUFJRSxJQUFJO0FBQ1ZPLGNBQU0sOENBQThDO0FBQ3BEakIsaUJBQVMsRUFBRTtBQUFBLE1BQ2IsT0FBTztBQUNMaUIsY0FBTSx3QkFBd0I7QUFBQSxNQUNoQztBQUFBLElBQ0YsU0FBU0MsS0FBSztBQUNaQyxjQUFRQyxNQUFNRixHQUFHO0FBQ2pCRCxZQUFNLGVBQWU7QUFBQSxJQUN2QjtBQUFBLEVBQ0Y7QUFFQSxRQUFNa0IsZUFBZSxZQUFZO0FBQy9CLFFBQUksQ0FBQ0MsT0FBT0MsUUFBUSw4QkFBOEI7QUFBRztBQUNyRCxRQUFJO0FBQ0YsWUFBTTdCLE1BQU0sTUFBTUMsTUFBTSxtQ0FBbUNWLEVBQUUsSUFBSTtBQUFBLFFBQy9EK0IsUUFBUTtBQUFBLFFBQ1JDLFNBQVM7QUFBQSxVQUNQLGdCQUFnQjdCO0FBQUFBLFFBQ2xCO0FBQUEsTUFDRixDQUFDO0FBQ0QsVUFBSU0sSUFBSUUsSUFBSTtBQUNWTyxjQUFNLDhCQUE4QjtBQUNwQ2pCLGlCQUFTLGdCQUFnQjtBQUFBLE1BQzNCLE9BQU87QUFDTGlCLGNBQU0sMEJBQTBCO0FBQUEsTUFDbEM7QUFBQSxJQUNGLFNBQVNDLEtBQUs7QUFDWkMsY0FBUUMsTUFBTUYsR0FBRztBQUFBLElBQ25CO0FBQUEsRUFDRjtBQUVBLE1BQUliLFdBQVc7QUFDYixXQUFPLHVCQUFDLFNBQUksV0FBVSxlQUFjLE9BQU87QUFBQSxNQUFFaUMsV0FBVztBQUFBLElBQVEsR0FBRyxrQ0FBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE4RTtBQUFBLEVBQ3ZGO0FBRUEsTUFBSSxDQUFDbkMsZ0JBQWdCO0FBQ25CLFdBQU87QUFBQSxFQUNUO0FBRUEsUUFBTW9DLFVBQVV0QyxNQUFNdUIsY0FBY3JCLGVBQWV3QjtBQUVuRCxTQUNFLHVCQUFDLFNBQUksV0FBVSwwQkFBeUIsT0FBTztBQUFBLElBQUVhLFlBQVk7QUFBQSxJQUFRQyxVQUFVO0FBQUEsSUFBU0MsUUFBUTtBQUFBLEVBQVMsR0FFdkc7QUFBQSwyQkFBQyxZQUNDLFNBQVMsTUFBTTFDLFNBQVMsRUFBRSxHQUMxQixPQUFPO0FBQUEsTUFBRTJDLGNBQWM7QUFBQSxNQUFRQyxZQUFZO0FBQUEsTUFBUUMsUUFBUTtBQUFBLE1BQVFDLE9BQU87QUFBQSxNQUFXQyxRQUFRO0FBQUEsTUFBV0MsWUFBWTtBQUFBLE1BQU9DLFVBQVU7QUFBQSxJQUFPLEdBQzdJLHNCQUhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxPQUFPO0FBQUEsTUFBRUwsWUFBWTtBQUFBLE1BQVFNLGNBQWM7QUFBQSxNQUFRQyxXQUFXO0FBQUEsTUFBK0JDLFVBQVU7QUFBQSxJQUFTLEdBQ25IO0FBQUEsNkJBQUMsU0FBSSxPQUFPO0FBQUEsUUFBRUMsU0FBUztBQUFBLFFBQVFDLGNBQWM7QUFBQSxNQUFvQixHQUMvRCxpQ0FBQyxRQUFHLE9BQU87QUFBQSxRQUFFWixRQUFRO0FBQUEsUUFBR08sVUFBVTtBQUFBLFFBQVFILE9BQU87QUFBQSxRQUFXRSxZQUFZO0FBQUEsTUFBTSxHQUFJN0MseUJBQWVZLGdCQUFqRztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThHLEtBRGhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLG9CQUFtQixPQUFPO0FBQUEsVUFBRXdDLGVBQWU7QUFBQSxRQUFPLEdBQy9EO0FBQUEsaUNBQUMsU0FBSSxXQUFVLG9CQUNiO0FBQUEsbUNBQUMsVUFBSyxXQUFVLHFCQUFxQnBELHlCQUFlcUQsZUFBZSxhQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2RTtBQUFBLFlBQzVFckQsZUFBZXNELFlBQ2QsdUJBQUMsVUFBSyxXQUFVLG9DQUFtQztBQUFBO0FBQUEsY0FBU3RELGVBQWVzRDtBQUFBQSxpQkFBM0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0Y7QUFBQSxZQUVyRnRELGVBQWV3QixZQUNkLHVCQUFDLFVBQUssV0FBVSxxQkFBb0IsT0FBTztBQUFBLGNBQUUrQixpQkFBaUI7QUFBQSxjQUFXWixPQUFPO0FBQUEsY0FBV0QsUUFBUTtBQUFBLFlBQW9CLEdBQUc7QUFBQTtBQUFBLGNBQ2hIMUMsZUFBZXdCO0FBQUFBLGlCQUR6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFSSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVVBO0FBQUEsVUFFQSx1QkFBQyxRQUFHLFdBQVUseUJBQXdCLG1DQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5RDtBQUFBLFVBQ3pELHVCQUFDLE9BQUUsV0FBVSxvQkFBb0J4Qix5QkFBZXdELGVBQWUsOEJBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBGO0FBQUEsVUFFekZ4RCxlQUFleUQsV0FDZCx1QkFBQyxTQUFJLE9BQU87QUFBQSxZQUFFWCxVQUFVO0FBQUEsWUFBUUgsT0FBTztBQUFBLFlBQVdILGNBQWM7QUFBQSxZQUFRSyxZQUFZO0FBQUEsVUFBTSxHQUFHO0FBQUE7QUFBQSxZQUNqRix1QkFBQyxVQUFLLE9BQU87QUFBQSxjQUFFRixPQUFPO0FBQUEsWUFBVSxHQUFJLGNBQUllLEtBQUsxRCxlQUFleUQsT0FBTyxFQUFFRSxtQkFBbUIsT0FBTyxLQUEvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpRztBQUFBLGVBRDdHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUdGLHVCQUFDLFNBQUksV0FBVSxvQkFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSx1QkFDYjtBQUFBLHFDQUFDLFFBQUcsNkJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUI7QUFBQSxjQUNqQix1QkFBQyxTQUFJLFdBQVUsb0JBQ1ozRCx5QkFBZTRELFFBQVFDLFNBQVMsSUFBSTdELGVBQWU0RCxPQUFPRSxJQUFJLENBQUNDLEdBQUdDLE1BQ2pFLHVCQUFDLFVBQWEsV0FBVSxvQ0FBb0NELGVBQWpEQyxHQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQThELENBQy9ELElBQUksdUJBQUMsVUFBSyxXQUFVLGtCQUFpQiw2QkFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBOEMsS0FIckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFJQTtBQUFBLGlCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBT0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSx1QkFDYjtBQUFBLHFDQUFDLFFBQUcsb0NBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBd0I7QUFBQSxjQUN4Qix1QkFBQyxRQUFHLFdBQVUsa0JBQ1o7QUFBQSx1Q0FBQyxRQUFHO0FBQUEseUNBQUMsVUFBSywrQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFxQjtBQUFBLGtCQUFPO0FBQUEsa0JBQUMsdUJBQUMsWUFBUWhFLHlCQUFlaUUsa0JBQWtCLFNBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdEO0FBQUEscUJBQWpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTBGO0FBQUEsZ0JBQzFGLHVCQUFDLFFBQUc7QUFBQSx5Q0FBQyxVQUFLLHlCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWU7QUFBQSxrQkFBTztBQUFBLGtCQUFDLHVCQUFDLFlBQVFqRTtBQUFBQSxtQ0FBZWtFLFFBQVE7QUFBQSxvQkFBSTtBQUFBLG9CQUFJbEUsZUFBZW1FLFlBQVk7QUFBQSx1QkFBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBdUU7QUFBQSxxQkFBbEc7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkc7QUFBQSxnQkFDM0csdUJBQUMsUUFBRztBQUFBLHlDQUFDLFVBQUsseUJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZTtBQUFBLGtCQUFPO0FBQUEsa0JBQUMsdUJBQUMsWUFBUW5FLHlCQUFlb0UsZUFBZSxVQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE4QztBQUFBLHFCQUF6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFrRjtBQUFBLG1CQUhwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUlBO0FBQUEsaUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFPQTtBQUFBLGVBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBaUJBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsbUJBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSxxQ0FBQyxRQUFHLGdDQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9CO0FBQUEsY0FDbkIsQ0FBQyxhQUFhLGNBQWMsYUFBYSxhQUFhLE9BQU8sRUFBRU4sSUFBSU8sU0FDbEVyRSxlQUFlc0Usa0JBQWtCRCxHQUFHLEdBQUdSLFNBQVMsS0FDOUMsdUJBQUMsU0FBYyxXQUFVLHNCQUN2QjtBQUFBLHVDQUFDLFFBQUlRLGlCQUFMO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQVM7QUFBQSxnQkFDVCx1QkFBQyxTQUFJLFdBQVUsb0JBQ1pyRSx5QkFBZXNFLGdCQUFnQkQsR0FBRyxFQUFFUCxJQUFJLENBQUNTLE9BQU9QLE1BQy9DLHVCQUFDLFVBQWEsV0FBVSxxQ0FBcUNPLG1CQUFsRFAsR0FBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFtRSxDQUNwRSxLQUhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSUE7QUFBQSxtQkFOUUssS0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU9BLENBRUg7QUFBQSxjQUNBLENBQUMsQ0FBQyxhQUFhLGNBQWMsYUFBYSxhQUFhLE9BQU8sRUFBRUcsS0FBS0gsU0FBT3JFLGVBQWVzRSxrQkFBa0JELEdBQUcsR0FBR1IsU0FBUyxDQUFDLEtBQzVILHVCQUFDLFVBQUssV0FBVSxrQkFBaUIsOENBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQStEO0FBQUEsaUJBZm5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBaUJBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsd0NBQ2I7QUFBQSxxQ0FBQyxRQUFHLDRCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdCO0FBQUEsY0FDZixDQUFDLGFBQWEsY0FBYyxhQUFhLGFBQWEsT0FBTyxFQUFFQyxJQUFJTyxTQUNsRXJFLGVBQWV5RSxpQkFBaUJKLEdBQUcsR0FBR1IsU0FBUyxLQUM3Qyx1QkFBQyxTQUFjLFdBQVUsc0JBQ3ZCO0FBQUEsdUNBQUMsUUFBSVEsaUJBQUw7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBUztBQUFBLGdCQUNULHVCQUFDLFNBQUksV0FBVSxvQkFDWnJFLHlCQUFleUUsZUFBZUosR0FBRyxFQUFFUCxJQUFJLENBQUNTLE9BQU9QLE1BQzlDLHVCQUFDLFVBQWEsV0FBVSxvQ0FBb0NPLG1CQUFqRFAsR0FBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFrRSxDQUNuRSxLQUhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSUE7QUFBQSxtQkFOUUssS0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU9BLENBRUg7QUFBQSxjQUNBLENBQUMsQ0FBQyxhQUFhLGNBQWMsYUFBYSxhQUFhLE9BQU8sRUFBRUcsS0FBS0gsU0FBT3JFLGVBQWV5RSxpQkFBaUJKLEdBQUcsR0FBR1IsU0FBUyxDQUFDLEtBQzNILHVCQUFDLFVBQUssV0FBVSxrQkFBaUIsNkNBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQThEO0FBQUEsaUJBZmxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBaUJBO0FBQUEsZUFyQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFzQ0E7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLG1DQUFDLFFBQUcsMkNBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0I7QUFBQSxZQUMvQix1QkFBQyxTQUFJLFdBQVUsb0JBQ2I7QUFBQSxxQ0FBQyxTQUNDO0FBQUEsdUNBQUMsUUFBRywrQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFtQjtBQUFBLGdCQUNuQix1QkFBQyxTQUFJLFdBQVUsb0JBQ1o3RCx5QkFBZTBFLGVBQWViLFNBQVMsSUFBSTdELGVBQWUwRSxjQUFjWixJQUFJLENBQUNhLE1BQU1YLE1BQ2xGLHVCQUFDLFVBQWEsV0FBVSw4QkFBOEJXLGtCQUEzQ1gsR0FBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEyRCxDQUM1RCxJQUFJLHVCQUFDLFVBQUssV0FBVSxrQkFBaUIsNkJBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQThDLEtBSHJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSUE7QUFBQSxtQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU9BO0FBQUEsY0FDQSx1QkFBQyxTQUNDO0FBQUEsdUNBQUMsUUFBRywyQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFlO0FBQUEsZ0JBQ2YsdUJBQUMsUUFBRyxXQUFVLGtCQUNaO0FBQUEseUNBQUMsUUFBRztBQUFBLDJDQUFDLFVBQUssNkJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBbUI7QUFBQSxvQkFBTztBQUFBLG9CQUFDLHVCQUFDLFlBQVFoRSx5QkFBZTRFLHlCQUF5QkMsY0FBYyxHQUFHN0UsZUFBZTRFLHdCQUF3QkMsV0FBVyxTQUFTLE9BQTdIO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWlJO0FBQUEsdUJBQWhLO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXlLO0FBQUEsa0JBQ3pLLHVCQUFDLFFBQUc7QUFBQSwyQ0FBQyxVQUFLLHlCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWU7QUFBQSxvQkFBTztBQUFBLG9CQUFDLHVCQUFDLFlBQVE3RSx5QkFBZTRFLHlCQUF5QkUsZ0JBQWdCLEdBQUc5RSxlQUFlNEUsd0JBQXdCRSxhQUFhLFdBQVcsT0FBbkk7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBdUk7QUFBQSx1QkFBbEs7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMks7QUFBQSxrQkFDM0ssdUJBQUMsUUFBRyxPQUFPO0FBQUEsb0JBQUVDLGVBQWU7QUFBQSxvQkFBVUMsWUFBWTtBQUFBLGtCQUFhLEdBQzdEO0FBQUEsMkNBQUMsVUFBSyxPQUFPO0FBQUEsc0JBQUV4QyxjQUFjO0FBQUEsb0JBQUUsR0FBRyw2QkFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBK0M7QUFBQSxvQkFDL0MsdUJBQUMsWUFBUXhDLHlCQUFlNEUseUJBQXlCSyxhQUFhQyxLQUFLLElBQUksS0FBSyxjQUE1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUF1RjtBQUFBLHVCQUZ6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUdBO0FBQUEscUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFPQTtBQUFBLG1CQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBVUE7QUFBQSxpQkFuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFvQkE7QUFBQSxlQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXVCQTtBQUFBLGFBeEdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF5R0E7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSxzQkFBcUIsT0FBTztBQUFBLFVBQUVDLFVBQVU7QUFBQSxVQUFZQyx3QkFBd0I7QUFBQSxVQUFHQyx5QkFBeUI7QUFBQSxVQUFHbEQsV0FBVztBQUFBLFVBQVFtRCxTQUFTO0FBQUEsVUFBUUMsZ0JBQWdCO0FBQUEsVUFBVUMsS0FBSztBQUFBLFFBQU8sR0FDak1wRCxvQkFDQyxtQ0FDRTtBQUFBLGlDQUFDLFlBQU8sV0FBVSxjQUFhLE9BQU87QUFBQSxZQUFFSyxZQUFZO0FBQUEsWUFBZUMsUUFBUTtBQUFBLFlBQXFCQyxPQUFPO0FBQUEsWUFBV08sU0FBUztBQUFBLFlBQWFILGNBQWM7QUFBQSxZQUFPRixZQUFZO0FBQUEsWUFBT0QsUUFBUTtBQUFBLFVBQVUsR0FBRyxTQUFTWixjQUFjLDJCQUE1TjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1TztBQUFBLFVBQ3ZPLHVCQUFDLFlBQU8sV0FBVSxjQUFhLE9BQU87QUFBQSxZQUFFUyxZQUFZO0FBQUEsWUFBZUMsUUFBUTtBQUFBLFlBQXFCQyxPQUFPO0FBQUEsWUFBV08sU0FBUztBQUFBLFlBQWFILGNBQWM7QUFBQSxZQUFPRixZQUFZO0FBQUEsWUFBT0QsUUFBUTtBQUFBLFVBQVUsR0FBRyxTQUFTLE1BQU0vQyxTQUFTLHFCQUFxQkQsRUFBRSxHQUFHLDhCQUF2UDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxUTtBQUFBLGFBRnZRO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQSxJQUVBLHVCQUFDLFlBQU8sV0FBVSxnQkFBZSxTQUFTc0IsWUFBWSw0QkFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrRSxLQVB0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0E7QUFBQSxXQXJIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBc0hBO0FBQUEsU0EzSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTRIQTtBQUFBLE9BcklGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FzSUE7QUFFSjtBQUFFdkIsR0FuT0lELG9CQUFrQjtBQUFBLFVBQ1BILFdBQ0VDLGFBQ09DLE9BQU87QUFBQTtBQUFBZ0csS0FIM0IvRjtBQXFPTixlQUFlQTtBQUFtQixJQUFBK0Y7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJ1c2VQYXJhbXMiLCJ1c2VOYXZpZ2F0ZSIsInVzZUF1dGgiLCJQcm9qZWN0RGV0YWlsc1ZpZXciLCJfcyIsImlkIiwibmF2aWdhdGUiLCJ1c2VyIiwidG9rZW4iLCJ2aWV3aW5nUHJvamVjdCIsInNldFZpZXdpbmdQcm9qZWN0IiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwiZmV0Y2hQcm9qZWN0IiwicmVzIiwiZmV0Y2giLCJvayIsImRhdGEiLCJqc29uIiwiZGlzcGxheUlkIiwicHJvamVjdElkIiwiZGlzcGxheVRpdGxlIiwidGl0bGUiLCJhbGVydCIsImVyciIsImNvbnNvbGUiLCJlcnJvciIsImhhbmRsZUpvaW4iLCJwYXlsb2FkIiwic2VuZGVySXQiLCJzdHVkZW50SWQiLCJmdWxsTmFtZSIsInRhcmdldEl0IiwiaXROdW1iZXIiLCJtZXNzYWdlIiwidHlwZSIsIm1ldGhvZCIsImhlYWRlcnMiLCJib2R5IiwiSlNPTiIsInN0cmluZ2lmeSIsImhhbmRsZURlbGV0ZSIsIndpbmRvdyIsImNvbmZpcm0iLCJtYXJnaW5Ub3AiLCJpc093bmVyIiwicGFkZGluZ1RvcCIsIm1heFdpZHRoIiwibWFyZ2luIiwibWFyZ2luQm90dG9tIiwiYmFja2dyb3VuZCIsImJvcmRlciIsImNvbG9yIiwiY3Vyc29yIiwiZm9udFdlaWdodCIsImZvbnRTaXplIiwiYm9yZGVyUmFkaXVzIiwiYm94U2hhZG93Iiwib3ZlcmZsb3ciLCJwYWRkaW5nIiwiYm9yZGVyQm90dG9tIiwicGFkZGluZ0JvdHRvbSIsInByb2plY3RUeXBlIiwidGVhbVNpemUiLCJiYWNrZ3JvdW5kQ29sb3IiLCJkZXNjcmlwdGlvbiIsImR1ZURhdGUiLCJEYXRlIiwidG9Mb2NhbGVEYXRlU3RyaW5nIiwiZG9tYWluIiwibGVuZ3RoIiwibWFwIiwiZCIsImkiLCJzcGVjaWFsaXphdGlvbiIsInllYXIiLCJzZW1lc3RlciIsIm1pbmltdW1DR1BBIiwiY2F0IiwiZXNzZW50aWFsU2tpbGxzIiwic2tpbGwiLCJzb21lIiwib3B0aW9uYWxTa2lsbHMiLCJyZXF1aXJlZFJvbGVzIiwicm9sZSIsImF2YWlsYWJpbGl0eVJlcXVpcmVtZW50Iiwid2Vla2x5SG91cnMiLCJkdXJhdGlvbldlZWtzIiwiZmxleERpcmVjdGlvbiIsImFsaWduSXRlbXMiLCJtZWV0aW5nRGF5cyIsImpvaW4iLCJwb3NpdGlvbiIsImJvcmRlckJvdHRvbUxlZnRSYWRpdXMiLCJib3JkZXJCb3R0b21SaWdodFJhZGl1cyIsImRpc3BsYXkiLCJqdXN0aWZ5Q29udGVudCIsImdhcCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUHJvamVjdERldGFpbHNWaWV3LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgdXNlUGFyYW1zLCB1c2VOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xyXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSAnLi4vLi4vY29udGV4dC9BdXRoQ29udGV4dCc7XHJcbmltcG9ydCAnLi9BbGxQcm9qZWN0cy5jc3MnO1xyXG5cclxuY29uc3QgUHJvamVjdERldGFpbHNWaWV3ID0gKCkgPT4ge1xyXG4gIGNvbnN0IHsgaWQgfSA9IHVzZVBhcmFtcygpO1xyXG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcclxuICBjb25zdCB7IHVzZXIsIHRva2VuIH0gPSB1c2VBdXRoKCk7XHJcbiAgY29uc3QgW3ZpZXdpbmdQcm9qZWN0LCBzZXRWaWV3aW5nUHJvamVjdF0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSk7XHJcblxyXG4gIGNvbnN0IGZldGNoUHJvamVjdCA9IGFzeW5jICgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKGBodHRwOi8vbG9jYWxob3N0OjMwMDAvYXBpL3Bvc3RzLyR7aWR9YCk7XHJcbiAgICAgIGlmIChyZXMub2spIHtcclxuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzLmpzb24oKTtcclxuICAgICAgICBjb25zdCBkaXNwbGF5SWQgPSBkYXRhLnByb2plY3RJZCB8fCAnUDAwMDAnO1xyXG4gICAgICAgIHNldFZpZXdpbmdQcm9qZWN0KHtcclxuICAgICAgICAgIC4uLmRhdGEsXHJcbiAgICAgICAgICBkaXNwbGF5SWQsXHJcbiAgICAgICAgICBkaXNwbGF5VGl0bGU6IGAke2Rpc3BsYXlJZH0gLSAke2RhdGEudGl0bGV9YFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGFsZXJ0KCdGYWlsZWQgdG8gZmV0Y2ggcHJvamVjdCBkZXRhaWxzJyk7XHJcbiAgICAgICAgbmF2aWdhdGUoLTEpO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihlcnIpO1xyXG4gICAgICBhbGVydCgnTmV0d29yayBlcnJvcicpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgZmV0Y2hQcm9qZWN0KCk7XHJcbiAgfSwgW2lkLCBuYXZpZ2F0ZV0pO1xyXG5cclxuICBjb25zdCBoYW5kbGVKb2luID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgY29uc3QgcGF5bG9hZCA9IHtcclxuICAgICAgc2VuZGVySXQ6IHVzZXIgPyBgJHt1c2VyLnN0dWRlbnRJZH0gLSAke3VzZXIuZnVsbE5hbWV9YCA6ICdVbmtub3duJyxcclxuICAgICAgdGFyZ2V0SXQ6IHZpZXdpbmdQcm9qZWN0Lml0TnVtYmVyIHx8ICdVbmtub3duJyxcclxuICAgICAgbWVzc2FnZTogYFJlcXVlc3RlZCB0byBqb2luICR7dmlld2luZ1Byb2plY3QuZGlzcGxheVRpdGxlfSBwcm9qZWN0YCxcclxuICAgICAgdHlwZTogJ2pvaW5fcmVxdWVzdCdcclxuICAgIH07XHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goJ2h0dHA6Ly9sb2NhbGhvc3Q6MzAwMC9hcGkvbm90aWZpY2F0aW9ucycsIHtcclxuICAgICAgICBtZXRob2Q6ICdQT1NUJyxcclxuICAgICAgICBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSxcclxuICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeShwYXlsb2FkKVxyXG4gICAgICB9KTtcclxuICAgICAgaWYgKHJlcy5vaykge1xyXG4gICAgICAgIGFsZXJ0KCdKb2luIFJlcXVlc3QgU2VudCB0byB0aGUgTm90aWZpY2F0aW9ucyBQYWdlIScpO1xyXG4gICAgICAgIG5hdmlnYXRlKC0xKTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBhbGVydCgnRmFpbGVkIHRvIHNlbmQgcmVxdWVzdCcpO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihlcnIpO1xyXG4gICAgICBhbGVydCgnTmV0d29yayBlcnJvcicpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZURlbGV0ZSA9IGFzeW5jICgpID0+IHtcclxuICAgIGlmICghd2luZG93LmNvbmZpcm0oJ0RlbGV0ZSB0aGlzIHByb2plY3QgZm9yZXZlcj8nKSkgcmV0dXJuO1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goYGh0dHA6Ly9sb2NhbGhvc3Q6MzAwMC9hcGkvcG9zdHMvJHtpZH1gLCB7XHJcbiAgICAgICAgbWV0aG9kOiAnREVMRVRFJyxcclxuICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAneC1hdXRoLXRva2VuJzogdG9rZW5cclxuICAgICAgICB9XHJcbiAgICAgIH0pO1xyXG4gICAgICBpZiAocmVzLm9rKSB7XHJcbiAgICAgICAgYWxlcnQoJ1Byb2plY3QgZGVsZXRlZCBzdWNjZXNzZnVsbHknKTtcclxuICAgICAgICBuYXZpZ2F0ZSgnL3lvdXItcHJvamVjdHMnKTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBhbGVydCgnRmFpbGVkIHRvIGRlbGV0ZSBwcm9qZWN0Jyk7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKGVycik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgaWYgKGlzTG9hZGluZykge1xyXG4gICAgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwiYWxsLWxvYWRpbmdcIiBzdHlsZT17eyBtYXJnaW5Ub3A6ICcxMDBweCcgfX0+TG9hZGluZyBkZXRhaWxzLi4uPC9kaXY+O1xyXG4gIH1cclxuXHJcbiAgaWYgKCF2aWV3aW5nUHJvamVjdCkge1xyXG4gICAgcmV0dXJuIG51bGw7XHJcbiAgfVxyXG5cclxuICBjb25zdCBpc093bmVyID0gdXNlcj8uc3R1ZGVudElkID09PSB2aWV3aW5nUHJvamVjdC5pdE51bWJlcjtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiYWxsLXByb2plY3RzLWNvbnRhaW5lclwiIHN0eWxlPXt7IHBhZGRpbmdUb3A6ICc0MHB4JywgbWF4V2lkdGg6ICc5MDBweCcsIG1hcmdpbjogJzAgYXV0bycgfX0+XHJcbiAgICAgIHsvKiBCYWNrIEJ1dHRvbiAqL31cclxuICAgICAgPGJ1dHRvblxyXG4gICAgICAgIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKC0xKX1cclxuICAgICAgICBzdHlsZT17eyBtYXJnaW5Cb3R0b206ICcyMHB4JywgYmFja2dyb3VuZDogJ25vbmUnLCBib3JkZXI6ICdub25lJywgY29sb3I6ICcjM0I4MkY2JywgY3Vyc29yOiAncG9pbnRlcicsIGZvbnRXZWlnaHQ6ICc2MDAnLCBmb250U2l6ZTogJzE1cHgnIH19XHJcbiAgICAgID5cclxuICAgICAgICDihpAgQmFja1xyXG4gICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgIDxkaXYgc3R5bGU9e3sgYmFja2dyb3VuZDogJyNmZmYnLCBib3JkZXJSYWRpdXM6ICcxMnB4JywgYm94U2hhZG93OiAnMCAyMHB4IDQwcHggcmdiYSgwLDAsMCwwLjEpJywgb3ZlcmZsb3c6ICdoaWRkZW4nIH19PlxyXG4gICAgICAgIDxkaXYgc3R5bGU9e3sgcGFkZGluZzogJzI0cHgnLCBib3JkZXJCb3R0b206ICcxcHggc29saWQgI2VhZWFlYScgfX0+XHJcbiAgICAgICAgICA8aDIgc3R5bGU9e3sgbWFyZ2luOiAwLCBmb250U2l6ZTogJzI0cHgnLCBjb2xvcjogJyMxZTI5M2InLCBmb250V2VpZ2h0OiAnNzAwJyB9fT57dmlld2luZ1Byb2plY3QuZGlzcGxheVRpdGxlfTwvaDI+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWxsLXByb2plY3QtZGV0YWlscy12aWV3IHJlbGF0aXZlXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFsbC1kZXRhaWxzLWJvZHlcIiBzdHlsZT17eyBwYWRkaW5nQm90dG9tOiAnMzJweCcgfX0+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWxsLWRldGFpbHMtbWV0YVwiPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImFsbC1kZXRhaWxzLWJhZGdlXCI+e3ZpZXdpbmdQcm9qZWN0LnByb2plY3RUeXBlIHx8ICdQcm9qZWN0J308L3NwYW4+XHJcbiAgICAgICAgICAgICAge3ZpZXdpbmdQcm9qZWN0LnRlYW1TaXplICYmIChcclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImFsbC1kZXRhaWxzLWJhZGdlIGFsbC1iYWRnZS10ZWFtXCI+VGVhbSBvZiB7dmlld2luZ1Byb2plY3QudGVhbVNpemV9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAge3ZpZXdpbmdQcm9qZWN0Lml0TnVtYmVyICYmIChcclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImFsbC1kZXRhaWxzLWJhZGdlXCIgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiAnI2Y4ZmFmYycsIGNvbG9yOiAnIzQ3NTU2OScsIGJvcmRlcjogJzFweCBzb2xpZCAjZTJlOGYwJyB9fT5cclxuICAgICAgICAgICAgICAgICAgSVQgTk86IHt2aWV3aW5nUHJvamVjdC5pdE51bWJlcn1cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJhbGwtc2VjdGlvbi10aXRsZS1tb2RcIj5Qcm9qZWN0IERlc2NyaXB0aW9uPC9oMz5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiYWxsLWRldGFpbHMtZGVzY1wiPnt2aWV3aW5nUHJvamVjdC5kZXNjcmlwdGlvbiB8fCAnTm8gZGVzY3JpcHRpb24gcHJvdmlkZWQuJ308L3A+XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICB7dmlld2luZ1Byb2plY3QuZHVlRGF0ZSAmJiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250U2l6ZTogJzE1cHgnLCBjb2xvcjogJyNlZjQ0NDQnLCBtYXJnaW5Cb3R0b206ICcyNHB4JywgZm9udFdlaWdodDogJzYwMCcgfX0+XHJcbiAgICAgICAgICAgICAgICBEdWUgRGF0ZTogPHNwYW4gc3R5bGU9e3sgY29sb3I6ICcjMWUyOTNiJyB9fT57bmV3IERhdGUodmlld2luZ1Byb2plY3QuZHVlRGF0ZSkudG9Mb2NhbGVEYXRlU3RyaW5nKCdlbi1HQicpfTwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWxsLWRldGFpbHMtZ3JpZFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWxsLWRldGFpbHMtc2VjdGlvblwiPlxyXG4gICAgICAgICAgICAgICAgPGg0PlRhcmdldCBEb21haW48L2g0PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhbGwtZGV0YWlscy10YWdzXCI+XHJcbiAgICAgICAgICAgICAgICAgIHt2aWV3aW5nUHJvamVjdC5kb21haW4/Lmxlbmd0aCA+IDAgPyB2aWV3aW5nUHJvamVjdC5kb21haW4ubWFwKChkLCBpKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4ga2V5PXtpfSBjbGFzc05hbWU9XCJhbGwtc2tpbGwtdGFnIGFsbC1kb21haW4tdGFnLW1vZFwiPntkfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgKSkgOiA8c3BhbiBjbGFzc05hbWU9XCJhbGwtZW1wdHktdGV4dFwiPk5vdCBzcGVjaWZpZWQ8L3NwYW4+fVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhbGwtZGV0YWlscy1zZWN0aW9uXCI+XHJcbiAgICAgICAgICAgICAgICA8aDQ+QWNhZGVtaWMgQ29uc3RyYWludHM8L2g0PlxyXG4gICAgICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cImFsbC1zdGF0cy1saXN0XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsaT48c3Bhbj5TcGVjaWFsaXphdGlvbjo8L3NwYW4+IDxzdHJvbmc+e3ZpZXdpbmdQcm9qZWN0LnNwZWNpYWxpemF0aW9uIHx8ICdBbnknfTwvc3Ryb25nPjwvbGk+XHJcbiAgICAgICAgICAgICAgICAgIDxsaT48c3Bhbj5ZZWFyL1NlbTo8L3NwYW4+IDxzdHJvbmc+e3ZpZXdpbmdQcm9qZWN0LnllYXIgfHwgJy0nfSAvIHt2aWV3aW5nUHJvamVjdC5zZW1lc3RlciB8fCAnLSd9PC9zdHJvbmc+PC9saT5cclxuICAgICAgICAgICAgICAgICAgPGxpPjxzcGFuPk1pbiBDR1BBOjwvc3Bhbj4gPHN0cm9uZz57dmlld2luZ1Byb2plY3QubWluaW11bUNHUEEgfHwgJ05vbmUnfTwvc3Ryb25nPjwvbGk+XHJcbiAgICAgICAgICAgICAgICA8L3VsPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWxsLXNraWxscy1ncmlkXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhbGwtZGV0YWlscy1zZWN0aW9uIGFsbC1ib3gtZXNzZW50aWFsXCI+XHJcbiAgICAgICAgICAgICAgICA8aDQ+TXVzdCBIYXZlIFNraWxsczwvaDQ+XHJcbiAgICAgICAgICAgICAgICB7WydsYW5ndWFnZXMnLCAnZnJhbWV3b3JrcycsICdkYXRhYmFzZXMnLCAnbGlicmFyaWVzJywgJ3Rvb2xzJ10ubWFwKGNhdCA9PiAoXHJcbiAgICAgICAgICAgICAgICAgIHZpZXdpbmdQcm9qZWN0LmVzc2VudGlhbFNraWxscz8uW2NhdF0/Lmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtjYXR9IGNsYXNzTmFtZT1cImFsbC1za2lsbC1jYXRlZ29yeVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGg1PntjYXR9PC9oNT5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWxsLWRldGFpbHMtdGFnc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7dmlld2luZ1Byb2plY3QuZXNzZW50aWFsU2tpbGxzW2NhdF0ubWFwKChza2lsbCwgaSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGtleT17aX0gY2xhc3NOYW1lPVwiYWxsLXNraWxsLXRhZyBhbGwtZXNzZW50aWFsLXNraWxsXCI+e3NraWxsfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICB7IVsnbGFuZ3VhZ2VzJywgJ2ZyYW1ld29ya3MnLCAnZGF0YWJhc2VzJywgJ2xpYnJhcmllcycsICd0b29scyddLnNvbWUoY2F0ID0+IHZpZXdpbmdQcm9qZWN0LmVzc2VudGlhbFNraWxscz8uW2NhdF0/Lmxlbmd0aCA+IDApICYmIChcclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYWxsLWVtcHR5LXRleHRcIj5ObyBlc3NlbnRpYWwgc2tpbGxzIHNwZWNpZmllZC48L3NwYW4+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFsbC1kZXRhaWxzLXNlY3Rpb24gYWxsLWJveC1vcHRpb25hbFwiPlxyXG4gICAgICAgICAgICAgICAgPGg0Pk5pY2UgdG8gSGF2ZTwvaDQ+XHJcbiAgICAgICAgICAgICAgICB7WydsYW5ndWFnZXMnLCAnZnJhbWV3b3JrcycsICdkYXRhYmFzZXMnLCAnbGlicmFyaWVzJywgJ3Rvb2xzJ10ubWFwKGNhdCA9PiAoXHJcbiAgICAgICAgICAgICAgICAgIHZpZXdpbmdQcm9qZWN0Lm9wdGlvbmFsU2tpbGxzPy5bY2F0XT8ubGVuZ3RoID4gMCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2NhdH0gY2xhc3NOYW1lPVwiYWxsLXNraWxsLWNhdGVnb3J5XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8aDU+e2NhdH08L2g1PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhbGwtZGV0YWlscy10YWdzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHt2aWV3aW5nUHJvamVjdC5vcHRpb25hbFNraWxsc1tjYXRdLm1hcCgoc2tpbGwsIGkpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBrZXk9e2l9IGNsYXNzTmFtZT1cImFsbC1za2lsbC10YWcgYWxsLW9wdGlvbmFsLXNraWxsXCI+e3NraWxsfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICB7IVsnbGFuZ3VhZ2VzJywgJ2ZyYW1ld29ya3MnLCAnZGF0YWJhc2VzJywgJ2xpYnJhcmllcycsICd0b29scyddLnNvbWUoY2F0ID0+IHZpZXdpbmdQcm9qZWN0Lm9wdGlvbmFsU2tpbGxzPy5bY2F0XT8ubGVuZ3RoID4gMCkgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhbGwtZW1wdHktdGV4dFwiPk5vIG9wdGlvbmFsIHNraWxscyBzcGVjaWZpZWQuPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFsbC1kZXRhaWxzLXNlY3Rpb24gYWxsLWJveC1yb2xlc1wiPlxyXG4gICAgICAgICAgICAgIDxoND5FbmdhZ2VtZW50ICYgRXhwZWN0ZWQgUm9sZXM8L2g0PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWxsLWRldGFpbHMtZ3JpZFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGg1PlJlcXVpcmVkIFJvbGVzOjwvaDU+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWxsLWRldGFpbHMtdGFnc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIHt2aWV3aW5nUHJvamVjdC5yZXF1aXJlZFJvbGVzPy5sZW5ndGggPiAwID8gdmlld2luZ1Byb2plY3QucmVxdWlyZWRSb2xlcy5tYXAoKHJvbGUsIGkpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGtleT17aX0gY2xhc3NOYW1lPVwiYWxsLXNraWxsLXRhZyBhbGwtcm9sZS10YWdcIj57cm9sZX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgKSkgOiA8c3BhbiBjbGFzc05hbWU9XCJhbGwtZW1wdHktdGV4dFwiPk5vdCBzcGVjaWZpZWQ8L3NwYW4+fVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGg1PkNvbW1pdG1lbnQ6PC9oNT5cclxuICAgICAgICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cImFsbC1zdGF0cy1saXN0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxpPjxzcGFuPldlZWtseSBIb3Vyczo8L3NwYW4+IDxzdHJvbmc+e3ZpZXdpbmdQcm9qZWN0LmF2YWlsYWJpbGl0eVJlcXVpcmVtZW50Py53ZWVrbHlIb3VycyA/IGAke3ZpZXdpbmdQcm9qZWN0LmF2YWlsYWJpbGl0eVJlcXVpcmVtZW50LndlZWtseUhvdXJzfSBocnNgIDogJy0nfTwvc3Ryb25nPjwvbGk+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxpPjxzcGFuPkR1cmF0aW9uOjwvc3Bhbj4gPHN0cm9uZz57dmlld2luZ1Byb2plY3QuYXZhaWxhYmlsaXR5UmVxdWlyZW1lbnQ/LmR1cmF0aW9uV2Vla3MgPyBgJHt2aWV3aW5nUHJvamVjdC5hdmFpbGFiaWxpdHlSZXF1aXJlbWVudC5kdXJhdGlvbldlZWtzfSB3ZWVrc2AgOiAnLSd9PC9zdHJvbmc+PC9saT5cclxuICAgICAgICAgICAgICAgICAgICA8bGkgc3R5bGU9e3sgZmxleERpcmVjdGlvbjogJ2NvbHVtbicsIGFsaWduSXRlbXM6ICdmbGV4LXN0YXJ0JyB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IG1hcmdpbkJvdHRvbTogNCB9fT5NZWV0aW5nIERheXM6PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz57dmlld2luZ1Byb2plY3QuYXZhaWxhYmlsaXR5UmVxdWlyZW1lbnQ/Lm1lZXRpbmdEYXlzPy5qb2luKCcsICcpIHx8ICdGbGV4aWJsZSd9PC9zdHJvbmc+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICAgICAgICAgPC91bD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWxsLWRldGFpbHMtZm9vdGVyXCIgc3R5bGU9e3sgcG9zaXRpb246ICdyZWxhdGl2ZScsIGJvcmRlckJvdHRvbUxlZnRSYWRpdXM6IDAsIGJvcmRlckJvdHRvbVJpZ2h0UmFkaXVzOiAwLCBtYXJnaW5Ub3A6ICcyMHB4JywgZGlzcGxheTogJ2ZsZXgnLCBqdXN0aWZ5Q29udGVudDogJ2NlbnRlcicsIGdhcDogJzIwcHgnIH19PlxyXG4gICAgICAgICAgICB7aXNPd25lciA/IChcclxuICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJidG4tZGVsZXRlXCIgc3R5bGU9e3sgYmFja2dyb3VuZDogJ3RyYW5zcGFyZW50JywgYm9yZGVyOiAnMnB4IHNvbGlkICNlZjQ0NDQnLCBjb2xvcjogJyNlZjQ0NDQnLCBwYWRkaW5nOiAnMTJweCAzMnB4JywgYm9yZGVyUmFkaXVzOiAnOHB4JywgZm9udFdlaWdodDogJzYwMCcsIGN1cnNvcjogJ3BvaW50ZXInIH19IG9uQ2xpY2s9e2hhbmRsZURlbGV0ZX0+RGVsZXRlIFBvc3Q8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYnRuLXVwZGF0ZVwiIHN0eWxlPXt7IGJhY2tncm91bmQ6ICd0cmFuc3BhcmVudCcsIGJvcmRlcjogJzJweCBzb2xpZCAjM0I4MkY2JywgY29sb3I6ICcjM0I4MkY2JywgcGFkZGluZzogJzEycHggMzJweCcsIGJvcmRlclJhZGl1czogJzhweCcsIGZvbnRXZWlnaHQ6ICc2MDAnLCBjdXJzb3I6ICdwb2ludGVyJyB9fSBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZSgnL3VwZGF0ZS1wcm9qZWN0LycgKyBpZCl9PlVwZGF0ZSBEZXRhaWxzPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJhbGwtYnRuLWpvaW5cIiBvbkNsaWNrPXtoYW5kbGVKb2lufT5Kb2luIFByb2plY3Q8L2J1dHRvbj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBQcm9qZWN0RGV0YWlsc1ZpZXc7XHJcbiJdLCJmaWxlIjoiRjovWTNTMi9JVFBNIHByb2plY3QvUHJvTWF0ZS0tUHJvamVjdC1QYXJ0bmVyLUZpbmRlci9mcm9udGVuZC9zcmMvcGFnZXMvUHJvamVjdHMvUHJvamVjdERldGFpbHNWaWV3LmpzeCJ9