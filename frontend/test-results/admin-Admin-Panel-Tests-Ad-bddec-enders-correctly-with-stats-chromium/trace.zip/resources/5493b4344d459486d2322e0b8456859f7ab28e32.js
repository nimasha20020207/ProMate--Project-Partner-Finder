import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Admin/AdminFeedbacks.jsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/AdminFeedbacks.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=383bea9f"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import AdminNavbar from "/src/components/AdminNavbar.jsx";
const AdminFeedbacks = () => {
  const feedbacks = [{
    id: "STU001",
    name: "John Doe",
    rating: 4,
    comment: "The system is very user-friendly and helpful.",
    improvement: "Add dark mode feature"
  }, {
    id: "STU002",
    name: "Jane Smith",
    rating: 5,
    comment: "Excellent experience! Everything works perfectly.",
    improvement: "No major improvements needed"
  }, {
    id: "STU003",
    name: "Michael Lee",
    rating: 3,
    comment: "Good, but some pages load slowly.",
    improvement: "Improve performance speed"
  }, {
    id: "STU004",
    name: "Sarah Khan",
    rating: 2,
    comment: "UI is confusing in some sections.",
    improvement: "Improve navigation and layout"
  }];
  const renderStars = (rating) => {
    return "⭐".repeat(rating) + "☆".repeat(5 - rating);
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "flex h-screen overflow-hidden", children: /* @__PURE__ */ jsxDEV("div", { className: "flex-1 p-6 bg-surface", children: [
    /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-bold mb-6 text-textPrimary", children: "User Feedbacks⭐" }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/AdminFeedbacks.jsx",
      lineNumber: 46,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "bg-white shadow-md rounded-xl overflow-hidden", children: /* @__PURE__ */ jsxDEV("table", { className: "w-full border-collapse", children: [
      /* @__PURE__ */ jsxDEV("thead", { className: "bg-primary", children: /* @__PURE__ */ jsxDEV("tr", { children: [
        /* @__PURE__ */ jsxDEV("th", { className: "p-3 text-left text-white", children: "Student ID" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/AdminFeedbacks.jsx",
          lineNumber: 53,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("th", { className: "p-3 text-left text-white", children: "Student Name" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/AdminFeedbacks.jsx",
          lineNumber: 54,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("th", { className: "p-3 text-left text-white", children: "Ratings" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/AdminFeedbacks.jsx",
          lineNumber: 55,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("th", { className: "p-3 text-left text-white", children: "Feedback Comment" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/AdminFeedbacks.jsx",
          lineNumber: 56,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("th", { className: "p-3 text-left text-white", children: "Improvement Area" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/AdminFeedbacks.jsx",
          lineNumber: 57,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/AdminFeedbacks.jsx",
        lineNumber: 52,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/AdminFeedbacks.jsx",
        lineNumber: 51,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("tbody", { children: feedbacks.map((fb, index) => /* @__PURE__ */ jsxDEV("tr", { className: "border-t hover:bg-gray-100", children: [
        /* @__PURE__ */ jsxDEV("td", { className: "p-3", children: fb.id }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/AdminFeedbacks.jsx",
          lineNumber: 63,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV("td", { className: "p-3", children: fb.name }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/AdminFeedbacks.jsx",
          lineNumber: 64,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV("td", { className: "p-3 text-yellow-500 font-medium", children: renderStars(fb.rating) }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/AdminFeedbacks.jsx",
          lineNumber: 65,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV("td", { className: "p-3", children: fb.comment }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/AdminFeedbacks.jsx",
          lineNumber: 68,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV("td", { className: "p-3", children: fb.improvement }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/AdminFeedbacks.jsx",
          lineNumber: 69,
          columnNumber: 19
        }, this)
      ] }, index, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/AdminFeedbacks.jsx",
        lineNumber: 62,
        columnNumber: 45
      }, this)) }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/AdminFeedbacks.jsx",
        lineNumber: 61,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/AdminFeedbacks.jsx",
      lineNumber: 49,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/AdminFeedbacks.jsx",
      lineNumber: 48,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/AdminFeedbacks.jsx",
    lineNumber: 44,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/AdminFeedbacks.jsx",
    lineNumber: 36,
    columnNumber: 10
  }, this);
};
_c = AdminFeedbacks;
export default AdminFeedbacks;
var _c;
$RefreshReg$(_c, "AdminFeedbacks");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/AdminFeedbacks.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcURRO0FBckRSLE9BQU9BLG9CQUFrQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDekIsT0FBT0MsaUJBQWlCO0FBRXhCLE1BQU1DLGlCQUFpQkEsTUFBTTtBQUczQixRQUFNQyxZQUFZLENBQ2hCO0FBQUEsSUFDRUMsSUFBSTtBQUFBLElBQ0pDLE1BQU07QUFBQSxJQUNOQyxRQUFRO0FBQUEsSUFDUkMsU0FBUztBQUFBLElBQ1RDLGFBQWE7QUFBQSxFQUNmLEdBQ0E7QUFBQSxJQUNFSixJQUFJO0FBQUEsSUFDSkMsTUFBTTtBQUFBLElBQ05DLFFBQVE7QUFBQSxJQUNSQyxTQUFTO0FBQUEsSUFDVEMsYUFBYTtBQUFBLEVBQ2YsR0FDQTtBQUFBLElBQ0VKLElBQUk7QUFBQSxJQUNKQyxNQUFNO0FBQUEsSUFDTkMsUUFBUTtBQUFBLElBQ1JDLFNBQVM7QUFBQSxJQUNUQyxhQUFhO0FBQUEsRUFDZixHQUNBO0FBQUEsSUFDRUosSUFBSTtBQUFBLElBQ0pDLE1BQU07QUFBQSxJQUNOQyxRQUFRO0FBQUEsSUFDUkMsU0FBUztBQUFBLElBQ1RDLGFBQWE7QUFBQSxFQUNmLENBQUM7QUFJSCxRQUFNQyxjQUFlSCxZQUFXO0FBQzlCLFdBQU8sSUFBSUksT0FBT0osTUFBTSxJQUFJLElBQUlJLE9BQU8sSUFBSUosTUFBTTtBQUFBLEVBQ25EO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsaUNBUWIsaUNBQUMsU0FBSSxXQUFVLHlCQUViO0FBQUEsMkJBQUMsUUFBRyxXQUFVLDRDQUEyQywrQkFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF3RTtBQUFBLElBRXhFLHVCQUFDLFNBQUksV0FBVSxpREFDYixpQ0FBQyxXQUFNLFdBQVUsMEJBRWY7QUFBQSw2QkFBQyxXQUFNLFdBQVUsY0FDZixpQ0FBQyxRQUNDO0FBQUEsK0JBQUMsUUFBRyxXQUFVLDRCQUEyQiwwQkFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtRDtBQUFBLFFBQ25ELHVCQUFDLFFBQUcsV0FBVSw0QkFBMkIsNEJBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUQ7QUFBQSxRQUNyRCx1QkFBQyxRQUFHLFdBQVUsNEJBQTJCLHVCQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdEO0FBQUEsUUFDaEQsdUJBQUMsUUFBRyxXQUFVLDRCQUEyQixnQ0FBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5RDtBQUFBLFFBQ3pELHVCQUFDLFFBQUcsV0FBVSw0QkFBMkIsZ0NBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUQ7QUFBQSxXQUwzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTUEsS0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUE7QUFBQSxNQUVBLHVCQUFDLFdBQ0VILG9CQUFVUSxJQUFJLENBQUNDLElBQUlDLFVBQ2xCLHVCQUFDLFFBQWUsV0FBVSw4QkFDeEI7QUFBQSwrQkFBQyxRQUFHLFdBQVUsT0FBT0QsYUFBR1IsTUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyQjtBQUFBLFFBQzNCLHVCQUFDLFFBQUcsV0FBVSxPQUFPUSxhQUFHUCxRQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZCO0FBQUEsUUFDN0IsdUJBQUMsUUFBRyxXQUFVLG1DQUNYSSxzQkFBWUcsR0FBR04sTUFBTSxLQUR4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFFBQUcsV0FBVSxPQUFPTSxhQUFHTCxXQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdDO0FBQUEsUUFDaEMsdUJBQUMsUUFBRyxXQUFVLE9BQU9LLGFBQUdKLGVBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0M7QUFBQSxXQVA3QkssT0FBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUEsQ0FDRCxLQVhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFZQTtBQUFBLFNBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EwQkEsS0EzQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTRCQTtBQUFBLE9BaENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FrQ0EsS0ExQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTJDQTtBQUVKO0FBQUNDLEtBckZLWjtBQXVGTixlQUFlQTtBQUFlLElBQUFZO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsIkFkbWluTmF2YmFyIiwiQWRtaW5GZWVkYmFja3MiLCJmZWVkYmFja3MiLCJpZCIsIm5hbWUiLCJyYXRpbmciLCJjb21tZW50IiwiaW1wcm92ZW1lbnQiLCJyZW5kZXJTdGFycyIsInJlcGVhdCIsIm1hcCIsImZiIiwiaW5kZXgiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkFkbWluRmVlZGJhY2tzLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnXHJcbmltcG9ydCBBZG1pbk5hdmJhciBmcm9tICcuLi8uLi9jb21wb25lbnRzL0FkbWluTmF2YmFyJyAvLyDinIUgRklYOiBtaXNzaW5nIGltcG9ydFxyXG5cclxuY29uc3QgQWRtaW5GZWVkYmFja3MgPSAoKSA9PiB7XHJcblxyXG4gIC8vIER1bW15IGZlZWRiYWNrIGRhdGFcclxuICBjb25zdCBmZWVkYmFja3MgPSBbXHJcbiAgICB7XHJcbiAgICAgIGlkOiBcIlNUVTAwMVwiLFxyXG4gICAgICBuYW1lOiBcIkpvaG4gRG9lXCIsXHJcbiAgICAgIHJhdGluZzogNCxcclxuICAgICAgY29tbWVudDogXCJUaGUgc3lzdGVtIGlzIHZlcnkgdXNlci1mcmllbmRseSBhbmQgaGVscGZ1bC5cIixcclxuICAgICAgaW1wcm92ZW1lbnQ6IFwiQWRkIGRhcmsgbW9kZSBmZWF0dXJlXCJcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGlkOiBcIlNUVTAwMlwiLFxyXG4gICAgICBuYW1lOiBcIkphbmUgU21pdGhcIixcclxuICAgICAgcmF0aW5nOiA1LFxyXG4gICAgICBjb21tZW50OiBcIkV4Y2VsbGVudCBleHBlcmllbmNlISBFdmVyeXRoaW5nIHdvcmtzIHBlcmZlY3RseS5cIixcclxuICAgICAgaW1wcm92ZW1lbnQ6IFwiTm8gbWFqb3IgaW1wcm92ZW1lbnRzIG5lZWRlZFwiXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBpZDogXCJTVFUwMDNcIixcclxuICAgICAgbmFtZTogXCJNaWNoYWVsIExlZVwiLFxyXG4gICAgICByYXRpbmc6IDMsXHJcbiAgICAgIGNvbW1lbnQ6IFwiR29vZCwgYnV0IHNvbWUgcGFnZXMgbG9hZCBzbG93bHkuXCIsXHJcbiAgICAgIGltcHJvdmVtZW50OiBcIkltcHJvdmUgcGVyZm9ybWFuY2Ugc3BlZWRcIlxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgaWQ6IFwiU1RVMDA0XCIsXHJcbiAgICAgIG5hbWU6IFwiU2FyYWggS2hhblwiLFxyXG4gICAgICByYXRpbmc6IDIsXHJcbiAgICAgIGNvbW1lbnQ6IFwiVUkgaXMgY29uZnVzaW5nIGluIHNvbWUgc2VjdGlvbnMuXCIsXHJcbiAgICAgIGltcHJvdmVtZW50OiBcIkltcHJvdmUgbmF2aWdhdGlvbiBhbmQgbGF5b3V0XCJcclxuICAgIH1cclxuICBdO1xyXG5cclxuICAvLyBSZW5kZXIgc3RhcnNcclxuICBjb25zdCByZW5kZXJTdGFycyA9IChyYXRpbmcpID0+IHtcclxuICAgIHJldHVybiBcIuKtkFwiLnJlcGVhdChyYXRpbmcpICsgXCLimIZcIi5yZXBlYXQoNSAtIHJhdGluZyk7XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBoLXNjcmVlbiBvdmVyZmxvdy1oaWRkZW5cIj5cclxuXHJcbiAgICAgIHsvKiBTaWRlYmFyXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy02NCBiZy1ncmF5LTgwMCB0ZXh0LXdoaXRlIGZpeGVkIGgtZnVsbFwiPlxyXG4gICAgICAgIDxBZG1pbk5hdmJhciAvPlxyXG4gICAgICA8L2Rpdj4gKi99XHJcblxyXG4gICAgICB7LyogTWFpbiBDb250ZW50ICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBwLTYgYmctc3VyZmFjZVwiPlxyXG5cclxuICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIG1iLTYgdGV4dC10ZXh0UHJpbWFyeVwiPlVzZXIgRmVlZGJhY2tz4q2QPC9oMj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBzaGFkb3ctbWQgcm91bmRlZC14bCBvdmVyZmxvdy1oaWRkZW5cIj5cclxuICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJ3LWZ1bGwgYm9yZGVyLWNvbGxhcHNlXCI+XHJcblxyXG4gICAgICAgICAgICA8dGhlYWQgY2xhc3NOYW1lPVwiYmctcHJpbWFyeVwiPlxyXG4gICAgICAgICAgICAgIDx0cj5cclxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTMgdGV4dC1sZWZ0IHRleHQtd2hpdGVcIj5TdHVkZW50IElEPC90aD5cclxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTMgdGV4dC1sZWZ0IHRleHQtd2hpdGVcIj5TdHVkZW50IE5hbWU8L3RoPlxyXG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMyB0ZXh0LWxlZnQgdGV4dC13aGl0ZVwiPlJhdGluZ3M8L3RoPlxyXG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMyB0ZXh0LWxlZnQgdGV4dC13aGl0ZVwiPkZlZWRiYWNrIENvbW1lbnQ8L3RoPlxyXG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMyB0ZXh0LWxlZnQgdGV4dC13aGl0ZVwiPkltcHJvdmVtZW50IEFyZWE8L3RoPlxyXG4gICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgIDwvdGhlYWQ+XHJcblxyXG4gICAgICAgICAgICA8dGJvZHk+XHJcbiAgICAgICAgICAgICAge2ZlZWRiYWNrcy5tYXAoKGZiLCBpbmRleCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgPHRyIGtleT17aW5kZXh9IGNsYXNzTmFtZT1cImJvcmRlci10IGhvdmVyOmJnLWdyYXktMTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTNcIj57ZmIuaWR9PC90ZD5cclxuICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtM1wiPntmYi5uYW1lfTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTMgdGV4dC15ZWxsb3ctNTAwIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge3JlbmRlclN0YXJzKGZiLnJhdGluZyl9XHJcbiAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTNcIj57ZmIuY29tbWVudH08L3RkPlxyXG4gICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0zXCI+e2ZiLmltcHJvdmVtZW50fTwvdGQ+XHJcbiAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICA8L3Rib2R5PlxyXG5cclxuICAgICAgICAgIDwvdGFibGU+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgQWRtaW5GZWVkYmFja3M7Il0sImZpbGUiOiJGOi9ZM1MyL0lUUE0gcHJvamVjdC9Qcm9NYXRlLS1Qcm9qZWN0LVBhcnRuZXItRmluZGVyL2Zyb250ZW5kL3NyYy9wYWdlcy9BZG1pbi9BZG1pbkZlZWRiYWNrcy5qc3gifQ==