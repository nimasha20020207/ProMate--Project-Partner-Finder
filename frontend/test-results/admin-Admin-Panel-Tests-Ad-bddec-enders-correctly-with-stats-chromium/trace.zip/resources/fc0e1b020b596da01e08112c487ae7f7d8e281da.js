import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Users/Settings.jsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Settings.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=383bea9f"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"];
import { useAuth } from "/src/context/AuthContext.jsx";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=383bea9f";
const Settings = () => {
  _s();
  const {
    logout,
    user,
    token
  } = useAuth();
  const navigate = useNavigate();
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [passwordError, setPasswordError] = useState("");
  const [passwordSuccess, setPasswordSuccess] = useState("");
  const [deletePassword, setDeletePassword] = useState("");
  const [deleteError, setDeleteError] = useState("");
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const handlePasswordChange = async (e) => {
    e.preventDefault();
    setPasswordError("");
    setPasswordSuccess("");
    if (newPassword !== confirmPassword) {
      setPasswordError("New passwords do not match");
      return;
    }
    try {
      const res = await fetch("http://localhost:3000/api/profile/me/password", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          "x-auth-token": token
        },
        body: JSON.stringify({
          currentPassword,
          newPassword
        })
      });
      const data = await res.json();
      if (res.ok) {
        setPasswordSuccess("Password successfully updated!");
        setCurrentPassword("");
        setNewPassword("");
        setConfirmPassword("");
      } else {
        setPasswordError(data.message || "Error updating password");
      }
    } catch (err) {
      setPasswordError("Server error occurred");
    }
  };
  const handleDeleteAccount = async () => {
    if (!deletePassword) {
      setDeleteError("Please enter your password to confirm");
      return;
    }
    try {
      const res = await fetch("http://localhost:3000/api/profile/delete-account", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-auth-token": token
        },
        body: JSON.stringify({
          password: deletePassword
        })
      });
      const data = await res.json();
      if (res.ok) {
        logout();
        navigate("/login");
      } else {
        setDeleteError(data.message || "Deletion failed. Check your password.");
      }
    } catch (err) {
      setDeleteError("Server error. Please try again later.");
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "section-card", style: {
    maxWidth: "600px",
    margin: "3rem auto"
  }, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "section-card-title", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "section-icon", children: "⚙️" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Settings.jsx",
        lineNumber: 86,
        columnNumber: 9
      }, this),
      "Account Settings"
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Settings.jsx",
      lineNumber: 85,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: {
      marginBottom: "2.5rem"
    }, children: [
      /* @__PURE__ */ jsxDEV("h4", { className: "sb-section-title", style: {
        padding: "0 0 0.5rem",
        borderBottom: "1px solid var(--border)",
        marginBottom: "1rem"
      }, children: "Preferences" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Settings.jsx",
        lineNumber: 93,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "notif-row", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "notif-info", children: [
          /* @__PURE__ */ jsxDEV("h5", { children: "Email Notifications" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Settings.jsx",
            lineNumber: 100,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { children: "Receive updates about project matches directly to your inbox." }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Settings.jsx",
            lineNumber: 101,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Settings.jsx",
          lineNumber: 99,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "toggle-switch", children: [
          /* @__PURE__ */ jsxDEV("input", { type: "checkbox", defaultChecked: true }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Settings.jsx",
            lineNumber: 104,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "toggle-track" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Settings.jsx",
            lineNumber: 105,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Settings.jsx",
          lineNumber: 103,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Settings.jsx",
        lineNumber: 98,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "notif-row", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "notif-info", children: [
          /* @__PURE__ */ jsxDEV("h5", { children: "Profile Visibility" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Settings.jsx",
            lineNumber: 110,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { children: "Allow other students to view your profile and skills." }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Settings.jsx",
            lineNumber: 111,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Settings.jsx",
          lineNumber: 109,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "toggle-switch", children: [
          /* @__PURE__ */ jsxDEV("input", { type: "checkbox", defaultChecked: true }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Settings.jsx",
            lineNumber: 114,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "toggle-track" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Settings.jsx",
            lineNumber: 115,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Settings.jsx",
          lineNumber: 113,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Settings.jsx",
        lineNumber: 108,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Settings.jsx",
      lineNumber: 90,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: {
      marginBottom: "2.5rem"
    }, children: [
      /* @__PURE__ */ jsxDEV("h4", { className: "sb-section-title", style: {
        padding: "0 0 0.5rem",
        borderBottom: "1px solid var(--border)",
        marginBottom: "1rem"
      }, children: "Account Security" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Settings.jsx",
        lineNumber: 123,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "notif-row", style: {
        alignItems: "center"
      }, children: [
        /* @__PURE__ */ jsxDEV("div", { className: "notif-info", children: [
          /* @__PURE__ */ jsxDEV("h5", { children: "Change Password" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Settings.jsx",
            lineNumber: 132,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { children: "Maintain your account's security by updating your password occasionally." }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Settings.jsx",
            lineNumber: 133,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Settings.jsx",
          lineNumber: 131,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("button", { className: "btn btn-outline btn-sm", onClick: () => navigate("/change-password"), children: "Update" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Settings.jsx",
          lineNumber: 135,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Settings.jsx",
        lineNumber: 128,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Settings.jsx",
      lineNumber: 120,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "danger-zone", style: {
      border: "1px solid rgba(239, 68, 68, 0.2)",
      padding: "1.5rem",
      borderRadius: "12px",
      background: "rgba(239, 68, 68, 0.05)"
    }, children: [
      /* @__PURE__ */ jsxDEV("h3", { style: {
        color: "var(--danger)",
        marginBottom: "0.5rem",
        fontSize: "1.1rem",
        fontWeight: 700
      }, children: "Delete Account" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Settings.jsx",
        lineNumber: 145,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { style: {
        fontSize: "0.85rem",
        color: "var(--mid)",
        marginBottom: "1rem"
      }, children: "Once you delete your account, there is no going back. Please be certain." }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Settings.jsx",
        lineNumber: 151,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "danger-actions", children: !showDeleteConfirm ? /* @__PURE__ */ jsxDEV("button", { className: "btn btn-danger", onClick: () => setShowDeleteConfirm(true), children: "Delete My Account" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Settings.jsx",
        lineNumber: 157,
        columnNumber: 33
      }, this) : /* @__PURE__ */ jsxDEV("div", { style: {
        display: "flex",
        flexDirection: "column",
        gap: "1rem",
        width: "100%"
      }, children: [
        /* @__PURE__ */ jsxDEV("div", { className: "form-group", style: {
          marginBottom: 0
        }, children: [
          /* @__PURE__ */ jsxDEV("label", { className: "form-label", style: {
            color: "var(--danger)"
          }, children: "Confirm Password" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Settings.jsx",
            lineNumber: 166,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("input", { type: "password", className: "ep-form-input", style: {
            borderColor: "var(--danger)"
          }, placeholder: "Enter password to confirm", value: deletePassword, onChange: (e) => {
            setDeletePassword(e.target.value);
            setDeleteError("");
          } }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Settings.jsx",
            lineNumber: 169,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Settings.jsx",
          lineNumber: 163,
          columnNumber: 15
        }, this),
        deleteError && /* @__PURE__ */ jsxDEV("div", { style: {
          color: "var(--danger)",
          fontSize: "0.8rem"
        }, children: [
          "⚠️ ",
          deleteError
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Settings.jsx",
          lineNumber: 176,
          columnNumber: 31
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: {
          display: "flex",
          gap: "0.5rem"
        }, children: [
          /* @__PURE__ */ jsxDEV("button", { className: "btn btn-danger", style: {
            flex: 1
          }, onClick: handleDeleteAccount, children: "Yes, Delete Everything" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Settings.jsx",
            lineNumber: 184,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("button", { className: "btn btn-outline", style: {
            flex: 1
          }, onClick: () => {
            setShowDeleteConfirm(false);
            setDeletePassword("");
            setDeleteError("");
          }, children: "Cancel" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Settings.jsx",
            lineNumber: 187,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Settings.jsx",
          lineNumber: 180,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Settings.jsx",
        lineNumber: 157,
        columnNumber: 140
      }, this) }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Settings.jsx",
        lineNumber: 156,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Settings.jsx",
      lineNumber: 139,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Settings.jsx",
    lineNumber: 81,
    columnNumber: 10
  }, this);
};
_s(Settings, "NekJAQSF5UZxtVwqrsRaw16zfZo=", false, function() {
  return [useAuth, useNavigate];
});
_c = Settings;
export default Settings;
var _c;
$RefreshReg$(_c, "Settings");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/Settings.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0VROzs7Ozs7Ozs7Ozs7Ozs7O0FBL0VSLE9BQU9BLFNBQVNDLGdCQUFnQjtBQUNoQyxTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLG1CQUFtQjtBQUU1QixNQUFNQyxXQUFXQSxNQUFNO0FBQUFDLEtBQUE7QUFDckIsUUFBTTtBQUFBLElBQUVDO0FBQUFBLElBQVFDO0FBQUFBLElBQU1DO0FBQUFBLEVBQU0sSUFBSU4sUUFBUTtBQUN4QyxRQUFNTyxXQUFXTixZQUFZO0FBRTdCLFFBQU0sQ0FBQ08saUJBQWlCQyxrQkFBa0IsSUFBSVYsU0FBUyxFQUFFO0FBQ3pELFFBQU0sQ0FBQ1csYUFBYUMsY0FBYyxJQUFJWixTQUFTLEVBQUU7QUFDakQsUUFBTSxDQUFDYSxpQkFBaUJDLGtCQUFrQixJQUFJZCxTQUFTLEVBQUU7QUFDekQsUUFBTSxDQUFDZSxlQUFlQyxnQkFBZ0IsSUFBSWhCLFNBQVMsRUFBRTtBQUNyRCxRQUFNLENBQUNpQixpQkFBaUJDLGtCQUFrQixJQUFJbEIsU0FBUyxFQUFFO0FBRXpELFFBQU0sQ0FBQ21CLGdCQUFnQkMsaUJBQWlCLElBQUlwQixTQUFTLEVBQUU7QUFDdkQsUUFBTSxDQUFDcUIsYUFBYUMsY0FBYyxJQUFJdEIsU0FBUyxFQUFFO0FBQ2pELFFBQU0sQ0FBQ3VCLG1CQUFtQkMsb0JBQW9CLElBQUl4QixTQUFTLEtBQUs7QUFFaEUsUUFBTXlCLHVCQUF1QixPQUFPQyxNQUFNO0FBQ3hDQSxNQUFFQyxlQUFlO0FBQ2pCWCxxQkFBaUIsRUFBRTtBQUNuQkUsdUJBQW1CLEVBQUU7QUFFckIsUUFBSVAsZ0JBQWdCRSxpQkFBaUI7QUFDbkNHLHVCQUFpQiw0QkFBNEI7QUFDN0M7QUFBQSxJQUNGO0FBRUEsUUFBSTtBQUNGLFlBQU1ZLE1BQU0sTUFBTUMsTUFBTSxpREFBaUQ7QUFBQSxRQUN2RUMsUUFBUTtBQUFBLFFBQ1JDLFNBQVM7QUFBQSxVQUFFLGdCQUFnQjtBQUFBLFVBQW9CLGdCQUFnQnhCO0FBQUFBLFFBQU07QUFBQSxRQUNyRXlCLE1BQU1DLEtBQUtDLFVBQVU7QUFBQSxVQUFFekI7QUFBQUEsVUFBaUJFO0FBQUFBLFFBQVksQ0FBQztBQUFBLE1BQ3ZELENBQUM7QUFFRCxZQUFNd0IsT0FBTyxNQUFNUCxJQUFJUSxLQUFLO0FBQzVCLFVBQUlSLElBQUlTLElBQUk7QUFDVm5CLDJCQUFtQixnQ0FBZ0M7QUFDbkRSLDJCQUFtQixFQUFFO0FBQ3JCRSx1QkFBZSxFQUFFO0FBQ2pCRSwyQkFBbUIsRUFBRTtBQUFBLE1BQ3ZCLE9BQU87QUFDTEUseUJBQWlCbUIsS0FBS0csV0FBVyx5QkFBeUI7QUFBQSxNQUM1RDtBQUFBLElBQ0YsU0FBU0MsS0FBSztBQUNadkIsdUJBQWlCLHVCQUF1QjtBQUFBLElBQzFDO0FBQUEsRUFDRjtBQUVBLFFBQU13QixzQkFBc0IsWUFBWTtBQUN0QyxRQUFJLENBQUNyQixnQkFBZ0I7QUFDbkJHLHFCQUFlLHVDQUF1QztBQUN0RDtBQUFBLElBQ0Y7QUFDQSxRQUFJO0FBQ0YsWUFBTU0sTUFBTSxNQUFNQyxNQUFNLG9EQUFvRDtBQUFBLFFBQzFFQyxRQUFRO0FBQUEsUUFDUkMsU0FBUztBQUFBLFVBQ1AsZ0JBQWdCO0FBQUEsVUFDaEIsZ0JBQWdCeEI7QUFBQUEsUUFDbEI7QUFBQSxRQUNBeUIsTUFBTUMsS0FBS0MsVUFBVTtBQUFBLFVBQUVPLFVBQVV0QjtBQUFBQSxRQUFlLENBQUM7QUFBQSxNQUNuRCxDQUFDO0FBRUQsWUFBTWdCLE9BQU8sTUFBTVAsSUFBSVEsS0FBSztBQUM1QixVQUFJUixJQUFJUyxJQUFJO0FBQ1ZoQyxlQUFPO0FBQ1BHLGlCQUFTLFFBQVE7QUFBQSxNQUNuQixPQUFPO0FBQ0xjLHVCQUFlYSxLQUFLRyxXQUFXLHVDQUF1QztBQUFBLE1BQ3hFO0FBQUEsSUFDRixTQUFTQyxLQUFLO0FBQ1pqQixxQkFBZSx1Q0FBdUM7QUFBQSxJQUN4RDtBQUFBLEVBQ0Y7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSxnQkFBZSxPQUFPO0FBQUEsSUFBRW9CLFVBQVU7QUFBQSxJQUFTQyxRQUFRO0FBQUEsRUFBWSxHQUM1RTtBQUFBLDJCQUFDLFNBQUksV0FBVSxzQkFDYjtBQUFBLDZCQUFDLFVBQUssV0FBVSxnQkFBZSxrQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpQztBQUFBLE1BQU87QUFBQSxTQUQxQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxJQUVBLHVCQUFDLFNBQUksT0FBTztBQUFBLE1BQUVDLGNBQWM7QUFBQSxJQUFTLEdBQ25DO0FBQUEsNkJBQUMsUUFBRyxXQUFVLG9CQUFtQixPQUFPO0FBQUEsUUFBRUMsU0FBUztBQUFBLFFBQWNDLGNBQWM7QUFBQSxRQUEyQkYsY0FBYztBQUFBLE1BQU8sR0FBRywyQkFBbEk7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2STtBQUFBLE1BQzdJLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSxpQ0FBQyxRQUFHLG1DQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVCO0FBQUEsVUFDdkIsdUJBQUMsT0FBRSw2RUFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnRTtBQUFBLGFBRmxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsaUNBQUMsV0FBTSxNQUFLLFlBQVcsZ0JBQWMsUUFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUM7QUFBQSxVQUNyQyx1QkFBQyxTQUFJLFdBQVUsa0JBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEI7QUFBQSxhQUZoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxXQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLGlDQUFDLFFBQUcsa0NBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0I7QUFBQSxVQUN0Qix1QkFBQyxPQUFFLHFFQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdEO0FBQUEsYUFGMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSxpQ0FBQyxXQUFNLE1BQUssWUFBVyxnQkFBYyxRQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxQztBQUFBLFVBQ3JDLHVCQUFDLFNBQUksV0FBVSxrQkFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4QjtBQUFBLGFBRmhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBO0FBQUEsU0FyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXNCQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxPQUFPO0FBQUEsTUFBRUEsY0FBYztBQUFBLElBQVMsR0FDbkM7QUFBQSw2QkFBQyxRQUFHLFdBQVUsb0JBQW1CLE9BQU87QUFBQSxRQUFFQyxTQUFTO0FBQUEsUUFBY0MsY0FBYztBQUFBLFFBQTJCRixjQUFjO0FBQUEsTUFBTyxHQUFHLGdDQUFsSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtKO0FBQUEsTUFDbEosdUJBQUMsU0FBSSxXQUFVLGFBQVksT0FBTztBQUFBLFFBQUVHLFlBQVk7QUFBQSxNQUFTLEdBQ3ZEO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSxpQ0FBQyxRQUFHLCtCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1CO0FBQUEsVUFDbkIsdUJBQUMsT0FBRSx3RkFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyRTtBQUFBLGFBRjdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsWUFBTyxXQUFVLDBCQUF5QixTQUFTLE1BQU12QyxTQUFTLGtCQUFrQixHQUFHLHNCQUF4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThGO0FBQUEsV0FMaEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1BO0FBQUEsU0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBU0E7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxlQUFjLE9BQU87QUFBQSxNQUFFd0MsUUFBUTtBQUFBLE1BQW9DSCxTQUFTO0FBQUEsTUFBVUksY0FBYztBQUFBLE1BQVFDLFlBQVk7QUFBQSxJQUEwQixHQUMvSjtBQUFBLDZCQUFDLFFBQUcsT0FBTztBQUFBLFFBQUVDLE9BQU87QUFBQSxRQUFpQlAsY0FBYztBQUFBLFFBQVVRLFVBQVU7QUFBQSxRQUFVQyxZQUFZO0FBQUEsTUFBSSxHQUFHLDhCQUFwRztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtIO0FBQUEsTUFDbEgsdUJBQUMsT0FBRSxPQUFPO0FBQUEsUUFBRUQsVUFBVTtBQUFBLFFBQVdELE9BQU87QUFBQSxRQUFjUCxjQUFjO0FBQUEsTUFBTyxHQUFHLHdGQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXNKO0FBQUEsTUFDdEosdUJBQUMsU0FBSSxXQUFVLGtCQUNaLFdBQUNyQixvQkFDQSx1QkFBQyxZQUFPLFdBQVUsa0JBQWlCLFNBQVMsTUFBTUMscUJBQXFCLElBQUksR0FBRyxpQ0FBOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErRixJQUUvRix1QkFBQyxTQUFJLE9BQU87QUFBQSxRQUFFOEIsU0FBUztBQUFBLFFBQVFDLGVBQWU7QUFBQSxRQUFVQyxLQUFLO0FBQUEsUUFBUUMsT0FBTztBQUFBLE1BQU8sR0FDakY7QUFBQSwrQkFBQyxTQUFJLFdBQVUsY0FBYSxPQUFPO0FBQUEsVUFBRWIsY0FBYztBQUFBLFFBQUUsR0FDbkQ7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsY0FBYSxPQUFPO0FBQUEsWUFBRU8sT0FBTztBQUFBLFVBQWdCLEdBQUcsZ0NBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlGO0FBQUEsVUFDakYsdUJBQUMsV0FDQyxNQUFLLFlBQ0wsV0FBVSxpQkFDVixPQUFPO0FBQUEsWUFBRU8sYUFBYTtBQUFBLFVBQWdCLEdBQ3RDLGFBQVksNkJBQ1osT0FBT3ZDLGdCQUNQLFVBQVdPLE9BQU07QUFDZk4sOEJBQWtCTSxFQUFFaUMsT0FBT0MsS0FBSztBQUNoQ3RDLDJCQUFlLEVBQUU7QUFBQSxVQUNuQixLQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBU0k7QUFBQSxhQVhOO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFhQTtBQUFBLFFBQ0NELGVBQWUsdUJBQUMsU0FBSSxPQUFPO0FBQUEsVUFBRThCLE9BQU87QUFBQSxVQUFpQkMsVUFBVTtBQUFBLFFBQVMsR0FBRztBQUFBO0FBQUEsVUFBSS9CO0FBQUFBLGFBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEU7QUFBQSxRQUM1Rix1QkFBQyxTQUFJLE9BQU87QUFBQSxVQUFFaUMsU0FBUztBQUFBLFVBQVFFLEtBQUs7QUFBQSxRQUFTLEdBQzNDO0FBQUEsaUNBQUMsWUFBTyxXQUFVLGtCQUFpQixPQUFPO0FBQUEsWUFBRUssTUFBTTtBQUFBLFVBQUUsR0FBRyxTQUFTckIscUJBQXFCLHNDQUFyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyRztBQUFBLFVBQzNHLHVCQUFDLFlBQU8sV0FBVSxtQkFBa0IsT0FBTztBQUFBLFlBQUVxQixNQUFNO0FBQUEsVUFBRSxHQUFHLFNBQVMsTUFBTTtBQUNyRXJDLGlDQUFxQixLQUFLO0FBQzFCSiw4QkFBa0IsRUFBRTtBQUNwQkUsMkJBQWUsRUFBRTtBQUFBLFVBQ25CLEdBQUcsc0JBSkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJUztBQUFBLGFBTlg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsV0F2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXdCQSxLQTVCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBOEJBO0FBQUEsU0FqQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWtDQTtBQUFBLE9BM0VGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E0RUE7QUFFSjtBQUFFbEIsR0F2SklELFVBQVE7QUFBQSxVQUNvQkYsU0FDZkMsV0FBVztBQUFBO0FBQUE0RCxLQUZ4QjNEO0FBeUpOLGVBQWVBO0FBQVMsSUFBQTJEO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsInVzZVN0YXRlIiwidXNlQXV0aCIsInVzZU5hdmlnYXRlIiwiU2V0dGluZ3MiLCJfcyIsImxvZ291dCIsInVzZXIiLCJ0b2tlbiIsIm5hdmlnYXRlIiwiY3VycmVudFBhc3N3b3JkIiwic2V0Q3VycmVudFBhc3N3b3JkIiwibmV3UGFzc3dvcmQiLCJzZXROZXdQYXNzd29yZCIsImNvbmZpcm1QYXNzd29yZCIsInNldENvbmZpcm1QYXNzd29yZCIsInBhc3N3b3JkRXJyb3IiLCJzZXRQYXNzd29yZEVycm9yIiwicGFzc3dvcmRTdWNjZXNzIiwic2V0UGFzc3dvcmRTdWNjZXNzIiwiZGVsZXRlUGFzc3dvcmQiLCJzZXREZWxldGVQYXNzd29yZCIsImRlbGV0ZUVycm9yIiwic2V0RGVsZXRlRXJyb3IiLCJzaG93RGVsZXRlQ29uZmlybSIsInNldFNob3dEZWxldGVDb25maXJtIiwiaGFuZGxlUGFzc3dvcmRDaGFuZ2UiLCJlIiwicHJldmVudERlZmF1bHQiLCJyZXMiLCJmZXRjaCIsIm1ldGhvZCIsImhlYWRlcnMiLCJib2R5IiwiSlNPTiIsInN0cmluZ2lmeSIsImRhdGEiLCJqc29uIiwib2siLCJtZXNzYWdlIiwiZXJyIiwiaGFuZGxlRGVsZXRlQWNjb3VudCIsInBhc3N3b3JkIiwibWF4V2lkdGgiLCJtYXJnaW4iLCJtYXJnaW5Cb3R0b20iLCJwYWRkaW5nIiwiYm9yZGVyQm90dG9tIiwiYWxpZ25JdGVtcyIsImJvcmRlciIsImJvcmRlclJhZGl1cyIsImJhY2tncm91bmQiLCJjb2xvciIsImZvbnRTaXplIiwiZm9udFdlaWdodCIsImRpc3BsYXkiLCJmbGV4RGlyZWN0aW9uIiwiZ2FwIiwid2lkdGgiLCJib3JkZXJDb2xvciIsInRhcmdldCIsInZhbHVlIiwiZmxleCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiU2V0dGluZ3MuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4uLy4uL2NvbnRleHQvQXV0aENvbnRleHQnO1xyXG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xyXG5cclxuY29uc3QgU2V0dGluZ3MgPSAoKSA9PiB7XHJcbiAgY29uc3QgeyBsb2dvdXQsIHVzZXIsIHRva2VuIH0gPSB1c2VBdXRoKCk7XHJcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xyXG5cclxuICBjb25zdCBbY3VycmVudFBhc3N3b3JkLCBzZXRDdXJyZW50UGFzc3dvcmRdID0gdXNlU3RhdGUoJycpO1xyXG4gIGNvbnN0IFtuZXdQYXNzd29yZCwgc2V0TmV3UGFzc3dvcmRdID0gdXNlU3RhdGUoJycpO1xyXG4gIGNvbnN0IFtjb25maXJtUGFzc3dvcmQsIHNldENvbmZpcm1QYXNzd29yZF0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgY29uc3QgW3Bhc3N3b3JkRXJyb3IsIHNldFBhc3N3b3JkRXJyb3JdID0gdXNlU3RhdGUoJycpO1xyXG4gIGNvbnN0IFtwYXNzd29yZFN1Y2Nlc3MsIHNldFBhc3N3b3JkU3VjY2Vzc10gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgXHJcbiAgY29uc3QgW2RlbGV0ZVBhc3N3b3JkLCBzZXREZWxldGVQYXNzd29yZF0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgY29uc3QgW2RlbGV0ZUVycm9yLCBzZXREZWxldGVFcnJvcl0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgY29uc3QgW3Nob3dEZWxldGVDb25maXJtLCBzZXRTaG93RGVsZXRlQ29uZmlybV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIGNvbnN0IGhhbmRsZVBhc3N3b3JkQ2hhbmdlID0gYXN5bmMgKGUpID0+IHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgIHNldFBhc3N3b3JkRXJyb3IoJycpO1xyXG4gICAgc2V0UGFzc3dvcmRTdWNjZXNzKCcnKTtcclxuICAgIFxyXG4gICAgaWYgKG5ld1Bhc3N3b3JkICE9PSBjb25maXJtUGFzc3dvcmQpIHtcclxuICAgICAgc2V0UGFzc3dvcmRFcnJvcignTmV3IHBhc3N3b3JkcyBkbyBub3QgbWF0Y2gnKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgXHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaCgnaHR0cDovL2xvY2FsaG9zdDozMDAwL2FwaS9wcm9maWxlL21lL3Bhc3N3b3JkJywge1xyXG4gICAgICAgIG1ldGhvZDogJ1BVVCcsXHJcbiAgICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLCAneC1hdXRoLXRva2VuJzogdG9rZW4gfSxcclxuICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7IGN1cnJlbnRQYXNzd29yZCwgbmV3UGFzc3dvcmQgfSlcclxuICAgICAgfSk7XHJcbiAgICAgIFxyXG4gICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzLmpzb24oKTtcclxuICAgICAgaWYgKHJlcy5vaykge1xyXG4gICAgICAgIHNldFBhc3N3b3JkU3VjY2VzcygnUGFzc3dvcmQgc3VjY2Vzc2Z1bGx5IHVwZGF0ZWQhJyk7XHJcbiAgICAgICAgc2V0Q3VycmVudFBhc3N3b3JkKCcnKTtcclxuICAgICAgICBzZXROZXdQYXNzd29yZCgnJyk7XHJcbiAgICAgICAgc2V0Q29uZmlybVBhc3N3b3JkKCcnKTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBzZXRQYXNzd29yZEVycm9yKGRhdGEubWVzc2FnZSB8fCAnRXJyb3IgdXBkYXRpbmcgcGFzc3dvcmQnKTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIHNldFBhc3N3b3JkRXJyb3IoJ1NlcnZlciBlcnJvciBvY2N1cnJlZCcpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZURlbGV0ZUFjY291bnQgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBpZiAoIWRlbGV0ZVBhc3N3b3JkKSB7XHJcbiAgICAgIHNldERlbGV0ZUVycm9yKFwiUGxlYXNlIGVudGVyIHlvdXIgcGFzc3dvcmQgdG8gY29uZmlybVwiKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goJ2h0dHA6Ly9sb2NhbGhvc3Q6MzAwMC9hcGkvcHJvZmlsZS9kZWxldGUtYWNjb3VudCcsIHtcclxuICAgICAgICBtZXRob2Q6ICdQT1NUJyxcclxuICAgICAgICBoZWFkZXJzOiB7IFxyXG4gICAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyxcclxuICAgICAgICAgICd4LWF1dGgtdG9rZW4nOiB0b2tlbiBcclxuICAgICAgICB9LFxyXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHsgcGFzc3dvcmQ6IGRlbGV0ZVBhc3N3b3JkIH0pXHJcbiAgICAgIH0pO1xyXG4gICAgICBcclxuICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlcy5qc29uKCk7XHJcbiAgICAgIGlmIChyZXMub2spIHtcclxuICAgICAgICBsb2dvdXQoKTtcclxuICAgICAgICBuYXZpZ2F0ZSgnL2xvZ2luJyk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgc2V0RGVsZXRlRXJyb3IoZGF0YS5tZXNzYWdlIHx8IFwiRGVsZXRpb24gZmFpbGVkLiBDaGVjayB5b3VyIHBhc3N3b3JkLlwiKTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIHNldERlbGV0ZUVycm9yKFwiU2VydmVyIGVycm9yLiBQbGVhc2UgdHJ5IGFnYWluIGxhdGVyLlwiKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJzZWN0aW9uLWNhcmRcIiBzdHlsZT17eyBtYXhXaWR0aDogJzYwMHB4JywgbWFyZ2luOiAnM3JlbSBhdXRvJyB9fT5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZWN0aW9uLWNhcmQtdGl0bGVcIj5cclxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzZWN0aW9uLWljb25cIj7impnvuI88L3NwYW4+XHJcbiAgICAgICAgQWNjb3VudCBTZXR0aW5nc1xyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIDxkaXYgc3R5bGU9e3sgbWFyZ2luQm90dG9tOiAnMi41cmVtJyB9fT5cclxuICAgICAgICA8aDQgY2xhc3NOYW1lPVwic2Itc2VjdGlvbi10aXRsZVwiIHN0eWxlPXt7IHBhZGRpbmc6ICcwIDAgMC41cmVtJywgYm9yZGVyQm90dG9tOiAnMXB4IHNvbGlkIHZhcigtLWJvcmRlciknLCBtYXJnaW5Cb3R0b206ICcxcmVtJyB9fT5QcmVmZXJlbmNlczwvaDQ+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJub3RpZi1yb3dcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibm90aWYtaW5mb1wiPlxyXG4gICAgICAgICAgICA8aDU+RW1haWwgTm90aWZpY2F0aW9uczwvaDU+XHJcbiAgICAgICAgICAgIDxwPlJlY2VpdmUgdXBkYXRlcyBhYm91dCBwcm9qZWN0IG1hdGNoZXMgZGlyZWN0bHkgdG8geW91ciBpbmJveC48L3A+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidG9nZ2xlLXN3aXRjaFwiPlxyXG4gICAgICAgICAgICA8aW5wdXQgdHlwZT1cImNoZWNrYm94XCIgZGVmYXVsdENoZWNrZWQgLz5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0b2dnbGUtdHJhY2tcIj48L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibm90aWYtcm93XCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm5vdGlmLWluZm9cIj5cclxuICAgICAgICAgICAgPGg1PlByb2ZpbGUgVmlzaWJpbGl0eTwvaDU+XHJcbiAgICAgICAgICAgIDxwPkFsbG93IG90aGVyIHN0dWRlbnRzIHRvIHZpZXcgeW91ciBwcm9maWxlIGFuZCBza2lsbHMuPC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRvZ2dsZS1zd2l0Y2hcIj5cclxuICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJjaGVja2JveFwiIGRlZmF1bHRDaGVja2VkIC8+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidG9nZ2xlLXRyYWNrXCI+PC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIFxyXG4gICAgICA8ZGl2IHN0eWxlPXt7IG1hcmdpbkJvdHRvbTogJzIuNXJlbScgfX0+XHJcbiAgICAgICAgPGg0IGNsYXNzTmFtZT1cInNiLXNlY3Rpb24tdGl0bGVcIiBzdHlsZT17eyBwYWRkaW5nOiAnMCAwIDAuNXJlbScsIGJvcmRlckJvdHRvbTogJzFweCBzb2xpZCB2YXIoLS1ib3JkZXIpJywgbWFyZ2luQm90dG9tOiAnMXJlbScgfX0+QWNjb3VudCBTZWN1cml0eTwvaDQ+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJub3RpZi1yb3dcIiBzdHlsZT17eyBhbGlnbkl0ZW1zOiAnY2VudGVyJyB9fT5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibm90aWYtaW5mb1wiPlxyXG4gICAgICAgICAgICA8aDU+Q2hhbmdlIFBhc3N3b3JkPC9oNT5cclxuICAgICAgICAgICAgPHA+TWFpbnRhaW4geW91ciBhY2NvdW50J3Mgc2VjdXJpdHkgYnkgdXBkYXRpbmcgeW91ciBwYXNzd29yZCBvY2Nhc2lvbmFsbHkuPC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImJ0biBidG4tb3V0bGluZSBidG4tc21cIiBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZSgnL2NoYW5nZS1wYXNzd29yZCcpfT5VcGRhdGU8L2J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImRhbmdlci16b25lXCIgc3R5bGU9e3sgYm9yZGVyOiAnMXB4IHNvbGlkIHJnYmEoMjM5LCA2OCwgNjgsIDAuMiknLCBwYWRkaW5nOiAnMS41cmVtJywgYm9yZGVyUmFkaXVzOiAnMTJweCcsIGJhY2tncm91bmQ6ICdyZ2JhKDIzOSwgNjgsIDY4LCAwLjA1KScgfX0+XHJcbiAgICAgICAgPGgzIHN0eWxlPXt7IGNvbG9yOiAndmFyKC0tZGFuZ2VyKScsIG1hcmdpbkJvdHRvbTogJzAuNXJlbScsIGZvbnRTaXplOiAnMS4xcmVtJywgZm9udFdlaWdodDogNzAwIH19PkRlbGV0ZSBBY2NvdW50PC9oMz5cclxuICAgICAgICA8cCBzdHlsZT17eyBmb250U2l6ZTogJzAuODVyZW0nLCBjb2xvcjogJ3ZhcigtLW1pZCknLCBtYXJnaW5Cb3R0b206ICcxcmVtJyB9fT5PbmNlIHlvdSBkZWxldGUgeW91ciBhY2NvdW50LCB0aGVyZSBpcyBubyBnb2luZyBiYWNrLiBQbGVhc2UgYmUgY2VydGFpbi48L3A+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkYW5nZXItYWN0aW9uc1wiPlxyXG4gICAgICAgICAgeyFzaG93RGVsZXRlQ29uZmlybSA/IChcclxuICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJidG4gYnRuLWRhbmdlclwiIG9uQ2xpY2s9eygpID0+IHNldFNob3dEZWxldGVDb25maXJtKHRydWUpfT5EZWxldGUgTXkgQWNjb3VudDwvYnV0dG9uPlxyXG4gICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGZsZXhEaXJlY3Rpb246ICdjb2x1bW4nLCBnYXA6ICcxcmVtJywgd2lkdGg6ICcxMDAlJyB9fT5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXBcIiBzdHlsZT17eyBtYXJnaW5Cb3R0b206IDAgfX0+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZm9ybS1sYWJlbFwiIHN0eWxlPXt7IGNvbG9yOiAndmFyKC0tZGFuZ2VyKScgfX0+Q29uZmlybSBQYXNzd29yZDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXQgXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJwYXNzd29yZFwiIFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJlcC1mb3JtLWlucHV0XCIgXHJcbiAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IGJvcmRlckNvbG9yOiAndmFyKC0tZGFuZ2VyKScgfX1cclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBwYXNzd29yZCB0byBjb25maXJtXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2RlbGV0ZVBhc3N3b3JkfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBzZXREZWxldGVQYXNzd29yZChlLnRhcmdldC52YWx1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0RGVsZXRlRXJyb3IoJycpO1xyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICB7ZGVsZXRlRXJyb3IgJiYgPGRpdiBzdHlsZT17eyBjb2xvcjogJ3ZhcigtLWRhbmdlciknLCBmb250U2l6ZTogJzAuOHJlbScgfX0+4pqg77iPIHtkZWxldGVFcnJvcn08L2Rpdj59XHJcbiAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIGdhcDogJzAuNXJlbScgfX0+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImJ0biBidG4tZGFuZ2VyXCIgc3R5bGU9e3sgZmxleDogMSB9fSBvbkNsaWNrPXtoYW5kbGVEZWxldGVBY2NvdW50fT5ZZXMsIERlbGV0ZSBFdmVyeXRoaW5nPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImJ0biBidG4tb3V0bGluZVwiIHN0eWxlPXt7IGZsZXg6IDEgfX0gb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBzZXRTaG93RGVsZXRlQ29uZmlybShmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICAgIHNldERlbGV0ZVBhc3N3b3JkKCcnKTtcclxuICAgICAgICAgICAgICAgICAgc2V0RGVsZXRlRXJyb3IoJycpO1xyXG4gICAgICAgICAgICAgICAgfX0+Q2FuY2VsPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgU2V0dGluZ3M7XHJcbiJdLCJmaWxlIjoiRjovWTNTMi9JVFBNIHByb2plY3QvUHJvTWF0ZS0tUHJvamVjdC1QYXJ0bmVyLUZpbmRlci9mcm9udGVuZC9zcmMvcGFnZXMvVXNlcnMvU2V0dGluZ3MuanN4In0=