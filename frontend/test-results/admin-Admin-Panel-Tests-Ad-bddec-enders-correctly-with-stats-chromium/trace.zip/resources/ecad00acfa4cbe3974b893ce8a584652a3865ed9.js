import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Notifications/Notifications.jsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Notifications/Notifications.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=383bea9f"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { useAuth } from "/src/context/AuthContext.jsx";
import "/src/pages/Notifications/Notifications.css";
const Notifications = () => {
  _s();
  const {
    user
  } = useAuth();
  const [notifications, setNotifications] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const fetchNotifications = async () => {
    try {
      const url = user?.studentId ? `http://localhost:3000/api/notifications?targetIt=${user.studentId}` : "http://localhost:3000/api/notifications";
      const res = await fetch(url);
      if (res.ok) {
        const data = await res.json();
        setNotifications(data);
      }
    } catch (err) {
      console.error("Failed to fetch notifications", err);
    } finally {
      setIsLoading(false);
    }
  };
  useEffect(() => {
    fetchNotifications();
  }, []);
  const handleResponse = async (notif, status) => {
    const isAccepted = status === "accepted";
    let projectName = "your";
    if (notif.message && notif.message.includes("Requested to join ")) {
      projectName = notif.message.replace("Requested to join ", "").replace(" project", "");
    }
    const payload = {
      senderIt: user ? `${user.studentId} - ${user.fullName}` : "Unknown",
      targetIt: notif.senderIt.split(" - ")[0],
      message: isAccepted ? `Request accepted ${projectName} project` : `Request rejected ${projectName} project`,
      type: status
    };
    try {
      await fetch("http://localhost:3000/api/notifications", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(payload)
      });
      const updatePayload = {
        message: isAccepted ? `You accepted - ${projectName} project` : `You rejected - ${projectName} project`,
        type: isAccepted ? "you_accepted" : "you_rejected"
      };
      await fetch(`http://localhost:3000/api/notifications/${notif._id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(updatePayload)
      });
      fetchNotifications();
    } catch (err) {
      console.error(err);
    }
  };
  const handleDelete = async (id) => {
    try {
      await fetch(`http://localhost:3000/api/notifications/${id}`, {
        method: "DELETE"
      });
      fetchNotifications();
    } catch (err) {
      console.error(err);
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "notif-page-container custom-scrollbar", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "notif-header", children: [
      /* @__PURE__ */ jsxDEV("h1", { children: "Notifications" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Notifications/Notifications.jsx",
        lineNumber: 87,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: "Manage your pending membership requests and alerts." }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Notifications/Notifications.jsx",
        lineNumber: 88,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Notifications/Notifications.jsx",
      lineNumber: 86,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "notif-list", children: isLoading ? /* @__PURE__ */ jsxDEV("div", { className: "notif-empty", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "spinner" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Notifications/Notifications.jsx",
        lineNumber: 93,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: "Loading alerts..." }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Notifications/Notifications.jsx",
        lineNumber: 94,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Notifications/Notifications.jsx",
      lineNumber: 92,
      columnNumber: 22
    }, this) : notifications.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "notif-empty notif-caught-up", children: [
      /* @__PURE__ */ jsxDEV("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", d: "M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Notifications/Notifications.jsx",
        lineNumber: 96,
        columnNumber: 88
      }, this) }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Notifications/Notifications.jsx",
        lineNumber: 96,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("h3", { children: "No new notifications" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Notifications/Notifications.jsx",
        lineNumber: 97,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: "You're all caught up! New alerts will appear here seamlessly." }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Notifications/Notifications.jsx",
        lineNumber: 98,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Notifications/Notifications.jsx",
      lineNumber: 95,
      columnNumber: 49
    }, this) : notifications.map((notif) => {
      const isRequest = notif.type === "join_request";
      return /* @__PURE__ */ jsxDEV("div", { className: `notif-card ${notif.type} flex flex-col md:flex-row gap-4 items-start md:items-center justify-between`, children: [
        /* @__PURE__ */ jsxDEV("div", { className: "notif-content flex items-center gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: `notif-icon ${notif.type}`, children: [
            notif.type === "join_request" && /* @__PURE__ */ jsxDEV("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", children: /* @__PURE__ */ jsxDEV("path", { d: "M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Notifications/Notifications.jsx",
              lineNumber: 104,
              columnNumber: 130
            }, this) }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Notifications/Notifications.jsx",
              lineNumber: 104,
              columnNumber: 55
            }, this),
            (notif.type === "accepted" || notif.type === "you_accepted") && /* @__PURE__ */ jsxDEV("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", children: /* @__PURE__ */ jsxDEV("path", { d: "M5 13l4 4L19 7" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Notifications/Notifications.jsx",
              lineNumber: 105,
              columnNumber: 161
            }, this) }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Notifications/Notifications.jsx",
              lineNumber: 105,
              columnNumber: 86
            }, this),
            (notif.type === "rejected" || notif.type === "you_rejected") && /* @__PURE__ */ jsxDEV("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", children: /* @__PURE__ */ jsxDEV("path", { d: "M6 18L18 6M6 6l12 12" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Notifications/Notifications.jsx",
              lineNumber: 106,
              columnNumber: 161
            }, this) }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Notifications/Notifications.jsx",
              lineNumber: 106,
              columnNumber: 86
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Notifications/Notifications.jsx",
            lineNumber: 103,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "notif-text", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "notif-it", children: notif.senderIt }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Notifications/Notifications.jsx",
              lineNumber: 109,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "notif-desc", children: notif.message }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Notifications/Notifications.jsx",
              lineNumber: 110,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Notifications/Notifications.jsx",
            lineNumber: 108,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Notifications/Notifications.jsx",
          lineNumber: 102,
          columnNumber: 17
        }, this),
        isRequest ? /* @__PURE__ */ jsxDEV("div", { className: "notif-actions flex gap-3 w-full md:w-auto mt-2 md:mt-0", children: [
          /* @__PURE__ */ jsxDEV("button", { className: "btn-notif btn-accept flex-1 md:flex-none", onClick: () => handleResponse(notif, "accepted"), children: "Accept" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Notifications/Notifications.jsx",
            lineNumber: 115,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("button", { className: "btn-notif btn-reject flex-1 md:flex-none", onClick: () => handleResponse(notif, "rejected"), children: "Reject" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Notifications/Notifications.jsx",
            lineNumber: 116,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Notifications/Notifications.jsx",
          lineNumber: 114,
          columnNumber: 30
        }, this) : /* @__PURE__ */ jsxDEV("div", { className: "notif-actions-simple flex items-center gap-4 w-full md:w-auto mt-2 md:mt-0", children: [
          /* @__PURE__ */ jsxDEV("span", { className: `status-badge ${notif.type}`, children: notif.type.includes("accepted") ? "Accepted" : "Rejected" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Notifications/Notifications.jsx",
            lineNumber: 118,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("button", { className: "btn-notif btn-dismiss", onClick: () => handleDelete(notif._id), children: "Dismiss" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Notifications/Notifications.jsx",
            lineNumber: 121,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Notifications/Notifications.jsx",
          lineNumber: 117,
          columnNumber: 28
        }, this)
      ] }, notif._id, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Notifications/Notifications.jsx",
        lineNumber: 101,
        columnNumber: 16
      }, this);
    }) }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Notifications/Notifications.jsx",
      lineNumber: 91,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Notifications/Notifications.jsx",
    lineNumber: 85,
    columnNumber: 10
  }, this);
};
_s(Notifications, "5SfNcQfYRaZlCBsmpc7GNyT9tG0=", false, function() {
  return [useAuth];
});
_c = Notifications;
export default Notifications;
var _c;
$RefreshReg$(_c, "Notifications");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Notifications/Notifications.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0ZROzs7Ozs7Ozs7Ozs7Ozs7O0FBeEZSLE9BQU9BLFNBQVNDLFVBQVVDLGlCQUFpQjtBQUMzQyxTQUFTQyxlQUFlO0FBQ3hCLE9BQU87QUFFUCxNQUFNQyxnQkFBZ0JBLE1BQU07QUFBQUMsS0FBQTtBQUMxQixRQUFNO0FBQUEsSUFBRUM7QUFBQUEsRUFBSyxJQUFJSCxRQUFRO0FBQ3pCLFFBQU0sQ0FBQ0ksZUFBZUMsZ0JBQWdCLElBQUlQLFNBQVMsRUFBRTtBQUNyRCxRQUFNLENBQUNRLFdBQVdDLFlBQVksSUFBSVQsU0FBUyxJQUFJO0FBRS9DLFFBQU1VLHFCQUFxQixZQUFZO0FBQ3JDLFFBQUk7QUFFRixZQUFNQyxNQUFNTixNQUFNTyxZQUNkLG9EQUFvRFAsS0FBS08sU0FBUyxLQUNsRTtBQUVKLFlBQU1DLE1BQU0sTUFBTUMsTUFBTUgsR0FBRztBQUMzQixVQUFJRSxJQUFJRSxJQUFJO0FBQ1YsY0FBTUMsT0FBTyxNQUFNSCxJQUFJSSxLQUFLO0FBQzVCVix5QkFBaUJTLElBQUk7QUFBQSxNQUN2QjtBQUFBLElBQ0YsU0FBU0UsS0FBSztBQUNaQyxjQUFRQyxNQUFNLGlDQUFpQ0YsR0FBRztBQUFBLElBQ3BELFVBQUM7QUFDQ1QsbUJBQWEsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQUVBUixZQUFVLE1BQU07QUFDZFMsdUJBQW1CO0FBQUEsRUFDckIsR0FBRyxFQUFFO0FBRUwsUUFBTVcsaUJBQWlCLE9BQU9DLE9BQU9DLFdBQVc7QUFDOUMsVUFBTUMsYUFBYUQsV0FBVztBQUc5QixRQUFJRSxjQUFjO0FBQ2xCLFFBQUlILE1BQU1JLFdBQVdKLE1BQU1JLFFBQVFDLFNBQVMsb0JBQW9CLEdBQUc7QUFDakVGLG9CQUFjSCxNQUFNSSxRQUFRRSxRQUFRLHNCQUFzQixFQUFFLEVBQUVBLFFBQVEsWUFBWSxFQUFFO0FBQUEsSUFDdEY7QUFHQSxVQUFNQyxVQUFVO0FBQUEsTUFDZEMsVUFBVXpCLE9BQU8sR0FBR0EsS0FBS08sU0FBUyxNQUFNUCxLQUFLMEIsUUFBUSxLQUFLO0FBQUEsTUFDMURDLFVBQVVWLE1BQU1RLFNBQVNHLE1BQU0sS0FBSyxFQUFFLENBQUM7QUFBQSxNQUN2Q1AsU0FBU0YsYUFBYSxvQkFBb0JDLFdBQVcsYUFBYSxvQkFBb0JBLFdBQVc7QUFBQSxNQUNqR1MsTUFBTVg7QUFBQUEsSUFDUjtBQUVBLFFBQUk7QUFFRixZQUFNVCxNQUFNLDJDQUEyQztBQUFBLFFBQ3JEcUIsUUFBUTtBQUFBLFFBQ1JDLFNBQVM7QUFBQSxVQUFFLGdCQUFnQjtBQUFBLFFBQW1CO0FBQUEsUUFDOUNDLE1BQU1DLEtBQUtDLFVBQVVWLE9BQU87QUFBQSxNQUM5QixDQUFDO0FBR0QsWUFBTVcsZ0JBQWdCO0FBQUEsUUFDcEJkLFNBQVNGLGFBQWEsa0JBQWtCQyxXQUFXLGFBQWEsa0JBQWtCQSxXQUFXO0FBQUEsUUFDN0ZTLE1BQU1WLGFBQWEsaUJBQWlCO0FBQUEsTUFDdEM7QUFFQSxZQUFNVixNQUFNLDJDQUEyQ1EsTUFBTW1CLEdBQUcsSUFBSTtBQUFBLFFBQ2xFTixRQUFRO0FBQUEsUUFDUkMsU0FBUztBQUFBLFVBQUUsZ0JBQWdCO0FBQUEsUUFBbUI7QUFBQSxRQUM5Q0MsTUFBTUMsS0FBS0MsVUFBVUMsYUFBYTtBQUFBLE1BQ3BDLENBQUM7QUFHRDlCLHlCQUFtQjtBQUFBLElBQ3JCLFNBQVNRLEtBQUs7QUFDWkMsY0FBUUMsTUFBTUYsR0FBRztBQUFBLElBQ25CO0FBQUEsRUFDRjtBQUVBLFFBQU13QixlQUFlLE9BQU9DLE9BQU87QUFDakMsUUFBSTtBQUNGLFlBQU03QixNQUFNLDJDQUEyQzZCLEVBQUUsSUFBSTtBQUFBLFFBQUVSLFFBQVE7QUFBQSxNQUFTLENBQUM7QUFDakZ6Qix5QkFBbUI7QUFBQSxJQUNyQixTQUFTUSxLQUFLO0FBQ1pDLGNBQVFDLE1BQU1GLEdBQUc7QUFBQSxJQUNuQjtBQUFBLEVBQ0Y7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLDJCQUFDLFNBQUksV0FBVSxnQkFDYjtBQUFBLDZCQUFDLFFBQUcsNkJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpQjtBQUFBLE1BQ2pCLHVCQUFDLE9BQUUsbUVBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFzRDtBQUFBLFNBRnhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLGNBQ1pWLHNCQUNDLHVCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGFBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5QjtBQUFBLE1BQ3pCLHVCQUFDLE9BQUUsaUNBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvQjtBQUFBLFNBRnRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQSxJQUNFRixjQUFjc0MsV0FBVyxJQUMzQix1QkFBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSw2QkFBQyxTQUFJLFNBQVEsYUFBWSxNQUFLLFFBQU8sUUFBTyxnQkFBZSxhQUFZLEtBQUksaUNBQUMsVUFBSyxlQUFjLFNBQVEsZ0JBQWUsU0FBUSxHQUFFLG1EQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFHLEtBQWhMO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUw7QUFBQSxNQUN2TCx1QkFBQyxRQUFHLG9DQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0I7QUFBQSxNQUN4Qix1QkFBQyxPQUFFLDZFQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0U7QUFBQSxTQUhsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUEsSUFFQXRDLGNBQWN1QyxJQUFJdkIsV0FBUztBQUN6QixZQUFNd0IsWUFBWXhCLE1BQU1ZLFNBQVM7QUFFakMsYUFDRSx1QkFBQyxTQUFvQixXQUFXLGNBQWNaLE1BQU1ZLElBQUksZ0ZBQ3REO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFXLGNBQWNaLE1BQU1ZLElBQUksSUFDckNaO0FBQUFBLGtCQUFNWSxTQUFTLGtCQUNkLHVCQUFDLFNBQUksU0FBUSxhQUFZLE1BQUssUUFBTyxRQUFPLGdCQUFlLGFBQVksS0FBSSxpQ0FBQyxVQUFLLEdBQUUsbU1BQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd00sS0FBblI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMFI7QUFBQSxhQUUxUlosTUFBTVksU0FBUyxjQUFjWixNQUFNWSxTQUFTLG1CQUM1Qyx1QkFBQyxTQUFJLFNBQVEsYUFBWSxNQUFLLFFBQU8sUUFBTyxnQkFBZSxhQUFZLEtBQUksaUNBQUMsVUFBSyxHQUFFLG9CQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlCLEtBQXBHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJHO0FBQUEsYUFFM0daLE1BQU1ZLFNBQVMsY0FBY1osTUFBTVksU0FBUyxtQkFDNUMsdUJBQUMsU0FBSSxTQUFRLGFBQVksTUFBSyxRQUFPLFFBQU8sZ0JBQWUsYUFBWSxLQUFJLGlDQUFDLFVBQUssR0FBRSwwQkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErQixLQUExRztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpSDtBQUFBLGVBUnJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVUE7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsbUNBQUMsVUFBSyxXQUFVLFlBQVlaLGdCQUFNUSxZQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyQztBQUFBLFlBQzNDLHVCQUFDLE9BQUUsV0FBVSxjQUFjUixnQkFBTUksV0FBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUM7QUFBQSxlQUYzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsYUFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ0JBO0FBQUEsUUFFQ29CLFlBQ0MsdUJBQUMsU0FBSSxXQUFVLDBEQUNiO0FBQUEsaUNBQUMsWUFBTyxXQUFVLDRDQUEyQyxTQUFTLE1BQU16QixlQUFlQyxPQUFPLFVBQVUsR0FBRyxzQkFBL0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUg7QUFBQSxVQUNySCx1QkFBQyxZQUFPLFdBQVUsNENBQTJDLFNBQVMsTUFBTUQsZUFBZUMsT0FBTyxVQUFVLEdBQUcsc0JBQS9HO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFIO0FBQUEsYUFGdkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBLElBRUEsdUJBQUMsU0FBSSxXQUFVLDhFQUNiO0FBQUEsaUNBQUMsVUFBSyxXQUFXLGdCQUFnQkEsTUFBTVksSUFBSSxJQUN4Q1osZ0JBQU1ZLEtBQUtQLFNBQVMsVUFBVSxJQUFJLGFBQWEsY0FEbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsWUFBTyxXQUFVLHlCQUF3QixTQUFTLE1BQU1lLGFBQWFwQixNQUFNbUIsR0FBRyxHQUFHLHVCQUFsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5RjtBQUFBLGFBSjNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFdBOUJNbkIsTUFBTW1CLEtBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFnQ0E7QUFBQSxJQUVKLENBQUMsS0FuREw7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXFEQTtBQUFBLE9BM0RGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E0REE7QUFFSjtBQUFFckMsR0FoSklELGVBQWE7QUFBQSxVQUNBRCxPQUFPO0FBQUE7QUFBQTZDLEtBRHBCNUM7QUFrSk4sZUFBZUE7QUFBYyxJQUFBNEM7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJ1c2VBdXRoIiwiTm90aWZpY2F0aW9ucyIsIl9zIiwidXNlciIsIm5vdGlmaWNhdGlvbnMiLCJzZXROb3RpZmljYXRpb25zIiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwiZmV0Y2hOb3RpZmljYXRpb25zIiwidXJsIiwic3R1ZGVudElkIiwicmVzIiwiZmV0Y2giLCJvayIsImRhdGEiLCJqc29uIiwiZXJyIiwiY29uc29sZSIsImVycm9yIiwiaGFuZGxlUmVzcG9uc2UiLCJub3RpZiIsInN0YXR1cyIsImlzQWNjZXB0ZWQiLCJwcm9qZWN0TmFtZSIsIm1lc3NhZ2UiLCJpbmNsdWRlcyIsInJlcGxhY2UiLCJwYXlsb2FkIiwic2VuZGVySXQiLCJmdWxsTmFtZSIsInRhcmdldEl0Iiwic3BsaXQiLCJ0eXBlIiwibWV0aG9kIiwiaGVhZGVycyIsImJvZHkiLCJKU09OIiwic3RyaW5naWZ5IiwidXBkYXRlUGF5bG9hZCIsIl9pZCIsImhhbmRsZURlbGV0ZSIsImlkIiwibGVuZ3RoIiwibWFwIiwiaXNSZXF1ZXN0IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJOb3RpZmljYXRpb25zLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4uLy4uL2NvbnRleHQvQXV0aENvbnRleHQnO1xyXG5pbXBvcnQgJy4vTm90aWZpY2F0aW9ucy5jc3MnO1xyXG5cclxuY29uc3QgTm90aWZpY2F0aW9ucyA9ICgpID0+IHtcclxuICBjb25zdCB7IHVzZXIgfSA9IHVzZUF1dGgoKTtcclxuICBjb25zdCBbbm90aWZpY2F0aW9ucywgc2V0Tm90aWZpY2F0aW9uc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpO1xyXG5cclxuICBjb25zdCBmZXRjaE5vdGlmaWNhdGlvbnMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICAvLyBPbmx5IGZldGNoIG5vdGlmaWNhdGlvbnMgdGFyZ2V0ZWQgYXQgdGhlIGN1cnJlbnRseSBsb2dnZWQtaW4gdXNlclxyXG4gICAgICBjb25zdCB1cmwgPSB1c2VyPy5zdHVkZW50SWQgXHJcbiAgICAgICAgPyBgaHR0cDovL2xvY2FsaG9zdDozMDAwL2FwaS9ub3RpZmljYXRpb25zP3RhcmdldEl0PSR7dXNlci5zdHVkZW50SWR9YFxyXG4gICAgICAgIDogJ2h0dHA6Ly9sb2NhbGhvc3Q6MzAwMC9hcGkvbm90aWZpY2F0aW9ucyc7XHJcbiAgICAgICAgXHJcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKHVybCk7XHJcbiAgICAgIGlmIChyZXMub2spIHtcclxuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzLmpzb24oKTtcclxuICAgICAgICBzZXROb3RpZmljYXRpb25zKGRhdGEpO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgY29uc29sZS5lcnJvcignRmFpbGVkIHRvIGZldGNoIG5vdGlmaWNhdGlvbnMnLCBlcnIpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgZmV0Y2hOb3RpZmljYXRpb25zKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCBoYW5kbGVSZXNwb25zZSA9IGFzeW5jIChub3RpZiwgc3RhdHVzKSA9PiB7XHJcbiAgICBjb25zdCBpc0FjY2VwdGVkID0gc3RhdHVzID09PSAnYWNjZXB0ZWQnO1xyXG5cclxuICAgIC8vIFNhZmVseSBleHRyYWN0IHRoZSBwcm9qZWN0IG5hbWUgZnJvbSB0aGUgaW5jb21pbmcgbm90aWZpY2F0aW9uIG1lc3NhZ2VcclxuICAgIGxldCBwcm9qZWN0TmFtZSA9IFwieW91clwiO1xyXG4gICAgaWYgKG5vdGlmLm1lc3NhZ2UgJiYgbm90aWYubWVzc2FnZS5pbmNsdWRlcygnUmVxdWVzdGVkIHRvIGpvaW4gJykpIHtcclxuICAgICAgcHJvamVjdE5hbWUgPSBub3RpZi5tZXNzYWdlLnJlcGxhY2UoJ1JlcXVlc3RlZCB0byBqb2luICcsICcnKS5yZXBsYWNlKCcgcHJvamVjdCcsICcnKTtcclxuICAgIH1cclxuXHJcbiAgICAvLyBDcmVhdGUgbmV3IHN0YXR1cyBub3RpZmljYXRpb24gcmVwbGFjaW5nIHRoZSBhY3Rpb24gcmVxdWVzdFxyXG4gICAgY29uc3QgcGF5bG9hZCA9IHtcclxuICAgICAgc2VuZGVySXQ6IHVzZXIgPyBgJHt1c2VyLnN0dWRlbnRJZH0gLSAke3VzZXIuZnVsbE5hbWV9YCA6ICdVbmtub3duJyxcclxuICAgICAgdGFyZ2V0SXQ6IG5vdGlmLnNlbmRlckl0LnNwbGl0KCcgLSAnKVswXSxcclxuICAgICAgbWVzc2FnZTogaXNBY2NlcHRlZCA/IGBSZXF1ZXN0IGFjY2VwdGVkICR7cHJvamVjdE5hbWV9IHByb2plY3RgIDogYFJlcXVlc3QgcmVqZWN0ZWQgJHtwcm9qZWN0TmFtZX0gcHJvamVjdGAsXHJcbiAgICAgIHR5cGU6IHN0YXR1c1xyXG4gICAgfTtcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICAvLyAxLiBTZW5kIHRoZSBuZXcgc3RhdHVzIG5vdGlmaWNhdGlvbiBiYWNrIHRvIHRoZSBzeXN0ZW1cclxuICAgICAgYXdhaXQgZmV0Y2goJ2h0dHA6Ly9sb2NhbGhvc3Q6MzAwMC9hcGkvbm90aWZpY2F0aW9ucycsIHtcclxuICAgICAgICBtZXRob2Q6ICdQT1NUJyxcclxuICAgICAgICBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSxcclxuICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeShwYXlsb2FkKVxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIC8vIDIuIFVwZGF0ZSB0aGUgcGVuZGluZyByZXF1ZXN0IGluc3RlYWQgb2YgZGVsZXRpbmcgaXRcclxuICAgICAgY29uc3QgdXBkYXRlUGF5bG9hZCA9IHtcclxuICAgICAgICBtZXNzYWdlOiBpc0FjY2VwdGVkID8gYFlvdSBhY2NlcHRlZCAtICR7cHJvamVjdE5hbWV9IHByb2plY3RgIDogYFlvdSByZWplY3RlZCAtICR7cHJvamVjdE5hbWV9IHByb2plY3RgLFxyXG4gICAgICAgIHR5cGU6IGlzQWNjZXB0ZWQgPyAneW91X2FjY2VwdGVkJyA6ICd5b3VfcmVqZWN0ZWQnXHJcbiAgICAgIH07XHJcblxyXG4gICAgICBhd2FpdCBmZXRjaChgaHR0cDovL2xvY2FsaG9zdDozMDAwL2FwaS9ub3RpZmljYXRpb25zLyR7bm90aWYuX2lkfWAsIHtcclxuICAgICAgICBtZXRob2Q6ICdQVVQnLFxyXG4gICAgICAgIGhlYWRlcnM6IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9LFxyXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHVwZGF0ZVBheWxvYWQpXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgLy8gMy4gSG90LXJlbG9hZCBmZWVkXHJcbiAgICAgIGZldGNoTm90aWZpY2F0aW9ucygpO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoZXJyKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVEZWxldGUgPSBhc3luYyAoaWQpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGF3YWl0IGZldGNoKGBodHRwOi8vbG9jYWxob3N0OjMwMDAvYXBpL25vdGlmaWNhdGlvbnMvJHtpZH1gLCB7IG1ldGhvZDogJ0RFTEVURScgfSk7XHJcbiAgICAgIGZldGNoTm90aWZpY2F0aW9ucygpO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoZXJyKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIm5vdGlmLXBhZ2UtY29udGFpbmVyIGN1c3RvbS1zY3JvbGxiYXJcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJub3RpZi1oZWFkZXJcIj5cclxuICAgICAgICA8aDE+Tm90aWZpY2F0aW9uczwvaDE+XHJcbiAgICAgICAgPHA+TWFuYWdlIHlvdXIgcGVuZGluZyBtZW1iZXJzaGlwIHJlcXVlc3RzIGFuZCBhbGVydHMuPC9wPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibm90aWYtbGlzdFwiPlxyXG4gICAgICAgIHtpc0xvYWRpbmcgPyAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm5vdGlmLWVtcHR5XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3Bpbm5lclwiPjwvZGl2PlxyXG4gICAgICAgICAgICA8cD5Mb2FkaW5nIGFsZXJ0cy4uLjwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICkgOiBub3RpZmljYXRpb25zLmxlbmd0aCA9PT0gMCA/IChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibm90aWYtZW1wdHkgbm90aWYtY2F1Z2h0LXVwXCI+XHJcbiAgICAgICAgICAgIDxzdmcgdmlld0JveD1cIjAgMCAyNCAyNFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgc3Ryb2tlV2lkdGg9XCIyXCI+PHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIGQ9XCJNOSAxMmwyIDIgNC00bTYgMmE5IDkgMCAxMS0xOCAwIDkgOSAwIDAxMTggMHpcIj48L3BhdGg+PC9zdmc+XHJcbiAgICAgICAgICAgIDxoMz5ObyBuZXcgbm90aWZpY2F0aW9uczwvaDM+XHJcbiAgICAgICAgICAgIDxwPllvdSdyZSBhbGwgY2F1Z2h0IHVwISBOZXcgYWxlcnRzIHdpbGwgYXBwZWFyIGhlcmUgc2VhbWxlc3NseS48L3A+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApIDogKFxyXG4gICAgICAgICAgbm90aWZpY2F0aW9ucy5tYXAobm90aWYgPT4ge1xyXG4gICAgICAgICAgICBjb25zdCBpc1JlcXVlc3QgPSBub3RpZi50eXBlID09PSAnam9pbl9yZXF1ZXN0JztcclxuXHJcbiAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBrZXk9e25vdGlmLl9pZH0gY2xhc3NOYW1lPXtgbm90aWYtY2FyZCAke25vdGlmLnR5cGV9IGZsZXggZmxleC1jb2wgbWQ6ZmxleC1yb3cgZ2FwLTQgaXRlbXMtc3RhcnQgbWQ6aXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbmB9PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJub3RpZi1jb250ZW50IGZsZXggaXRlbXMtY2VudGVyIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgbm90aWYtaWNvbiAke25vdGlmLnR5cGV9YH0+XHJcbiAgICAgICAgICAgICAgICAgICAge25vdGlmLnR5cGUgPT09ICdqb2luX3JlcXVlc3QnICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxzdmcgdmlld0JveD1cIjAgMCAyNCAyNFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgc3Ryb2tlV2lkdGg9XCIyXCI+PHBhdGggZD1cIk0xNSAxN2g1bC0xLjQwNS0xLjQwNUEyLjAzMiAyLjAzMiAwIDAxMTggMTQuMTU4VjExYTYuMDAyIDYuMDAyIDAgMDAtNC01LjY1OVY1YTIgMiAwIDEwLTQgMHYuMzQxQzcuNjcgNi4xNjUgNiA4LjM4OCA2IDExdjMuMTU5YzAgLjUzOC0uMjE0IDEuMDU1LS41OTUgMS40MzZMNCAxN2g1bTYgMHYxYTMgMyAwIDExLTYgMHYtMW02IDBIOVwiPjwvcGF0aD48L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIHsobm90aWYudHlwZSA9PT0gJ2FjY2VwdGVkJyB8fCBub3RpZi50eXBlID09PSAneW91X2FjY2VwdGVkJykgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPHN2ZyB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiBzdHJva2VXaWR0aD1cIjJcIj48cGF0aCBkPVwiTTUgMTNsNCA0TDE5IDdcIj48L3BhdGg+PC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICB7KG5vdGlmLnR5cGUgPT09ICdyZWplY3RlZCcgfHwgbm90aWYudHlwZSA9PT0gJ3lvdV9yZWplY3RlZCcpICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxzdmcgdmlld0JveD1cIjAgMCAyNCAyNFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgc3Ryb2tlV2lkdGg9XCIyXCI+PHBhdGggZD1cIk02IDE4TDE4IDZNNiA2bDEyIDEyXCI+PC9wYXRoPjwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm5vdGlmLXRleHRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJub3RpZi1pdFwiPntub3RpZi5zZW5kZXJJdH08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibm90aWYtZGVzY1wiPntub3RpZi5tZXNzYWdlfTwvcD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICB7aXNSZXF1ZXN0ID8gKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm5vdGlmLWFjdGlvbnMgZmxleCBnYXAtMyB3LWZ1bGwgbWQ6dy1hdXRvIG10LTIgbWQ6bXQtMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYnRuLW5vdGlmIGJ0bi1hY2NlcHQgZmxleC0xIG1kOmZsZXgtbm9uZVwiIG9uQ2xpY2s9eygpID0+IGhhbmRsZVJlc3BvbnNlKG5vdGlmLCAnYWNjZXB0ZWQnKX0+QWNjZXB0PC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJidG4tbm90aWYgYnRuLXJlamVjdCBmbGV4LTEgbWQ6ZmxleC1ub25lXCIgb25DbGljaz17KCkgPT4gaGFuZGxlUmVzcG9uc2Uobm90aWYsICdyZWplY3RlZCcpfT5SZWplY3Q8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm5vdGlmLWFjdGlvbnMtc2ltcGxlIGZsZXggaXRlbXMtY2VudGVyIGdhcC00IHctZnVsbCBtZDp3LWF1dG8gbXQtMiBtZDptdC0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgc3RhdHVzLWJhZGdlICR7bm90aWYudHlwZX1gfT5cclxuICAgICAgICAgICAgICAgICAgICAgIHtub3RpZi50eXBlLmluY2x1ZGVzKCdhY2NlcHRlZCcpID8gJ0FjY2VwdGVkJyA6ICdSZWplY3RlZCd9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYnRuLW5vdGlmIGJ0bi1kaXNtaXNzXCIgb25DbGljaz17KCkgPT4gaGFuZGxlRGVsZXRlKG5vdGlmLl9pZCl9PkRpc21pc3M8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApO1xyXG4gICAgICAgICAgfSlcclxuICAgICAgICApfVxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBOb3RpZmljYXRpb25zO1xyXG4iXSwiZmlsZSI6IkY6L1kzUzIvSVRQTSBwcm9qZWN0L1Byb01hdGUtLVByb2plY3QtUGFydG5lci1GaW5kZXIvZnJvbnRlbmQvc3JjL3BhZ2VzL05vdGlmaWNhdGlvbnMvTm90aWZpY2F0aW9ucy5qc3gifQ==