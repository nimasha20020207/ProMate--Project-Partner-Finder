import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Users/VerifyOTP.jsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/VerifyOTP.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=383bea9f"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"];
import { useLocation, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=383bea9f";
const VerifyOTP = () => {
  _s();
  const navigate = useNavigate();
  const location = useLocation();
  const [otp, setOtp] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const email = location.state?.email;
  if (!email) {
    navigate("/forgot-password");
    return null;
  }
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    if (otp.length !== 6) {
      setError("Please enter the 6-digit code exactly.");
      return;
    }
    setLoading(true);
    try {
      const res = await fetch("http://localhost:3000/api/auth/verify-otp", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          email,
          otp
        })
      });
      const data = await res.json();
      if (res.ok) {
        navigate("/reset-password", {
          state: {
            email,
            otp
          }
        });
      } else {
        setError(data.message || "Invalid or expired OTP.");
      }
    } catch (err) {
      setError("Server error.");
    } finally {
      setLoading(false);
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "page active", style: {
    display: "flex",
    minHeight: "100vh",
    alignItems: "center",
    justifyContent: "center"
  }, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "auth-blob-1" }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/VerifyOTP.jsx",
      lineNumber: 60,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "auth-blob-2" }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/VerifyOTP.jsx",
      lineNumber: 61,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "auth-card", style: {
      zIndex: 10
    }, children: [
      /* @__PURE__ */ jsxDEV("div", { className: "auth-header", style: {
        marginBottom: "1.5rem",
        textAlign: "center"
      }, children: [
        /* @__PURE__ */ jsxDEV("h2", { children: "Verify Email" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/VerifyOTP.jsx",
          lineNumber: 69,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: [
          "We sent a 6-digit code to ",
          /* @__PURE__ */ jsxDEV("strong", { children: email }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/VerifyOTP.jsx",
            lineNumber: 70,
            columnNumber: 40
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/VerifyOTP.jsx",
          lineNumber: 70,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/VerifyOTP.jsx",
        lineNumber: 65,
        columnNumber: 9
      }, this),
      error && /* @__PURE__ */ jsxDEV("div", { className: "form-error show", style: {
        marginBottom: "1rem",
        textAlign: "center"
      }, children: error }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/VerifyOTP.jsx",
        lineNumber: 73,
        columnNumber: 19
      }, this),
      /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, children: [
        /* @__PURE__ */ jsxDEV("div", { className: "form-group text-center", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "form-label", style: {
            textAlign: "center"
          }, children: "Authentication Code" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/VerifyOTP.jsx",
            lineNumber: 80,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("input", { type: "text", className: "form-input text-center text-2xl tracking-widest", maxLength: 6, value: otp, onChange: (e) => setOtp(e.target.value.replace(/\D/g, "")), placeholder: "000000", style: {
            padding: "1rem"
          } }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/VerifyOTP.jsx",
            lineNumber: 83,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/VerifyOTP.jsx",
          lineNumber: 79,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("button", { type: "submit", className: "btn btn-primary btn-full flex justify-center mt-4", style: {
          padding: ".8rem"
        }, disabled: loading, children: loading ? "Verifying..." : "Verify Code" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/VerifyOTP.jsx",
          lineNumber: 87,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/VerifyOTP.jsx",
        lineNumber: 78,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/VerifyOTP.jsx",
      lineNumber: 62,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/VerifyOTP.jsx",
    lineNumber: 54,
    columnNumber: 10
  }, this);
};
_s(VerifyOTP, "ZBsA45dA9CDjAauxlltV1ogdEjQ=", false, function() {
  return [useNavigate, useLocation];
});
_c = VerifyOTP;
export default VerifyOTP;
var _c;
$RefreshReg$(_c, "VerifyOTP");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/VerifyOTP.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbURNOzs7Ozs7Ozs7Ozs7Ozs7O0FBbkROLE9BQU9BLFNBQVNDLGdCQUFnQjtBQUNoQyxTQUFTQyxhQUFhQyxtQkFBbUI7QUFFekMsTUFBTUMsWUFBWUEsTUFBTTtBQUFBQyxLQUFBO0FBQ3RCLFFBQU1DLFdBQVdILFlBQVk7QUFDN0IsUUFBTUksV0FBV0wsWUFBWTtBQUM3QixRQUFNLENBQUNNLEtBQUtDLE1BQU0sSUFBSVIsU0FBUyxFQUFFO0FBQ2pDLFFBQU0sQ0FBQ1MsT0FBT0MsUUFBUSxJQUFJVixTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDVyxTQUFTQyxVQUFVLElBQUlaLFNBQVMsS0FBSztBQUU1QyxRQUFNYSxRQUFRUCxTQUFTUSxPQUFPRDtBQUU5QixNQUFJLENBQUNBLE9BQU87QUFFVlIsYUFBUyxrQkFBa0I7QUFDM0IsV0FBTztBQUFBLEVBQ1Q7QUFFQSxRQUFNVSxlQUFlLE9BQU9DLE1BQU07QUFDaENBLE1BQUVDLGVBQWU7QUFDakJQLGFBQVMsRUFBRTtBQUVYLFFBQUlILElBQUlXLFdBQVcsR0FBRztBQUNwQlIsZUFBUyx3Q0FBd0M7QUFDakQ7QUFBQSxJQUNGO0FBRUFFLGVBQVcsSUFBSTtBQUNmLFFBQUk7QUFDRixZQUFNTyxNQUFNLE1BQU1DLE1BQU0sNkNBQTZDO0FBQUEsUUFDbkVDLFFBQVE7QUFBQSxRQUNSQyxTQUFTO0FBQUEsVUFBRSxnQkFBZ0I7QUFBQSxRQUFtQjtBQUFBLFFBQzlDQyxNQUFNQyxLQUFLQyxVQUFVO0FBQUEsVUFBRVo7QUFBQUEsVUFBT047QUFBQUEsUUFBSSxDQUFDO0FBQUEsTUFDckMsQ0FBQztBQUNELFlBQU1tQixPQUFPLE1BQU1QLElBQUlRLEtBQUs7QUFFNUIsVUFBSVIsSUFBSVMsSUFBSTtBQUVWdkIsaUJBQVMsbUJBQW1CO0FBQUEsVUFBRVMsT0FBTztBQUFBLFlBQUVEO0FBQUFBLFlBQU9OO0FBQUFBLFVBQUk7QUFBQSxRQUFFLENBQUM7QUFBQSxNQUN2RCxPQUFPO0FBQ0xHLGlCQUFTZ0IsS0FBS0csV0FBVyx5QkFBeUI7QUFBQSxNQUNwRDtBQUFBLElBQ0YsU0FBU0MsS0FBSztBQUNacEIsZUFBUyxlQUFlO0FBQUEsSUFDMUIsVUFBQztBQUNDRSxpQkFBVyxLQUFLO0FBQUEsSUFDbEI7QUFBQSxFQUNGO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsZUFBYyxPQUFPO0FBQUEsSUFBRW1CLFNBQVM7QUFBQSxJQUFRQyxXQUFXO0FBQUEsSUFBU0MsWUFBWTtBQUFBLElBQVVDLGdCQUFnQjtBQUFBLEVBQVMsR0FDeEg7QUFBQSwyQkFBQyxTQUFJLFdBQVUsaUJBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE2QjtBQUFBLElBQzdCLHVCQUFDLFNBQUksV0FBVSxpQkFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTZCO0FBQUEsSUFDN0IsdUJBQUMsU0FBSSxXQUFVLGFBQVksT0FBTztBQUFBLE1BQUVDLFFBQVE7QUFBQSxJQUFHLEdBQzdDO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGVBQWMsT0FBTztBQUFBLFFBQUVDLGNBQWM7QUFBQSxRQUFVQyxXQUFXO0FBQUEsTUFBUyxHQUNoRjtBQUFBLCtCQUFDLFFBQUcsNEJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnQjtBQUFBLFFBQ2hCLHVCQUFDLE9BQUU7QUFBQTtBQUFBLFVBQTBCLHVCQUFDLFlBQVF4QixtQkFBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFlO0FBQUEsYUFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxRDtBQUFBLFdBRnZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BRUNKLFNBQVMsdUJBQUMsU0FBSSxXQUFVLG1CQUFrQixPQUFPO0FBQUEsUUFBRTJCLGNBQWM7QUFBQSxRQUFRQyxXQUFXO0FBQUEsTUFBUyxHQUFJNUIsbUJBQXhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBOEY7QUFBQSxNQUV4Ryx1QkFBQyxVQUFLLFVBQVVNLGNBQ2Q7QUFBQSwrQkFBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsY0FBYSxPQUFPO0FBQUEsWUFBRXNCLFdBQVc7QUFBQSxVQUFTLEdBQUcsbUNBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlGO0FBQUEsVUFDakYsdUJBQUMsV0FDQyxNQUFLLFFBQ0wsV0FBVSxtREFDVixXQUFXLEdBQ1gsT0FBTzlCLEtBQ1AsVUFBV1MsT0FBTVIsT0FBT1EsRUFBRXNCLE9BQU9DLE1BQU1DLFFBQVEsT0FBTyxFQUFFLENBQUMsR0FDekQsYUFBWSxVQUNaLE9BQU87QUFBQSxZQUFFQyxTQUFTO0FBQUEsVUFBTyxLQVAzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU82QjtBQUFBLGFBVC9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFXQTtBQUFBLFFBQ0EsdUJBQUMsWUFBTyxNQUFLLFVBQVMsV0FBVSxxREFBb0QsT0FBTztBQUFBLFVBQUVBLFNBQVM7QUFBQSxRQUFRLEdBQUcsVUFBVTlCLFNBQ3hIQSxvQkFBVSxpQkFBaUIsaUJBRDlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWdCQTtBQUFBLFNBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F5QkE7QUFBQSxPQTVCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNkJBO0FBRUo7QUFBRVAsR0E5RUlELFdBQVM7QUFBQSxVQUNJRCxhQUNBRCxXQUFXO0FBQUE7QUFBQXlDLEtBRnhCdkM7QUFnRk4sZUFBZUE7QUFBVSxJQUFBdUM7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwidXNlU3RhdGUiLCJ1c2VMb2NhdGlvbiIsInVzZU5hdmlnYXRlIiwiVmVyaWZ5T1RQIiwiX3MiLCJuYXZpZ2F0ZSIsImxvY2F0aW9uIiwib3RwIiwic2V0T3RwIiwiZXJyb3IiLCJzZXRFcnJvciIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwiZW1haWwiLCJzdGF0ZSIsImhhbmRsZVN1Ym1pdCIsImUiLCJwcmV2ZW50RGVmYXVsdCIsImxlbmd0aCIsInJlcyIsImZldGNoIiwibWV0aG9kIiwiaGVhZGVycyIsImJvZHkiLCJKU09OIiwic3RyaW5naWZ5IiwiZGF0YSIsImpzb24iLCJvayIsIm1lc3NhZ2UiLCJlcnIiLCJkaXNwbGF5IiwibWluSGVpZ2h0IiwiYWxpZ25JdGVtcyIsImp1c3RpZnlDb250ZW50IiwiekluZGV4IiwibWFyZ2luQm90dG9tIiwidGV4dEFsaWduIiwidGFyZ2V0IiwidmFsdWUiLCJyZXBsYWNlIiwicGFkZGluZyIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiVmVyaWZ5T1RQLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IHVzZUxvY2F0aW9uLCB1c2VOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xyXG5cclxuY29uc3QgVmVyaWZ5T1RQID0gKCkgPT4ge1xyXG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcclxuICBjb25zdCBsb2NhdGlvbiA9IHVzZUxvY2F0aW9uKCk7XHJcbiAgY29uc3QgW290cCwgc2V0T3RwXSA9IHVzZVN0YXRlKCcnKTtcclxuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKCcnKTtcclxuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgXHJcbiAgY29uc3QgZW1haWwgPSBsb2NhdGlvbi5zdGF0ZT8uZW1haWw7XHJcblxyXG4gIGlmICghZW1haWwpIHtcclxuICAgIC8vIElmIHVzZXIgYXJyaXZlZCBoZXJlIGRpcmVjdGx5IHdpdGhvdXQgYW4gZW1haWwgaW4gc3RhdGUsIHJlZGlyZWN0IGJhY2tcclxuICAgIG5hdmlnYXRlKCcvZm9yZ290LXBhc3N3b3JkJyk7XHJcbiAgICByZXR1cm4gbnVsbDtcclxuICB9XHJcblxyXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICBzZXRFcnJvcignJyk7XHJcblxyXG4gICAgaWYgKG90cC5sZW5ndGggIT09IDYpIHtcclxuICAgICAgc2V0RXJyb3IoJ1BsZWFzZSBlbnRlciB0aGUgNi1kaWdpdCBjb2RlIGV4YWN0bHkuJyk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBzZXRMb2FkaW5nKHRydWUpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goJ2h0dHA6Ly9sb2NhbGhvc3Q6MzAwMC9hcGkvYXV0aC92ZXJpZnktb3RwJywge1xyXG4gICAgICAgIG1ldGhvZDogJ1BPU1QnLFxyXG4gICAgICAgIGhlYWRlcnM6IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9LFxyXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHsgZW1haWwsIG90cCB9KVxyXG4gICAgICB9KTtcclxuICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlcy5qc29uKCk7XHJcbiAgICAgIFxyXG4gICAgICBpZiAocmVzLm9rKSB7XHJcbiAgICAgICAgLy8gUGFzcyBib3RoIGVtYWlsIGFuZCB0aGUgdmVyaWZpZWQgT1RQIChhcyBwcm9vZikgdG8gdGhlIGZpbmFsIHJlc2V0IHNjcmVlblxyXG4gICAgICAgIG5hdmlnYXRlKCcvcmVzZXQtcGFzc3dvcmQnLCB7IHN0YXRlOiB7IGVtYWlsLCBvdHAgfSB9KTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBzZXRFcnJvcihkYXRhLm1lc3NhZ2UgfHwgJ0ludmFsaWQgb3IgZXhwaXJlZCBPVFAuJyk7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBzZXRFcnJvcignU2VydmVyIGVycm9yLicpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwicGFnZSBhY3RpdmVcIiBzdHlsZT17eyBkaXNwbGF5OiAnZmxleCcsIG1pbkhlaWdodDogJzEwMHZoJywgYWxpZ25JdGVtczogJ2NlbnRlcicsIGp1c3RpZnlDb250ZW50OiAnY2VudGVyJyB9fT5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJhdXRoLWJsb2ItMVwiPjwvZGl2PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImF1dGgtYmxvYi0yXCI+PC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYXV0aC1jYXJkXCIgc3R5bGU9e3sgekluZGV4OiAxMCB9fT5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImF1dGgtaGVhZGVyXCIgc3R5bGU9e3sgbWFyZ2luQm90dG9tOiAnMS41cmVtJywgdGV4dEFsaWduOiAnY2VudGVyJyB9fT5cclxuICAgICAgICAgIDxoMj5WZXJpZnkgRW1haWw8L2gyPlxyXG4gICAgICAgICAgPHA+V2Ugc2VudCBhIDYtZGlnaXQgY29kZSB0byA8c3Ryb25nPntlbWFpbH08L3N0cm9uZz48L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgXHJcbiAgICAgICAge2Vycm9yICYmIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1lcnJvciBzaG93XCIgc3R5bGU9e3sgbWFyZ2luQm90dG9tOiAnMXJlbScsIHRleHRBbGlnbjogJ2NlbnRlcicgfX0+e2Vycm9yfTwvZGl2Pn1cclxuICAgICAgICBcclxuICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU3VibWl0fT5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1ncm91cCB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZm9ybS1sYWJlbFwiIHN0eWxlPXt7IHRleHRBbGlnbjogJ2NlbnRlcicgfX0+QXV0aGVudGljYXRpb24gQ29kZTwvbGFiZWw+XHJcbiAgICAgICAgICAgIDxpbnB1dCBcclxuICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiIFxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZvcm0taW5wdXQgdGV4dC1jZW50ZXIgdGV4dC0yeGwgdHJhY2tpbmctd2lkZXN0XCIgXHJcbiAgICAgICAgICAgICAgbWF4TGVuZ3RoPXs2fVxyXG4gICAgICAgICAgICAgIHZhbHVlPXtvdHB9IFxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0T3RwKGUudGFyZ2V0LnZhbHVlLnJlcGxhY2UoL1xcRC9nLCAnJykpfSBcclxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIjAwMDAwMFwiIFxyXG4gICAgICAgICAgICAgIHN0eWxlPXt7IHBhZGRpbmc6ICcxcmVtJyB9fVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBjbGFzc05hbWU9XCJidG4gYnRuLXByaW1hcnkgYnRuLWZ1bGwgZmxleCBqdXN0aWZ5LWNlbnRlciBtdC00XCIgc3R5bGU9e3sgcGFkZGluZzogJy44cmVtJyB9fSBkaXNhYmxlZD17bG9hZGluZ30+XHJcbiAgICAgICAgICAgIHtsb2FkaW5nID8gJ1ZlcmlmeWluZy4uLicgOiAnVmVyaWZ5IENvZGUnfVxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9mb3JtPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBWZXJpZnlPVFA7XHJcbiJdLCJmaWxlIjoiRjovWTNTMi9JVFBNIHByb2plY3QvUHJvTWF0ZS0tUHJvamVjdC1QYXJ0bmVyLUZpbmRlci9mcm9udGVuZC9zcmMvcGFnZXMvVXNlcnMvVmVyaWZ5T1RQLmpzeCJ9