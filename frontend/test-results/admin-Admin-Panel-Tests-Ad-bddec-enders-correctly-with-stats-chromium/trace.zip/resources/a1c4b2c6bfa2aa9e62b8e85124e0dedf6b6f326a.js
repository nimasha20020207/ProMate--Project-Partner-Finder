import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ProtectedRoute.jsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/ProtectedRoute.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=383bea9f"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import { Navigate } from "/node_modules/.vite/deps/react-router-dom.js?v=383bea9f";
import { useAuth } from "/src/context/AuthContext.jsx";
import Navbar from "/src/components/Navbar.jsx";
import AdminNavbar from "/src/components/AdminNavbar.jsx";
const ProtectedRoute = ({
  children,
  allowedRoles
}) => {
  _s();
  const {
    user,
    token,
    loading
  } = useAuth();
  if (loading) {
    return /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center h-screen bg-slate-50", children: /* @__PURE__ */ jsxDEV("div", { className: "animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary" }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/ProtectedRoute.jsx",
      lineNumber: 19,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/ProtectedRoute.jsx",
      lineNumber: 18,
      columnNumber: 12
    }, this);
  }
  if (!token) {
    return /* @__PURE__ */ jsxDEV(Navigate, { to: "/login", replace: true }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/ProtectedRoute.jsx",
      lineNumber: 23,
      columnNumber: 12
    }, this);
  }
  if (!user) {
    return /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center h-screen bg-slate-50", children: /* @__PURE__ */ jsxDEV("div", { className: "animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary" }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/ProtectedRoute.jsx",
      lineNumber: 29,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/ProtectedRoute.jsx",
      lineNumber: 28,
      columnNumber: 12
    }, this);
  }
  if (allowedRoles && !allowedRoles.includes(user.role)) {
    if (user.role === "admin") {
      return /* @__PURE__ */ jsxDEV(Navigate, { to: "/admindashboard", replace: true }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/ProtectedRoute.jsx",
        lineNumber: 37,
        columnNumber: 14
      }, this);
    } else {
      return /* @__PURE__ */ jsxDEV(Navigate, { to: "/dashboard", replace: true }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/ProtectedRoute.jsx",
        lineNumber: 39,
        columnNumber: 14
      }, this);
    }
  }
  const Navigation = user.role === "admin" ? AdminNavbar : Navbar;
  return /* @__PURE__ */ jsxDEV("div", { className: "flex h-screen overflow-hidden bg-slate-50", children: [
    /* @__PURE__ */ jsxDEV(Navigation, {}, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/ProtectedRoute.jsx",
      lineNumber: 46,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("main", { className: "flex-1 overflow-y-auto p-4 transition-all duration-300", children }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/ProtectedRoute.jsx",
      lineNumber: 47,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/ProtectedRoute.jsx",
    lineNumber: 45,
    columnNumber: 10
  }, this);
};
_s(ProtectedRoute, "blXMumh0eZXeGIY+65DREFUmUF0=", false, function() {
  return [useAuth];
});
_c = ProtectedRoute;
export default ProtectedRoute;
var _c;
$RefreshReg$(_c, "ProtectedRoute");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/components/ProtectedRoute.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBWVE7Ozs7Ozs7Ozs7Ozs7Ozs7QUFaUixPQUFPQSxXQUFXO0FBQ2xCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxlQUFlO0FBQ3hCLE9BQU9DLFlBQVk7QUFDbkIsT0FBT0MsaUJBQWlCO0FBRXhCLE1BQU1DLGlCQUFpQkEsQ0FBQztBQUFBLEVBQUVDO0FBQUFBLEVBQVVDO0FBQWEsTUFBTTtBQUFBQyxLQUFBO0FBQ3JELFFBQU07QUFBQSxJQUFFQztBQUFBQSxJQUFNQztBQUFBQSxJQUFPQztBQUFBQSxFQUFRLElBQUlULFFBQVE7QUFFekMsTUFBSVMsU0FBUztBQUNYLFdBQ0UsdUJBQUMsU0FBSSxXQUFVLHlEQUNiLGlDQUFDLFNBQUksV0FBVSw4RUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBGLEtBRDVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLEVBRUo7QUFFQSxNQUFJLENBQUNELE9BQU87QUFDVixXQUFPLHVCQUFDLFlBQVMsSUFBRyxVQUFTLFNBQU8sUUFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE2QjtBQUFBLEVBQ3RDO0FBR0EsTUFBSSxDQUFDRCxNQUFNO0FBQ1QsV0FDRSx1QkFBQyxTQUFJLFdBQVUseURBQ2IsaUNBQUMsU0FBSSxXQUFVLDhFQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMEYsS0FENUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsRUFFSjtBQUdBLE1BQUlGLGdCQUFnQixDQUFDQSxhQUFhSyxTQUFTSCxLQUFLSSxJQUFJLEdBQUc7QUFFckQsUUFBSUosS0FBS0ksU0FBUyxTQUFTO0FBQ3pCLGFBQU8sdUJBQUMsWUFBUyxJQUFHLG1CQUFrQixTQUFPLFFBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0M7QUFBQSxJQUMvQyxPQUFPO0FBQ0wsYUFBTyx1QkFBQyxZQUFTLElBQUcsY0FBYSxTQUFPLFFBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUM7QUFBQSxJQUMxQztBQUFBLEVBQ0Y7QUFHQSxRQUFNQyxhQUFhTCxLQUFLSSxTQUFTLFVBQVVULGNBQWNEO0FBRXpELFNBQ0UsdUJBQUMsU0FBSSxXQUFVLDZDQUNiO0FBQUEsMkJBQUMsZ0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFXO0FBQUEsSUFDWCx1QkFBQyxVQUFLLFdBQVUsMERBQ2JHLFlBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsT0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBS0E7QUFFSjtBQUFFRSxHQTdDSUgsZ0JBQWM7QUFBQSxVQUNlSCxPQUFPO0FBQUE7QUFBQWEsS0FEcENWO0FBK0NOLGVBQWVBO0FBQWUsSUFBQVU7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwiTmF2aWdhdGUiLCJ1c2VBdXRoIiwiTmF2YmFyIiwiQWRtaW5OYXZiYXIiLCJQcm90ZWN0ZWRSb3V0ZSIsImNoaWxkcmVuIiwiYWxsb3dlZFJvbGVzIiwiX3MiLCJ1c2VyIiwidG9rZW4iLCJsb2FkaW5nIiwiaW5jbHVkZXMiLCJyb2xlIiwiTmF2aWdhdGlvbiIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUHJvdGVjdGVkUm91dGUuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IE5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XHJcbmltcG9ydCB7IHVzZUF1dGggfSBmcm9tICcuLi9jb250ZXh0L0F1dGhDb250ZXh0JztcclxuaW1wb3J0IE5hdmJhciBmcm9tICcuL05hdmJhcic7XHJcbmltcG9ydCBBZG1pbk5hdmJhciBmcm9tICcuL0FkbWluTmF2YmFyJztcclxuXHJcbmNvbnN0IFByb3RlY3RlZFJvdXRlID0gKHsgY2hpbGRyZW4sIGFsbG93ZWRSb2xlcyB9KSA9PiB7XHJcbiAgY29uc3QgeyB1c2VyLCB0b2tlbiwgbG9hZGluZyB9ID0gdXNlQXV0aCgpO1xyXG5cclxuICBpZiAobG9hZGluZykge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBoLXNjcmVlbiBiZy1zbGF0ZS01MFwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYW5pbWF0ZS1zcGluIHJvdW5kZWQtZnVsbCBoLTEyIHctMTIgYm9yZGVyLXQtMiBib3JkZXItYi0yIGJvcmRlci1wcmltYXJ5XCI+PC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxuICB9XHJcblxyXG4gIGlmICghdG9rZW4pIHtcclxuICAgIHJldHVybiA8TmF2aWdhdGUgdG89XCIvbG9naW5cIiByZXBsYWNlIC8+O1xyXG4gIH1cclxuXHJcbiAgLy8gSWYgdXNlciBkYXRhIGlzIG5vdCB5ZXQgbG9hZGVkLCBzaG93IGxvYWRpbmdcclxuICBpZiAoIXVzZXIpIHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgaC1zY3JlZW4gYmctc2xhdGUtNTBcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFuaW1hdGUtc3BpbiByb3VuZGVkLWZ1bGwgaC0xMiB3LTEyIGJvcmRlci10LTIgYm9yZGVyLWItMiBib3JkZXItcHJpbWFyeVwiPjwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgICk7XHJcbiAgfVxyXG5cclxuICAvLyBDaGVjayByb2xlIGF1dGhvcml6YXRpb25cclxuICBpZiAoYWxsb3dlZFJvbGVzICYmICFhbGxvd2VkUm9sZXMuaW5jbHVkZXModXNlci5yb2xlKSkge1xyXG4gICAgLy8gUmVkaXJlY3QgYmFzZWQgb24gdGhlaXIgYWN0dWFsIHJvbGVcclxuICAgIGlmICh1c2VyLnJvbGUgPT09ICdhZG1pbicpIHtcclxuICAgICAgcmV0dXJuIDxOYXZpZ2F0ZSB0bz1cIi9hZG1pbmRhc2hib2FyZFwiIHJlcGxhY2UgLz47XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXR1cm4gPE5hdmlnYXRlIHRvPVwiL2Rhc2hib2FyZFwiIHJlcGxhY2UgLz47XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvLyBTZWxlY3QgdGhlIGNvcnJlY3QgTmF2YmFyIGJhc2VkIG9uIHJvbGVcclxuICBjb25zdCBOYXZpZ2F0aW9uID0gdXNlci5yb2xlID09PSAnYWRtaW4nID8gQWRtaW5OYXZiYXIgOiBOYXZiYXI7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaC1zY3JlZW4gb3ZlcmZsb3ctaGlkZGVuIGJnLXNsYXRlLTUwXCI+XHJcbiAgICAgIDxOYXZpZ2F0aW9uIC8+XHJcbiAgICAgIDxtYWluIGNsYXNzTmFtZT1cImZsZXgtMSBvdmVyZmxvdy15LWF1dG8gcC00IHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMFwiPlxyXG4gICAgICAgIHtjaGlsZHJlbn1cclxuICAgICAgPC9tYWluPlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFByb3RlY3RlZFJvdXRlO1xyXG4iXSwiZmlsZSI6IkY6L1kzUzIvSVRQTSBwcm9qZWN0L1Byb01hdGUtLVByb2plY3QtUGFydG5lci1GaW5kZXIvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvUHJvdGVjdGVkUm91dGUuanN4In0=