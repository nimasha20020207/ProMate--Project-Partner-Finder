import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Projects/YourProjects.jsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/YourProjects.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=383bea9f"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { useAuth } from "/src/context/AuthContext.jsx";
import ProjectCard from "/src/components/ProjectCard.jsx";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=383bea9f";
import "/src/pages/Projects/YourProjects.css";
const YourProjects = () => {
  _s();
  const {
    user,
    token
  } = useAuth();
  const navigate = useNavigate();
  const [projects, setProjects] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const fetchProjects = async () => {
    try {
      setIsLoading(true);
      const res = await fetch("http://localhost:3000/api/posts");
      if (res.ok) {
        const data = await res.json();
        const mappedData = data.map((project) => {
          const displayId = project.projectId || "P0000";
          return {
            ...project,
            displayId,
            displayTitle: `${displayId} - ${project.title}`
          };
        });
        const filteredData = mappedData.filter((project) => project.itNumber === user?.studentId);
        setProjects(filteredData.reverse());
      }
    } catch (error) {
      console.error("Failed to fetch projects", error);
    } finally {
      setIsLoading(false);
    }
  };
  useEffect(() => {
    fetchProjects();
  }, []);
  const handleDelete = async (id) => {
    if (!window.confirm("Delete this project forever?"))
      return;
    try {
      const res = await fetch(`http://localhost:3000/api/posts/${id}`, {
        method: "DELETE",
        headers: {
          "x-auth-token": token
        }
      });
      if (res.ok) {
        setProjects((prev) => prev.filter((p) => p._id !== id));
      } else {
        alert("Failed to delete project");
      }
    } catch (err) {
      console.error(err);
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "your-projects-layout", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "your-projects-header", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "header-text", children: [
        /* @__PURE__ */ jsxDEV("h1", { children: "Your Projects" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/YourProjects.jsx",
          lineNumber: 65,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: "Manage all your posted partnership requests." }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/YourProjects.jsx",
          lineNumber: 66,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/YourProjects.jsx",
        lineNumber: 64,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { className: "create-project-btn", onClick: () => navigate("/insert-project"), children: "Create Project" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/YourProjects.jsx",
        lineNumber: 68,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/YourProjects.jsx",
      lineNumber: 63,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "projects-grid-container", children: isLoading ? /* @__PURE__ */ jsxDEV("div", { className: "loading-spinner", children: "Loading projects..." }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/YourProjects.jsx",
      lineNumber: 74,
      columnNumber: 22
    }, this) : projects.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "no-projects", children: [
      /* @__PURE__ */ jsxDEV("h3", { children: "No projects found" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/YourProjects.jsx",
        lineNumber: 75,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: "You haven't posted any partnership requests yet." }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/YourProjects.jsx",
        lineNumber: 76,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("button", { className: "create-link-btn", onClick: () => navigate("/insert-project"), children: "Create your first project →" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/YourProjects.jsx",
        lineNumber: 77,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/YourProjects.jsx",
      lineNumber: 74,
      columnNumber: 107
    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "projects-grid", children: projects.map((project) => /* @__PURE__ */ jsxDEV(ProjectCard, { project, onView: (p) => navigate("/projects/" + p._id) }, project._id, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/YourProjects.jsx",
      lineNumber: 81,
      columnNumber: 38
    }, this)) }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/YourProjects.jsx",
      lineNumber: 80,
      columnNumber: 20
    }, this) }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/YourProjects.jsx",
      lineNumber: 73,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/YourProjects.jsx",
    lineNumber: 62,
    columnNumber: 10
  }, this);
};
_s(YourProjects, "QsI9BQrUEO84sB/4FjM+NCdlFfA=", false, function() {
  return [useAuth, useNavigate];
});
_c = YourProjects;
export default YourProjects;
var _c;
$RefreshReg$(_c, "YourProjects");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/YourProjects.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0VVOzs7Ozs7Ozs7Ozs7Ozs7O0FBbEVWLE9BQU9BLFNBQVNDLFVBQVVDLGlCQUFpQjtBQUMzQyxTQUFTQyxlQUFlO0FBQ3hCLE9BQU9DLGlCQUFpQjtBQUN4QixTQUFTQyxtQkFBbUI7QUFDNUIsT0FBTztBQUVQLE1BQU1DLGVBQWVBLE1BQU07QUFBQUMsS0FBQTtBQUN6QixRQUFNO0FBQUEsSUFBRUM7QUFBQUEsSUFBTUM7QUFBQUEsRUFBTSxJQUFJTixRQUFRO0FBQ2hDLFFBQU1PLFdBQVdMLFlBQVk7QUFDN0IsUUFBTSxDQUFDTSxVQUFVQyxXQUFXLElBQUlYLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUNZLFdBQVdDLFlBQVksSUFBSWIsU0FBUyxJQUFJO0FBRS9DLFFBQU1jLGdCQUFnQixZQUFZO0FBQ2hDLFFBQUk7QUFDRkQsbUJBQWEsSUFBSTtBQUNqQixZQUFNRSxNQUFNLE1BQU1DLE1BQU0saUNBQWlDO0FBQ3pELFVBQUlELElBQUlFLElBQUk7QUFDVixjQUFNQyxPQUFPLE1BQU1ILElBQUlJLEtBQUs7QUFHNUIsY0FBTUMsYUFBYUYsS0FBS0csSUFBS0MsYUFBWTtBQUN2QyxnQkFBTUMsWUFBWUQsUUFBUUUsYUFBYTtBQUN2QyxpQkFBTztBQUFBLFlBQ0wsR0FBR0Y7QUFBQUEsWUFDSEM7QUFBQUEsWUFDQUUsY0FBYyxHQUFHRixTQUFTLE1BQU1ELFFBQVFJLEtBQUs7QUFBQSxVQUMvQztBQUFBLFFBQ0YsQ0FBQztBQUVELGNBQU1DLGVBQWVQLFdBQVdRLE9BQU9OLGFBQVdBLFFBQVFPLGFBQWF0QixNQUFNdUIsU0FBUztBQUN0Rm5CLG9CQUFZZ0IsYUFBYUksUUFBUSxDQUFDO0FBQUEsTUFDcEM7QUFBQSxJQUNGLFNBQVNDLE9BQU87QUFDZEMsY0FBUUQsTUFBTSw0QkFBNEJBLEtBQUs7QUFBQSxJQUNqRCxVQUFDO0FBQ0NuQixtQkFBYSxLQUFLO0FBQUEsSUFDcEI7QUFBQSxFQUNGO0FBRUFaLFlBQVUsTUFBTTtBQUNkYSxrQkFBYztBQUFBLEVBQ2hCLEdBQUcsRUFBRTtBQUVMLFFBQU1vQixlQUFlLE9BQU9DLE9BQU87QUFDakMsUUFBSSxDQUFDQyxPQUFPQyxRQUFRLDhCQUE4QjtBQUFHO0FBQ3JELFFBQUk7QUFDRixZQUFNdEIsTUFBTSxNQUFNQyxNQUFNLG1DQUFtQ21CLEVBQUUsSUFBSTtBQUFBLFFBQy9ERyxRQUFRO0FBQUEsUUFDUkMsU0FBUztBQUFBLFVBQ1AsZ0JBQWdCL0I7QUFBQUEsUUFDbEI7QUFBQSxNQUNGLENBQUM7QUFDRCxVQUFJTyxJQUFJRSxJQUFJO0FBQ1ZOLG9CQUFZNkIsVUFBUUEsS0FBS1osT0FBT2EsT0FBS0EsRUFBRUMsUUFBUVAsRUFBRSxDQUFDO0FBQUEsTUFDcEQsT0FBTztBQUNMUSxjQUFNLDBCQUEwQjtBQUFBLE1BQ2xDO0FBQUEsSUFDRixTQUFTQyxLQUFLO0FBQ1pYLGNBQVFELE1BQU1ZLEdBQUc7QUFBQSxJQUNuQjtBQUFBLEVBQ0Y7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLDJCQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsK0JBQUMsUUFBRyw2QkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlCO0FBQUEsUUFDakIsdUJBQUMsT0FBRSw0REFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStDO0FBQUEsV0FGakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxZQUFPLFdBQVUsc0JBQXFCLFNBQVMsTUFBTW5DLFNBQVMsaUJBQWlCLEdBQUcsOEJBQW5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVFBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ1pHLHNCQUNDLHVCQUFDLFNBQUksV0FBVSxtQkFBa0IsbUNBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBb0QsSUFDbERGLFNBQVNtQyxXQUFXLElBQ3RCLHVCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsNkJBQUMsUUFBRyxpQ0FBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFCO0FBQUEsTUFDckIsdUJBQUMsT0FBRSxnRUFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1EO0FBQUEsTUFDbkQsdUJBQUMsWUFBTyxXQUFVLG1CQUFrQixTQUFTLE1BQU1wQyxTQUFTLGlCQUFpQixHQUFHLDJDQUFoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FNQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxpQkFDWkMsbUJBQVNXLElBQUlDLGFBQ1osdUJBQUMsZUFBOEIsU0FBa0IsUUFBU21CLE9BQU1oQyxTQUFTLGVBQWVnQyxFQUFFQyxHQUFHLEtBQTNFcEIsUUFBUW9CLEtBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBK0YsQ0FDaEcsS0FISDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUEsS0FoQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWtCQTtBQUFBLE9BN0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E4QkE7QUFFSjtBQUFFcEMsR0F6RklELGNBQVk7QUFBQSxVQUNRSCxTQUNQRSxXQUFXO0FBQUE7QUFBQTBDLEtBRnhCekM7QUEyRk4sZUFBZUE7QUFBYSxJQUFBeUM7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJ1c2VBdXRoIiwiUHJvamVjdENhcmQiLCJ1c2VOYXZpZ2F0ZSIsIllvdXJQcm9qZWN0cyIsIl9zIiwidXNlciIsInRva2VuIiwibmF2aWdhdGUiLCJwcm9qZWN0cyIsInNldFByb2plY3RzIiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwiZmV0Y2hQcm9qZWN0cyIsInJlcyIsImZldGNoIiwib2siLCJkYXRhIiwianNvbiIsIm1hcHBlZERhdGEiLCJtYXAiLCJwcm9qZWN0IiwiZGlzcGxheUlkIiwicHJvamVjdElkIiwiZGlzcGxheVRpdGxlIiwidGl0bGUiLCJmaWx0ZXJlZERhdGEiLCJmaWx0ZXIiLCJpdE51bWJlciIsInN0dWRlbnRJZCIsInJldmVyc2UiLCJlcnJvciIsImNvbnNvbGUiLCJoYW5kbGVEZWxldGUiLCJpZCIsIndpbmRvdyIsImNvbmZpcm0iLCJtZXRob2QiLCJoZWFkZXJzIiwicHJldiIsInAiLCJfaWQiLCJhbGVydCIsImVyciIsImxlbmd0aCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiWW91clByb2plY3RzLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4uLy4uL2NvbnRleHQvQXV0aENvbnRleHQnO1xyXG5pbXBvcnQgUHJvamVjdENhcmQgZnJvbSAnLi4vLi4vY29tcG9uZW50cy9Qcm9qZWN0Q2FyZCc7XHJcbmltcG9ydCB7IHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XHJcbmltcG9ydCAnLi9Zb3VyUHJvamVjdHMuY3NzJztcclxuXHJcbmNvbnN0IFlvdXJQcm9qZWN0cyA9ICgpID0+IHtcclxuICBjb25zdCB7IHVzZXIsIHRva2VuIH0gPSB1c2VBdXRoKCk7XHJcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xyXG4gIGNvbnN0IFtwcm9qZWN0cywgc2V0UHJvamVjdHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKTtcclxuXHJcbiAgY29uc3QgZmV0Y2hQcm9qZWN0cyA9IGFzeW5jICgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuICAgICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goJ2h0dHA6Ly9sb2NhbGhvc3Q6MzAwMC9hcGkvcG9zdHMnKTtcclxuICAgICAgaWYgKHJlcy5vaykge1xyXG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXMuanNvbigpO1xyXG5cclxuICAgICAgICAvLyBSZXRhaW4gY2hyb25vbG9naWNhbCBzb3J0aW5nIGxvZ2ljIHJlYWRpbmcgbmF0aXZlbHkgbWFwcGVkIElEcyBmcm9tIGRhdGFiYXNlXHJcbiAgICAgICAgY29uc3QgbWFwcGVkRGF0YSA9IGRhdGEubWFwKChwcm9qZWN0KSA9PiB7XHJcbiAgICAgICAgICBjb25zdCBkaXNwbGF5SWQgPSBwcm9qZWN0LnByb2plY3RJZCB8fCAnUDAwMDAnO1xyXG4gICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgLi4ucHJvamVjdCxcclxuICAgICAgICAgICAgZGlzcGxheUlkLFxyXG4gICAgICAgICAgICBkaXNwbGF5VGl0bGU6IGAke2Rpc3BsYXlJZH0gLSAke3Byb2plY3QudGl0bGV9YFxyXG4gICAgICAgICAgfTtcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgY29uc3QgZmlsdGVyZWREYXRhID0gbWFwcGVkRGF0YS5maWx0ZXIocHJvamVjdCA9PiBwcm9qZWN0Lml0TnVtYmVyID09PSB1c2VyPy5zdHVkZW50SWQpO1xyXG4gICAgICAgIHNldFByb2plY3RzKGZpbHRlcmVkRGF0YS5yZXZlcnNlKCkpOyAvLyBOZXdlc3QgZmlyc3RcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcignRmFpbGVkIHRvIGZldGNoIHByb2plY3RzJywgZXJyb3IpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgZmV0Y2hQcm9qZWN0cygpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRGVsZXRlID0gYXN5bmMgKGlkKSA9PiB7XHJcbiAgICBpZiAoIXdpbmRvdy5jb25maXJtKCdEZWxldGUgdGhpcyBwcm9qZWN0IGZvcmV2ZXI/JykpIHJldHVybjtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKGBodHRwOi8vbG9jYWxob3N0OjMwMDAvYXBpL3Bvc3RzLyR7aWR9YCwge1xyXG4gICAgICAgIG1ldGhvZDogJ0RFTEVURScsXHJcbiAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgJ3gtYXV0aC10b2tlbic6IHRva2VuXHJcbiAgICAgICAgfVxyXG4gICAgICB9KTtcclxuICAgICAgaWYgKHJlcy5vaykge1xyXG4gICAgICAgIHNldFByb2plY3RzKHByZXYgPT4gcHJldi5maWx0ZXIocCA9PiBwLl9pZCAhPT0gaWQpKTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBhbGVydCgnRmFpbGVkIHRvIGRlbGV0ZSBwcm9qZWN0Jyk7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKGVycik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwieW91ci1wcm9qZWN0cy1sYXlvdXRcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJ5b3VyLXByb2plY3RzLWhlYWRlclwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGVhZGVyLXRleHRcIj5cclxuICAgICAgICAgIDxoMT5Zb3VyIFByb2plY3RzPC9oMT5cclxuICAgICAgICAgIDxwPk1hbmFnZSBhbGwgeW91ciBwb3N0ZWQgcGFydG5lcnNoaXAgcmVxdWVzdHMuPC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiY3JlYXRlLXByb2plY3QtYnRuXCIgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoJy9pbnNlcnQtcHJvamVjdCcpfT5cclxuICAgICAgICAgIENyZWF0ZSBQcm9qZWN0XHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm9qZWN0cy1ncmlkLWNvbnRhaW5lclwiPlxyXG4gICAgICAgIHtpc0xvYWRpbmcgPyAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxvYWRpbmctc3Bpbm5lclwiPkxvYWRpbmcgcHJvamVjdHMuLi48L2Rpdj5cclxuICAgICAgICApIDogcHJvamVjdHMubGVuZ3RoID09PSAwID8gKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJuby1wcm9qZWN0c1wiPlxyXG4gICAgICAgICAgICA8aDM+Tm8gcHJvamVjdHMgZm91bmQ8L2gzPlxyXG4gICAgICAgICAgICA8cD5Zb3UgaGF2ZW4ndCBwb3N0ZWQgYW55IHBhcnRuZXJzaGlwIHJlcXVlc3RzIHlldC48L3A+XHJcbiAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiY3JlYXRlLWxpbmstYnRuXCIgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoJy9pbnNlcnQtcHJvamVjdCcpfT5cclxuICAgICAgICAgICAgICBDcmVhdGUgeW91ciBmaXJzdCBwcm9qZWN0IOKGklxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICkgOiAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByb2plY3RzLWdyaWRcIj5cclxuICAgICAgICAgICAge3Byb2plY3RzLm1hcChwcm9qZWN0ID0+IChcclxuICAgICAgICAgICAgICA8UHJvamVjdENhcmQga2V5PXtwcm9qZWN0Ll9pZH0gcHJvamVjdD17cHJvamVjdH0gb25WaWV3PXsocCkgPT4gbmF2aWdhdGUoJy9wcm9qZWN0cy8nICsgcC5faWQpfSAvPlxyXG4gICAgICAgICAgICApKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFlvdXJQcm9qZWN0cztcclxuIl0sImZpbGUiOiJGOi9ZM1MyL0lUUE0gcHJvamVjdC9Qcm9NYXRlLS1Qcm9qZWN0LVBhcnRuZXItRmluZGVyL2Zyb250ZW5kL3NyYy9wYWdlcy9Qcm9qZWN0cy9Zb3VyUHJvamVjdHMuanN4In0=