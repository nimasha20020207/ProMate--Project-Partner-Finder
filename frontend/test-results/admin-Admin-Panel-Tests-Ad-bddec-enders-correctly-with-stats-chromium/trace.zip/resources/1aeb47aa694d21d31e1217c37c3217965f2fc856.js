import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Admin/Requestmanagement.jsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Requestmanagement.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=383bea9f"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import axios from "/node_modules/.vite/deps/axios.js?v=383bea9f";
import AdminNavbar from "/src/components/AdminNavbar.jsx";
import { useAuth } from "/src/context/AuthContext.jsx";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=383bea9f";
const Requestmanagement = () => {
  _s();
  const {
    token
  } = useAuth();
  const [requests, setRequests] = useState([]);
  const navigate = useNavigate();
  const fetchRequests = () => {
    axios.get("http://localhost:3000/api/admin/requests", {
      headers: {
        "x-auth-token": token
      }
    }).then((res) => setRequests(res.data)).catch((err) => console.log(err));
  };
  useEffect(() => {
    fetchRequests();
  }, [token]);
  const updateStatus = (id, status) => {
    axios.put(`http://localhost:3000/api/admin/requests/${id}`, {
      status
    }, {
      headers: {
        "x-auth-token": token
      }
    }).then(fetchRequests).catch((err) => console.log(err));
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-screen", children: /* @__PURE__ */ jsxDEV("div", { className: "flex-1 p-6 bg-surface", children: [
    /* @__PURE__ */ jsxDEV("button", { onClick: () => navigate(`/history`), className: "bg-[#3B82F6] text-white px-4 py-2 rounded hover:bg-blue-700 transition", children: "View Suspension History" }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Requestmanagement.jsx",
      lineNumber: 42,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "p-6", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold mb-4", children: "Requests" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Requestmanagement.jsx",
        lineNumber: 44,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV("table", { className: "min-w-full bg-white", children: [
        /* @__PURE__ */ jsxDEV("thead", { children: /* @__PURE__ */ jsxDEV("tr", { className: "bg-gray-200", children: [
          /* @__PURE__ */ jsxDEV("th", { className: "p-2", children: "Student" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Requestmanagement.jsx",
            lineNumber: 48,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("th", { children: "Project" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Requestmanagement.jsx",
            lineNumber: 49,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("th", { children: "Role" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Requestmanagement.jsx",
            lineNumber: 50,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("th", { children: "Status" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Requestmanagement.jsx",
            lineNumber: 51,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("th", { children: "Actions" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Requestmanagement.jsx",
            lineNumber: 52,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Requestmanagement.jsx",
          lineNumber: 47,
          columnNumber: 11
        }, this) }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Requestmanagement.jsx",
          lineNumber: 46,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV("tbody", { children: requests.map((r) => /* @__PURE__ */ jsxDEV("tr", { className: "border-b", children: [
          /* @__PURE__ */ jsxDEV("td", { className: "p-2", children: r.studentFullName }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Requestmanagement.jsx",
            lineNumber: 57,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("td", { children: r.projectTitle }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Requestmanagement.jsx",
            lineNumber: 58,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("td", { children: r.roleRequested }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Requestmanagement.jsx",
            lineNumber: 59,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("td", { children: r.status }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Requestmanagement.jsx",
            lineNumber: 60,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("td", { className: "space-x-2", children: [
            /* @__PURE__ */ jsxDEV("button", { onClick: () => updateStatus(r._id, "Accepted"), className: "bg-green-500 text-white px-2 py-1 rounded", children: "Accept" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Requestmanagement.jsx",
              lineNumber: 62,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("button", { onClick: () => updateStatus(r._id, "Rejected"), className: "bg-red-500 text-white px-2 py-1 rounded", children: "Reject" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Requestmanagement.jsx",
              lineNumber: 65,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Requestmanagement.jsx",
            lineNumber: 61,
            columnNumber: 15
          }, this)
        ] }, r._id, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Requestmanagement.jsx",
          lineNumber: 56,
          columnNumber: 30
        }, this)) }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Requestmanagement.jsx",
          lineNumber: 55,
          columnNumber: 9
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Requestmanagement.jsx",
        lineNumber: 45,
        columnNumber: 7
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Requestmanagement.jsx",
      lineNumber: 43,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Requestmanagement.jsx",
    lineNumber: 40,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Requestmanagement.jsx",
    lineNumber: 33,
    columnNumber: 10
  }, this);
};
_s(Requestmanagement, "BSYGYTaRfmoUeClVIQPy43zX8zw=", false, function() {
  return [useAuth, useNavigate];
});
_c = Requestmanagement;
export default Requestmanagement;
var _c;
$RefreshReg$(_c, "Requestmanagement");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Requestmanagement.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUNROzs7Ozs7Ozs7Ozs7Ozs7O0FBekNSLE9BQU9BLFNBQU9DLFdBQVVDLGdCQUFlO0FBQ3ZDLE9BQU9DLFdBQVc7QUFDbEIsT0FBT0MsaUJBQWlCO0FBQ3hCLFNBQVNDLGVBQWU7QUFDeEIsU0FBUUMsbUJBQWtCO0FBRTFCLE1BQU1DLG9CQUFvQkEsTUFBTTtBQUFBQyxLQUFBO0FBQzlCLFFBQU07QUFBQSxJQUFFQztBQUFBQSxFQUFNLElBQUlKLFFBQVE7QUFDMUIsUUFBTSxDQUFDSyxVQUFVQyxXQUFXLElBQUlULFNBQVMsRUFBRTtBQUMzQyxRQUFNVSxXQUFXTixZQUFZO0FBRTdCLFFBQU1PLGdCQUFnQkEsTUFBTTtBQUMxQlYsVUFBTVcsSUFBSSw0Q0FBNEM7QUFBQSxNQUNwREMsU0FBUztBQUFBLFFBQUUsZ0JBQWdCTjtBQUFBQSxNQUFNO0FBQUEsSUFDbkMsQ0FBQyxFQUNFTyxLQUFLQyxTQUFPTixZQUFZTSxJQUFJQyxJQUFJLENBQUMsRUFDakNDLE1BQU1DLFNBQU9DLFFBQVFDLElBQUlGLEdBQUcsQ0FBQztBQUFBLEVBQ2xDO0FBRUFuQixZQUFVLE1BQU07QUFDZFksa0JBQWM7QUFBQSxFQUNoQixHQUFHLENBQUNKLEtBQUssQ0FBQztBQUVWLFFBQU1jLGVBQWVBLENBQUNDLElBQUlDLFdBQVc7QUFDbkN0QixVQUFNdUIsSUFBSSw0Q0FBNENGLEVBQUUsSUFBSTtBQUFBLE1BQUVDO0FBQUFBLElBQU8sR0FBRztBQUFBLE1BQ3RFVixTQUFTO0FBQUEsUUFBRSxnQkFBZ0JOO0FBQUFBLE1BQU07QUFBQSxJQUNuQyxDQUFDLEVBQ0VPLEtBQUtILGFBQWEsRUFDbEJNLE1BQU1DLFNBQU9DLFFBQVFDLElBQUlGLEdBQUcsQ0FBQztBQUFBLEVBQ2xDO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUscUJBT2IsaUNBQUMsU0FBSSxXQUFVLHlCQUViO0FBQUEsMkJBQUMsWUFBTyxTQUFTLE1BQUtSLFNBQVMsVUFBVSxHQUN2QyxXQUFVLDBFQUNULHVDQUZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFMEI7QUFBQSxJQUN0Qix1QkFBQyxTQUFJLFdBQVUsT0FDckI7QUFBQSw2QkFBQyxRQUFHLFdBQVUsMkJBQTBCLHdCQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdEO0FBQUEsTUFDaEQsdUJBQUMsV0FBTSxXQUFVLHVCQUNmO0FBQUEsK0JBQUMsV0FDQyxpQ0FBQyxRQUFHLFdBQVUsZUFDWjtBQUFBLGlDQUFDLFFBQUcsV0FBVSxPQUFNLHVCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyQjtBQUFBLFVBQzNCLHVCQUFDLFFBQUcsdUJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBVztBQUFBLFVBQ1gsdUJBQUMsUUFBRyxvQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFRO0FBQUEsVUFDUix1QkFBQyxRQUFHLHNCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQVU7QUFBQSxVQUNWLHVCQUFDLFFBQUcsdUJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBVztBQUFBLGFBTGI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1BLEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsUUFDQSx1QkFBQyxXQUNFRixtQkFBU2lCLElBQUlDLE9BQ1osdUJBQUMsUUFBZSxXQUFVLFlBQ3hCO0FBQUEsaUNBQUMsUUFBRyxXQUFVLE9BQU9BLFlBQUVDLG1CQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1QztBQUFBLFVBQ3ZDLHVCQUFDLFFBQUlELFlBQUVFLGdCQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9CO0FBQUEsVUFDcEIsdUJBQUMsUUFBSUYsWUFBRUcsaUJBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUI7QUFBQSxVQUNyQix1QkFBQyxRQUFJSCxZQUFFSCxVQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWM7QUFBQSxVQUNkLHVCQUFDLFFBQUcsV0FBVSxhQUNaO0FBQUEsbUNBQUMsWUFDQyxTQUFTLE1BQU1GLGFBQWFLLEVBQUVJLEtBQUssVUFBVSxHQUM3QyxXQUFVLDZDQUNYLHNCQUhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxZQUNBLHVCQUFDLFlBQ0MsU0FBUyxNQUFNVCxhQUFhSyxFQUFFSSxLQUFLLFVBQVUsR0FDN0MsV0FBVSwyQ0FDWCxzQkFIRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsZUFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWFBO0FBQUEsYUFsQk9KLEVBQUVJLEtBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW1CQSxDQUNELEtBdEJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF1QkE7QUFBQSxXQWpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBa0NBO0FBQUEsU0FwQ007QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXFDUjtBQUFBLE9BMUNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EyQ0EsS0FsREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW1EQTtBQUVKO0FBQUN4QixHQS9FS0QsbUJBQWlCO0FBQUEsVUFDSEYsU0FFREMsV0FBVztBQUFBO0FBQUEyQixLQUh4QjFCO0FBaUZOLGVBQWVBO0FBQWlCLElBQUEwQjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsImF4aW9zIiwiQWRtaW5OYXZiYXIiLCJ1c2VBdXRoIiwidXNlTmF2aWdhdGUiLCJSZXF1ZXN0bWFuYWdlbWVudCIsIl9zIiwidG9rZW4iLCJyZXF1ZXN0cyIsInNldFJlcXVlc3RzIiwibmF2aWdhdGUiLCJmZXRjaFJlcXVlc3RzIiwiZ2V0IiwiaGVhZGVycyIsInRoZW4iLCJyZXMiLCJkYXRhIiwiY2F0Y2giLCJlcnIiLCJjb25zb2xlIiwibG9nIiwidXBkYXRlU3RhdHVzIiwiaWQiLCJzdGF0dXMiLCJwdXQiLCJtYXAiLCJyIiwic3R1ZGVudEZ1bGxOYW1lIiwicHJvamVjdFRpdGxlIiwicm9sZVJlcXVlc3RlZCIsIl9pZCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUmVxdWVzdG1hbmFnZW1lbnQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCx7dXNlRWZmZWN0LHVzZVN0YXRlfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCBheGlvcyBmcm9tIFwiYXhpb3NcIjtcclxuaW1wb3J0IEFkbWluTmF2YmFyIGZyb20gJy4uLy4uL2NvbXBvbmVudHMvQWRtaW5OYXZiYXInO1xyXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSBcIi4uLy4uL2NvbnRleHQvQXV0aENvbnRleHRcIjtcclxuaW1wb3J0IHt1c2VOYXZpZ2F0ZX0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcclxuXHJcbmNvbnN0IFJlcXVlc3RtYW5hZ2VtZW50ID0gKCkgPT4ge1xyXG4gIGNvbnN0IHsgdG9rZW4gfSA9IHVzZUF1dGgoKTtcclxuICBjb25zdCBbcmVxdWVzdHMsIHNldFJlcXVlc3RzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XHJcblxyXG4gIGNvbnN0IGZldGNoUmVxdWVzdHMgPSAoKSA9PiB7XHJcbiAgICBheGlvcy5nZXQoXCJodHRwOi8vbG9jYWxob3N0OjMwMDAvYXBpL2FkbWluL3JlcXVlc3RzXCIsIHtcclxuICAgICAgaGVhZGVyczogeyBcIngtYXV0aC10b2tlblwiOiB0b2tlbiB9LFxyXG4gICAgfSlcclxuICAgICAgLnRoZW4ocmVzID0+IHNldFJlcXVlc3RzKHJlcy5kYXRhKSlcclxuICAgICAgLmNhdGNoKGVyciA9PiBjb25zb2xlLmxvZyhlcnIpKTtcclxuICB9O1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgZmV0Y2hSZXF1ZXN0cygpO1xyXG4gIH0sIFt0b2tlbl0pO1xyXG5cclxuICBjb25zdCB1cGRhdGVTdGF0dXMgPSAoaWQsIHN0YXR1cykgPT4ge1xyXG4gICAgYXhpb3MucHV0KGBodHRwOi8vbG9jYWxob3N0OjMwMDAvYXBpL2FkbWluL3JlcXVlc3RzLyR7aWR9YCwgeyBzdGF0dXMgfSwge1xyXG4gICAgICBoZWFkZXJzOiB7IFwieC1hdXRoLXRva2VuXCI6IHRva2VuIH0sXHJcbiAgICB9KVxyXG4gICAgICAudGhlbihmZXRjaFJlcXVlc3RzKVxyXG4gICAgICAuY2F0Y2goZXJyID0+IGNvbnNvbGUubG9nKGVycikpO1xyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbWluLWgtc2NyZWVuXCI+XHJcbiAgICAgIHsvKiBTaWRlYmFyXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy02NCBiZy1ncmF5LTgwMCB0ZXh0LXdoaXRlXCI+XHJcbiAgICAgICAgPEFkbWluTmF2YmFyIC8+XHJcbiAgICAgIDwvZGl2PiAqL31cclxuXHJcbiAgICAgIHsvKiBNYWluIGNvbnRlbnQgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIHAtNiBiZy1zdXJmYWNlXCI+XHJcblxyXG4gICAgICAgIDxidXR0b24gb25DbGljaz17KCk9PiBuYXZpZ2F0ZShgL2hpc3RvcnlgKX1cclxuICAgICAgICAgIGNsYXNzTmFtZT1cImJnLVsjM0I4MkY2XSB0ZXh0LXdoaXRlIHB4LTQgcHktMiByb3VuZGVkIGhvdmVyOmJnLWJsdWUtNzAwIHRyYW5zaXRpb25cIlxyXG4gICAgICAgICAgPlZpZXcgU3VzcGVuc2lvbiBIaXN0b3J5PC9idXR0b24+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02XCI+XHJcbiAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgbWItNFwiPlJlcXVlc3RzPC9oMT5cclxuICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cIm1pbi13LWZ1bGwgYmctd2hpdGVcIj5cclxuICAgICAgICA8dGhlYWQ+XHJcbiAgICAgICAgICA8dHIgY2xhc3NOYW1lPVwiYmctZ3JheS0yMDBcIj5cclxuICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMlwiPlN0dWRlbnQ8L3RoPlxyXG4gICAgICAgICAgICA8dGg+UHJvamVjdDwvdGg+XHJcbiAgICAgICAgICAgIDx0aD5Sb2xlPC90aD5cclxuICAgICAgICAgICAgPHRoPlN0YXR1czwvdGg+XHJcbiAgICAgICAgICAgIDx0aD5BY3Rpb25zPC90aD5cclxuICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgPC90aGVhZD5cclxuICAgICAgICA8dGJvZHk+XHJcbiAgICAgICAgICB7cmVxdWVzdHMubWFwKHIgPT4gKFxyXG4gICAgICAgICAgICA8dHIga2V5PXtyLl9pZH0gY2xhc3NOYW1lPVwiYm9yZGVyLWJcIj5cclxuICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0yXCI+e3Iuc3R1ZGVudEZ1bGxOYW1lfTwvdGQ+XHJcbiAgICAgICAgICAgICAgPHRkPntyLnByb2plY3RUaXRsZX08L3RkPlxyXG4gICAgICAgICAgICAgIDx0ZD57ci5yb2xlUmVxdWVzdGVkfTwvdGQ+XHJcbiAgICAgICAgICAgICAgPHRkPntyLnN0YXR1c308L3RkPlxyXG4gICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJzcGFjZS14LTJcIj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdXBkYXRlU3RhdHVzKHIuX2lkLCBcIkFjY2VwdGVkXCIpfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmVlbi01MDAgdGV4dC13aGl0ZSBweC0yIHB5LTEgcm91bmRlZFwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIEFjY2VwdFxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHVwZGF0ZVN0YXR1cyhyLl9pZCwgXCJSZWplY3RlZFwiKX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctcmVkLTUwMCB0ZXh0LXdoaXRlIHB4LTIgcHktMSByb3VuZGVkXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgUmVqZWN0XHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgKSl9XHJcbiAgICAgICAgPC90Ym9keT5cclxuICAgICAgPC90YWJsZT5cclxuICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgUmVxdWVzdG1hbmFnZW1lbnQiXSwiZmlsZSI6IkY6L1kzUzIvSVRQTSBwcm9qZWN0L1Byb01hdGUtLVByb2plY3QtUGFydG5lci1GaW5kZXIvZnJvbnRlbmQvc3JjL3BhZ2VzL0FkbWluL1JlcXVlc3RtYW5hZ2VtZW50LmpzeCJ9