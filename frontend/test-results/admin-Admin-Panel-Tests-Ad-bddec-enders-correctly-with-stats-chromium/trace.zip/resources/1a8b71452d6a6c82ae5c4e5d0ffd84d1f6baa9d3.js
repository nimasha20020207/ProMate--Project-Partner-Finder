import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Projects/AllProjects.jsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/AllProjects.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=383bea9f"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { useAuth } from "/src/context/AuthContext.jsx";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=383bea9f";
import "/src/pages/Projects/AllProjects.css";
const AllProjects = () => {
  _s();
  const {
    user
  } = useAuth();
  const navigate = useNavigate();
  const [projects, setProjects] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const fetchProjects = async () => {
    try {
      setIsLoading(true);
      const res = await fetch("http://localhost:3000/api/posts");
      if (res.ok) {
        const data = await res.json();
        const mappedData = data.map((project) => {
          const displayId = project.projectId || "P0000";
          return {
            ...project,
            displayId,
            displayTitle: `${displayId} - ${project.title}`
          };
        });
        const today = /* @__PURE__ */ new Date();
        today.setHours(0, 0, 0, 0);
        const filteredData = mappedData.filter((project) => {
          if (project.itNumber === user?.studentId)
            return false;
          if (project.dueDate) {
            const dDate = new Date(project.dueDate);
            dDate.setHours(0, 0, 0, 0);
            if (dDate < today)
              return false;
          }
          return true;
        });
        setProjects(filteredData.reverse());
      }
    } catch (error) {
      console.error("Failed to fetch projects", error);
    } finally {
      setIsLoading(false);
    }
  };
  useEffect(() => {
    fetchProjects();
  }, []);
  const filteredProjects = projects.filter((project) => {
    if (!searchQuery)
      return true;
    const lowerQuery = searchQuery.toLowerCase();
    if (project.displayTitle?.toLowerCase().includes(lowerQuery) || project.title?.toLowerCase().includes(lowerQuery))
      return true;
    if (project.specialization?.toLowerCase().includes(lowerQuery))
      return true;
    if (project.domain?.some((d) => d.toLowerCase().includes(lowerQuery)))
      return true;
    let hasSkill = false;
    if (project.essentialSkills) {
      Object.values(project.essentialSkills).forEach((skills) => {
        if (skills?.some((s) => s.toLowerCase().includes(lowerQuery))) {
          hasSkill = true;
        }
      });
    }
    return hasSkill;
  });
  return /* @__PURE__ */ jsxDEV("div", { className: "all-projects-container", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "all-projects-header", children: [
      /* @__PURE__ */ jsxDEV("h1", { children: "All Projects" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/AllProjects.jsx",
        lineNumber: 81,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: "Discover partnership opportunities from other students." }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/AllProjects.jsx",
        lineNumber: 82,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "all-search-wrapper", children: [
        /* @__PURE__ */ jsxDEV("svg", { className: "all-search-icon", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/AllProjects.jsx",
          lineNumber: 86,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/AllProjects.jsx",
          lineNumber: 85,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("input", { type: "text", className: "all-search-input", placeholder: "Search by title, domain, or specific skills...", value: searchQuery, onChange: (e) => setSearchQuery(e.target.value) }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/AllProjects.jsx",
          lineNumber: 88,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/AllProjects.jsx",
        lineNumber: 84,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/AllProjects.jsx",
      lineNumber: 80,
      columnNumber: 7
    }, this),
    isLoading ? /* @__PURE__ */ jsxDEV("div", { className: "all-loading", children: "Loading projects..." }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/AllProjects.jsx",
      lineNumber: 92,
      columnNumber: 20
    }, this) : filteredProjects.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "all-empty", children: [
      /* @__PURE__ */ jsxDEV("h3", { children: "No projects found" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/AllProjects.jsx",
        lineNumber: 93,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: "Try adjusting your search terms" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/AllProjects.jsx",
        lineNumber: 94,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/AllProjects.jsx",
      lineNumber: 92,
      columnNumber: 109
    }, this) : (
      // Project card in grid layout in all-projects page 
      /* @__PURE__ */ jsxDEV("div", { className: "all-projects-grid", children: filteredProjects.map((project, i) => /* @__PURE__ */ jsxDEV("div", { className: "all-card", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "all-card-title", children: project.displayTitle }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/AllProjects.jsx",
          lineNumber: 99,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "all-academic-info", style: {
          marginBottom: "16px"
        }, children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("span", { children: "Owner:" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/AllProjects.jsx",
              lineNumber: 104,
              columnNumber: 22
            }, this),
            " ",
            project.itNumber || "Unknown"
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/AllProjects.jsx",
            lineNumber: 104,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("span", { children: "Need More:" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/AllProjects.jsx",
              lineNumber: 105,
              columnNumber: 22
            }, this),
            " ",
            project.teamSize || "N/A"
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/AllProjects.jsx",
            lineNumber: 105,
            columnNumber: 17
          }, this),
          project.dueDate && /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("span", { children: "Due Date:" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/AllProjects.jsx",
              lineNumber: 106,
              columnNumber: 42
            }, this),
            " ",
            new Date(project.dueDate).toLocaleDateString("en-GB")
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/AllProjects.jsx",
            lineNumber: 106,
            columnNumber: 37
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/AllProjects.jsx",
          lineNumber: 101,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "all-section", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "all-section-title", children: "Essential Skills:" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/AllProjects.jsx",
            lineNumber: 110,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "all-skills-container", children: project.essentialSkills && Object.entries(project.essentialSkills).map(([key, skills], idx) => (skills || []).map((skill, sidx) => /* @__PURE__ */ jsxDEV("span", { className: "all-skill-pill", children: skill }, `${idx}-${sidx}`, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/AllProjects.jsx",
            lineNumber: 112,
            columnNumber: 151
          }, this))) }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/AllProjects.jsx",
            lineNumber: 111,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/AllProjects.jsx",
          lineNumber: 109,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "all-academic-info", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("span", { children: "Specialization:" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/AllProjects.jsx",
              lineNumber: 119,
              columnNumber: 22
            }, this),
            " ",
            project.specialization || "Any"
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/AllProjects.jsx",
            lineNumber: 119,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("span", { children: "Year:" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/AllProjects.jsx",
              lineNumber: 120,
              columnNumber: 22
            }, this),
            " ",
            project.year || "-"
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/AllProjects.jsx",
            lineNumber: 120,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("span", { children: "Semester:" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/AllProjects.jsx",
              lineNumber: 121,
              columnNumber: 22
            }, this),
            " ",
            project.semester || "-"
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/AllProjects.jsx",
            lineNumber: 121,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/AllProjects.jsx",
          lineNumber: 118,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "all-section", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "all-section-title", children: "Domain:" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/AllProjects.jsx",
            lineNumber: 125,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "all-domain-container", children: (project.domain || []).map((d, idx) => /* @__PURE__ */ jsxDEV("span", { className: "all-domain-pill", children: d }, idx, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/AllProjects.jsx",
            lineNumber: 127,
            columnNumber: 59
          }, this)) }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/AllProjects.jsx",
            lineNumber: 126,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/AllProjects.jsx",
          lineNumber: 124,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "all-card-actions", children: /* @__PURE__ */ jsxDEV("button", { className: "all-btn-view", onClick: () => navigate("/projects/" + project._id), children: "View Project" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/AllProjects.jsx",
          lineNumber: 134,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/AllProjects.jsx",
          lineNumber: 133,
          columnNumber: 15
        }, this)
      ] }, i, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/AllProjects.jsx",
        lineNumber: 98,
        columnNumber: 49
      }, this)) }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/AllProjects.jsx",
        lineNumber: 97,
        columnNumber: 5
      }, this)
    )
  ] }, void 0, true, {
    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/AllProjects.jsx",
    lineNumber: 79,
    columnNumber: 10
  }, this);
};
_s(AllProjects, "1ADyb102PDHkJcosomonh9GmD+4=", false, function() {
  return [useAuth, useNavigate];
});
_c = AllProjects;
export default AllProjects;
var _c;
$RefreshReg$(_c, "AllProjects");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Projects/AllProjects.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUZROzs7Ozs7Ozs7Ozs7Ozs7O0FBckZSLE9BQU9BLFNBQVNDLFVBQVVDLGlCQUFpQjtBQUMzQyxTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLG1CQUFtQjtBQUM1QixPQUFPO0FBRVAsTUFBTUMsY0FBY0EsTUFBTTtBQUFBQyxLQUFBO0FBQ3hCLFFBQU07QUFBQSxJQUFFQztBQUFBQSxFQUFLLElBQUlKLFFBQVE7QUFDekIsUUFBTUssV0FBV0osWUFBWTtBQUM3QixRQUFNLENBQUNLLFVBQVVDLFdBQVcsSUFBSVQsU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQ1UsV0FBV0MsWUFBWSxJQUFJWCxTQUFTLElBQUk7QUFDL0MsUUFBTSxDQUFDWSxhQUFhQyxjQUFjLElBQUliLFNBQVMsRUFBRTtBQUlqRCxRQUFNYyxnQkFBZ0IsWUFBWTtBQUNoQyxRQUFJO0FBQ0ZILG1CQUFhLElBQUk7QUFDakIsWUFBTUksTUFBTSxNQUFNQyxNQUFNLGlDQUFpQztBQUN6RCxVQUFJRCxJQUFJRSxJQUFJO0FBQ1YsY0FBTUMsT0FBTyxNQUFNSCxJQUFJSSxLQUFLO0FBRzVCLGNBQU1DLGFBQWFGLEtBQUtHLElBQUtDLGFBQVk7QUFDdkMsZ0JBQU1DLFlBQVlELFFBQVFFLGFBQWE7QUFDdkMsaUJBQU87QUFBQSxZQUNMLEdBQUdGO0FBQUFBLFlBQ0hDO0FBQUFBLFlBQ0FFLGNBQWMsR0FBR0YsU0FBUyxNQUFNRCxRQUFRSSxLQUFLO0FBQUEsVUFDL0M7QUFBQSxRQUNGLENBQUM7QUFFRCxjQUFNQyxRQUFRLG9CQUFJQyxLQUFLO0FBQ3ZCRCxjQUFNRSxTQUFTLEdBQUcsR0FBRyxHQUFHLENBQUM7QUFHekIsY0FBTUMsZUFBZVYsV0FBV1csT0FBT1QsYUFBVztBQUNoRCxjQUFJQSxRQUFRVSxhQUFhMUIsTUFBTTJCO0FBQVcsbUJBQU87QUFDakQsY0FBSVgsUUFBUVksU0FBUztBQUNuQixrQkFBTUMsUUFBUSxJQUFJUCxLQUFLTixRQUFRWSxPQUFPO0FBQ3RDQyxrQkFBTU4sU0FBUyxHQUFHLEdBQUcsR0FBRyxDQUFDO0FBQ3pCLGdCQUFJTSxRQUFRUjtBQUFPLHFCQUFPO0FBQUEsVUFDNUI7QUFDQSxpQkFBTztBQUFBLFFBQ1QsQ0FBQztBQUNEbEIsb0JBQVlxQixhQUFhTSxRQUFRLENBQUM7QUFBQSxNQUNwQztBQUFBLElBQ0YsU0FBU0MsT0FBTztBQUNkQyxjQUFRRCxNQUFNLDRCQUE0QkEsS0FBSztBQUFBLElBQ2pELFVBQUM7QUFDQzFCLG1CQUFhLEtBQUs7QUFBQSxJQUNwQjtBQUFBLEVBQ0Y7QUFFQVYsWUFBVSxNQUFNO0FBQ2RhLGtCQUFjO0FBQUEsRUFDaEIsR0FBRyxFQUFFO0FBRUwsUUFBTXlCLG1CQUFtQi9CLFNBQVN1QixPQUFPVCxhQUFXO0FBQ2xELFFBQUksQ0FBQ1Y7QUFBYSxhQUFPO0FBQ3pCLFVBQU00QixhQUFhNUIsWUFBWTZCLFlBQVk7QUFHM0MsUUFBSW5CLFFBQVFHLGNBQWNnQixZQUFZLEVBQUVDLFNBQVNGLFVBQVUsS0FBS2xCLFFBQVFJLE9BQU9lLFlBQVksRUFBRUMsU0FBU0YsVUFBVTtBQUFHLGFBQU87QUFHMUgsUUFBSWxCLFFBQVFxQixnQkFBZ0JGLFlBQVksRUFBRUMsU0FBU0YsVUFBVTtBQUFHLGFBQU87QUFHdkUsUUFBSWxCLFFBQVFzQixRQUFRQyxLQUFLQyxPQUFLQSxFQUFFTCxZQUFZLEVBQUVDLFNBQVNGLFVBQVUsQ0FBQztBQUFHLGFBQU87QUFHNUUsUUFBSU8sV0FBVztBQUNmLFFBQUl6QixRQUFRMEIsaUJBQWlCO0FBQzNCQyxhQUFPQyxPQUFPNUIsUUFBUTBCLGVBQWUsRUFBRUcsUUFBUUMsWUFBVTtBQUN2RCxZQUFJQSxRQUFRUCxLQUFLUSxPQUFLQSxFQUFFWixZQUFZLEVBQUVDLFNBQVNGLFVBQVUsQ0FBQyxHQUFHO0FBQzNETyxxQkFBVztBQUFBLFFBQ2I7QUFBQSxNQUNGLENBQUM7QUFBQSxJQUNIO0FBQ0EsV0FBT0E7QUFBQUEsRUFDVCxDQUFDO0FBRUQsU0FDRSx1QkFBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQSwyQkFBQyxTQUFJLFdBQVUsdUJBQ2I7QUFBQSw2QkFBQyxRQUFHLDRCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0I7QUFBQSxNQUNoQix1QkFBQyxPQUFFLHVFQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMEQ7QUFBQSxNQUUxRCx1QkFBQyxTQUFJLFdBQVUsc0JBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsbUJBQWtCLE1BQUssUUFBTyxRQUFPLGdCQUFlLFNBQVEsYUFDekUsaUNBQUMsVUFBSyxlQUFjLFNBQVEsZ0JBQWUsU0FBUSxhQUFZLEtBQUksR0FBRSxpREFBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtSCxLQURySDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFdBQ0MsTUFBSyxRQUNMLFdBQVUsb0JBQ1YsYUFBWSxrREFDWixPQUFPbkMsYUFDUCxVQUFXMEMsT0FBTXpDLGVBQWV5QyxFQUFFQyxPQUFPQyxLQUFLLEtBTGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLa0Q7QUFBQSxXQVRwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBV0E7QUFBQSxTQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnQkE7QUFBQSxJQUVDOUMsWUFDQyx1QkFBQyxTQUFJLFdBQVUsZUFBYyxtQ0FBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnRCxJQUM5QzZCLGlCQUFpQmtCLFdBQVcsSUFDOUIsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSw2QkFBQyxRQUFHLGlDQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUI7QUFBQSxNQUNyQix1QkFBQyxPQUFFLCtDQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0M7QUFBQSxTQUZwQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQTtBQUFBLE1BSUEsdUJBQUMsU0FBSSxXQUFVLHFCQUNabEIsMkJBQWlCbEIsSUFBSSxDQUFDQyxTQUFTb0MsTUFDOUIsdUJBQUMsU0FBWSxXQUFVLFlBQ3JCO0FBQUEsK0JBQUMsUUFBRyxXQUFVLGtCQUFrQnBDLGtCQUFRRyxnQkFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxRDtBQUFBLFFBRXJELHVCQUFDLFNBQUksV0FBVSxxQkFBb0IsT0FBTztBQUFBLFVBQUVrQyxjQUFjO0FBQUEsUUFBTyxHQUMvRDtBQUFBLGlDQUFDLFNBQUk7QUFBQSxtQ0FBQyxVQUFLLHNCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQVk7QUFBQSxZQUFPO0FBQUEsWUFBRXJDLFFBQVFVLFlBQVk7QUFBQSxlQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3RDtBQUFBLFVBQ3hELHVCQUFDLFNBQUk7QUFBQSxtQ0FBQyxVQUFLLDBCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdCO0FBQUEsWUFBTztBQUFBLFlBQUVWLFFBQVFzQyxZQUFZO0FBQUEsZUFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0Q7QUFBQSxVQUN2RHRDLFFBQVFZLFdBQVksdUJBQUMsU0FBSTtBQUFBLG1DQUFDLFVBQUsseUJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZTtBQUFBLFlBQU87QUFBQSxZQUFFLElBQUlOLEtBQUtOLFFBQVFZLE9BQU8sRUFBRTJCLG1CQUFtQixPQUFPO0FBQUEsZUFBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUY7QUFBQSxhQUgxRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSUE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsaUNBQUMsT0FBRSxXQUFVLHFCQUFvQixpQ0FBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0Q7QUFBQSxVQUNsRCx1QkFBQyxTQUFJLFdBQVUsd0JBQ1p2QyxrQkFBUTBCLG1CQUFtQkMsT0FBT2EsUUFBUXhDLFFBQVEwQixlQUFlLEVBQUUzQixJQUNsRSxDQUFDLENBQUMwQyxLQUFLWCxNQUFNLEdBQUdZLFNBQ2JaLFVBQVUsSUFBSS9CLElBQUksQ0FBQzRDLE9BQU9DLFNBQ3pCLHVCQUFDLFVBQTRCLFdBQVUsa0JBQ3BDRCxtQkFEUSxHQUFHRCxHQUFHLElBQUlFLElBQUksSUFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQSxDQUNELENBQ0wsS0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVNBO0FBQUEsYUFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBWUE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLGlDQUFDLFNBQUk7QUFBQSxtQ0FBQyxVQUFLLCtCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFCO0FBQUEsWUFBTztBQUFBLFlBQUU1QyxRQUFRcUIsa0JBQWtCO0FBQUEsZUFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUU7QUFBQSxVQUNuRSx1QkFBQyxTQUFJO0FBQUEsbUNBQUMsVUFBSyxxQkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFXO0FBQUEsWUFBTztBQUFBLFlBQUVyQixRQUFRNkMsUUFBUTtBQUFBLGVBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZDO0FBQUEsVUFDN0MsdUJBQUMsU0FBSTtBQUFBLG1DQUFDLFVBQUsseUJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZTtBQUFBLFlBQU87QUFBQSxZQUFFN0MsUUFBUThDLFlBQVk7QUFBQSxlQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFxRDtBQUFBLGFBSHZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSxpQ0FBQyxPQUFFLFdBQVUscUJBQW9CLHVCQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3QztBQUFBLFVBQ3hDLHVCQUFDLFNBQUksV0FBVSx3QkFDWDlDLG1CQUFRc0IsVUFBVSxJQUFJdkIsSUFBSSxDQUFDeUIsR0FBR2tCLFFBQzlCLHVCQUFDLFVBQWUsV0FBVSxtQkFDdkJsQixlQURRa0IsS0FBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBLENBQ0QsS0FMSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU1BO0FBQUEsYUFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0E7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSxvQkFDYixpQ0FBQyxZQUFPLFdBQVUsZ0JBQWUsU0FBUyxNQUFNekQsU0FBUyxlQUFlZSxRQUFRK0MsR0FBRyxHQUFHLDRCQUF0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtHLEtBRHBHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBMUNRWCxHQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEyQ0EsQ0FDRCxLQTlDSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZ0RBO0FBQUE7QUFBQSxPQTdFSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBa0ZBO0FBRUo7QUFBRXJELEdBbEtJRCxhQUFXO0FBQUEsVUFDRUYsU0FDQUMsV0FBVztBQUFBO0FBQUFtRSxLQUZ4QmxFO0FBb0tOLGVBQWVBO0FBQVksSUFBQWtFO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsInVzZVN0YXRlIiwidXNlRWZmZWN0IiwidXNlQXV0aCIsInVzZU5hdmlnYXRlIiwiQWxsUHJvamVjdHMiLCJfcyIsInVzZXIiLCJuYXZpZ2F0ZSIsInByb2plY3RzIiwic2V0UHJvamVjdHMiLCJpc0xvYWRpbmciLCJzZXRJc0xvYWRpbmciLCJzZWFyY2hRdWVyeSIsInNldFNlYXJjaFF1ZXJ5IiwiZmV0Y2hQcm9qZWN0cyIsInJlcyIsImZldGNoIiwib2siLCJkYXRhIiwianNvbiIsIm1hcHBlZERhdGEiLCJtYXAiLCJwcm9qZWN0IiwiZGlzcGxheUlkIiwicHJvamVjdElkIiwiZGlzcGxheVRpdGxlIiwidGl0bGUiLCJ0b2RheSIsIkRhdGUiLCJzZXRIb3VycyIsImZpbHRlcmVkRGF0YSIsImZpbHRlciIsIml0TnVtYmVyIiwic3R1ZGVudElkIiwiZHVlRGF0ZSIsImREYXRlIiwicmV2ZXJzZSIsImVycm9yIiwiY29uc29sZSIsImZpbHRlcmVkUHJvamVjdHMiLCJsb3dlclF1ZXJ5IiwidG9Mb3dlckNhc2UiLCJpbmNsdWRlcyIsInNwZWNpYWxpemF0aW9uIiwiZG9tYWluIiwic29tZSIsImQiLCJoYXNTa2lsbCIsImVzc2VudGlhbFNraWxscyIsIk9iamVjdCIsInZhbHVlcyIsImZvckVhY2giLCJza2lsbHMiLCJzIiwiZSIsInRhcmdldCIsInZhbHVlIiwibGVuZ3RoIiwiaSIsIm1hcmdpbkJvdHRvbSIsInRlYW1TaXplIiwidG9Mb2NhbGVEYXRlU3RyaW5nIiwiZW50cmllcyIsImtleSIsImlkeCIsInNraWxsIiwic2lkeCIsInllYXIiLCJzZW1lc3RlciIsIl9pZCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQWxsUHJvamVjdHMuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSAnLi4vLi4vY29udGV4dC9BdXRoQ29udGV4dCc7XHJcbmltcG9ydCB7IHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XHJcbmltcG9ydCAnLi9BbGxQcm9qZWN0cy5jc3MnO1xyXG5cclxuY29uc3QgQWxsUHJvamVjdHMgPSAoKSA9PiB7XHJcbiAgY29uc3QgeyB1c2VyIH0gPSB1c2VBdXRoKCk7XHJcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xyXG4gIGNvbnN0IFtwcm9qZWN0cywgc2V0UHJvamVjdHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKTtcclxuICBjb25zdCBbc2VhcmNoUXVlcnksIHNldFNlYXJjaFF1ZXJ5XSA9IHVzZVN0YXRlKCcnKTtcclxuXHJcblxyXG5cclxuICBjb25zdCBmZXRjaFByb2plY3RzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0SXNMb2FkaW5nKHRydWUpO1xyXG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaCgnaHR0cDovL2xvY2FsaG9zdDozMDAwL2FwaS9wb3N0cycpO1xyXG4gICAgICBpZiAocmVzLm9rKSB7XHJcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlcy5qc29uKCk7XHJcblxyXG4gICAgICAgIC8vIFVzZSB0aGUgcGVyc2lzdGVudCBwcm9qZWN0SWQgZnJvbSB0aGUgYmFja2VuZCBcclxuICAgICAgICBjb25zdCBtYXBwZWREYXRhID0gZGF0YS5tYXAoKHByb2plY3QpID0+IHtcclxuICAgICAgICAgIGNvbnN0IGRpc3BsYXlJZCA9IHByb2plY3QucHJvamVjdElkIHx8ICdQMDAwMCc7XHJcbiAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAuLi5wcm9qZWN0LFxyXG4gICAgICAgICAgICBkaXNwbGF5SWQsXHJcbiAgICAgICAgICAgIGRpc3BsYXlUaXRsZTogYCR7ZGlzcGxheUlkfSAtICR7cHJvamVjdC50aXRsZX1gXHJcbiAgICAgICAgICB9O1xyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBjb25zdCB0b2RheSA9IG5ldyBEYXRlKCk7XHJcbiAgICAgICAgdG9kYXkuc2V0SG91cnMoMCwgMCwgMCwgMCk7XHJcblxyXG4gICAgICAgIC8vIERpc2NhcmQgdXNlciBwcm9qZWN0IGNhcmRzIGVudGlyZWx5IGZvciBcIkFsbCBQcm9qZWN0c1wiIGFuZCBkaXNjYXJkIHByb2plY3RzIHdpdGggcGFzdCBkdWUgZGF0ZXNcclxuICAgICAgICBjb25zdCBmaWx0ZXJlZERhdGEgPSBtYXBwZWREYXRhLmZpbHRlcihwcm9qZWN0ID0+IHtcclxuICAgICAgICAgIGlmIChwcm9qZWN0Lml0TnVtYmVyID09PSB1c2VyPy5zdHVkZW50SWQpIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgIGlmIChwcm9qZWN0LmR1ZURhdGUpIHtcclxuICAgICAgICAgICAgY29uc3QgZERhdGUgPSBuZXcgRGF0ZShwcm9qZWN0LmR1ZURhdGUpO1xyXG4gICAgICAgICAgICBkRGF0ZS5zZXRIb3VycygwLCAwLCAwLCAwKTtcclxuICAgICAgICAgICAgaWYgKGREYXRlIDwgdG9kYXkpIHJldHVybiBmYWxzZTtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHNldFByb2plY3RzKGZpbHRlcmVkRGF0YS5yZXZlcnNlKCkpOyAvLyBOZXdlc3QgZmlyc3RcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcignRmFpbGVkIHRvIGZldGNoIHByb2plY3RzJywgZXJyb3IpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgZmV0Y2hQcm9qZWN0cygpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgY29uc3QgZmlsdGVyZWRQcm9qZWN0cyA9IHByb2plY3RzLmZpbHRlcihwcm9qZWN0ID0+IHtcclxuICAgIGlmICghc2VhcmNoUXVlcnkpIHJldHVybiB0cnVlO1xyXG4gICAgY29uc3QgbG93ZXJRdWVyeSA9IHNlYXJjaFF1ZXJ5LnRvTG93ZXJDYXNlKCk7XHJcblxyXG4gICAgLy8gQ2hlY2sgVGl0bGVcclxuICAgIGlmIChwcm9qZWN0LmRpc3BsYXlUaXRsZT8udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhsb3dlclF1ZXJ5KSB8fCBwcm9qZWN0LnRpdGxlPy50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGxvd2VyUXVlcnkpKSByZXR1cm4gdHJ1ZTtcclxuXHJcbiAgICAvLyBDaGVjayBTcGVjaWFsaXphdGlvblxyXG4gICAgaWYgKHByb2plY3Quc3BlY2lhbGl6YXRpb24/LnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMobG93ZXJRdWVyeSkpIHJldHVybiB0cnVlO1xyXG5cclxuICAgIC8vIENoZWNrIERvbWFpbiBhcnJheXNcclxuICAgIGlmIChwcm9qZWN0LmRvbWFpbj8uc29tZShkID0+IGQudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhsb3dlclF1ZXJ5KSkpIHJldHVybiB0cnVlO1xyXG5cclxuICAgIC8vIENoZWNrIEVzc2VudGlhbCBTa2lsbHNcclxuICAgIGxldCBoYXNTa2lsbCA9IGZhbHNlO1xyXG4gICAgaWYgKHByb2plY3QuZXNzZW50aWFsU2tpbGxzKSB7XHJcbiAgICAgIE9iamVjdC52YWx1ZXMocHJvamVjdC5lc3NlbnRpYWxTa2lsbHMpLmZvckVhY2goc2tpbGxzID0+IHtcclxuICAgICAgICBpZiAoc2tpbGxzPy5zb21lKHMgPT4gcy50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGxvd2VyUXVlcnkpKSkge1xyXG4gICAgICAgICAgaGFzU2tpbGwgPSB0cnVlO1xyXG4gICAgICAgIH1cclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gaGFzU2tpbGw7XHJcbiAgfSk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImFsbC1wcm9qZWN0cy1jb250YWluZXJcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJhbGwtcHJvamVjdHMtaGVhZGVyXCI+XHJcbiAgICAgICAgPGgxPkFsbCBQcm9qZWN0czwvaDE+XHJcbiAgICAgICAgPHA+RGlzY292ZXIgcGFydG5lcnNoaXAgb3Bwb3J0dW5pdGllcyBmcm9tIG90aGVyIHN0dWRlbnRzLjwvcD5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhbGwtc2VhcmNoLXdyYXBwZXJcIj5cclxuICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwiYWxsLXNlYXJjaC1pY29uXCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XHJcbiAgICAgICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD1cIjJcIiBkPVwiTTIxIDIxbC02LTZtMi01YTcgNyAwIDExLTE0IDAgNyA3IDAgMDExNCAwelwiPjwvcGF0aD5cclxuICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWxsLXNlYXJjaC1pbnB1dFwiXHJcbiAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoIGJ5IHRpdGxlLCBkb21haW4sIG9yIHNwZWNpZmljIHNraWxscy4uLlwiXHJcbiAgICAgICAgICAgIHZhbHVlPXtzZWFyY2hRdWVyeX1cclxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWFyY2hRdWVyeShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHtpc0xvYWRpbmcgPyAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhbGwtbG9hZGluZ1wiPkxvYWRpbmcgcHJvamVjdHMuLi48L2Rpdj5cclxuICAgICAgKSA6IGZpbHRlcmVkUHJvamVjdHMubGVuZ3RoID09PSAwID8gKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWxsLWVtcHR5XCI+XHJcbiAgICAgICAgICA8aDM+Tm8gcHJvamVjdHMgZm91bmQ8L2gzPlxyXG4gICAgICAgICAgPHA+VHJ5IGFkanVzdGluZyB5b3VyIHNlYXJjaCB0ZXJtczwvcD5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKSA6IChcclxuXHJcbiAgICAgICAgLy8gUHJvamVjdCBjYXJkIGluIGdyaWQgbGF5b3V0IGluIGFsbC1wcm9qZWN0cyBwYWdlIFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWxsLXByb2plY3RzLWdyaWRcIj5cclxuICAgICAgICAgIHtmaWx0ZXJlZFByb2plY3RzLm1hcCgocHJvamVjdCwgaSkgPT4gKFxyXG4gICAgICAgICAgICA8ZGl2IGtleT17aX0gY2xhc3NOYW1lPVwiYWxsLWNhcmRcIj5cclxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiYWxsLWNhcmQtdGl0bGVcIj57cHJvamVjdC5kaXNwbGF5VGl0bGV9PC9oMz5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhbGwtYWNhZGVtaWMtaW5mb1wiIHN0eWxlPXt7IG1hcmdpbkJvdHRvbTogJzE2cHgnIH19PlxyXG4gICAgICAgICAgICAgICAgPGRpdj48c3Bhbj5Pd25lcjo8L3NwYW4+IHtwcm9qZWN0Lml0TnVtYmVyIHx8ICdVbmtub3duJ308L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXY+PHNwYW4+TmVlZCBNb3JlOjwvc3Bhbj4ge3Byb2plY3QudGVhbVNpemUgfHwgJ04vQSd9PC9kaXY+XHJcbiAgICAgICAgICAgICAgICB7cHJvamVjdC5kdWVEYXRlICYmICg8ZGl2PjxzcGFuPkR1ZSBEYXRlOjwvc3Bhbj4ge25ldyBEYXRlKHByb2plY3QuZHVlRGF0ZSkudG9Mb2NhbGVEYXRlU3RyaW5nKCdlbi1HQicpfTwvZGl2Pil9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWxsLXNlY3Rpb25cIj5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImFsbC1zZWN0aW9uLXRpdGxlXCI+RXNzZW50aWFsIFNraWxsczo8L3A+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFsbC1za2lsbHMtY29udGFpbmVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtwcm9qZWN0LmVzc2VudGlhbFNraWxscyAmJiBPYmplY3QuZW50cmllcyhwcm9qZWN0LmVzc2VudGlhbFNraWxscykubWFwKFxyXG4gICAgICAgICAgICAgICAgICAgIChba2V5LCBza2lsbHNdLCBpZHgpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAoc2tpbGxzIHx8IFtdKS5tYXAoKHNraWxsLCBzaWR4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGtleT17YCR7aWR4fS0ke3NpZHh9YH0gY2xhc3NOYW1lPVwiYWxsLXNraWxsLXBpbGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7c2tpbGx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICkpXHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhbGwtYWNhZGVtaWMtaW5mb1wiPlxyXG4gICAgICAgICAgICAgICAgPGRpdj48c3Bhbj5TcGVjaWFsaXphdGlvbjo8L3NwYW4+IHtwcm9qZWN0LnNwZWNpYWxpemF0aW9uIHx8ICdBbnknfTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdj48c3Bhbj5ZZWFyOjwvc3Bhbj4ge3Byb2plY3QueWVhciB8fCAnLSd9PC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PjxzcGFuPlNlbWVzdGVyOjwvc3Bhbj4ge3Byb2plY3Quc2VtZXN0ZXIgfHwgJy0nfTwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFsbC1zZWN0aW9uXCI+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJhbGwtc2VjdGlvbi10aXRsZVwiPkRvbWFpbjo8L3A+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFsbC1kb21haW4tY29udGFpbmVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIHsocHJvamVjdC5kb21haW4gfHwgW10pLm1hcCgoZCwgaWR4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4ga2V5PXtpZHh9IGNsYXNzTmFtZT1cImFsbC1kb21haW4tcGlsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2R9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFsbC1jYXJkLWFjdGlvbnNcIj5cclxuICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYWxsLWJ0bi12aWV3XCIgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoJy9wcm9qZWN0cy8nICsgcHJvamVjdC5faWQpfT5WaWV3IFByb2plY3Q8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApKX1cclxuICAgICAgICAgIHsvKiBlbmQgb2YgcHJvamVjdCBjYXJkIGdyaWQgbGF5b3V0ICovfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG5cclxuXHJcblxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IEFsbFByb2plY3RzO1xyXG4iXSwiZmlsZSI6IkY6L1kzUzIvSVRQTSBwcm9qZWN0L1Byb01hdGUtLVByb2plY3QtUGFydG5lci1GaW5kZXIvZnJvbnRlbmQvc3JjL3BhZ2VzL1Byb2plY3RzL0FsbFByb2plY3RzLmpzeCJ9