import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=383bea9f"; const React = __vite__cjsImport1_react.__esModule ? __vite__cjsImport1_react.default : __vite__cjsImport1_react;
const projectView = () => {
  const project = {
    id: "P3",
    title: "ITPM Project",
    essentialSkills: {
      languages: ["JavaScript"],
      frameworks: ["React"],
      libraries: [],
      databases: ["MongoDB", "MySQL"],
      tools: ["Git"]
    },
    requiredRoles: ["Frontend Developer", "Backend Developer", "Fullstack Developer"],
    availabilityRequirement: {
      weeklyHours: 15
    },
    domain: ["Web Development"],
    academicConstraints: {
      specialization: ["IT"],
      year: 3,
      semester: 1,
      minimumCGPA: 3
    }
  };
  const colors = {
    primary: "#3B82F6",
    secondary: "#F472B6",
    accent: "#FACC15",
    surface: "#F9FAFB",
    textPrimary: "#1F2937",
    textSecondary: "#6B7280"
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen p-8", style: {
    backgroundColor: colors.surface
  }, children: /* @__PURE__ */ jsxDEV("div", { className: "max-w-4xl mx-auto bg-white rounded-xl shadow-lg p-8 border-l-4", style: {
    borderColor: colors.primary
  }, children: [
    /* @__PURE__ */ jsxDEV("h1", { className: "text-3xl font-bold mb-4", style: {
      color: colors.textPrimary
    }, children: project.title }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectView.jsx",
      lineNumber: 43,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "mb-6", children: [
      /* @__PURE__ */ jsxDEV("p", { className: "font-semibold mb-2", style: {
        color: colors.textSecondary
      }, children: "🔹 Essential Skills" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectView.jsx",
        lineNumber: 51,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2", children: Object.entries(project.essentialSkills).map(([category, skills]) => skills.map((skill, idx) => /* @__PURE__ */ jsxDEV("span", { className: "px-3 py-1 rounded-full font-medium text-xs", style: {
        backgroundColor: colors.primary + "20",
        color: colors.primary
      }, children: skill }, `${category}-${idx}`, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectView.jsx",
        lineNumber: 57,
        columnNumber: 109
      }, this))) }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectView.jsx",
        lineNumber: 56,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectView.jsx",
      lineNumber: 50,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "mb-6", children: [
      /* @__PURE__ */ jsxDEV("p", { className: "font-semibold mb-2", style: {
        color: colors.textSecondary
      }, children: "🎯 Required Roles" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectView.jsx",
        lineNumber: 68,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2", children: project.requiredRoles.map((role, idx) => /* @__PURE__ */ jsxDEV("span", { className: "px-3 py-1 rounded-full font-medium text-xs", style: {
        backgroundColor: colors.secondary + "20",
        color: colors.secondary
      }, children: role }, idx, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectView.jsx",
        lineNumber: 74,
        columnNumber: 55
      }, this)) }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectView.jsx",
        lineNumber: 73,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectView.jsx",
      lineNumber: 67,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "mb-6", children: /* @__PURE__ */ jsxDEV("p", { className: "font-semibold", style: {
      color: colors.textSecondary
    }, children: [
      "⏱ Weekly Hours Required:",
      " ",
      /* @__PURE__ */ jsxDEV("span", { style: {
        color: colors.textPrimary,
        fontWeight: "500"
      }, children: [
        project.availabilityRequirement.weeklyHours,
        " hrs"
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectView.jsx",
        lineNumber: 89,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectView.jsx",
      lineNumber: 85,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectView.jsx",
      lineNumber: 84,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "mb-6", children: [
      /* @__PURE__ */ jsxDEV("p", { className: "font-semibold mb-2", style: {
        color: colors.textSecondary
      }, children: "🌐 Domain" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectView.jsx",
        lineNumber: 100,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2", children: project.domain.map((d, idx) => /* @__PURE__ */ jsxDEV("span", { className: "px-3 py-1 rounded-full font-medium text-xs", style: {
        backgroundColor: colors.accent + "20",
        color: colors.accent
      }, children: d }, idx, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectView.jsx",
        lineNumber: 106,
        columnNumber: 45
      }, this)) }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectView.jsx",
        lineNumber: 105,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectView.jsx",
      lineNumber: 99,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "mb-6", children: [
      /* @__PURE__ */ jsxDEV("p", { className: "font-semibold mb-2", style: {
        color: colors.textSecondary
      }, children: "🎓 Academic Constraints" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectView.jsx",
        lineNumber: 117,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("ul", { className: "ml-4 list-disc", style: {
        color: colors.textPrimary
      }, children: [
        /* @__PURE__ */ jsxDEV("li", { children: [
          "Specialization: ",
          project.academicConstraints.specialization.join(", ")
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectView.jsx",
          lineNumber: 125,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("li", { children: [
          "Year: ",
          project.academicConstraints.year
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectView.jsx",
          lineNumber: 126,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("li", { children: [
          "Semester: ",
          project.academicConstraints.semester
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectView.jsx",
          lineNumber: 127,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("li", { children: [
          "Minimum CGPA: ",
          project.academicConstraints.minimumCGPA
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectView.jsx",
          lineNumber: 128,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectView.jsx",
        lineNumber: 122,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectView.jsx",
      lineNumber: 116,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4 mt-6", children: [
      /* @__PURE__ */ jsxDEV("button", { className: "flex-1 py-2 rounded-lg font-medium text-white text-sm", style: {
        backgroundColor: colors.primary
      }, onClick: () => alert("Request sent! ✅"), children: "Request to Join" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectView.jsx",
        lineNumber: 134,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("button", { className: "flex-1 py-2 rounded-lg font-medium text-white text-sm", style: {
        backgroundColor: colors.secondary
      }, onClick: () => alert("Project bookmarked! ⭐"), children: "Bookmark Project" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectView.jsx",
        lineNumber: 139,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectView.jsx",
      lineNumber: 133,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectView.jsx",
    lineNumber: 39,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/RecEngine/ProjectView.jsx",
    lineNumber: 35,
    columnNumber: 10
  }, this);
};
export default projectView;

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNENRO0FBNUNSLE9BQU9BLFdBQVc7QUFFbEIsTUFBTUMsY0FBY0EsTUFBTTtBQUN4QixRQUFNQyxVQUFVO0FBQUEsSUFDZEMsSUFBSTtBQUFBLElBQ0pDLE9BQU87QUFBQSxJQUNQQyxpQkFBaUI7QUFBQSxNQUNmQyxXQUFXLENBQUMsWUFBWTtBQUFBLE1BQ3hCQyxZQUFZLENBQUMsT0FBTztBQUFBLE1BQ3BCQyxXQUFXO0FBQUEsTUFDWEMsV0FBVyxDQUFDLFdBQVcsT0FBTztBQUFBLE1BQzlCQyxPQUFPLENBQUMsS0FBSztBQUFBLElBQ2Y7QUFBQSxJQUNBQyxlQUFlLENBQUMsc0JBQXNCLHFCQUFxQixxQkFBcUI7QUFBQSxJQUNoRkMseUJBQXlCO0FBQUEsTUFDdkJDLGFBQWE7QUFBQSxJQUNmO0FBQUEsSUFDQUMsUUFBUSxDQUFDLGlCQUFpQjtBQUFBLElBQzFCQyxxQkFBcUI7QUFBQSxNQUNuQkMsZ0JBQWdCLENBQUMsSUFBSTtBQUFBLE1BQ3JCQyxNQUFNO0FBQUEsTUFDTkMsVUFBVTtBQUFBLE1BQ1ZDLGFBQWE7QUFBQSxJQUNmO0FBQUEsRUFDRjtBQUdBLFFBQU1DLFNBQVM7QUFBQSxJQUNiQyxTQUFTO0FBQUEsSUFDVEMsV0FBVztBQUFBLElBQ1hDLFFBQVE7QUFBQSxJQUNSQyxTQUFTO0FBQUEsSUFDVEMsYUFBYTtBQUFBLElBQ2JDLGVBQWU7QUFBQSxFQUNqQjtBQUVBLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLG9CQUFtQixPQUFPO0FBQUEsSUFBRUMsaUJBQWlCUCxPQUFPSTtBQUFBQSxFQUFRLEdBRXpFLGlDQUFDLFNBQ0MsV0FBVSxrRUFDVixPQUFPO0FBQUEsSUFBRUksYUFBYVIsT0FBT0M7QUFBQUEsRUFBUSxHQUdyQztBQUFBLDJCQUFDLFFBQUcsV0FBVSwyQkFBMEIsT0FBTztBQUFBLE1BQUVRLE9BQU9ULE9BQU9LO0FBQUFBLElBQVksR0FDeEV2QixrQkFBUUUsU0FEWDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsNkJBQUMsT0FBRSxXQUFVLHNCQUFxQixPQUFPO0FBQUEsUUFBRXlCLE9BQU9ULE9BQU9NO0FBQUFBLE1BQWMsR0FBRyxtQ0FBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsd0JBQ1pJLGlCQUFPQyxRQUFRN0IsUUFBUUcsZUFBZSxFQUFFMkIsSUFBSSxDQUFDLENBQUNDLFVBQVVDLE1BQU0sTUFDN0RBLE9BQU9GLElBQUksQ0FBQ0csT0FBT0MsUUFDakIsdUJBQUMsVUFFQyxXQUFVLDhDQUNWLE9BQU87QUFBQSxRQUNMVCxpQkFBaUJQLE9BQU9DLFVBQVU7QUFBQSxRQUNsQ1EsT0FBT1QsT0FBT0M7QUFBQUEsTUFDaEIsR0FFQ2MsbUJBUEksR0FBR0YsUUFBUSxJQUFJRyxHQUFHLElBRHpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQSxDQUNELENBQ0gsS0FkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZUE7QUFBQSxTQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBb0JBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLDZCQUFDLE9BQUUsV0FBVSxzQkFBcUIsT0FBTztBQUFBLFFBQUVQLE9BQU9ULE9BQU9NO0FBQUFBLE1BQWMsR0FBRyxpQ0FBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsd0JBQ1p4QixrQkFBUVMsY0FBY3FCLElBQUksQ0FBQ0ssTUFBTUQsUUFDaEMsdUJBQUMsVUFFQyxXQUFVLDhDQUNWLE9BQU87QUFBQSxRQUNMVCxpQkFBaUJQLE9BQU9FLFlBQVk7QUFBQSxRQUNwQ08sT0FBT1QsT0FBT0U7QUFBQUEsTUFDaEIsR0FFQ2Usa0JBUElELEtBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBLENBQ0QsS0FaSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBYUE7QUFBQSxTQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBa0JBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUsUUFDYixpQ0FBQyxPQUFFLFdBQVUsaUJBQWdCLE9BQU87QUFBQSxNQUFFUCxPQUFPVCxPQUFPTTtBQUFBQSxJQUFjLEdBQUc7QUFBQTtBQUFBLE1BQzFDO0FBQUEsTUFDekIsdUJBQUMsVUFBSyxPQUFPO0FBQUEsUUFBRUcsT0FBT1QsT0FBT0s7QUFBQUEsUUFBYWEsWUFBWTtBQUFBLE1BQU0sR0FDekRwQztBQUFBQSxnQkFBUVUsd0JBQXdCQztBQUFBQSxRQUFZO0FBQUEsV0FEL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0E7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsNkJBQUMsT0FBRSxXQUFVLHNCQUFxQixPQUFPO0FBQUEsUUFBRWdCLE9BQU9ULE9BQU9NO0FBQUFBLE1BQWMsR0FBRyx5QkFBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsd0JBQ1p4QixrQkFBUVksT0FBT2tCLElBQUksQ0FBQ08sR0FBR0gsUUFDdEIsdUJBQUMsVUFFQyxXQUFVLDhDQUNWLE9BQU87QUFBQSxRQUNMVCxpQkFBaUJQLE9BQU9HLFNBQVM7QUFBQSxRQUNqQ00sT0FBT1QsT0FBT0c7QUFBQUEsTUFDaEIsR0FFQ2dCLGVBUElILEtBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBLENBQ0QsS0FaSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBYUE7QUFBQSxTQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBa0JBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLDZCQUFDLE9BQUUsV0FBVSxzQkFBcUIsT0FBTztBQUFBLFFBQUVQLE9BQU9ULE9BQU9NO0FBQUFBLE1BQWMsR0FBRyx1Q0FBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxRQUFHLFdBQVUsa0JBQWlCLE9BQU87QUFBQSxRQUFFRyxPQUFPVCxPQUFPSztBQUFBQSxNQUFZLEdBQ2hFO0FBQUEsK0JBQUMsUUFBRztBQUFBO0FBQUEsVUFBaUJ2QixRQUFRYSxvQkFBb0JDLGVBQWV3QixLQUFLLElBQUk7QUFBQSxhQUF6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJFO0FBQUEsUUFDM0UsdUJBQUMsUUFBRztBQUFBO0FBQUEsVUFBT3RDLFFBQVFhLG9CQUFvQkU7QUFBQUEsYUFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0QztBQUFBLFFBQzVDLHVCQUFDLFFBQUc7QUFBQTtBQUFBLFVBQVdmLFFBQVFhLG9CQUFvQkc7QUFBQUEsYUFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvRDtBQUFBLFFBQ3BELHVCQUFDLFFBQUc7QUFBQTtBQUFBLFVBQWVoQixRQUFRYSxvQkFBb0JJO0FBQUFBLGFBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkQ7QUFBQSxXQUo3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxTQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLG1CQUNiO0FBQUEsNkJBQUMsWUFDQyxXQUFVLHlEQUNWLE9BQU87QUFBQSxRQUFFUSxpQkFBaUJQLE9BQU9DO0FBQUFBLE1BQVEsR0FDekMsU0FBUyxNQUFNb0IsTUFBTSxpQkFBaUIsR0FDdkMsK0JBSkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1BO0FBQUEsTUFDQSx1QkFBQyxZQUNDLFdBQVUseURBQ1YsT0FBTztBQUFBLFFBQUVkLGlCQUFpQlAsT0FBT0U7QUFBQUEsTUFBVSxHQUMzQyxTQUFTLE1BQU1tQixNQUFNLHVCQUF1QixHQUM3QyxnQ0FKRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTUE7QUFBQSxTQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FlQTtBQUFBLE9BakhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FrSEEsS0FwSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXFIQTtBQUVKO0FBRUEsZUFBZXhDIiwibmFtZXMiOlsiUmVhY3QiLCJwcm9qZWN0VmlldyIsInByb2plY3QiLCJpZCIsInRpdGxlIiwiZXNzZW50aWFsU2tpbGxzIiwibGFuZ3VhZ2VzIiwiZnJhbWV3b3JrcyIsImxpYnJhcmllcyIsImRhdGFiYXNlcyIsInRvb2xzIiwicmVxdWlyZWRSb2xlcyIsImF2YWlsYWJpbGl0eVJlcXVpcmVtZW50Iiwid2Vla2x5SG91cnMiLCJkb21haW4iLCJhY2FkZW1pY0NvbnN0cmFpbnRzIiwic3BlY2lhbGl6YXRpb24iLCJ5ZWFyIiwic2VtZXN0ZXIiLCJtaW5pbXVtQ0dQQSIsImNvbG9ycyIsInByaW1hcnkiLCJzZWNvbmRhcnkiLCJhY2NlbnQiLCJzdXJmYWNlIiwidGV4dFByaW1hcnkiLCJ0ZXh0U2Vjb25kYXJ5IiwiYmFja2dyb3VuZENvbG9yIiwiYm9yZGVyQ29sb3IiLCJjb2xvciIsIk9iamVjdCIsImVudHJpZXMiLCJtYXAiLCJjYXRlZ29yeSIsInNraWxscyIsInNraWxsIiwiaWR4Iiwicm9sZSIsImZvbnRXZWlnaHQiLCJkIiwiam9pbiIsImFsZXJ0Il0sInNvdXJjZXMiOlsiUHJvamVjdFZpZXcuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcclxuXHJcbmNvbnN0IHByb2plY3RWaWV3ID0gKCkgPT4ge1xyXG4gIGNvbnN0IHByb2plY3QgPSB7XHJcbiAgICBpZDogXCJQM1wiLFxyXG4gICAgdGl0bGU6IFwiSVRQTSBQcm9qZWN0XCIsXHJcbiAgICBlc3NlbnRpYWxTa2lsbHM6IHtcclxuICAgICAgbGFuZ3VhZ2VzOiBbXCJKYXZhU2NyaXB0XCJdLFxyXG4gICAgICBmcmFtZXdvcmtzOiBbXCJSZWFjdFwiXSxcclxuICAgICAgbGlicmFyaWVzOiBbXSxcclxuICAgICAgZGF0YWJhc2VzOiBbXCJNb25nb0RCXCIsIFwiTXlTUUxcIl0sXHJcbiAgICAgIHRvb2xzOiBbXCJHaXRcIl0sXHJcbiAgICB9LFxyXG4gICAgcmVxdWlyZWRSb2xlczogW1wiRnJvbnRlbmQgRGV2ZWxvcGVyXCIsIFwiQmFja2VuZCBEZXZlbG9wZXJcIiwgXCJGdWxsc3RhY2sgRGV2ZWxvcGVyXCJdLFxyXG4gICAgYXZhaWxhYmlsaXR5UmVxdWlyZW1lbnQ6IHtcclxuICAgICAgd2Vla2x5SG91cnM6IDE1LFxyXG4gICAgfSxcclxuICAgIGRvbWFpbjogW1wiV2ViIERldmVsb3BtZW50XCJdLFxyXG4gICAgYWNhZGVtaWNDb25zdHJhaW50czoge1xyXG4gICAgICBzcGVjaWFsaXphdGlvbjogW1wiSVRcIl0sXHJcbiAgICAgIHllYXI6IDMsXHJcbiAgICAgIHNlbWVzdGVyOiAxLFxyXG4gICAgICBtaW5pbXVtQ0dQQTogMyxcclxuICAgIH0sXHJcbiAgfTtcclxuXHJcbiAgLy8gQ29sb3JzXHJcbiAgY29uc3QgY29sb3JzID0ge1xyXG4gICAgcHJpbWFyeTogXCIjM0I4MkY2XCIsXHJcbiAgICBzZWNvbmRhcnk6IFwiI0Y0NzJCNlwiLFxyXG4gICAgYWNjZW50OiBcIiNGQUNDMTVcIixcclxuICAgIHN1cmZhY2U6IFwiI0Y5RkFGQlwiLFxyXG4gICAgdGV4dFByaW1hcnk6IFwiIzFGMjkzN1wiLFxyXG4gICAgdGV4dFNlY29uZGFyeTogXCIjNkI3MjgwXCIsXHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLWgtc2NyZWVuIHAtOFwiIHN0eWxlPXt7IGJhY2tncm91bmRDb2xvcjogY29sb3JzLnN1cmZhY2UgfX0+XHJcbiAgICAgIHsvKiBDYXJkIENvbnRhaW5lciAqL31cclxuICAgICAgPGRpdlxyXG4gICAgICAgIGNsYXNzTmFtZT1cIm1heC13LTR4bCBteC1hdXRvIGJnLXdoaXRlIHJvdW5kZWQteGwgc2hhZG93LWxnIHAtOCBib3JkZXItbC00XCJcclxuICAgICAgICBzdHlsZT17eyBib3JkZXJDb2xvcjogY29sb3JzLnByaW1hcnkgfX1cclxuICAgICAgPlxyXG4gICAgICAgIHsvKiBQcm9qZWN0IFRpdGxlICovfVxyXG4gICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWJvbGQgbWItNFwiIHN0eWxlPXt7IGNvbG9yOiBjb2xvcnMudGV4dFByaW1hcnkgfX0+XHJcbiAgICAgICAgICB7cHJvamVjdC50aXRsZX1cclxuICAgICAgICA8L2gxPlxyXG5cclxuICAgICAgICB7LyogRXNzZW50aWFsIFNraWxscyAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTZcIj5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgbWItMlwiIHN0eWxlPXt7IGNvbG9yOiBjb2xvcnMudGV4dFNlY29uZGFyeSB9fT5cclxuICAgICAgICAgICAg8J+UuSBFc3NlbnRpYWwgU2tpbGxzXHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGdhcC0yXCI+XHJcbiAgICAgICAgICAgIHtPYmplY3QuZW50cmllcyhwcm9qZWN0LmVzc2VudGlhbFNraWxscykubWFwKChbY2F0ZWdvcnksIHNraWxsc10pID0+XHJcbiAgICAgICAgICAgICAgc2tpbGxzLm1hcCgoc2tpbGwsIGlkeCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgPHNwYW5cclxuICAgICAgICAgICAgICAgICAga2V5PXtgJHtjYXRlZ29yeX0tJHtpZHh9YH1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMyBweS0xIHJvdW5kZWQtZnVsbCBmb250LW1lZGl1bSB0ZXh0LXhzXCJcclxuICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IGNvbG9ycy5wcmltYXJ5ICsgXCIyMFwiLFxyXG4gICAgICAgICAgICAgICAgICAgIGNvbG9yOiBjb2xvcnMucHJpbWFyeSxcclxuICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAge3NraWxsfVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICkpXHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgey8qIFJlcXVpcmVkIFJvbGVzICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNlwiPlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCBtYi0yXCIgc3R5bGU9e3sgY29sb3I6IGNvbG9ycy50ZXh0U2Vjb25kYXJ5IH19PlxyXG4gICAgICAgICAgICDwn46vIFJlcXVpcmVkIFJvbGVzXHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGdhcC0yXCI+XHJcbiAgICAgICAgICAgIHtwcm9qZWN0LnJlcXVpcmVkUm9sZXMubWFwKChyb2xlLCBpZHgpID0+IChcclxuICAgICAgICAgICAgICA8c3BhblxyXG4gICAgICAgICAgICAgICAga2V5PXtpZHh9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zIHB5LTEgcm91bmRlZC1mdWxsIGZvbnQtbWVkaXVtIHRleHQteHNcIlxyXG4gICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOiBjb2xvcnMuc2Vjb25kYXJ5ICsgXCIyMFwiLFxyXG4gICAgICAgICAgICAgICAgICBjb2xvcjogY29sb3JzLnNlY29uZGFyeSxcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAge3JvbGV9XHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICApKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogV2Vla2x5IEhvdXJzICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNlwiPlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZFwiIHN0eWxlPXt7IGNvbG9yOiBjb2xvcnMudGV4dFNlY29uZGFyeSB9fT5cclxuICAgICAgICAgICAg4o+xIFdlZWtseSBIb3VycyBSZXF1aXJlZDp7XCIgXCJ9XHJcbiAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IGNvbG9yOiBjb2xvcnMudGV4dFByaW1hcnksIGZvbnRXZWlnaHQ6IFwiNTAwXCIgfX0+XHJcbiAgICAgICAgICAgICAge3Byb2plY3QuYXZhaWxhYmlsaXR5UmVxdWlyZW1lbnQud2Vla2x5SG91cnN9IGhyc1xyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHsvKiBEb21haW4gKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi02XCI+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIG1iLTJcIiBzdHlsZT17eyBjb2xvcjogY29sb3JzLnRleHRTZWNvbmRhcnkgfX0+XHJcbiAgICAgICAgICAgIPCfjJAgRG9tYWluXHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGdhcC0yXCI+XHJcbiAgICAgICAgICAgIHtwcm9qZWN0LmRvbWFpbi5tYXAoKGQsIGlkeCkgPT4gKFxyXG4gICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICBrZXk9e2lkeH1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMgcHktMSByb3VuZGVkLWZ1bGwgZm9udC1tZWRpdW0gdGV4dC14c1wiXHJcbiAgICAgICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IGNvbG9ycy5hY2NlbnQgKyBcIjIwXCIsXHJcbiAgICAgICAgICAgICAgICAgIGNvbG9yOiBjb2xvcnMuYWNjZW50LFxyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICB7ZH1cclxuICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHsvKiBBY2FkZW1pYyBDb25zdHJhaW50cyAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTZcIj5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgbWItMlwiIHN0eWxlPXt7IGNvbG9yOiBjb2xvcnMudGV4dFNlY29uZGFyeSB9fT5cclxuICAgICAgICAgICAg8J+OkyBBY2FkZW1pYyBDb25zdHJhaW50c1xyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPHVsIGNsYXNzTmFtZT1cIm1sLTQgbGlzdC1kaXNjXCIgc3R5bGU9e3sgY29sb3I6IGNvbG9ycy50ZXh0UHJpbWFyeSB9fT5cclxuICAgICAgICAgICAgPGxpPlNwZWNpYWxpemF0aW9uOiB7cHJvamVjdC5hY2FkZW1pY0NvbnN0cmFpbnRzLnNwZWNpYWxpemF0aW9uLmpvaW4oXCIsIFwiKX08L2xpPlxyXG4gICAgICAgICAgICA8bGk+WWVhcjoge3Byb2plY3QuYWNhZGVtaWNDb25zdHJhaW50cy55ZWFyfTwvbGk+XHJcbiAgICAgICAgICAgIDxsaT5TZW1lc3Rlcjoge3Byb2plY3QuYWNhZGVtaWNDb25zdHJhaW50cy5zZW1lc3Rlcn08L2xpPlxyXG4gICAgICAgICAgICA8bGk+TWluaW11bSBDR1BBOiB7cHJvamVjdC5hY2FkZW1pY0NvbnN0cmFpbnRzLm1pbmltdW1DR1BBfTwvbGk+XHJcbiAgICAgICAgICA8L3VsPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogQWN0aW9uIEJ1dHRvbnMgKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC00IG10LTZcIj5cclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIHB5LTIgcm91bmRlZC1sZyBmb250LW1lZGl1bSB0ZXh0LXdoaXRlIHRleHQtc21cIlxyXG4gICAgICAgICAgICBzdHlsZT17eyBiYWNrZ3JvdW5kQ29sb3I6IGNvbG9ycy5wcmltYXJ5IH19XHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGFsZXJ0KFwiUmVxdWVzdCBzZW50ISDinIVcIil9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIFJlcXVlc3QgdG8gSm9pblxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSBweS0yIHJvdW5kZWQtbGcgZm9udC1tZWRpdW0gdGV4dC13aGl0ZSB0ZXh0LXNtXCJcclxuICAgICAgICAgICAgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiBjb2xvcnMuc2Vjb25kYXJ5IH19XHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGFsZXJ0KFwiUHJvamVjdCBib29rbWFya2VkISDirZBcIil9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIEJvb2ttYXJrIFByb2plY3RcclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBwcm9qZWN0VmlldzsiXSwiZmlsZSI6IkY6L1kzUzIvSVRQTSBwcm9qZWN0L1Byb01hdGUtLVByb2plY3QtUGFydG5lci1GaW5kZXIvZnJvbnRlbmQvc3JjL3BhZ2VzL1JlY0VuZ2luZS9Qcm9qZWN0Vmlldy5qc3gifQ==