import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Users/ChangePassword.jsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ChangePassword.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=383bea9f"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"];
import { useAuth } from "/src/context/AuthContext.jsx";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=383bea9f";
const ChangePassword = () => {
  _s();
  const {
    token
  } = useAuth();
  const navigate = useNavigate();
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [passwordError, setPasswordError] = useState("");
  const [passwordSuccess, setPasswordSuccess] = useState("");
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const handlePasswordChange = async (e) => {
    e.preventDefault();
    setPasswordError("");
    setPasswordSuccess("");
    if (newPassword !== confirmPassword) {
      setPasswordError("New passwords do not match");
      return;
    }
    try {
      const res = await fetch("http://localhost:3000/api/profile/me/password", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          "x-auth-token": token
        },
        body: JSON.stringify({
          currentPassword,
          newPassword
        })
      });
      const data = await res.json();
      if (res.ok) {
        setPasswordSuccess("Password successfully updated!");
        setCurrentPassword("");
        setNewPassword("");
        setConfirmPassword("");
      } else {
        setPasswordError(data.message || "Error updating password");
      }
    } catch (err) {
      setPasswordError("Server error occurred");
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { id: "page-change-password", className: "page active", style: {
    display: "block",
    paddingBottom: "3rem"
  }, children: [
    /* @__PURE__ */ jsxDEV("div", { className: "page-hdr", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "page-hdr-left", children: [
        /* @__PURE__ */ jsxDEV("h1", { children: "Security Settings" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ChangePassword.jsx",
          lineNumber: 58,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: "Update your password to keep your account secure" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ChangePassword.jsx",
          lineNumber: 59,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ChangePassword.jsx",
        lineNumber: 57,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "page-hdr-right", children: /* @__PURE__ */ jsxDEV("button", { className: "btn btn-outline btn-sm", onClick: () => navigate("/settings"), children: "← Back to Settings" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ChangePassword.jsx",
        lineNumber: 62,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ChangePassword.jsx",
        lineNumber: 61,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ChangePassword.jsx",
      lineNumber: 56,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "section-card", style: {
      maxWidth: "600px",
      margin: "2rem auto"
    }, children: [
      /* @__PURE__ */ jsxDEV("div", { className: "section-card-title", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "section-icon", children: "🔐" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ChangePassword.jsx",
          lineNumber: 71,
          columnNumber: 11
        }, this),
        "Change Password"
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ChangePassword.jsx",
        lineNumber: 70,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("form", { onSubmit: handlePasswordChange, children: [
        passwordError && /* @__PURE__ */ jsxDEV("div", { className: "form-error show", style: {
          marginBottom: "1rem"
        }, children: passwordError }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ChangePassword.jsx",
          lineNumber: 76,
          columnNumber: 29
        }, this),
        passwordSuccess && /* @__PURE__ */ jsxDEV("div", { style: {
          color: "var(--success)",
          fontSize: "0.85rem",
          marginBottom: "1rem",
          fontWeight: 600
        }, children: passwordSuccess }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ChangePassword.jsx",
          lineNumber: 79,
          columnNumber: 31
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "form-label", children: "Current Password" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ChangePassword.jsx",
            lineNumber: 87,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "pw-wrap", children: [
            /* @__PURE__ */ jsxDEV("input", { type: showCurrentPassword ? "text" : "password", required: true, className: "form-input", value: currentPassword, onChange: (e) => setCurrentPassword(e.target.value), placeholder: "Enter current password" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ChangePassword.jsx",
              lineNumber: 89,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("button", { className: "pw-toggle", type: "button", onClick: () => setShowCurrentPassword(!showCurrentPassword), children: showCurrentPassword ? "🙈" : "👁️" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ChangePassword.jsx",
              lineNumber: 90,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ChangePassword.jsx",
            lineNumber: 88,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ChangePassword.jsx",
          lineNumber: 86,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "form-label", children: "New Password" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ChangePassword.jsx",
            lineNumber: 95,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "pw-wrap", children: [
            /* @__PURE__ */ jsxDEV("input", { type: showNewPassword ? "text" : "password", required: true, className: "form-input", value: newPassword, onChange: (e) => setNewPassword(e.target.value), placeholder: "Create a strong new password" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ChangePassword.jsx",
              lineNumber: 97,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("button", { className: "pw-toggle", type: "button", onClick: () => setShowNewPassword(!showNewPassword), children: showNewPassword ? "🙈" : "👁️" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ChangePassword.jsx",
              lineNumber: 98,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ChangePassword.jsx",
            lineNumber: 96,
            columnNumber: 13
          }, this),
          newPassword.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "pw-strength", children: [
            /* @__PURE__ */ jsxDEV("div", { className: `pw-seg ${newPassword.length > 3 ? "weak" : ""} ${newPassword.length > 7 ? "strong" : ""}` }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ChangePassword.jsx",
              lineNumber: 101,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: `pw-seg ${newPassword.length > 5 ? "fair" : ""} ${newPassword.length > 7 ? "strong" : ""}` }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ChangePassword.jsx",
              lineNumber: 102,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: `pw-seg ${newPassword.length > 7 ? "strong" : ""}` }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ChangePassword.jsx",
              lineNumber: 103,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ChangePassword.jsx",
            lineNumber: 100,
            columnNumber: 40
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ChangePassword.jsx",
          lineNumber: 94,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "form-label", children: "Confirm New Password" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ChangePassword.jsx",
            lineNumber: 108,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "pw-wrap", children: [
            /* @__PURE__ */ jsxDEV("input", { type: showConfirmPassword ? "text" : "password", required: true, className: "form-input", value: confirmPassword, onChange: (e) => setConfirmPassword(e.target.value), placeholder: "Repeat new password" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ChangePassword.jsx",
              lineNumber: 110,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("button", { className: "pw-toggle", type: "button", onClick: () => setShowConfirmPassword(!showConfirmPassword), children: showConfirmPassword ? "🙈" : "👁️" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ChangePassword.jsx",
              lineNumber: 111,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ChangePassword.jsx",
            lineNumber: 109,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ChangePassword.jsx",
          lineNumber: 107,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { style: {
          marginTop: "2.5rem",
          textAlign: "right"
        }, children: /* @__PURE__ */ jsxDEV("button", { type: "submit", className: "btn btn-primary btn-lg", style: {
          minWidth: "180px"
        }, children: "Save New Password" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ChangePassword.jsx",
          lineNumber: 119,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ChangePassword.jsx",
          lineNumber: 115,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ChangePassword.jsx",
        lineNumber: 75,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ChangePassword.jsx",
      lineNumber: 66,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ChangePassword.jsx",
    lineNumber: 52,
    columnNumber: 10
  }, this);
};
_s(ChangePassword, "94dt2h4+yha+XmRhNMsV4fTt2zU=", false, function() {
  return [useAuth, useNavigate];
});
_c = ChangePassword;
export default ChangePassword;
var _c;
$RefreshReg$(_c, "ChangePassword");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Users/ChangePassword.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcURVOzs7Ozs7Ozs7Ozs7Ozs7O0FBckRWLE9BQU9BLFNBQVNDLGdCQUFnQjtBQUNoQyxTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLG1CQUFtQjtBQUU1QixNQUFNQyxpQkFBaUJBLE1BQU07QUFBQUMsS0FBQTtBQUMzQixRQUFNO0FBQUEsSUFBRUM7QUFBQUEsRUFBTSxJQUFJSixRQUFRO0FBQzFCLFFBQU1LLFdBQVdKLFlBQVk7QUFFN0IsUUFBTSxDQUFDSyxpQkFBaUJDLGtCQUFrQixJQUFJUixTQUFTLEVBQUU7QUFDekQsUUFBTSxDQUFDUyxhQUFhQyxjQUFjLElBQUlWLFNBQVMsRUFBRTtBQUNqRCxRQUFNLENBQUNXLGlCQUFpQkMsa0JBQWtCLElBQUlaLFNBQVMsRUFBRTtBQUN6RCxRQUFNLENBQUNhLGVBQWVDLGdCQUFnQixJQUFJZCxTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDZSxpQkFBaUJDLGtCQUFrQixJQUFJaEIsU0FBUyxFQUFFO0FBRXpELFFBQU0sQ0FBQ2lCLHFCQUFxQkMsc0JBQXNCLElBQUlsQixTQUFTLEtBQUs7QUFDcEUsUUFBTSxDQUFDbUIsaUJBQWlCQyxrQkFBa0IsSUFBSXBCLFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUNxQixxQkFBcUJDLHNCQUFzQixJQUFJdEIsU0FBUyxLQUFLO0FBRXBFLFFBQU11Qix1QkFBdUIsT0FBT0MsTUFBTTtBQUN4Q0EsTUFBRUMsZUFBZTtBQUNqQlgscUJBQWlCLEVBQUU7QUFDbkJFLHVCQUFtQixFQUFFO0FBRXJCLFFBQUlQLGdCQUFnQkUsaUJBQWlCO0FBQ25DRyx1QkFBaUIsNEJBQTRCO0FBQzdDO0FBQUEsSUFDRjtBQUVBLFFBQUk7QUFDRixZQUFNWSxNQUFNLE1BQU1DLE1BQU0saURBQWlEO0FBQUEsUUFDdkVDLFFBQVE7QUFBQSxRQUNSQyxTQUFTO0FBQUEsVUFBRSxnQkFBZ0I7QUFBQSxVQUFvQixnQkFBZ0J4QjtBQUFBQSxRQUFNO0FBQUEsUUFDckV5QixNQUFNQyxLQUFLQyxVQUFVO0FBQUEsVUFBRXpCO0FBQUFBLFVBQWlCRTtBQUFBQSxRQUFZLENBQUM7QUFBQSxNQUN2RCxDQUFDO0FBRUQsWUFBTXdCLE9BQU8sTUFBTVAsSUFBSVEsS0FBSztBQUM1QixVQUFJUixJQUFJUyxJQUFJO0FBQ1ZuQiwyQkFBbUIsZ0NBQWdDO0FBQ25EUiwyQkFBbUIsRUFBRTtBQUNyQkUsdUJBQWUsRUFBRTtBQUNqQkUsMkJBQW1CLEVBQUU7QUFBQSxNQUN2QixPQUFPO0FBQ0xFLHlCQUFpQm1CLEtBQUtHLFdBQVcseUJBQXlCO0FBQUEsTUFDNUQ7QUFBQSxJQUNGLFNBQVNDLEtBQUs7QUFDWnZCLHVCQUFpQix1QkFBdUI7QUFBQSxJQUMxQztBQUFBLEVBQ0Y7QUFFQSxTQUNFLHVCQUFDLFNBQUksSUFBRyx3QkFBdUIsV0FBVSxlQUFjLE9BQU87QUFBQSxJQUFFd0IsU0FBUztBQUFBLElBQVNDLGVBQWU7QUFBQSxFQUFPLEdBQ3RHO0FBQUEsMkJBQUMsU0FBSSxXQUFVLFlBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSwrQkFBQyxRQUFHLGlDQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUI7QUFBQSxRQUNyQix1QkFBQyxPQUFFLGdFQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUQ7QUFBQSxXQUZyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxrQkFDYixpQ0FBQyxZQUFPLFdBQVUsMEJBQXlCLFNBQVMsTUFBTWpDLFNBQVMsV0FBVyxHQUFHLGtDQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1HLEtBRHJHO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVFBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsZ0JBQWUsT0FBTztBQUFBLE1BQUVrQyxVQUFVO0FBQUEsTUFBU0MsUUFBUTtBQUFBLElBQVksR0FDNUU7QUFBQSw2QkFBQyxTQUFJLFdBQVUsc0JBQ2I7QUFBQSwrQkFBQyxVQUFLLFdBQVUsZ0JBQWUsa0JBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUM7QUFBQSxRQUFPO0FBQUEsV0FEMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFFQSx1QkFBQyxVQUFLLFVBQVVsQixzQkFDYlY7QUFBQUEseUJBQWlCLHVCQUFDLFNBQUksV0FBVSxtQkFBa0IsT0FBTztBQUFBLFVBQUU2QixjQUFjO0FBQUEsUUFBTyxHQUFJN0IsMkJBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUY7QUFBQSxRQUNsR0UsbUJBQW1CLHVCQUFDLFNBQUksT0FBTztBQUFBLFVBQUU0QixPQUFPO0FBQUEsVUFBa0JDLFVBQVU7QUFBQSxVQUFXRixjQUFjO0FBQUEsVUFBUUcsWUFBWTtBQUFBLFFBQUksR0FBSTlCLDZCQUF0RztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNIO0FBQUEsUUFFMUksdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsY0FBYSxnQ0FBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBOEM7QUFBQSxVQUM5Qyx1QkFBQyxTQUFJLFdBQVUsV0FDYjtBQUFBLG1DQUFDLFdBQU0sTUFBTUUsc0JBQXNCLFNBQVMsWUFBWSxVQUFRLE1BQUMsV0FBVSxjQUFhLE9BQU9WLGlCQUFpQixVQUFXaUIsT0FBTWhCLG1CQUFtQmdCLEVBQUVzQixPQUFPQyxLQUFLLEdBQUcsYUFBWSw0QkFBakw7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeU07QUFBQSxZQUN6TSx1QkFBQyxZQUFPLFdBQVUsYUFBWSxNQUFLLFVBQVMsU0FBUyxNQUFNN0IsdUJBQXVCLENBQUNELG1CQUFtQixHQUFJQSxnQ0FBc0IsT0FBTyxTQUF2STtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2STtBQUFBLGVBRi9JO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsY0FBYSw0QkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEM7QUFBQSxVQUMxQyx1QkFBQyxTQUFJLFdBQVUsV0FDYjtBQUFBLG1DQUFDLFdBQU0sTUFBTUUsa0JBQWtCLFNBQVMsWUFBWSxVQUFRLE1BQUMsV0FBVSxjQUFhLE9BQU9WLGFBQWEsVUFBV2UsT0FBTWQsZUFBZWMsRUFBRXNCLE9BQU9DLEtBQUssR0FBRyxhQUFZLGtDQUFySztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtTTtBQUFBLFlBQ25NLHVCQUFDLFlBQU8sV0FBVSxhQUFZLE1BQUssVUFBUyxTQUFTLE1BQU0zQixtQkFBbUIsQ0FBQ0QsZUFBZSxHQUFJQSw0QkFBa0IsT0FBTyxTQUEzSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpSTtBQUFBLGVBRm5JO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNDVixZQUFZdUMsU0FBUyxLQUNwQix1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLG1DQUFDLFNBQUksV0FBVyxVQUFVdkMsWUFBWXVDLFNBQVMsSUFBSSxTQUFTLEVBQUUsSUFBSXZDLFlBQVl1QyxTQUFTLElBQUksV0FBVyxFQUFFLE1BQXhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRHO0FBQUEsWUFDNUcsdUJBQUMsU0FBSSxXQUFXLFVBQVV2QyxZQUFZdUMsU0FBUyxJQUFJLFNBQVMsRUFBRSxJQUFJdkMsWUFBWXVDLFNBQVMsSUFBSSxXQUFXLEVBQUUsTUFBeEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNEc7QUFBQSxZQUM1Ryx1QkFBQyxTQUFJLFdBQVcsVUFBVXZDLFlBQVl1QyxTQUFTLElBQUksV0FBVyxFQUFFLE1BQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9FO0FBQUEsZUFIdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJQTtBQUFBLGFBWEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWFBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLGlDQUFDLFdBQU0sV0FBVSxjQUFhLG9DQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFrRDtBQUFBLFVBQ2xELHVCQUFDLFNBQUksV0FBVSxXQUNiO0FBQUEsbUNBQUMsV0FBTSxNQUFNM0Isc0JBQXNCLFNBQVMsWUFBWSxVQUFRLE1BQUMsV0FBVSxjQUFhLE9BQU9WLGlCQUFpQixVQUFXYSxPQUFNWixtQkFBbUJZLEVBQUVzQixPQUFPQyxLQUFLLEdBQUcsYUFBWSx5QkFBakw7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc007QUFBQSxZQUN0TSx1QkFBQyxZQUFPLFdBQVUsYUFBWSxNQUFLLFVBQVMsU0FBUyxNQUFNekIsdUJBQXVCLENBQUNELG1CQUFtQixHQUFJQSxnQ0FBc0IsT0FBTyxTQUF2STtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2STtBQUFBLGVBRi9JO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxPQUFPO0FBQUEsVUFBRTRCLFdBQVc7QUFBQSxVQUFVQyxXQUFXO0FBQUEsUUFBUSxHQUNwRCxpQ0FBQyxZQUFPLE1BQUssVUFBUyxXQUFVLDBCQUF5QixPQUFPO0FBQUEsVUFBRUMsVUFBVTtBQUFBLFFBQVEsR0FBRyxpQ0FBdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3RyxLQUQxRztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQXJDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBc0NBO0FBQUEsU0E1Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTZDQTtBQUFBLE9BeERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F5REE7QUFFSjtBQUFFL0MsR0F6R0lELGdCQUFjO0FBQUEsVUFDQUYsU0FDREMsV0FBVztBQUFBO0FBQUFrRCxLQUZ4QmpEO0FBMkdOLGVBQWVBO0FBQWUsSUFBQWlEO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsInVzZVN0YXRlIiwidXNlQXV0aCIsInVzZU5hdmlnYXRlIiwiQ2hhbmdlUGFzc3dvcmQiLCJfcyIsInRva2VuIiwibmF2aWdhdGUiLCJjdXJyZW50UGFzc3dvcmQiLCJzZXRDdXJyZW50UGFzc3dvcmQiLCJuZXdQYXNzd29yZCIsInNldE5ld1Bhc3N3b3JkIiwiY29uZmlybVBhc3N3b3JkIiwic2V0Q29uZmlybVBhc3N3b3JkIiwicGFzc3dvcmRFcnJvciIsInNldFBhc3N3b3JkRXJyb3IiLCJwYXNzd29yZFN1Y2Nlc3MiLCJzZXRQYXNzd29yZFN1Y2Nlc3MiLCJzaG93Q3VycmVudFBhc3N3b3JkIiwic2V0U2hvd0N1cnJlbnRQYXNzd29yZCIsInNob3dOZXdQYXNzd29yZCIsInNldFNob3dOZXdQYXNzd29yZCIsInNob3dDb25maXJtUGFzc3dvcmQiLCJzZXRTaG93Q29uZmlybVBhc3N3b3JkIiwiaGFuZGxlUGFzc3dvcmRDaGFuZ2UiLCJlIiwicHJldmVudERlZmF1bHQiLCJyZXMiLCJmZXRjaCIsIm1ldGhvZCIsImhlYWRlcnMiLCJib2R5IiwiSlNPTiIsInN0cmluZ2lmeSIsImRhdGEiLCJqc29uIiwib2siLCJtZXNzYWdlIiwiZXJyIiwiZGlzcGxheSIsInBhZGRpbmdCb3R0b20iLCJtYXhXaWR0aCIsIm1hcmdpbiIsIm1hcmdpbkJvdHRvbSIsImNvbG9yIiwiZm9udFNpemUiLCJmb250V2VpZ2h0IiwidGFyZ2V0IiwidmFsdWUiLCJsZW5ndGgiLCJtYXJnaW5Ub3AiLCJ0ZXh0QWxpZ24iLCJtaW5XaWR0aCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQ2hhbmdlUGFzc3dvcmQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gJy4uLy4uL2NvbnRleHQvQXV0aENvbnRleHQnO1xyXG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xyXG5cclxuY29uc3QgQ2hhbmdlUGFzc3dvcmQgPSAoKSA9PiB7XHJcbiAgY29uc3QgeyB0b2tlbiB9ID0gdXNlQXV0aCgpO1xyXG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcclxuXHJcbiAgY29uc3QgW2N1cnJlbnRQYXNzd29yZCwgc2V0Q3VycmVudFBhc3N3b3JkXSA9IHVzZVN0YXRlKCcnKTtcclxuICBjb25zdCBbbmV3UGFzc3dvcmQsIHNldE5ld1Bhc3N3b3JkXSA9IHVzZVN0YXRlKCcnKTtcclxuICBjb25zdCBbY29uZmlybVBhc3N3b3JkLCBzZXRDb25maXJtUGFzc3dvcmRdID0gdXNlU3RhdGUoJycpO1xyXG4gIGNvbnN0IFtwYXNzd29yZEVycm9yLCBzZXRQYXNzd29yZEVycm9yXSA9IHVzZVN0YXRlKCcnKTtcclxuICBjb25zdCBbcGFzc3dvcmRTdWNjZXNzLCBzZXRQYXNzd29yZFN1Y2Nlc3NdID0gdXNlU3RhdGUoJycpO1xyXG4gIFxyXG4gIGNvbnN0IFtzaG93Q3VycmVudFBhc3N3b3JkLCBzZXRTaG93Q3VycmVudFBhc3N3b3JkXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2hvd05ld1Bhc3N3b3JkLCBzZXRTaG93TmV3UGFzc3dvcmRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzaG93Q29uZmlybVBhc3N3b3JkLCBzZXRTaG93Q29uZmlybVBhc3N3b3JkXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlUGFzc3dvcmRDaGFuZ2UgPSBhc3luYyAoZSkgPT4ge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgc2V0UGFzc3dvcmRFcnJvcignJyk7XHJcbiAgICBzZXRQYXNzd29yZFN1Y2Nlc3MoJycpO1xyXG4gICAgXHJcbiAgICBpZiAobmV3UGFzc3dvcmQgIT09IGNvbmZpcm1QYXNzd29yZCkge1xyXG4gICAgICBzZXRQYXNzd29yZEVycm9yKCdOZXcgcGFzc3dvcmRzIGRvIG5vdCBtYXRjaCcpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcbiAgICBcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKCdodHRwOi8vbG9jYWxob3N0OjMwMDAvYXBpL3Byb2ZpbGUvbWUvcGFzc3dvcmQnLCB7XHJcbiAgICAgICAgbWV0aG9kOiAnUFVUJyxcclxuICAgICAgICBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsICd4LWF1dGgtdG9rZW4nOiB0b2tlbiB9LFxyXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHsgY3VycmVudFBhc3N3b3JkLCBuZXdQYXNzd29yZCB9KVxyXG4gICAgICB9KTtcclxuICAgICAgXHJcbiAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXMuanNvbigpO1xyXG4gICAgICBpZiAocmVzLm9rKSB7XHJcbiAgICAgICAgc2V0UGFzc3dvcmRTdWNjZXNzKCdQYXNzd29yZCBzdWNjZXNzZnVsbHkgdXBkYXRlZCEnKTtcclxuICAgICAgICBzZXRDdXJyZW50UGFzc3dvcmQoJycpO1xyXG4gICAgICAgIHNldE5ld1Bhc3N3b3JkKCcnKTtcclxuICAgICAgICBzZXRDb25maXJtUGFzc3dvcmQoJycpO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHNldFBhc3N3b3JkRXJyb3IoZGF0YS5tZXNzYWdlIHx8ICdFcnJvciB1cGRhdGluZyBwYXNzd29yZCcpO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgc2V0UGFzc3dvcmRFcnJvcignU2VydmVyIGVycm9yIG9jY3VycmVkJyk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgaWQ9XCJwYWdlLWNoYW5nZS1wYXNzd29yZFwiIGNsYXNzTmFtZT1cInBhZ2UgYWN0aXZlXCIgc3R5bGU9e3sgZGlzcGxheTogJ2Jsb2NrJywgcGFkZGluZ0JvdHRvbTogJzNyZW0nIH19PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInBhZ2UtaGRyXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwYWdlLWhkci1sZWZ0XCI+XHJcbiAgICAgICAgICA8aDE+U2VjdXJpdHkgU2V0dGluZ3M8L2gxPlxyXG4gICAgICAgICAgPHA+VXBkYXRlIHlvdXIgcGFzc3dvcmQgdG8ga2VlcCB5b3VyIGFjY291bnQgc2VjdXJlPC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGFnZS1oZHItcmlnaHRcIj5cclxuICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYnRuIGJ0bi1vdXRsaW5lIGJ0bi1zbVwiIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKCcvc2V0dGluZ3MnKX0+4oaQIEJhY2sgdG8gU2V0dGluZ3M8L2J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInNlY3Rpb24tY2FyZFwiIHN0eWxlPXt7IG1heFdpZHRoOiAnNjAwcHgnLCBtYXJnaW46ICcycmVtIGF1dG8nIH19PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2VjdGlvbi1jYXJkLXRpdGxlXCI+XHJcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzZWN0aW9uLWljb25cIj7wn5SQPC9zcGFuPlxyXG4gICAgICAgICAgQ2hhbmdlIFBhc3N3b3JkXHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgXHJcbiAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVBhc3N3b3JkQ2hhbmdlfT5cclxuICAgICAgICAgIHtwYXNzd29yZEVycm9yICYmIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1lcnJvciBzaG93XCIgc3R5bGU9e3sgbWFyZ2luQm90dG9tOiAnMXJlbScgfX0+e3Bhc3N3b3JkRXJyb3J9PC9kaXY+fVxyXG4gICAgICAgICAge3Bhc3N3b3JkU3VjY2VzcyAmJiA8ZGl2IHN0eWxlPXt7IGNvbG9yOiAndmFyKC0tc3VjY2VzcyknLCBmb250U2l6ZTogJzAuODVyZW0nLCBtYXJnaW5Cb3R0b206ICcxcmVtJywgZm9udFdlaWdodDogNjAwIH19PntwYXNzd29yZFN1Y2Nlc3N9PC9kaXY+fVxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXBcIj5cclxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZvcm0tbGFiZWxcIj5DdXJyZW50IFBhc3N3b3JkPC9sYWJlbD5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdy13cmFwXCI+XHJcbiAgICAgICAgICAgICAgPGlucHV0IHR5cGU9e3Nob3dDdXJyZW50UGFzc3dvcmQgPyBcInRleHRcIiA6IFwicGFzc3dvcmRcIn0gcmVxdWlyZWQgY2xhc3NOYW1lPVwiZm9ybS1pbnB1dFwiIHZhbHVlPXtjdXJyZW50UGFzc3dvcmR9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0Q3VycmVudFBhc3N3b3JkKGUudGFyZ2V0LnZhbHVlKX0gcGxhY2Vob2xkZXI9XCJFbnRlciBjdXJyZW50IHBhc3N3b3JkXCIgLz5cclxuICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cInB3LXRvZ2dsZVwiIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiBzZXRTaG93Q3VycmVudFBhc3N3b3JkKCFzaG93Q3VycmVudFBhc3N3b3JkKX0+e3Nob3dDdXJyZW50UGFzc3dvcmQgPyBcIvCfmYhcIiA6IFwi8J+Rge+4j1wifTwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXBcIj5cclxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZvcm0tbGFiZWxcIj5OZXcgUGFzc3dvcmQ8L2xhYmVsPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB3LXdyYXBcIj5cclxuICAgICAgICAgICAgICA8aW5wdXQgdHlwZT17c2hvd05ld1Bhc3N3b3JkID8gXCJ0ZXh0XCIgOiBcInBhc3N3b3JkXCJ9IHJlcXVpcmVkIGNsYXNzTmFtZT1cImZvcm0taW5wdXRcIiB2YWx1ZT17bmV3UGFzc3dvcmR9IG9uQ2hhbmdlPXsoZSkgPT4gc2V0TmV3UGFzc3dvcmQoZS50YXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj1cIkNyZWF0ZSBhIHN0cm9uZyBuZXcgcGFzc3dvcmRcIiAvPlxyXG4gICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwicHctdG9nZ2xlXCIgdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHNldFNob3dOZXdQYXNzd29yZCghc2hvd05ld1Bhc3N3b3JkKX0+e3Nob3dOZXdQYXNzd29yZCA/IFwi8J+ZiFwiIDogXCLwn5GB77iPXCJ9PC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICB7bmV3UGFzc3dvcmQubGVuZ3RoID4gMCAmJiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdy1zdHJlbmd0aFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2Bwdy1zZWcgJHtuZXdQYXNzd29yZC5sZW5ndGggPiAzID8gJ3dlYWsnIDogJyd9ICR7bmV3UGFzc3dvcmQubGVuZ3RoID4gNyA/ICdzdHJvbmcnIDogJyd9YH0+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YHB3LXNlZyAke25ld1Bhc3N3b3JkLmxlbmd0aCA+IDUgPyAnZmFpcicgOiAnJ30gJHtuZXdQYXNzd29yZC5sZW5ndGggPiA3ID8gJ3N0cm9uZycgOiAnJ31gfT48L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgcHctc2VnICR7bmV3UGFzc3dvcmQubGVuZ3RoID4gNyA/ICdzdHJvbmcnIDogJyd9YH0+PC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLWdyb3VwXCI+XHJcbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmb3JtLWxhYmVsXCI+Q29uZmlybSBOZXcgUGFzc3dvcmQ8L2xhYmVsPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB3LXdyYXBcIj5cclxuICAgICAgICAgICAgICA8aW5wdXQgdHlwZT17c2hvd0NvbmZpcm1QYXNzd29yZCA/IFwidGV4dFwiIDogXCJwYXNzd29yZFwifSByZXF1aXJlZCBjbGFzc05hbWU9XCJmb3JtLWlucHV0XCIgdmFsdWU9e2NvbmZpcm1QYXNzd29yZH0gb25DaGFuZ2U9eyhlKSA9PiBzZXRDb25maXJtUGFzc3dvcmQoZS50YXJnZXQudmFsdWUpfSBwbGFjZWhvbGRlcj1cIlJlcGVhdCBuZXcgcGFzc3dvcmRcIiAvPlxyXG4gICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwicHctdG9nZ2xlXCIgdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IHNldFNob3dDb25maXJtUGFzc3dvcmQoIXNob3dDb25maXJtUGFzc3dvcmQpfT57c2hvd0NvbmZpcm1QYXNzd29yZCA/IFwi8J+ZiFwiIDogXCLwn5GB77iPXCJ9PC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICBcclxuICAgICAgICAgIDxkaXYgc3R5bGU9e3sgbWFyZ2luVG9wOiAnMi41cmVtJywgdGV4dEFsaWduOiAncmlnaHQnIH19PlxyXG4gICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBjbGFzc05hbWU9XCJidG4gYnRuLXByaW1hcnkgYnRuLWxnXCIgc3R5bGU9e3sgbWluV2lkdGg6ICcxODBweCcgfX0+U2F2ZSBOZXcgUGFzc3dvcmQ8L2J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZm9ybT5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgQ2hhbmdlUGFzc3dvcmQ7XHJcbiJdLCJmaWxlIjoiRjovWTNTMi9JVFBNIHByb2plY3QvUHJvTWF0ZS0tUHJvamVjdC1QYXJ0bmVyLUZpbmRlci9mcm9udGVuZC9zcmMvcGFnZXMvVXNlcnMvQ2hhbmdlUGFzc3dvcmQuanN4In0=