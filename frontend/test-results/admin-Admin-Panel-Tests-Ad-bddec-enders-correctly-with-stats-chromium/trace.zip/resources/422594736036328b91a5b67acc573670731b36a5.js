import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/context/AuthContext.jsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/context/AuthContext.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=383bea9f"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const createContext = __vite__cjsImport3_react["createContext"]; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useContext = __vite__cjsImport3_react["useContext"];
const AuthContext = createContext();
export const useAuth = () => {
  _s();
  return useContext(AuthContext);
};
_s(useAuth, "gDsCjeeItUuvgOWf1v4qoK9RF6k=");
export const AuthProvider = ({
  children
}) => {
  _s2();
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(localStorage.getItem("token") || null);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    if (token) {
      localStorage.setItem("token", token);
      fetchProfile();
    } else {
      localStorage.removeItem("token");
      setUser(null);
      setLoading(false);
    }
  }, [token]);
  const fetchProfile = async () => {
    try {
      const res = await fetch("http://127.0.0.1:3000/api/profile/me", {
        headers: {
          "x-auth-token": token
        }
      });
      if (res.ok) {
        const data = await res.json();
        setUser(data);
      } else {
        setToken(null);
      }
    } catch (error) {
      console.error("Error fetching profile:", error);
      setToken(null);
    } finally {
      setLoading(false);
    }
  };
  const login = async (identifier, password) => {
    const res = await fetch("http://127.0.0.1:3000/api/auth/login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        identifier,
        password
      })
    });
    const data = await res.json();
    if (res.ok) {
      setToken(data.token);
      return {
        success: true,
        user: data.user
      };
    }
    return {
      success: false,
      message: data.message
    };
  };
  const register = async (userData) => {
    const res = await fetch("http://127.0.0.1:3000/api/auth/register", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(userData)
    });
    const data = await res.json();
    if (res.ok) {
      setToken(data.token);
      return {
        success: true
      };
    }
    return {
      success: false,
      message: data.message
    };
  };
  const checkAvailability = async (fields) => {
    try {
      const res = await fetch("http://127.0.0.1:3000/api/auth/check-availability", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(fields)
      });
      if (!res.ok) {
        return {
          success: false,
          available: true,
          message: "Server error during check"
        };
      }
      const data = await res.json();
      return {
        success: true,
        available: data.available,
        message: data.message
      };
    } catch (error) {
      console.error("Error checking availability:", error);
      return {
        success: false,
        available: true,
        message: "Server unreachable"
      };
    }
  };
  const logout = () => {
    setToken(null);
  };
  return /* @__PURE__ */ jsxDEV(AuthContext.Provider, { value: {
    user,
    token,
    loading,
    login,
    register,
    logout,
    fetchProfile,
    checkAvailability
  }, children: !loading ? children : /* @__PURE__ */ jsxDEV("div", { children: "Loading..." }, void 0, false, {
    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/context/AuthContext.jsx",
    lineNumber: 135,
    columnNumber: 30
  }, this) }, void 0, false, {
    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/context/AuthContext.jsx",
    lineNumber: 125,
    columnNumber: 10
  }, this);
};
_s2(AuthProvider, "zvU4U6qzDzFTziISSdKoxTicSiQ=");
_c = AuthProvider;
var _c;
$RefreshReg$(_c, "AuthProvider");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/context/AuthContext.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUc2Qjs7Ozs7Ozs7Ozs7Ozs7OztBQWpHN0IsT0FBT0EsU0FBU0MsZUFBZUMsVUFBVUMsV0FBV0Msa0JBQWtCO0FBRXRFLE1BQU1DLGNBQWNKLGNBQWM7QUFFM0IsYUFBTUssVUFBVUEsTUFBQTtBQUFBQyxLQUFBO0FBQUEsU0FBTUgsV0FBV0MsV0FBVztBQUFDO0FBQUNFLEdBQXhDRCxTQUFPO0FBRWIsYUFBTUUsZUFBZUEsQ0FBQztBQUFBLEVBQUVDO0FBQVMsTUFBTTtBQUFBQyxNQUFBO0FBQzVDLFFBQU0sQ0FBQ0MsTUFBTUMsT0FBTyxJQUFJVixTQUFTLElBQUk7QUFDckMsUUFBTSxDQUFDVyxPQUFPQyxRQUFRLElBQUlaLFNBQVNhLGFBQWFDLFFBQVEsT0FBTyxLQUFLLElBQUk7QUFDeEUsUUFBTSxDQUFDQyxTQUFTQyxVQUFVLElBQUloQixTQUFTLElBQUk7QUFFM0NDLFlBQVUsTUFBTTtBQUNkLFFBQUlVLE9BQU87QUFDVEUsbUJBQWFJLFFBQVEsU0FBU04sS0FBSztBQUNuQ08sbUJBQWE7QUFBQSxJQUNmLE9BQU87QUFDTEwsbUJBQWFNLFdBQVcsT0FBTztBQUMvQlQsY0FBUSxJQUFJO0FBQ1pNLGlCQUFXLEtBQUs7QUFBQSxJQUNsQjtBQUFBLEVBQ0YsR0FBRyxDQUFDTCxLQUFLLENBQUM7QUFFVixRQUFNTyxlQUFlLFlBQVk7QUFDL0IsUUFBSTtBQUNGLFlBQU1FLE1BQU0sTUFBTUMsTUFBTSx3Q0FBd0M7QUFBQSxRQUM5REMsU0FBUztBQUFBLFVBQ1AsZ0JBQWdCWDtBQUFBQSxRQUNsQjtBQUFBLE1BQ0YsQ0FBQztBQUNELFVBQUlTLElBQUlHLElBQUk7QUFDVixjQUFNQyxPQUFPLE1BQU1KLElBQUlLLEtBQUs7QUFDNUJmLGdCQUFRYyxJQUFJO0FBQUEsTUFDZCxPQUFPO0FBQ0xaLGlCQUFTLElBQUk7QUFBQSxNQUNmO0FBQUEsSUFDRixTQUFTYyxPQUFPO0FBQ2RDLGNBQVFELE1BQU0sMkJBQTJCQSxLQUFLO0FBQzlDZCxlQUFTLElBQUk7QUFBQSxJQUNmLFVBQUM7QUFDQ0ksaUJBQVcsS0FBSztBQUFBLElBQ2xCO0FBQUEsRUFDRjtBQUVBLFFBQU1ZLFFBQVEsT0FBT0MsWUFBWUMsYUFBYTtBQUM1QyxVQUFNVixNQUFNLE1BQU1DLE1BQU0sd0NBQXdDO0FBQUEsTUFDOURVLFFBQVE7QUFBQSxNQUNSVCxTQUFTO0FBQUEsUUFBRSxnQkFBZ0I7QUFBQSxNQUFtQjtBQUFBLE1BQzlDVSxNQUFNQyxLQUFLQyxVQUFVO0FBQUEsUUFBRUw7QUFBQUEsUUFBWUM7QUFBQUEsTUFBUyxDQUFDO0FBQUEsSUFDL0MsQ0FBQztBQUVELFVBQU1OLE9BQU8sTUFBTUosSUFBSUssS0FBSztBQUM1QixRQUFJTCxJQUFJRyxJQUFJO0FBQ1ZYLGVBQVNZLEtBQUtiLEtBQUs7QUFDbkIsYUFBTztBQUFBLFFBQUV3QixTQUFTO0FBQUEsUUFBTTFCLE1BQU1lLEtBQUtmO0FBQUFBLE1BQUs7QUFBQSxJQUMxQztBQUNBLFdBQU87QUFBQSxNQUFFMEIsU0FBUztBQUFBLE1BQU9DLFNBQVNaLEtBQUtZO0FBQUFBLElBQVE7QUFBQSxFQUNqRDtBQUVBLFFBQU1DLFdBQVcsT0FBT0MsYUFBYTtBQUNuQyxVQUFNbEIsTUFBTSxNQUFNQyxNQUFNLDJDQUEyQztBQUFBLE1BQ2pFVSxRQUFRO0FBQUEsTUFDUlQsU0FBUztBQUFBLFFBQUUsZ0JBQWdCO0FBQUEsTUFBbUI7QUFBQSxNQUM5Q1UsTUFBTUMsS0FBS0MsVUFBVUksUUFBUTtBQUFBLElBQy9CLENBQUM7QUFFRCxVQUFNZCxPQUFPLE1BQU1KLElBQUlLLEtBQUs7QUFDNUIsUUFBSUwsSUFBSUcsSUFBSTtBQUNWWCxlQUFTWSxLQUFLYixLQUFLO0FBQ25CLGFBQU87QUFBQSxRQUFFd0IsU0FBUztBQUFBLE1BQUs7QUFBQSxJQUN6QjtBQUNBLFdBQU87QUFBQSxNQUFFQSxTQUFTO0FBQUEsTUFBT0MsU0FBU1osS0FBS1k7QUFBQUEsSUFBUTtBQUFBLEVBQ2pEO0FBRUEsUUFBTUcsb0JBQW9CLE9BQU9DLFdBQVc7QUFDMUMsUUFBSTtBQUNGLFlBQU1wQixNQUFNLE1BQU1DLE1BQU0scURBQXFEO0FBQUEsUUFDM0VVLFFBQVE7QUFBQSxRQUNSVCxTQUFTO0FBQUEsVUFBRSxnQkFBZ0I7QUFBQSxRQUFtQjtBQUFBLFFBQzlDVSxNQUFNQyxLQUFLQyxVQUFVTSxNQUFNO0FBQUEsTUFDN0IsQ0FBQztBQUNELFVBQUksQ0FBQ3BCLElBQUlHLElBQUk7QUFDWCxlQUFPO0FBQUEsVUFBRVksU0FBUztBQUFBLFVBQU9NLFdBQVc7QUFBQSxVQUFNTCxTQUFTO0FBQUEsUUFBNEI7QUFBQSxNQUNqRjtBQUNBLFlBQU1aLE9BQU8sTUFBTUosSUFBSUssS0FBSztBQUM1QixhQUFPO0FBQUEsUUFBRVUsU0FBUztBQUFBLFFBQU1NLFdBQVdqQixLQUFLaUI7QUFBQUEsUUFBV0wsU0FBU1osS0FBS1k7QUFBQUEsTUFBUTtBQUFBLElBQzNFLFNBQVNWLE9BQU87QUFDZEMsY0FBUUQsTUFBTSxnQ0FBZ0NBLEtBQUs7QUFDbkQsYUFBTztBQUFBLFFBQUVTLFNBQVM7QUFBQSxRQUFPTSxXQUFXO0FBQUEsUUFBTUwsU0FBUztBQUFBLE1BQXFCO0FBQUEsSUFDMUU7QUFBQSxFQUNGO0FBRUEsUUFBTU0sU0FBU0EsTUFBTTtBQUNuQjlCLGFBQVMsSUFBSTtBQUFBLEVBQ2Y7QUFFQSxTQUNFLHVCQUFDLFlBQVksVUFBWixFQUFxQixPQUFPO0FBQUEsSUFBRUg7QUFBQUEsSUFBTUU7QUFBQUEsSUFBT0k7QUFBQUEsSUFBU2E7QUFBQUEsSUFBT1M7QUFBQUEsSUFBVUs7QUFBQUEsSUFBUXhCO0FBQUFBLElBQWNxQjtBQUFBQSxFQUFrQixHQUMzRyxXQUFDeEIsVUFBVVIsV0FBVyx1QkFBQyxTQUFJLDBCQUFMO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBZSxLQUR4QztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBRUE7QUFFSjtBQUFFQyxJQTlGV0YsY0FBWTtBQUFBcUMsS0FBWnJDO0FBQVksSUFBQXFDO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsImNyZWF0ZUNvbnRleHQiLCJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsInVzZUNvbnRleHQiLCJBdXRoQ29udGV4dCIsInVzZUF1dGgiLCJfcyIsIkF1dGhQcm92aWRlciIsImNoaWxkcmVuIiwiX3MyIiwidXNlciIsInNldFVzZXIiLCJ0b2tlbiIsInNldFRva2VuIiwibG9jYWxTdG9yYWdlIiwiZ2V0SXRlbSIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwic2V0SXRlbSIsImZldGNoUHJvZmlsZSIsInJlbW92ZUl0ZW0iLCJyZXMiLCJmZXRjaCIsImhlYWRlcnMiLCJvayIsImRhdGEiLCJqc29uIiwiZXJyb3IiLCJjb25zb2xlIiwibG9naW4iLCJpZGVudGlmaWVyIiwicGFzc3dvcmQiLCJtZXRob2QiLCJib2R5IiwiSlNPTiIsInN0cmluZ2lmeSIsInN1Y2Nlc3MiLCJtZXNzYWdlIiwicmVnaXN0ZXIiLCJ1c2VyRGF0YSIsImNoZWNrQXZhaWxhYmlsaXR5IiwiZmllbGRzIiwiYXZhaWxhYmxlIiwibG9nb3V0IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJBdXRoQ29udGV4dC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IGNyZWF0ZUNvbnRleHQsIHVzZVN0YXRlLCB1c2VFZmZlY3QsIHVzZUNvbnRleHQgfSBmcm9tICdyZWFjdCc7XHJcblxyXG5jb25zdCBBdXRoQ29udGV4dCA9IGNyZWF0ZUNvbnRleHQoKTtcclxuXHJcbmV4cG9ydCBjb25zdCB1c2VBdXRoID0gKCkgPT4gdXNlQ29udGV4dChBdXRoQ29udGV4dCk7XHJcblxyXG5leHBvcnQgY29uc3QgQXV0aFByb3ZpZGVyID0gKHsgY2hpbGRyZW4gfSkgPT4ge1xyXG4gIGNvbnN0IFt1c2VyLCBzZXRVc2VyXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFt0b2tlbiwgc2V0VG9rZW5dID0gdXNlU3RhdGUobG9jYWxTdG9yYWdlLmdldEl0ZW0oJ3Rva2VuJykgfHwgbnVsbCk7XHJcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAodG9rZW4pIHtcclxuICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ3Rva2VuJywgdG9rZW4pO1xyXG4gICAgICBmZXRjaFByb2ZpbGUoKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKCd0b2tlbicpO1xyXG4gICAgICBzZXRVc2VyKG51bGwpO1xyXG4gICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9LCBbdG9rZW5dKTtcclxuXHJcbiAgY29uc3QgZmV0Y2hQcm9maWxlID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goJ2h0dHA6Ly8xMjcuMC4wLjE6MzAwMC9hcGkvcHJvZmlsZS9tZScsIHtcclxuICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAneC1hdXRoLXRva2VuJzogdG9rZW5cclxuICAgICAgICB9XHJcbiAgICAgIH0pO1xyXG4gICAgICBpZiAocmVzLm9rKSB7XHJcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlcy5qc29uKCk7XHJcbiAgICAgICAgc2V0VXNlcihkYXRhKTsgLy8gZGF0YSBpcyB0aGUgdXNlciBvYmplY3QgZGlyZWN0bHlcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBzZXRUb2tlbihudWxsKTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgZmV0Y2hpbmcgcHJvZmlsZTonLCBlcnJvcik7XHJcbiAgICAgIHNldFRva2VuKG51bGwpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgbG9naW4gPSBhc3luYyAoaWRlbnRpZmllciwgcGFzc3dvcmQpID0+IHtcclxuICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKCdodHRwOi8vMTI3LjAuMC4xOjMwMDAvYXBpL2F1dGgvbG9naW4nLCB7XHJcbiAgICAgIG1ldGhvZDogJ1BPU1QnLFxyXG4gICAgICBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSxcclxuICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoeyBpZGVudGlmaWVyLCBwYXNzd29yZCB9KVxyXG4gICAgfSk7XHJcbiAgICBcclxuICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXMuanNvbigpO1xyXG4gICAgaWYgKHJlcy5vaykge1xyXG4gICAgICBzZXRUb2tlbihkYXRhLnRva2VuKTtcclxuICAgICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSwgdXNlcjogZGF0YS51c2VyIH07XHJcbiAgICB9XHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgbWVzc2FnZTogZGF0YS5tZXNzYWdlIH07XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgcmVnaXN0ZXIgPSBhc3luYyAodXNlckRhdGEpID0+IHtcclxuICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKCdodHRwOi8vMTI3LjAuMC4xOjMwMDAvYXBpL2F1dGgvcmVnaXN0ZXInLCB7XHJcbiAgICAgIG1ldGhvZDogJ1BPU1QnLFxyXG4gICAgICBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSxcclxuICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkodXNlckRhdGEpXHJcbiAgICB9KTtcclxuICAgIFxyXG4gICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlcy5qc29uKCk7XHJcbiAgICBpZiAocmVzLm9rKSB7XHJcbiAgICAgIHNldFRva2VuKGRhdGEudG9rZW4pO1xyXG4gICAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlIH07XHJcbiAgICB9XHJcbiAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgbWVzc2FnZTogZGF0YS5tZXNzYWdlIH07XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgY2hlY2tBdmFpbGFiaWxpdHkgPSBhc3luYyAoZmllbGRzKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaCgnaHR0cDovLzEyNy4wLjAuMTozMDAwL2FwaS9hdXRoL2NoZWNrLWF2YWlsYWJpbGl0eScsIHtcclxuICAgICAgICBtZXRob2Q6ICdQT1NUJyxcclxuICAgICAgICBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSxcclxuICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeShmaWVsZHMpXHJcbiAgICAgIH0pO1xyXG4gICAgICBpZiAoIXJlcy5vaykge1xyXG4gICAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBhdmFpbGFibGU6IHRydWUsIG1lc3NhZ2U6ICdTZXJ2ZXIgZXJyb3IgZHVyaW5nIGNoZWNrJyB9O1xyXG4gICAgICB9XHJcbiAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXMuanNvbigpO1xyXG4gICAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlLCBhdmFpbGFibGU6IGRhdGEuYXZhaWxhYmxlLCBtZXNzYWdlOiBkYXRhLm1lc3NhZ2UgfTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGNoZWNraW5nIGF2YWlsYWJpbGl0eTonLCBlcnJvcik7XHJcbiAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBhdmFpbGFibGU6IHRydWUsIG1lc3NhZ2U6ICdTZXJ2ZXIgdW5yZWFjaGFibGUnIH07XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgbG9nb3V0ID0gKCkgPT4ge1xyXG4gICAgc2V0VG9rZW4obnVsbCk7XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxBdXRoQ29udGV4dC5Qcm92aWRlciB2YWx1ZT17eyB1c2VyLCB0b2tlbiwgbG9hZGluZywgbG9naW4sIHJlZ2lzdGVyLCBsb2dvdXQsIGZldGNoUHJvZmlsZSwgY2hlY2tBdmFpbGFiaWxpdHkgfX0+XHJcbiAgICAgIHshbG9hZGluZyA/IGNoaWxkcmVuIDogPGRpdj5Mb2FkaW5nLi4uPC9kaXY+fVxyXG4gICAgPC9BdXRoQ29udGV4dC5Qcm92aWRlcj5cclxuICApO1xyXG59O1xyXG4iXSwiZmlsZSI6IkY6L1kzUzIvSVRQTSBwcm9qZWN0L1Byb01hdGUtLVByb2plY3QtUGFydG5lci1GaW5kZXIvZnJvbnRlbmQvc3JjL2NvbnRleHQvQXV0aENvbnRleHQuanN4In0=