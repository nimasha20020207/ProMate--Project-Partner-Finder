import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Admin/Studentmanagement.jsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=383bea9f"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"]; const useRef = __vite__cjsImport3_react["useRef"];
import axios from "/node_modules/.vite/deps/axios.js?v=383bea9f";
import AdminNavbar from "/src/components/AdminNavbar.jsx";
import { useAuth } from "/src/context/AuthContext.jsx";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=383bea9f";
const StudentManagement = () => {
  _s();
  const navigate = useNavigate();
  const {
    token
  } = useAuth();
  const [students, setStudents] = useState([]);
  const [showSuspendModal, setShowSuspendModal] = useState(false);
  const [selectedStudent, setSelectedStudent] = useState(null);
  const [reason, setReason] = useState("");
  const [additionalComments, setAdditionalComments] = useState("");
  const [suspendDate, setSuspendDate] = useState("");
  const [error, setError] = useState("");
  const [searchId, setSearchId] = useState("");
  const tableRef = useRef(null);
  const fetchStudents = () => {
    axios.get("http://localhost:3000/api/admin/students", {
      headers: {
        "x-auth-token": token
      }
    }).then((res) => setStudents(res.data)).catch((err) => console.log(err));
  };
  useEffect(() => {
    fetchStudents();
  }, [token]);
  const openSuspendModal = (student) => {
    setSelectedStudent(student);
    setReason("");
    setAdditionalComments("");
    setSuspendDate("");
    setError("");
    setShowSuspendModal(true);
  };
  const handleSuspend = async () => {
    if (!reason)
      return setError("Please select a reason.");
    if (additionalComments.trim().length < 5)
      return setError("Additional comments must be at least 5 characters.");
    if (!suspendDate)
      return setError("Please select a suspension date.");
    try {
      await axios.post(`http://localhost:3000/api/admin/suspend/${selectedStudent._id}`, {
        reason,
        additionalComments,
        suspendDate
      }, {
        headers: {
          "x-auth-token": token
        }
      });
      setStudents((prev) => prev.filter((s) => s._id !== selectedStudent._id));
      setShowSuspendModal(false);
      alert("Student suspended successfully!");
    } catch (err) {
      console.error(err);
      setError("Failed to suspend student");
    }
  };
  const verifyStudent = (id) => {
    alert("Student verified (mock action)");
  };
  const scrollToTable = () => {
    tableRef.current?.scrollIntoView({
      behavior: "smooth"
    });
  };
  const filteredStudents = students.filter((s) => s.studentId.toLowerCase().includes(searchId.toLowerCase()));
  return /* @__PURE__ */ jsxDEV("div", { className: "flex h-screen", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex-1 p-6 bg-surface", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-6", children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold text-textPrimary", children: "New Users 👨‍🎓👩‍🎓" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
          lineNumber: 80,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("button", { onClick: scrollToTable, className: "bg-[#3B82F6] text-white px-4 py-2 rounded-lg shadow hover:bg-blue-700 transition", children: "View All Users" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
          lineNumber: 81,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
        lineNumber: 79,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 mb-12", children: students.map((s) => /* @__PURE__ */ jsxDEV("div", { className: "bg-white shadow-md rounded-xl p-5 border hover:shadow-lg transition transform hover:-translate-y-1", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mb-3", children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-bold text-[#3B82F6]", children: s.fullName }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
            lineNumber: 90,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500", children: [
            "ID: ",
            s.studentId
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
            lineNumber: 91,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
          lineNumber: 89,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-[#374151] space-y-1", children: [
          /* @__PURE__ */ jsxDEV("p", { children: [
            /* @__PURE__ */ jsxDEV("strong", { children: "Degree:" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
              lineNumber: 95,
              columnNumber: 20
            }, this),
            " ",
            s.degreeProgram
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
            lineNumber: 95,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { children: [
            /* @__PURE__ */ jsxDEV("strong", { children: "Department:" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
              lineNumber: 96,
              columnNumber: 20
            }, this),
            " ",
            s.department
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
            lineNumber: 96,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { children: [
            /* @__PURE__ */ jsxDEV("strong", { children: "Specialization:" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
              lineNumber: 97,
              columnNumber: 20
            }, this),
            " ",
            s.academicInfo?.specialization
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
            lineNumber: 97,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { children: [
            /* @__PURE__ */ jsxDEV("strong", { children: "Year:" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
              lineNumber: 98,
              columnNumber: 20
            }, this),
            " ",
            s.academicInfo?.year
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
            lineNumber: 98,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("p", { children: [
            /* @__PURE__ */ jsxDEV("strong", { children: "Semester:" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
              lineNumber: 99,
              columnNumber: 20
            }, this),
            " ",
            s.academicInfo?.semester
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
            lineNumber: 99,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
          lineNumber: 94,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between mt-4 gap-2 flex-wrap", children: [
          /* @__PURE__ */ jsxDEV("button", { onClick: () => navigate(`/profile/${s._id}`), className: "flex-1 text-xs bg-[#3B82F6] text-white px-2 py-1 rounded hover:bg-blue-700 transition whitespace-nowrap", children: "View Profile" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
            lineNumber: 103,
            columnNumber: 3
          }, this),
          /* @__PURE__ */ jsxDEV("button", { onClick: () => verifyStudent(s._id), className: "flex-1 text-xs bg-secondary text-white px-2 py-1 rounded hover:opacity-90 transition whitespace-nowrap", children: "Verify⭐" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
            lineNumber: 106,
            columnNumber: 3
          }, this),
          /* @__PURE__ */ jsxDEV("button", { onClick: () => openSuspendModal(s), className: "flex-1 text-xs bg-[#6B7280] text-white px-2 py-1 rounded hover:bg-gray-500 transition whitespace-nowrap", children: "Suspend" }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
            lineNumber: 109,
            columnNumber: 3
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
          lineNumber: 102,
          columnNumber: 15
        }, this)
      ] }, s._id, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
        lineNumber: 88,
        columnNumber: 30
      }, this)) }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
        lineNumber: 87,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { ref: tableRef, className: "bg-white p-4 rounded-xl shadow-md mb-12", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-bold text-[#1F2937] mb-4", children: "All Students" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
          lineNumber: 118,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mb-4 flex justify-end", children: /* @__PURE__ */ jsxDEV("input", { type: "text", placeholder: "Search by Student ID...", value: searchId, onChange: (e) => setSearchId(e.target.value), className: "w-full md:w-1/3 border border-blue-400 bg-blue-50 shadow-sm rounded p-2 focus:outline-none focus:ring-2 focus:ring-blue-400 placeholder-gray-500" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
          lineNumber: 123,
          columnNumber: 3
        }, this) }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
          lineNumber: 122,
          columnNumber: 1
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full border border-gray-300", children: [
          /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-200", children: /* @__PURE__ */ jsxDEV("tr", { children: [
            /* @__PURE__ */ jsxDEV("th", { className: "p-2 border", children: "Full Name" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
              lineNumber: 130,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "p-2 border", children: "Student ID" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
              lineNumber: 131,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "p-2 border", children: "Email" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
              lineNumber: 132,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "p-2 border", children: "Degree" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
              lineNumber: 133,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "p-2 border", children: "Department" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
              lineNumber: 134,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "p-2 border", children: "Specialization" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
              lineNumber: 135,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "p-2 border", children: "Year" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
              lineNumber: 136,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "p-2 border", children: "Semester" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
              lineNumber: 137,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("th", { className: "p-2 border", children: "Actions" }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
              lineNumber: 138,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
            lineNumber: 129,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
            lineNumber: 128,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("tbody", { children: filteredStudents.map((s) => /* @__PURE__ */ jsxDEV("tr", { className: "border-b hover:bg-gray-50", children: [
            /* @__PURE__ */ jsxDEV("td", { className: "p-2 border", children: s.fullName }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
              lineNumber: 143,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "p-2 border", children: s.studentId }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
              lineNumber: 144,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "p-2 border", children: s.email }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
              lineNumber: 145,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "p-2 border", children: s.degreeProgram }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
              lineNumber: 146,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "p-2 border", children: s.department }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
              lineNumber: 147,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "p-2 border", children: s.academicInfo?.specialization }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
              lineNumber: 148,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "p-2 border", children: s.academicInfo?.year }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
              lineNumber: 149,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "p-2 border", children: s.academicInfo?.semester }, void 0, false, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
              lineNumber: 150,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("td", { className: "p-2 border space-x-2", children: [
              /* @__PURE__ */ jsxDEV("button", { onClick: () => navigate(`/profile/${s._id}`), className: "bg-[#3B82F6] text-white px-2 py-1 rounded text-sm hover:bg-blue-700 transition", children: "View Profile" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
                lineNumber: 152,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("button", { onClick: () => openSuspendModal(s), className: "bg-textSecondary text-white px-2 py-1 rounded text-sm hover:bg-red-600 transition", children: "Suspend" }, void 0, false, {
                fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
                lineNumber: 155,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
              lineNumber: 151,
              columnNumber: 21
            }, this)
          ] }, s._id, true, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
            lineNumber: 142,
            columnNumber: 44
          }, this)) }, void 0, false, {
            fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
            lineNumber: 141,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
          lineNumber: 127,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
          lineNumber: 126,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
        lineNumber: 117,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
      lineNumber: 77,
      columnNumber: 7
    }, this),
    showSuspendModal && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 flex items-center justify-center bg-black bg-opacity-40 z-50", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-6 rounded-xl shadow-lg w-96", children: [
      /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-bold mb-4 text-[#EF4444]", children: "Suspend Student" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
        lineNumber: 169,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "mb-2", children: [
        "You are suspending: ",
        /* @__PURE__ */ jsxDEV("strong", { children: selectedStudent.fullName }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
          lineNumber: 171,
          columnNumber: 35
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
        lineNumber: 170,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium mb-1", children: "Reason" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
        lineNumber: 174,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("select", { className: "w-full border rounded p-2 mb-2 focus:outline-none focus:ring-2 focus:ring-[#3B82F6]", value: reason, onChange: (e) => setReason(e.target.value), children: [
        /* @__PURE__ */ jsxDEV("option", { value: "", children: "-- Select Reason --" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
          lineNumber: 176,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("option", { value: "Violation of rules", children: "Violation of rules" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
          lineNumber: 177,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("option", { value: "Attendance issue", children: "Attendance issue" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
          lineNumber: 178,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("option", { value: "Plagiarism / Academic misconduct", children: "Plagiarism / Academic misconduct" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
          lineNumber: 179,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("option", { value: "Other", children: "Other" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
          lineNumber: 180,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
        lineNumber: 175,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium mb-1", children: "Additional Comments" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
        lineNumber: 183,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("textarea", { className: "w-full border rounded p-2 mb-2 focus:outline-none focus:ring-2 focus:ring-[#3B82F6]", rows: 3, value: additionalComments, onChange: (e) => setAdditionalComments(e.target.value), placeholder: "Provide additional context (min 5 characters)" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
        lineNumber: 184,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium mb-1", children: "Suspension Date" }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
        lineNumber: 186,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "date",
          className: "w-full border rounded p-2 mb-2 focus:outline-none focus:ring-2 focus:ring-[#3B82F6]",
          value: suspendDate,
          onChange: (e) => setSuspendDate(e.target.value),
          min: (/* @__PURE__ */ new Date()).toISOString().split("T")[0]
        },
        void 0,
        false,
        {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
          lineNumber: 187,
          columnNumber: 13
        },
        this
      ),
      error && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mb-2", children: error }, void 0, false, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
        lineNumber: 190,
        columnNumber: 23
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end gap-2 mt-2", children: [
        /* @__PURE__ */ jsxDEV("button", { onClick: () => setShowSuspendModal(false), className: "px-3 py-1 rounded bg-gray-300 hover:bg-gray-400 transition", children: "Cancel" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
          lineNumber: 193,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("button", { onClick: handleSuspend, className: "px-3 py-1 rounded bg-red-500 text-white hover:bg-red-600 transition", children: "Suspend" }, void 0, false, {
          fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
          lineNumber: 196,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
        lineNumber: 192,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
      lineNumber: 168,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
      lineNumber: 167,
      columnNumber: 28
    }, this)
  ] }, void 0, true, {
    fileName: "F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx",
    lineNumber: 76,
    columnNumber: 10
  }, this);
};
_s(StudentManagement, "KZDsboIdedRhyUzp8y9SYfqCE0w=", false, function() {
  return [useNavigate, useAuth];
});
_c = StudentManagement;
export default StudentManagement;
var _c;
$RefreshReg$(_c, "StudentManagement");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("F:/Y3S2/ITPM project/ProMate--Project-Partner-Finder/frontend/src/pages/Admin/Studentmanagement.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0ZVOzs7Ozs7Ozs7Ozs7Ozs7O0FBL0ZWLE9BQU9BLFNBQVNDLFdBQVdDLFVBQVVDLGNBQWM7QUFDbkQsT0FBT0MsV0FBVztBQUNsQixPQUFPQyxpQkFBaUI7QUFDeEIsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyxtQkFBbUI7QUFFNUIsTUFBTUMsb0JBQW9CQSxNQUFNO0FBQUFDLEtBQUE7QUFFOUIsUUFBTUMsV0FBV0gsWUFBWTtBQUU3QixRQUFNO0FBQUEsSUFBRUk7QUFBQUEsRUFBTSxJQUFJTCxRQUFRO0FBQzFCLFFBQU0sQ0FBQ00sVUFBVUMsV0FBVyxJQUFJWCxTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDWSxrQkFBa0JDLG1CQUFtQixJQUFJYixTQUFTLEtBQUs7QUFDOUQsUUFBTSxDQUFDYyxpQkFBaUJDLGtCQUFrQixJQUFJZixTQUFTLElBQUk7QUFDM0QsUUFBTSxDQUFDZ0IsUUFBUUMsU0FBUyxJQUFJakIsU0FBUyxFQUFFO0FBQ3ZDLFFBQU0sQ0FBQ2tCLG9CQUFvQkMscUJBQXFCLElBQUluQixTQUFTLEVBQUU7QUFDL0QsUUFBTSxDQUFDb0IsYUFBYUMsY0FBYyxJQUFJckIsU0FBUyxFQUFFO0FBQ2pELFFBQU0sQ0FBQ3NCLE9BQU9DLFFBQVEsSUFBSXZCLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUN3QixVQUFVQyxXQUFXLElBQUl6QixTQUFTLEVBQUU7QUFFM0MsUUFBTTBCLFdBQVd6QixPQUFPLElBQUk7QUFFNUIsUUFBTTBCLGdCQUFnQkEsTUFBTTtBQUMxQnpCLFVBQ0cwQixJQUFJLDRDQUE0QztBQUFBLE1BQy9DQyxTQUFTO0FBQUEsUUFBRSxnQkFBZ0JwQjtBQUFBQSxNQUFNO0FBQUEsSUFDbkMsQ0FBQyxFQUNBcUIsS0FBTUMsU0FBUXBCLFlBQVlvQixJQUFJQyxJQUFJLENBQUMsRUFDbkNDLE1BQU9DLFNBQVFDLFFBQVFDLElBQUlGLEdBQUcsQ0FBQztBQUFBLEVBQ3BDO0FBRUFuQyxZQUFVLE1BQU07QUFDZDRCLGtCQUFjO0FBQUEsRUFDaEIsR0FBRyxDQUFDbEIsS0FBSyxDQUFDO0FBRVYsUUFBTTRCLG1CQUFvQkMsYUFBWTtBQUNwQ3ZCLHVCQUFtQnVCLE9BQU87QUFDMUJyQixjQUFVLEVBQUU7QUFDWkUsMEJBQXNCLEVBQUU7QUFDeEJFLG1CQUFlLEVBQUU7QUFDakJFLGFBQVMsRUFBRTtBQUNYVix3QkFBb0IsSUFBSTtBQUFBLEVBQzFCO0FBRUEsUUFBTTBCLGdCQUFnQixZQUFXO0FBQ2pDLFFBQUksQ0FBQ3ZCO0FBQVEsYUFBT08sU0FBUyx5QkFBeUI7QUFDdEQsUUFBSUwsbUJBQW1Cc0IsS0FBSyxFQUFFQyxTQUFTO0FBQ3JDLGFBQU9sQixTQUFTLG9EQUFvRDtBQUN0RSxRQUFJLENBQUNIO0FBQWEsYUFBT0csU0FBUyxrQ0FBa0M7QUFFcEUsUUFBSTtBQUNGLFlBQU1yQixNQUFNd0MsS0FDViwyQ0FBMkM1QixnQkFBZ0I2QixHQUFHLElBQzlEO0FBQUEsUUFDRTNCO0FBQUFBLFFBQ0FFO0FBQUFBLFFBQ0FFO0FBQUFBLE1BQ0YsR0FDQTtBQUFBLFFBQ0VTLFNBQVM7QUFBQSxVQUFFLGdCQUFnQnBCO0FBQUFBLFFBQU07QUFBQSxNQUNuQyxDQUNGO0FBR0FFLGtCQUFhaUMsVUFDWEEsS0FBS0MsT0FBUUMsT0FBTUEsRUFBRUgsUUFBUTdCLGdCQUFnQjZCLEdBQUcsQ0FDbEQ7QUFFQTlCLDBCQUFvQixLQUFLO0FBQ3pCa0MsWUFBTSxpQ0FBaUM7QUFBQSxJQUV6QyxTQUFTYixLQUFLO0FBQ1pDLGNBQVFiLE1BQU1ZLEdBQUc7QUFDakJYLGVBQVMsMkJBQTJCO0FBQUEsSUFDdEM7QUFBQSxFQUNGO0FBRUUsUUFBTXlCLGdCQUFpQkMsUUFBTztBQUM1QkYsVUFBTSxnQ0FBZ0M7QUFBQSxFQUN4QztBQUVBLFFBQU1HLGdCQUFnQkEsTUFBTTtBQUMxQnhCLGFBQVN5QixTQUFTQyxlQUFlO0FBQUEsTUFBRUMsVUFBVTtBQUFBLElBQVMsQ0FBQztBQUFBLEVBQ3pEO0FBR0EsUUFBTUMsbUJBQW1CNUMsU0FBU21DLE9BQVFDLE9BQ3hDQSxFQUFFUyxVQUFVQyxZQUFZLEVBQUVDLFNBQVNqQyxTQUFTZ0MsWUFBWSxDQUFDLENBQzNEO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSwyQkFBQyxTQUFJLFdBQVUseUJBRWI7QUFBQSw2QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSwrQkFBQyxRQUFHLFdBQVUsdUNBQXNDLG9DQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdFO0FBQUEsUUFDeEUsdUJBQUMsWUFDQyxTQUFTTixlQUNULFdBQVUsb0ZBQ1gsOEJBSEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsV0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUE7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSw2RUFDWnhDLG1CQUFTZ0QsSUFBS1osT0FDYix1QkFBQyxTQUVDLFdBQVUsc0dBRVY7QUFBQSwrQkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLGlDQUFDLFFBQUcsV0FBVSxvQ0FBb0NBLFlBQUVhLFlBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZEO0FBQUEsVUFDN0QsdUJBQUMsT0FBRSxXQUFVLHlCQUF3QjtBQUFBO0FBQUEsWUFBS2IsRUFBRVM7QUFBQUEsZUFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0Q7QUFBQSxhQUZ4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSxvQ0FDYjtBQUFBLGlDQUFDLE9BQUU7QUFBQSxtQ0FBQyxZQUFPLHVCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWU7QUFBQSxZQUFTO0FBQUEsWUFBRVQsRUFBRWM7QUFBQUEsZUFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNkM7QUFBQSxVQUM3Qyx1QkFBQyxPQUFFO0FBQUEsbUNBQUMsWUFBTywyQkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtQjtBQUFBLFlBQVM7QUFBQSxZQUFFZCxFQUFFZTtBQUFBQSxlQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4QztBQUFBLFVBQzlDLHVCQUFDLE9BQUU7QUFBQSxtQ0FBQyxZQUFPLCtCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVCO0FBQUEsWUFBUztBQUFBLFlBQUVmLEVBQUVnQixjQUFjQztBQUFBQSxlQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvRTtBQUFBLFVBQ3BFLHVCQUFDLE9BQUU7QUFBQSxtQ0FBQyxZQUFPLHFCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWE7QUFBQSxZQUFTO0FBQUEsWUFBRWpCLEVBQUVnQixjQUFjRTtBQUFBQSxlQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnRDtBQUFBLFVBQ2hELHVCQUFDLE9BQUU7QUFBQSxtQ0FBQyxZQUFPLHlCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlCO0FBQUEsWUFBUztBQUFBLFlBQUVsQixFQUFFZ0IsY0FBY0c7QUFBQUEsZUFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0Q7QUFBQSxhQUwxRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTUE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSw2Q0FDM0I7QUFBQSxpQ0FBQyxZQUNDLFNBQVMsTUFBTXpELFNBQVMsWUFBWXNDLEVBQUVILEdBQUcsRUFBRSxHQUMzQyxXQUFVLDJHQUNYLDRCQUhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxVQUNBLHVCQUFDLFlBQ0MsU0FBUyxNQUFNSyxjQUFjRixFQUFFSCxHQUFHLEdBQ2xDLFdBQVUsMEdBQ1gsdUJBSEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLFVBQ0EsdUJBQUMsWUFDQyxTQUFTLE1BQU1OLGlCQUFpQlMsQ0FBQyxHQUNqQyxXQUFVLDJHQUNYLHVCQUhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxhQWxCWTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBbUJkO0FBQUEsV0FuQ21CQSxFQUFFSCxLQURUO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFxQ0EsQ0FDRCxLQXhDSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBeUNBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLEtBQUtqQixVQUFVLFdBQVUsMkNBQzVCO0FBQUEsK0JBQUMsUUFBRyxXQUFVLHlDQUF3Qyw0QkFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrRTtBQUFBLFFBSTVFLHVCQUFDLFNBQUksV0FBVSx5QkFDYixpQ0FBQyxXQUNDLE1BQUssUUFDTCxhQUFZLDJCQUNaLE9BQU9GLFVBQ1AsVUFBVzBDLE9BQU16QyxZQUFZeUMsRUFBRUMsT0FBT0MsS0FBSyxHQUMzQyxXQUFVLHNKQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLOEosS0FOaEs7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsUUFFVSx1QkFBQyxTQUFJLFdBQVUsbUJBQ2IsaUNBQUMsV0FBTSxXQUFVLHFDQUNmO0FBQUEsaUNBQUMsV0FBTSxXQUFVLGVBQ2YsaUNBQUMsUUFDQztBQUFBLG1DQUFDLFFBQUcsV0FBVSxjQUFhLHlCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvQztBQUFBLFlBQ3BDLHVCQUFDLFFBQUcsV0FBVSxjQUFhLDBCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxQztBQUFBLFlBQ3JDLHVCQUFDLFFBQUcsV0FBVSxjQUFhLHFCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnQztBQUFBLFlBQ2hDLHVCQUFDLFFBQUcsV0FBVSxjQUFhLHNCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpQztBQUFBLFlBQ2pDLHVCQUFDLFFBQUcsV0FBVSxjQUFhLDBCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxQztBQUFBLFlBQ3JDLHVCQUFDLFFBQUcsV0FBVSxjQUFhLDhCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF5QztBQUFBLFlBQ3pDLHVCQUFDLFFBQUcsV0FBVSxjQUFhLG9CQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErQjtBQUFBLFlBQy9CLHVCQUFDLFFBQUcsV0FBVSxjQUFhLHdCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtQztBQUFBLFlBQ25DLHVCQUFDLFFBQUcsV0FBVSxjQUFhLHVCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrQztBQUFBLGVBVHBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVUEsS0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVlBO0FBQUEsVUFDQSx1QkFBQyxXQUNFZCwyQkFBaUJJLElBQUtaLE9BQ3JCLHVCQUFDLFFBQWUsV0FBVSw2QkFDeEI7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsY0FBY0EsWUFBRWEsWUFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUM7QUFBQSxZQUN2Qyx1QkFBQyxRQUFHLFdBQVUsY0FBY2IsWUFBRVMsYUFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0M7QUFBQSxZQUN4Qyx1QkFBQyxRQUFHLFdBQVUsY0FBY1QsWUFBRXVCLFNBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9DO0FBQUEsWUFDcEMsdUJBQUMsUUFBRyxXQUFVLGNBQWN2QixZQUFFYyxpQkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNEM7QUFBQSxZQUM1Qyx1QkFBQyxRQUFHLFdBQVUsY0FBY2QsWUFBRWUsY0FBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUM7QUFBQSxZQUN6Qyx1QkFBQyxRQUFHLFdBQVUsY0FBY2YsWUFBRWdCLGNBQWNDLGtCQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyRDtBQUFBLFlBQzNELHVCQUFDLFFBQUcsV0FBVSxjQUFjakIsWUFBRWdCLGNBQWNFLFFBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlEO0FBQUEsWUFDakQsdUJBQUMsUUFBRyxXQUFVLGNBQWNsQixZQUFFZ0IsY0FBY0csWUFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUQ7QUFBQSxZQUNyRCx1QkFBQyxRQUFHLFdBQVUsd0JBQ1o7QUFBQSxxQ0FBQyxZQUNELFNBQVMsTUFBTXpELFNBQVMsWUFBWXNDLEVBQUVILEdBQUcsRUFBRSxHQUMzQyxXQUFVLGtGQUFpRiw0QkFGM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFJQTtBQUFBLGNBQ0EsdUJBQUMsWUFDQyxTQUFTLE1BQU1OLGlCQUFpQlMsQ0FBQyxHQUNqQyxXQUFVLHFGQUNYLHVCQUhEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBS0E7QUFBQSxpQkFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVlBO0FBQUEsZUFyQk9BLEVBQUVILEtBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFzQkEsQ0FDRCxLQXpCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTBCQTtBQUFBLGFBeENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF5Q0EsS0ExQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTJDQTtBQUFBLFdBMURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEyREE7QUFBQSxTQXBIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBcUhBO0FBQUEsSUFHQy9CLG9CQUNDLHVCQUFDLFNBQUksV0FBVSw4RUFDYixpQ0FBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSw2QkFBQyxRQUFHLFdBQVUseUNBQXdDLCtCQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFFO0FBQUEsTUFDckUsdUJBQUMsT0FBRSxXQUFVLFFBQU87QUFBQTtBQUFBLFFBQ0UsdUJBQUMsWUFBUUUsMEJBQWdCNkMsWUFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrQztBQUFBLFdBRHhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BRUEsdUJBQUMsV0FBTSxXQUFVLGtDQUFpQyxzQkFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3RDtBQUFBLE1BQ3hELHVCQUFDLFlBQ0MsV0FBVSx1RkFDVixPQUFPM0MsUUFDUCxVQUFXa0QsT0FBTWpELFVBQVVpRCxFQUFFQyxPQUFPQyxLQUFLLEdBRXpDO0FBQUEsK0JBQUMsWUFBTyxPQUFNLElBQUcsbUNBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0M7QUFBQSxRQUNwQyx1QkFBQyxZQUFPLE9BQU0sc0JBQXFCLGtDQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFEO0FBQUEsUUFDckQsdUJBQUMsWUFBTyxPQUFNLG9CQUFtQixnQ0FBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRDtBQUFBLFFBQ2pELHVCQUFDLFlBQU8sT0FBTSxvQ0FBbUMsZ0RBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUY7QUFBQSxRQUNqRix1QkFBQyxZQUFPLE9BQU0sU0FBUSxxQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyQjtBQUFBLFdBVDdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFVQTtBQUFBLE1BRUEsdUJBQUMsV0FBTSxXQUFVLGtDQUFpQyxtQ0FBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxRTtBQUFBLE1BQ3JFLHVCQUFDLGNBQ0MsV0FBVSx1RkFDVixNQUFNLEdBQ04sT0FBT2xELG9CQUNQLFVBQVdnRCxPQUFNL0Msc0JBQXNCK0MsRUFBRUMsT0FBT0MsS0FBSyxHQUNyRCxhQUFZLG1EQUxkO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLNkQ7QUFBQSxNQUc3RCx1QkFBQyxXQUFNLFdBQVUsa0NBQWlDLCtCQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlFO0FBQUEsTUFDakU7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNYLE1BQUs7QUFBQSxVQUNMLFdBQVU7QUFBQSxVQUNWLE9BQU9oRDtBQUFBQSxVQUNQLFVBQVc4QyxPQUFNN0MsZUFBZTZDLEVBQUVDLE9BQU9DLEtBQUs7QUFBQSxVQUM5QyxNQUFLLG9CQUFJRSxLQUFLLEdBQUVDLFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBO0FBQUEsUUFMaEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BS21DO0FBQUEsTUFHbENsRCxTQUFTLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkJBLG1CQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdEO0FBQUEsTUFFMUQsdUJBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsK0JBQUMsWUFDQyxTQUFTLE1BQU1ULG9CQUFvQixLQUFLLEdBQ3hDLFdBQVUsOERBQ1gsc0JBSEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsUUFDQSx1QkFBQyxZQUNDLFNBQVMwQixlQUNULFdBQVUsdUVBQ1gsdUJBSEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsV0FaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBYUE7QUFBQSxTQXBERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBcURBLEtBdERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1REE7QUFBQSxPQWpMSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBbUxBO0FBRUo7QUFBRWhDLEdBMVFJRCxtQkFBaUI7QUFBQSxVQUVKRCxhQUVDRCxPQUFPO0FBQUE7QUFBQXFFLEtBSnJCbkU7QUE0UU4sZUFBZUE7QUFBa0IsSUFBQW1FO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwidXNlUmVmIiwiYXhpb3MiLCJBZG1pbk5hdmJhciIsInVzZUF1dGgiLCJ1c2VOYXZpZ2F0ZSIsIlN0dWRlbnRNYW5hZ2VtZW50IiwiX3MiLCJuYXZpZ2F0ZSIsInRva2VuIiwic3R1ZGVudHMiLCJzZXRTdHVkZW50cyIsInNob3dTdXNwZW5kTW9kYWwiLCJzZXRTaG93U3VzcGVuZE1vZGFsIiwic2VsZWN0ZWRTdHVkZW50Iiwic2V0U2VsZWN0ZWRTdHVkZW50IiwicmVhc29uIiwic2V0UmVhc29uIiwiYWRkaXRpb25hbENvbW1lbnRzIiwic2V0QWRkaXRpb25hbENvbW1lbnRzIiwic3VzcGVuZERhdGUiLCJzZXRTdXNwZW5kRGF0ZSIsImVycm9yIiwic2V0RXJyb3IiLCJzZWFyY2hJZCIsInNldFNlYXJjaElkIiwidGFibGVSZWYiLCJmZXRjaFN0dWRlbnRzIiwiZ2V0IiwiaGVhZGVycyIsInRoZW4iLCJyZXMiLCJkYXRhIiwiY2F0Y2giLCJlcnIiLCJjb25zb2xlIiwibG9nIiwib3BlblN1c3BlbmRNb2RhbCIsInN0dWRlbnQiLCJoYW5kbGVTdXNwZW5kIiwidHJpbSIsImxlbmd0aCIsInBvc3QiLCJfaWQiLCJwcmV2IiwiZmlsdGVyIiwicyIsImFsZXJ0IiwidmVyaWZ5U3R1ZGVudCIsImlkIiwic2Nyb2xsVG9UYWJsZSIsImN1cnJlbnQiLCJzY3JvbGxJbnRvVmlldyIsImJlaGF2aW9yIiwiZmlsdGVyZWRTdHVkZW50cyIsInN0dWRlbnRJZCIsInRvTG93ZXJDYXNlIiwiaW5jbHVkZXMiLCJtYXAiLCJmdWxsTmFtZSIsImRlZ3JlZVByb2dyYW0iLCJkZXBhcnRtZW50IiwiYWNhZGVtaWNJbmZvIiwic3BlY2lhbGl6YXRpb24iLCJ5ZWFyIiwic2VtZXN0ZXIiLCJlIiwidGFyZ2V0IiwidmFsdWUiLCJlbWFpbCIsIkRhdGUiLCJ0b0lTT1N0cmluZyIsInNwbGl0IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJTdHVkZW50bWFuYWdlbWVudC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUsIHVzZVJlZiB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgYXhpb3MgZnJvbSBcImF4aW9zXCI7XHJcbmltcG9ydCBBZG1pbk5hdmJhciBmcm9tIFwiLi4vLi4vY29tcG9uZW50cy9BZG1pbk5hdmJhclwiO1xyXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSBcIi4uLy4uL2NvbnRleHQvQXV0aENvbnRleHRcIjtcclxuaW1wb3J0IHsgdXNlTmF2aWdhdGUgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5cclxuY29uc3QgU3R1ZGVudE1hbmFnZW1lbnQgPSAoKSA9PiB7XHJcblxyXG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcclxuXHJcbiAgY29uc3QgeyB0b2tlbiB9ID0gdXNlQXV0aCgpO1xyXG4gIGNvbnN0IFtzdHVkZW50cywgc2V0U3R1ZGVudHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzaG93U3VzcGVuZE1vZGFsLCBzZXRTaG93U3VzcGVuZE1vZGFsXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2VsZWN0ZWRTdHVkZW50LCBzZXRTZWxlY3RlZFN0dWRlbnRdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3JlYXNvbiwgc2V0UmVhc29uXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFthZGRpdGlvbmFsQ29tbWVudHMsIHNldEFkZGl0aW9uYWxDb21tZW50c10gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbc3VzcGVuZERhdGUsIHNldFN1c3BlbmREYXRlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3NlYXJjaElkLCBzZXRTZWFyY2hJZF0gPSB1c2VTdGF0ZShcIlwiKTsgLy8gc2VhcmNoIGlucHV0XHJcblxyXG4gIGNvbnN0IHRhYmxlUmVmID0gdXNlUmVmKG51bGwpO1xyXG5cclxuICBjb25zdCBmZXRjaFN0dWRlbnRzID0gKCkgPT4ge1xyXG4gICAgYXhpb3NcclxuICAgICAgLmdldChcImh0dHA6Ly9sb2NhbGhvc3Q6MzAwMC9hcGkvYWRtaW4vc3R1ZGVudHNcIiwge1xyXG4gICAgICAgIGhlYWRlcnM6IHsgXCJ4LWF1dGgtdG9rZW5cIjogdG9rZW4gfSxcclxuICAgICAgfSlcclxuICAgICAgLnRoZW4oKHJlcykgPT4gc2V0U3R1ZGVudHMocmVzLmRhdGEpKVxyXG4gICAgICAuY2F0Y2goKGVycikgPT4gY29uc29sZS5sb2coZXJyKSk7XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGZldGNoU3R1ZGVudHMoKTtcclxuICB9LCBbdG9rZW5dKTtcclxuXHJcbiAgY29uc3Qgb3BlblN1c3BlbmRNb2RhbCA9IChzdHVkZW50KSA9PiB7XHJcbiAgICBzZXRTZWxlY3RlZFN0dWRlbnQoc3R1ZGVudCk7XHJcbiAgICBzZXRSZWFzb24oXCJcIik7XHJcbiAgICBzZXRBZGRpdGlvbmFsQ29tbWVudHMoXCJcIik7XHJcbiAgICBzZXRTdXNwZW5kRGF0ZShcIlwiKTtcclxuICAgIHNldEVycm9yKFwiXCIpO1xyXG4gICAgc2V0U2hvd1N1c3BlbmRNb2RhbCh0cnVlKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVTdXNwZW5kID0gYXN5bmMoKSA9PiB7XHJcbiAgaWYgKCFyZWFzb24pIHJldHVybiBzZXRFcnJvcihcIlBsZWFzZSBzZWxlY3QgYSByZWFzb24uXCIpO1xyXG4gIGlmIChhZGRpdGlvbmFsQ29tbWVudHMudHJpbSgpLmxlbmd0aCA8IDUpXHJcbiAgICByZXR1cm4gc2V0RXJyb3IoXCJBZGRpdGlvbmFsIGNvbW1lbnRzIG11c3QgYmUgYXQgbGVhc3QgNSBjaGFyYWN0ZXJzLlwiKTtcclxuICBpZiAoIXN1c3BlbmREYXRlKSByZXR1cm4gc2V0RXJyb3IoXCJQbGVhc2Ugc2VsZWN0IGEgc3VzcGVuc2lvbiBkYXRlLlwiKTtcclxuXHJcbiAgdHJ5IHtcclxuICAgIGF3YWl0IGF4aW9zLnBvc3QoXHJcbiAgICAgIGBodHRwOi8vbG9jYWxob3N0OjMwMDAvYXBpL2FkbWluL3N1c3BlbmQvJHtzZWxlY3RlZFN0dWRlbnQuX2lkfWAsXHJcbiAgICAgIHtcclxuICAgICAgICByZWFzb24sXHJcbiAgICAgICAgYWRkaXRpb25hbENvbW1lbnRzLFxyXG4gICAgICAgIHN1c3BlbmREYXRlXHJcbiAgICAgIH0sXHJcbiAgICAgIHtcclxuICAgICAgICBoZWFkZXJzOiB7IFwieC1hdXRoLXRva2VuXCI6IHRva2VuIH1cclxuICAgICAgfVxyXG4gICAgKTtcclxuXHJcbiAgICAvLyDinIUgUmVtb3ZlIHN0dWRlbnQgZnJvbSBVSSBpbW1lZGlhdGVseVxyXG4gICAgc2V0U3R1ZGVudHMoKHByZXYpID0+XHJcbiAgICAgIHByZXYuZmlsdGVyKChzKSA9PiBzLl9pZCAhPT0gc2VsZWN0ZWRTdHVkZW50Ll9pZClcclxuICAgICk7XHJcblxyXG4gICAgc2V0U2hvd1N1c3BlbmRNb2RhbChmYWxzZSk7XHJcbiAgICBhbGVydChcIlN0dWRlbnQgc3VzcGVuZGVkIHN1Y2Nlc3NmdWxseSFcIik7XHJcblxyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgY29uc29sZS5lcnJvcihlcnIpO1xyXG4gICAgc2V0RXJyb3IoXCJGYWlsZWQgdG8gc3VzcGVuZCBzdHVkZW50XCIpO1xyXG4gIH1cclxufTtcclxuXHJcbiAgY29uc3QgdmVyaWZ5U3R1ZGVudCA9IChpZCkgPT4ge1xyXG4gICAgYWxlcnQoXCJTdHVkZW50IHZlcmlmaWVkIChtb2NrIGFjdGlvbilcIik7XHJcbiAgfTtcclxuXHJcbiAgY29uc3Qgc2Nyb2xsVG9UYWJsZSA9ICgpID0+IHtcclxuICAgIHRhYmxlUmVmLmN1cnJlbnQ/LnNjcm9sbEludG9WaWV3KHsgYmVoYXZpb3I6IFwic21vb3RoXCIgfSk7XHJcbiAgfTtcclxuXHJcbiAgLy8gRmlsdGVyIHN0dWRlbnRzIGJ5IHN0dWRlbnQgSURcclxuICBjb25zdCBmaWx0ZXJlZFN0dWRlbnRzID0gc3R1ZGVudHMuZmlsdGVyKChzKSA9PlxyXG4gICAgcy5zdHVkZW50SWQudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzZWFyY2hJZC50b0xvd2VyQ2FzZSgpKVxyXG4gICk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaC1zY3JlZW5cIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgcC02IGJnLXN1cmZhY2VcIj5cclxuICAgICAgICB7LyogSGVhZGVyICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTZcIj5cclxuICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC10ZXh0UHJpbWFyeVwiPk5ldyBVc2VycyDwn5Go4oCN8J+Ok/CfkanigI3wn46TPC9oMT5cclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgb25DbGljaz17c2Nyb2xsVG9UYWJsZX1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctWyMzQjgyRjZdIHRleHQtd2hpdGUgcHgtNCBweS0yIHJvdW5kZWQtbGcgc2hhZG93IGhvdmVyOmJnLWJsdWUtNzAwIHRyYW5zaXRpb25cIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICBWaWV3IEFsbCBVc2Vyc1xyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHsvKiBDYXJkcyBHcmlkICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBtZDpncmlkLWNvbHMtMyBsZzpncmlkLWNvbHMtNCBnYXAtNiBtYi0xMlwiPlxyXG4gICAgICAgICAge3N0dWRlbnRzLm1hcCgocykgPT4gKFxyXG4gICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAga2V5PXtzLl9pZH1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy13aGl0ZSBzaGFkb3ctbWQgcm91bmRlZC14bCBwLTUgYm9yZGVyIGhvdmVyOnNoYWRvdy1sZyB0cmFuc2l0aW9uIHRyYW5zZm9ybSBob3ZlcjotdHJhbnNsYXRlLXktMVwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTNcIj5cclxuICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LVsjM0I4MkY2XVwiPntzLmZ1bGxOYW1lfTwvaDI+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj5JRDoge3Muc3R1ZGVudElkfTwvcD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtWyMzNzQxNTFdIHNwYWNlLXktMVwiPlxyXG4gICAgICAgICAgICAgICAgPHA+PHN0cm9uZz5EZWdyZWU6PC9zdHJvbmc+IHtzLmRlZ3JlZVByb2dyYW19PC9wPlxyXG4gICAgICAgICAgICAgICAgPHA+PHN0cm9uZz5EZXBhcnRtZW50Ojwvc3Ryb25nPiB7cy5kZXBhcnRtZW50fTwvcD5cclxuICAgICAgICAgICAgICAgIDxwPjxzdHJvbmc+U3BlY2lhbGl6YXRpb246PC9zdHJvbmc+IHtzLmFjYWRlbWljSW5mbz8uc3BlY2lhbGl6YXRpb259PC9wPlxyXG4gICAgICAgICAgICAgICAgPHA+PHN0cm9uZz5ZZWFyOjwvc3Ryb25nPiB7cy5hY2FkZW1pY0luZm8/LnllYXJ9PC9wPlxyXG4gICAgICAgICAgICAgICAgPHA+PHN0cm9uZz5TZW1lc3Rlcjo8L3N0cm9uZz4ge3MuYWNhZGVtaWNJbmZvPy5zZW1lc3Rlcn08L3A+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gbXQtNCBnYXAtMiBmbGV4LXdyYXBcIj5cclxuICA8YnV0dG9uXHJcbiAgICBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZShgL3Byb2ZpbGUvJHtzLl9pZH1gKX1cclxuICAgIGNsYXNzTmFtZT1cImZsZXgtMSB0ZXh0LXhzIGJnLVsjM0I4MkY2XSB0ZXh0LXdoaXRlIHB4LTIgcHktMSByb3VuZGVkIGhvdmVyOmJnLWJsdWUtNzAwIHRyYW5zaXRpb24gd2hpdGVzcGFjZS1ub3dyYXBcIlxyXG4gID5cclxuICAgIFZpZXcgUHJvZmlsZVxyXG4gIDwvYnV0dG9uPlxyXG4gIDxidXR0b25cclxuICAgIG9uQ2xpY2s9eygpID0+IHZlcmlmeVN0dWRlbnQocy5faWQpfVxyXG4gICAgY2xhc3NOYW1lPVwiZmxleC0xIHRleHQteHMgYmctc2Vjb25kYXJ5IHRleHQtd2hpdGUgcHgtMiBweS0xIHJvdW5kZWQgaG92ZXI6b3BhY2l0eS05MCB0cmFuc2l0aW9uIHdoaXRlc3BhY2Utbm93cmFwXCJcclxuICA+XHJcbiAgICBWZXJpZnnirZBcclxuICA8L2J1dHRvbj5cclxuICA8YnV0dG9uXHJcbiAgICBvbkNsaWNrPXsoKSA9PiBvcGVuU3VzcGVuZE1vZGFsKHMpfVxyXG4gICAgY2xhc3NOYW1lPVwiZmxleC0xIHRleHQteHMgYmctWyM2QjcyODBdIHRleHQtd2hpdGUgcHgtMiBweS0xIHJvdW5kZWQgaG92ZXI6YmctZ3JheS01MDAgdHJhbnNpdGlvbiB3aGl0ZXNwYWNlLW5vd3JhcFwiXHJcbiAgPlxyXG4gICAgU3VzcGVuZFxyXG4gIDwvYnV0dG9uPlxyXG48L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApKX1cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgey8qIEFsbCBTdHVkZW50cyBUYWJsZSAqL31cclxuICAgICAgICA8ZGl2IHJlZj17dGFibGVSZWZ9IGNsYXNzTmFtZT1cImJnLXdoaXRlIHAtNCByb3VuZGVkLXhsIHNoYWRvdy1tZCBtYi0xMlwiPlxyXG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtWyMxRjI5MzddIG1iLTRcIj5BbGwgU3R1ZGVudHM8L2gyPlxyXG5cclxuICAgICAgICAgIHsvKiBTZWFyY2ggQmFyICovfVxyXG4gICAgICAgICAgey8qIFNlYXJjaCBCYXIgKi99XHJcbjxkaXYgY2xhc3NOYW1lPVwibWItNCBmbGV4IGp1c3RpZnktZW5kXCI+XHJcbiAgPGlucHV0XHJcbiAgICB0eXBlPVwidGV4dFwiXHJcbiAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaCBieSBTdHVkZW50IElELi4uXCJcclxuICAgIHZhbHVlPXtzZWFyY2hJZH1cclxuICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VhcmNoSWQoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgY2xhc3NOYW1lPVwidy1mdWxsIG1kOnctMS8zIGJvcmRlciBib3JkZXItYmx1ZS00MDAgYmctYmx1ZS01MCBzaGFkb3ctc20gcm91bmRlZCBwLTIgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWJsdWUtNDAwIHBsYWNlaG9sZGVyLWdyYXktNTAwXCJcclxuICAvPlxyXG48L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LXgtYXV0b1wiPlxyXG4gICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwibWluLXctZnVsbCBib3JkZXIgYm9yZGVyLWdyYXktMzAwXCI+XHJcbiAgICAgICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cImJnLWdyYXktMjAwXCI+XHJcbiAgICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTIgYm9yZGVyXCI+RnVsbCBOYW1lPC90aD5cclxuICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMiBib3JkZXJcIj5TdHVkZW50IElEPC90aD5cclxuICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMiBib3JkZXJcIj5FbWFpbDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTIgYm9yZGVyXCI+RGVncmVlPC90aD5cclxuICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMiBib3JkZXJcIj5EZXBhcnRtZW50PC90aD5cclxuICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMiBib3JkZXJcIj5TcGVjaWFsaXphdGlvbjwvdGg+XHJcbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTIgYm9yZGVyXCI+WWVhcjwvdGg+XHJcbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTIgYm9yZGVyXCI+U2VtZXN0ZXI8L3RoPlxyXG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0yIGJvcmRlclwiPkFjdGlvbnM8L3RoPlxyXG4gICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICA8L3RoZWFkPlxyXG4gICAgICAgICAgICAgIDx0Ym9keT5cclxuICAgICAgICAgICAgICAgIHtmaWx0ZXJlZFN0dWRlbnRzLm1hcCgocykgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8dHIga2V5PXtzLl9pZH0gY2xhc3NOYW1lPVwiYm9yZGVyLWIgaG92ZXI6YmctZ3JheS01MFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTIgYm9yZGVyXCI+e3MuZnVsbE5hbWV9PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0yIGJvcmRlclwiPntzLnN0dWRlbnRJZH08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTIgYm9yZGVyXCI+e3MuZW1haWx9PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0yIGJvcmRlclwiPntzLmRlZ3JlZVByb2dyYW19PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0yIGJvcmRlclwiPntzLmRlcGFydG1lbnR9PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0yIGJvcmRlclwiPntzLmFjYWRlbWljSW5mbz8uc3BlY2lhbGl6YXRpb259PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0yIGJvcmRlclwiPntzLmFjYWRlbWljSW5mbz8ueWVhcn08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTIgYm9yZGVyXCI+e3MuYWNhZGVtaWNJbmZvPy5zZW1lc3Rlcn08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTIgYm9yZGVyIHNwYWNlLXgtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBcclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG5hdmlnYXRlKGAvcHJvZmlsZS8ke3MuX2lkfWApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctWyMzQjgyRjZdIHRleHQtd2hpdGUgcHgtMiBweS0xIHJvdW5kZWQgdGV4dC1zbSBob3ZlcjpiZy1ibHVlLTcwMCB0cmFuc2l0aW9uXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFZpZXcgUHJvZmlsZVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9wZW5TdXNwZW5kTW9kYWwocyl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXRleHRTZWNvbmRhcnkgdGV4dC13aGl0ZSBweC0yIHB5LTEgcm91bmRlZCB0ZXh0LXNtIGhvdmVyOmJnLXJlZC02MDAgdHJhbnNpdGlvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFN1c3BlbmRcclxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICA8L3Rib2R5PlxyXG4gICAgICAgICAgICA8L3RhYmxlPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgey8qIFN1c3BlbmQgTW9kYWwgKi99XHJcbiAgICAgIHtzaG93U3VzcGVuZE1vZGFsICYmIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmctYmxhY2sgYmctb3BhY2l0eS00MCB6LTUwXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHAtNiByb3VuZGVkLXhsIHNoYWRvdy1sZyB3LTk2XCI+XHJcbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCBtYi00IHRleHQtWyNFRjQ0NDRdXCI+U3VzcGVuZCBTdHVkZW50PC9oMj5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibWItMlwiPlxyXG4gICAgICAgICAgICAgIFlvdSBhcmUgc3VzcGVuZGluZzogPHN0cm9uZz57c2VsZWN0ZWRTdHVkZW50LmZ1bGxOYW1lfTwvc3Ryb25nPlxyXG4gICAgICAgICAgICA8L3A+XHJcblxyXG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSBtYi0xXCI+UmVhc29uPC9sYWJlbD5cclxuICAgICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXIgcm91bmRlZCBwLTIgbWItMiBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctWyMzQjgyRjZdXCJcclxuICAgICAgICAgICAgICB2YWx1ZT17cmVhc29ufVxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0UmVhc29uKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj4tLSBTZWxlY3QgUmVhc29uIC0tPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlZpb2xhdGlvbiBvZiBydWxlc1wiPlZpb2xhdGlvbiBvZiBydWxlczwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJBdHRlbmRhbmNlIGlzc3VlXCI+QXR0ZW5kYW5jZSBpc3N1ZTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJQbGFnaWFyaXNtIC8gQWNhZGVtaWMgbWlzY29uZHVjdFwiPlBsYWdpYXJpc20gLyBBY2FkZW1pYyBtaXNjb25kdWN0PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIk90aGVyXCI+T3RoZXI8L29wdGlvbj5cclxuICAgICAgICAgICAgPC9zZWxlY3Q+XHJcblxyXG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSBtYi0xXCI+QWRkaXRpb25hbCBDb21tZW50czwvbGFiZWw+XHJcbiAgICAgICAgICAgIDx0ZXh0YXJlYVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXIgcm91bmRlZCBwLTIgbWItMiBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctWyMzQjgyRjZdXCJcclxuICAgICAgICAgICAgICByb3dzPXszfVxyXG4gICAgICAgICAgICAgIHZhbHVlPXthZGRpdGlvbmFsQ29tbWVudHN9XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRBZGRpdGlvbmFsQ29tbWVudHMoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiUHJvdmlkZSBhZGRpdGlvbmFsIGNvbnRleHQgKG1pbiA1IGNoYXJhY3RlcnMpXCJcclxuICAgICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIG1iLTFcIj5TdXNwZW5zaW9uIERhdGU8L2xhYmVsPlxyXG4gICAgICAgICAgICA8aW5wdXRcclxuICB0eXBlPVwiZGF0ZVwiXHJcbiAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciByb3VuZGVkIHAtMiBtYi0yIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1bIzNCODJGNl1cIlxyXG4gIHZhbHVlPXtzdXNwZW5kRGF0ZX1cclxuICBvbkNoYW5nZT17KGUpID0+IHNldFN1c3BlbmREYXRlKGUudGFyZ2V0LnZhbHVlKX1cclxuICBtaW49e25ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zcGxpdChcIlRcIilbMF19IC8vIOKchSBQcmV2ZW50IHBhc3QgZGF0ZXNcclxuLz5cclxuXHJcbiAgICAgICAgICAgIHtlcnJvciAmJiA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC1zbSBtYi0yXCI+e2Vycm9yfTwvcD59XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgZ2FwLTIgbXQtMlwiPlxyXG4gICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dTdXNwZW5kTW9kYWwoZmFsc2UpfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMyBweS0xIHJvdW5kZWQgYmctZ3JheS0zMDAgaG92ZXI6YmctZ3JheS00MDAgdHJhbnNpdGlvblwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgQ2FuY2VsXHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlU3VzcGVuZH1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMgcHktMSByb3VuZGVkIGJnLXJlZC01MDAgdGV4dC13aGl0ZSBob3ZlcjpiZy1yZWQtNjAwIHRyYW5zaXRpb25cIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIFN1c3BlbmRcclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBTdHVkZW50TWFuYWdlbWVudDsiXSwiZmlsZSI6IkY6L1kzUzIvSVRQTSBwcm9qZWN0L1Byb01hdGUtLVByb2plY3QtUGFydG5lci1GaW5kZXIvZnJvbnRlbmQvc3JjL3BhZ2VzL0FkbWluL1N0dWRlbnRtYW5hZ2VtZW50LmpzeCJ9